'use strict'
const path = require('path')
const baseURL = process.env.VUE_APP_URL

function resolve(dir) {
  return path.join(__dirname, dir)
}

const CompressionPlugin = require('compression-webpack-plugin')
const CopyWebpackPlugin = require('copy-webpack-plugin')

module.exports = {
  transpileDependencies: ['webpack-dev-server/client'],
  chainWebpack: (config) => {
    config.module.rule('vue').uses.store.delete('cache-loader')
    config.module.rule('js').uses.store.delete('cache-loader')
    config.entry.app = ['babel-polyfill', './src/main.js']
  },

  /**
   * You will need to set publicPath if you plan to deploy your site under a sub path,
   * for example GitHub Pages. If you plan to deploy your site to https://foo.github.io/bar/,
   * then publicPath should be set to "/bar/".
   * In most cases please use '/' !!!
   * Detail: https://cli.vuejs.org/config/#publicpath
   */
  configureWebpack: {
    plugins: process.env.NODE_ENV === 'production' ? [
      new CompressionPlugin({
        algorithm: 'gzip', // 使用gzip压缩
        test: /\.js$|\.css$|\.html$/, // 匹配文件名
        filename: '[path][base].gz', // 压缩后的文件名(保持原文件名，后缀加.gz)
        minRatio: 0.8, // 压缩率小于0.8才会压缩
        threshold: 10240, // 对超过10k的数据压缩
        deleteOriginalAssets: false // 是否删除未压缩的源文件，谨慎设置，如果希望提供非gzip的资源，可不设置或者设置为false（比如删除打包后的gz后还可以加载到原始资源文件）
      }),
      new CopyWebpackPlugin([
        { from: 'node_modules/@easydarwin/easyplayer/dist/component/EasyPlayer.wasm' },
        { from: 'node_modules/@easydarwin/easyplayer/dist/component/crossdomain.xml' },
        { from: 'node_modules/@easydarwin/easyplayer/dist/component/EasyPlayer-lib.min.js', to: 'js/' }
      ])
    ] : [],
    resolve: {
      alias: {
        '@': resolve('src')
      }
    }
  },
  /*  productionGzip: true,
    productionGzipExtensions: ['js', 'css'],*/
  productionSourceMap: false,
  publicPath: './',
  lintOnSave: false,
  devServer: {
    https: false,
    proxy: {
      '/xks': {
        target: baseURL + ':' + process.env.VUE_APP_XKS_PORT,
        changeOrigin: true,
        ws: false
      },
      '/file': {
        target: baseURL + ':' + process.env.VUE_APP_SYS_PORT,
        changeOrigin: true,
        ws: false
      },
      '/smoke': {
        target: baseURL + ':' + process.env.VUE_APP_SMOKE_PORT,
        changeOrigin: true,
        ws: false
      },
      '/common': {
        target: baseURL + ':' + process.env.VUE_APP_COMMON_PORT,
        changeOrigin: true,
        ws: false
      },
      '/water': {
        target: baseURL + ':' + process.env.VUE_APP_WATER_PORT,
        changeOrigin: true,
        ws: false
      },
      '/elec': {
        target: baseURL + ':' + process.env.VUE_APP_ELEC_PORT,
        changeOrigin: true,
        ws: false
      },
      '/switch': {
        target: baseURL + ':' + process.env.VUE_APP_SWITCH_PORT,
        changeOrigin: true,
        ws: false
      },
      '/temp': {
        target: baseURL + ':' + process.env.VUE_APP_TEMP_PORT,
        changeOrigin: true,
        ws: false
      },
      '/xfs': {
        target: baseURL + ':' + process.env.VUE_APP_XFS_PORT,
        changeOrigin: true,
        ws: false
      },
      '/gas': {
        target: baseURL + ':' + process.env.VUE_APP_GAS_PORT,
        changeOrigin: true,
        ws: false
      },
      '/bottle': {
        target: baseURL + ':' + process.env.VUE_APP_BOTTLE_PORT,
        changeOrigin: true,
        ws: false
      },
      '/btn': {
        target: baseURL + ':' + process.env.VUE_APP_BTN_PORT,
        changeOrigin: true,
        ws: false
      },
      '/wx': {
        target: baseURL + ':' + process.env.VUE_APP_SYS_PORT,
        changeOrigin: true,
        ws: false
      },
      '/sys': {
        target: baseURL + ':' + process.env.VUE_APP_SYS_PORT,
        changeOrigin: true,
        ws: false
      },
      '/exam': {
        target: baseURL + ':' + process.env.VUE_APP_EXAM_PORT,
        changeOrigin: true,
        ws: false
      },
      '/monitor': {
        target: baseURL + ':' + process.env.VUE_APP_MONITOR_PORT,
        changeOrigin: true,
        ws: false
      },
      '/newExam': {
        target: baseURL + ':' + process.env.VUE_APP_NEW_EXAM_PORT,
        changeOrigin: true,
        ws: false
      }
    }
  }
}
