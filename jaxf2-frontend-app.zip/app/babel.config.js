module.exports = {
  presets: [
    [
      '@vue/app',
      {
        'useBuiltIns': 'entry',
        polyfills: [
          'es6.promise',
          'es6.symbol',
          'es6.array.iterator',
          'es6.object.assign',
          'es6.let',
          'es6.const',
          'es6.class',
          'es6.function'
        ]
      }
    ]
  ]
}
