import {getLoginUser, login, logout} from '@/api/sys/login'
import {getToken, removeToken, setToken} from '@/utils/auth'
import router, {resetRouter} from '@/router'

const state = {
  id: '',
  token: getToken(),
  name: '',
  avatar: '',
  avatarPath: '',
  introduction: '',
  menus: [],
  permissions: [],
  roles: [],
  application: '',
  adminType: '',
  unitId: '',
  unitName: '',
  unitType: ''
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_INTRODUCTION: (state, introduction) => {
    state.introduction = introduction
  },
  SET_EMAIL: (state, email) => {
    state.email = email
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_ID: (state, id) => {
    state.id = id
  },
  SET_UnitNAME: (state, name) => {
    state.unitName = name
  },
  SET_UnitId: (state, id) => {
    state.unitId = id
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_AVATARPATH: (state, avatarPath) => {
    state.avatarPath = avatarPath
  },
  SET_ROLES: (state, roles) => {
    state.roles = roles
  },
  SET_MENUS: (state, menus) => {
    state.menus = menus
  },
  SET_PERMS: (state, perms) => {
    state.permissions = perms
  },
  SET_APPLICATION: (state, application) => {
    state.application = application
  },
  SET_ADMINTYPE: (state, adminType) => {
    state.adminType = adminType
  },
  SET_UNITTYPE: (state, unitType) => {
    state.unitType = unitType
  }
}

const actions = {
  // user login
  login({commit}, userInfo) {
    const {username, password, openId} = userInfo
    return new Promise((resolve, reject) => {
      const data = {username: username.trim(), password: password, application: 'app', openId: openId}
      if (window.AndroidWebView) {
        data.application = 'app'
      } else {
        data.application = 'wx'
      }
      login(data).then(response => {
        const {data} = response
        commit('SET_TOKEN', data)
        setToken(data)
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  loginByToken({commit}, data) {
    return new Promise((resolve, reject) => {
      commit('SET_TOKEN', data)
      setToken(data)
      resolve()
    })
  },

  // get user info
  getInfo({commit, state}) {
    return new Promise((resolve, reject) => {
      getLoginUser(state.token).then(response => {
        const {data} = response
        if (!data) {
          reject('Verification failed, please Login again.')
        }
        const {permissions, application, menus, id, name, unitName, unitId, avatarPath, email, introduction, adminType, unitType} = data
        // roles must be a non-empty array
        commit('SET_PERMS', permissions)
        commit('SET_APPLICATION', application)
        commit('SET_MENUS', menus)
        commit('SET_ID', id)
        commit('SET_ROLES', ['admin'])
        commit('SET_NAME', name)
        commit('SET_AVATARPATH', avatarPath)
        commit('SET_INTRODUCTION', introduction)
        commit('SET_EMAIL', email)
        commit('SET_UnitNAME', unitName)
        commit('SET_UnitId', unitId)
        commit('SET_ADMINTYPE', adminType)
        commit('SET_UNITTYPE', unitType)
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({commit, state, dispatch}) {
    return new Promise((resolve, reject) => {
      logout(state.token).then((response) => {
        if (response.success) {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          removeToken()
          resetRouter()

          // reset visited views and cached views
          // to fixed https://github.com/PanJiaChen/vue-element-admin/issues/2485
          dispatch('tagsView/delAllViews', null, {root: true})

          resolve(response.data)
        }
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token
  resetToken({commit}) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      commit('SET_ROLES', [])
      removeToken()
      resolve()
    })
  },

  // dynamically modify permissions
  async changeRoles({commit, dispatch}, role) {
    const token = role + '-token'

    commit('SET_TOKEN', token)
    setToken(token)

    const {roles} = await dispatch('getInfo')

    resetRouter()

    // generate accessible routes map based on roles
    const accessRoutes = await dispatch('permission/generateRoutes', roles, {root: true})
    // dynamically add accessible routes
    router.addRoutes(accessRoutes)

    // reset visited views and cached views
    dispatch('tagsView/delAllViews', null, {root: true})
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
