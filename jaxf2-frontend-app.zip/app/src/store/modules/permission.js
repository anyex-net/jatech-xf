import {constantRoutes} from '@/router'
import {getMenuList} from '@/api/system/menuManage'

/**
 * Use meta.role to determine if the current user has permission
 * @param roles
 * @param route
 */
function hasPermission(roles, route) {
  if (route.meta && route.meta.roles) {
    return roles.some(role => route.meta.roles.includes(role))
  } else {
    return true
  }
}

/**
 * Filter asynchronous routing tables by recursion
 * @param routes asyncRoutes
 * @param roles
 */
export function filterAsyncRoutes(routes, index) {
  const res = []
  routes.forEach(route => {
    const tmp = {...route}
    //if (hasPermission(roles, tmp)) {
    if (tmp.children.length !== 0) {
      tmp.children = filterAsyncRoutes(tmp.children, index + 1)
    }
    if (tmp.path != null) {
      tmp.component = (resolve) => require(['@/views' + tmp.path], resolve)
      tmp.meta.index = index;
    }
    res.push(tmp)
    // }
  })
  return res
}


const state = {
  routes: [],
  addRoutes: []
}

const mutations = {
  SET_ROUTES: (state, accessedRoutes, constantRoutes) => {
    state.addRoutes = accessedRoutes
    state.routes = constantRoutes
  }
}

export function getMenuData() {

  return getMenuList({'application': 'app', 'type': '1'}).then((response) => {
    return response.data
  })

}

const actions = {
  async generateRoutes({commit}, menuList) {
    let accessedRoutes
    return new Promise(resolve => {
      accessedRoutes = filterAsyncRoutes(menuList, 0)
      console.log(accessedRoutes, "动态路由")
      commit('SET_ROUTES', accessedRoutes, constantRoutes.concat(accessedRoutes))
      resolve(accessedRoutes)
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
