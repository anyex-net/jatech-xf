import request from '@/utils/request'

const xkspre = '/xks/transmissionInfo';

export function xksTransmissionDeviceList(query, type) {
  if (type === "list") {
    return request({
      url: xkspre + "/list",
      method: 'get',
      params: query
    })
  } else {
    return request({
      url: xkspre + "/page",
      method: 'get',
      params: query
    })
  }
}

export function xksTransmissionGetCode() {
  return request({
    url: xkspre + '/getCode',
    method: 'get',
  })
}

export function xksTransmissionDeviceDetail(id) {
  return request({
    url: xkspre + '/detail/' + id,
    method: 'get',
  })
}

export function addXksTransmissionDevice(data) {
  return request({
    url: xkspre + "/add",
    method: 'post',
    data: data
  })
}

export function updateXksTransmissionDevice(data) {
  return request({
    url: xkspre + "/edit",
    method: 'put',
    data: data
  })
}

export function deleteXksTransmissionDevice(data) {
  return request({
    url: xkspre + "/del",
    method: 'delete',
    data: data
  })
}

export function downloadImportDataExcel(query) {
  return request({
    url: xkspre + "/downloadImportDataExcel",
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function xksTransmissionSetIsPush(data) {
  return request({
    url: xkspre + "/setIsPush",
    method: 'post',
    params: data
  })
}
