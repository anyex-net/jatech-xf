import request from '@/utils/request'

export function list(query) {
  return request({
    url: '/xks/info/list',
    method: 'post',
    params: query
  })
}

export function xksDetail(id) {
  return request({
    url: '/xks/info/detail/' + id,
    method: 'get',
  })
}

const xkspre = '/xks';

export function addXks(data) {
  return request({
    url: xkspre + '/info/add',
    method: 'post',
    data: data
  })
}

export function updateXks(data) {
  return request({
    url: xkspre + '/info/edit',
    method: 'put',
    data: data
  })
}

export function deleteXks(data) {
  return request({
    url: xkspre + '/info/del',
    method: 'delete',
    data: data
  })
}
