import request from '@/utils/request'

const xkspre = '/xks/transmissionInfoControl';

export function xksTransmissionControlPage(query) {
  return request({
    url: xkspre + "/page",
    method: 'get',
    params: query
  })
}

export function xksTransmissionControlDetail(id) {
  return request({
    url: xkspre + '/detail/' + id,
    method: 'get',
  })
}

export function addXksTransmissionControl(data) {
  return request({
    url: xkspre + "/add",
    method: 'post',
    data
  })
}

export function controlXksTransmissionControl(data) {
  return request({
    url: xkspre + "/control",
    method: 'get',
    params: data
  })
}

export function updateXksTransmissionControl(data) {
  return request({
    url: xkspre + "/edit",
    method: 'put',
    data
  })
}

export function deleteXksTransmissionControl(data) {
  return request({
    url: xkspre + "/del",
    method: 'delete',
    data: data
  })
}
