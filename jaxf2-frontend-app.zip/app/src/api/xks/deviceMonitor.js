import request from '@/utils/request'

const xkspre = '/xks/deviceMonitor'

export function xksDeviceMonitorPage(query) {
  return request({
    url: xkspre + '/page',
    method: 'get',
    params: query
  })
}

export function xksDeviceMonitorList(query) {
  return request({
    url: xkspre + '/list',
    method: 'get',
    params: query
  })
}

export function xksDeviceMonitorDetail(id) {
  return request({
    url: xkspre + '/detail/' + id,
    method: 'get'
  })
}

export function addXksDeviceMonitor(data) {
  return request({
    url: xkspre + '/add',
    method: 'post',
    data
  })
}

export function updateXksDeviceMonitor(data) {
  return request({
    url: xkspre + '/edit',
    method: 'put',
    data
  })
}

export function deleteXksDeviceMonitor(data) {
  return request({
    url: xkspre + '/del',
    method: 'delete',
    data: data
  })
}
