import request from '@/utils/request'

export function getCount(query) {
  return request({
    url: '/xks/device/count',
    method: 'get',
    params: query
  })
}

export function getDeviceList(query) {
  return request({
    url: '/xks/device/page',
    method: 'get',
    params: query
  })
}

export function getTypeList(query) {
  return request({
    url: '/xks/device/typeList',
    method: 'get',
    params: query
  })
}

export function getHandle(query) {
  return request({
    url: '/xks/device/handle',
    method: 'get',
    params: query
  })
}

export function getXksInfo(query) {
  return request({
    url: '/xks/info/list',
    method: 'get',
    params: query
  })
}

export function getEventPage(query) {
  return request({
    url: '/xks/event/page',
    method: 'get',
    params: query
  })
}


export function getExamUnit(query) {
  return request({
    url: '/xks/info/getExamUnit',
    method: 'get',
    params: query
  })
}

export function getCurrentScheduleList(query) {
  return request({
    url: '/xks/schedule/getCurrentScheduleList',
    method: 'get',
    params: query
  })
}

export function getAttendanceAndSchedulePage(query) {
  return request({
    url: '/xks/attendance/getAttendanceAndSchedulePage',
    method: 'get',
    params: query
  })
}

export function getAttendanceType(query) {
  return request({
    url: '/xks/attendance/getAttendanceType',
    method: 'get',
    params: query
  })
}

export function getCurrentUserSchedule(query) {
  return request({
    url: '/xks/schedule/getCurrentUserSchedule',
    method: 'get',
    params: query
  })
}

export function getAttendance(query) {
  return request({
    url: '/xks/attendance/attendance',
    method: 'post',
    params: query
  })
}

export function xksDetail(id) {
  return request({
    url: '/xks/info/detail/' + id,
    method: 'get',
  })
}

export function addXks(data) {
  return request({
    url: "/xks/info/add",
    method: 'post',
    data
  })
}

export function updateXks(data) {
  return request({
    url: "/xks/info/edit",
    method: 'put',
    data
  })
}

export function deleteXks(data) {
  return request({
    url: "/xks/info/del",
    method: 'delete',
    data: data
  })
}
