import request from '@/utils/request'


export function deviceCount(query) {
  return request({
    url: '/elec/device/count',
    method: 'get',
    params: query
  })
}

export function devicePage(query) {
  return request({
    url: '/elec/device/page',
    method: 'get',
    params: query
  })
}

export function deviceList(query) {
  return request({
    url: '/elec/device/list',
    method: 'get',
    params: query
  })
}


export function updateElec(data) {
  return request({
    url: '/elec/device/edit',
    method: 'put',
    data
  })
}

export function elecSetIsPush(data) {
  return request({
    url: "/elec/device/setIsPush",
    method: 'post',
    params: data
  })
}
