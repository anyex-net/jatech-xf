const constant = [
  {key: 0, value: "心跳"},
  {key: 1, value: "报警"},
  {key: 4, value: "故障"},
  {key: 32, value: "探头失联"},
  {key: 64, value: "测试报警"},
  {key: 128, value: "低电压报警"},
  {key: 2048, value: "上线"},
  {key: 4096, value: "下线"},
  {key: 16384, value: "拆除报警"},
  {key: 32768, value: "系统消音"},
  {key: 65536, value: "系统消警"},
  {key: 131072, value: "系统复位"}
];

const stateConstant = [
  {key: 0, type: 0, value: "未处理"},
  {key: 1, type: 1, value: "一级推送中"},
  {key: 2, type: 1, value: "一级推送失败"},
  {key: 3, type: 1, value: "一级推送成功"},
  {key: 4, type: 1, value: "二级推送中"},
  {key: 5, type: 1, value: "二级推送失败"},
  {key: 6, type: 1, value: "二级推送成功"},
  {key: 7, type: 1, value: "三级推送中"},
  {key: 8, type: 1, value: "三级推送失败"},
  {key: 9, type: 1, value: "三级推送成功"},
  {key: 10, type: 2, value: "处理中"},
  {key: 11, type: 3, value: "误报"},
  {key: 12, type: 4, value: "确认"},
  {key: 13, type: 3, value: "复位"},
  {key: 14, type: 3, value: "已处理"},
  {key: 15, type: 3, value: "不处理"},
];


const deviceStateOptions = [
  {value: '全部', key: 0},
  {value: '在线', key: 1},
  {value: '离线', key: 2},
  {value: '报警', key: 3},
  {value: '测试报警', key: 4},
  {value: '故障', key: 5},
  {value: '低电压', key: 6},
  {value: '迷宫污染', key: 7},
  {value: '拆除', key: 8},
];

export default {
  eventOptions: constant,
  stateOptions: stateConstant,
  deviceStateOptions: deviceStateOptions,
  deviceTypeId: 128,
  fuwei: "fuwei",
  xiaoyin: "xiaoyin",
  baojing: "baojing",
}
