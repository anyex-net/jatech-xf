import {axios} from '@/utils/request'

const syspre = '/sys'

/**
 * 系统属性监控
 *
 * @author yubaoshan
 * @date 2020/6/8 19:47
 */
export function sysMachineQuery(parameter) {
  return axios({
    url: syspre + '/sysMachine/query',
    method: 'get',
    params: parameter
  })
}
