import request from '@/utils/request'

export function devicePage(query) {
  return request({
    url: '/btn/device/page',
    method: 'get',
    params: query
  })
}

export function deviceCount(query) {
  return request({
    url: '/btn/device/count',
    method: 'get',
    params: query
  })
}

export function btnSetIsPush(data) {
  return request({
    url: "/btn/device/setIsPush",
    method: 'post',
    params: data
  })
}
