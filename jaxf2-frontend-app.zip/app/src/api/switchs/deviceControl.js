import request from '@/utils/request'

const xkspre = '/switch/deviceControl';

export function switchDeviceControlPage(query) {
  return request({
    url: xkspre + "/page",
    method: 'get',
    params: query
  })
}

export function switchDeviceControlDetail(id) {
  return request({
    url: xkspre + '/detail/' + id,
    method: 'get',
  })
}

export function addSwitchDeviceControl(data) {
  return request({
    url: xkspre + "/add",
    method: 'post',
    data
  })
}

export function controlSwitchDeviceControl(data) {
  return request({
    url: xkspre + "/control",
    method: 'get',
    params: data
  })
}

export function updateSwitchDeviceControl(data) {
  return request({
    url: xkspre + "/edit",
    method: 'put',
    data
  })
}

export function deleteSwitchDeviceControl(data) {
  return request({
    url: xkspre + "/del",
    method: 'delete',
    data: data
  })
}
