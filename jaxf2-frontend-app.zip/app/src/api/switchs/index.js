import request from '@/utils/request'

export function devicePage(query) {
  return request({
    url: '/switch/device/page',
    method: 'get',
    params: query
  })
}

export function deviceCount(query) {
  return request({
    url: '/switch/device/count',
    method: 'get',
    params: query
  })
}


export function gatePage(query) {
  return request({
    url: '/switch/gate/page',
    method: 'get',
    params: query
  })
}


export function gateList(query) {
  return request({
    url: '/switch/gate/list',
    method: 'get',
    params: query
  })
}

export function gateDetail(id) {
  return request({
    url: '/switch/gate/detail/' + id,
    method: 'get',
  })
}

export function gateAdd(query) {
  return request({
    url: '/switch/gate/add',
    method: 'post',
    data: query
  })
}

export function deviceAdd(query) {
  return request({
    url: '/switch/device/add',
    method: 'post',
    data: query
  })
}

export function deviceUpdate(query) {
  return request({
    url: '/switch/device/edit',
    method: 'put',
    data: query
  })
}

export function gateUpdate(query) {
  return request({
    url: '/switch/gate/edit',
    method: 'put',
    data: query
  })
}

export function gateDelete(query) {
  return request({
    url: '/switch/gate/del',
    method: 'delete',
    data: query
  })
}

export function deviceDetail(id) {
  return request({
    url: '/switch/device/getDeviceInfo/' + id,
    method: 'get',
  })
}

