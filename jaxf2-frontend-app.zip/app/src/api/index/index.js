import request from '@/utils/request'



export function getDeviceList(query) {
  return request({
    url: '/sys/device/page',
    method: 'get',
    params: query
  })
}