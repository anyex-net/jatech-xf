import request from '@/utils/request'

export function devicePage(query) {
  return request({
    url: '/bottle/device/page',
    method: 'get',
    params: query
  })
}

export function gatePage(query) {
  return request({
    url: '/bottle/gate/page',
    method: 'get',
    params: query
  })
}


export function gateLunxun(query) {
  return request({
    url: '/bottle/gate/lunxun',
    method: 'get',
    params: query
  })
}

export function deviceCount(query) {
  return request({
    url: '/bottle/device/count',
    method: 'get',
    params: query
  })
}

export function gateList(query) {
  return request({
    url: '/bottle/gate/list',
    method: 'get',
    params: query
  })
}

export function gateDetail(id) {
  return request({
    url: '/bottle/gate/detail/' + id,
    method: 'get',
  })
}

export function gateAdd(query) {
  return request({
    url: '/bottle/gate/add',
    method: 'post',
    data: query
  })
}

export function gateUpdate(query) {
  return request({
    url: '/bottle/gate/edit',
    method: 'put',
    data: query
  })
}

export function deviceAdd(query) {
  return request({
    url: '/bottle/device/add',
    method: 'post',
    data: query
  })
}

export function deviceUpdate(query) {
  return request({
    url: '/bottle/device/edit',
    method: 'put',
    data: query
  })
}

export function deviceDetail(id) {
  return request({
    url: '/bottle/device/getDeviceInfo/' + id,
    method: 'get',
  })
}


export function gateDelete(query) {
  return request({
    url: '/bottle/gate/del',
    method: 'delete',
    data: query
  })
}

