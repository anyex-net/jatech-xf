import request from '@/utils/request'

const syspre = '/newExam/area'

export function areaList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}
