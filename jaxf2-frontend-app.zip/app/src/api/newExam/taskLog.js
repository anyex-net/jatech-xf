import request from '@/utils/request'

const syspre = '/newExam/taskLog'

export function taskLogPage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}
export function taskLogInfo(parameter) {
  return request({
    url: syspre + '/getPointInfoAndTables',
    method: 'get',
    params: parameter
  })
}

export function taskLogInfoDetail(id) {
  return request({
    url: syspre + '/getPointInfoAndTables/' + id,
    method: 'get'
  })
}

export function taskLogList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function taskLogDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function taskLogAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function taskLogUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function taskLogUpdateTaskStatus(id) {
  return request({
    url: syspre + '/updateTaskStatus/' + id,
    method: 'put'
  })
}

export function taskLogDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function taskLogExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function endPatrolInspection(data) {
  return request({
    url: syspre + '/endPatrolInspection',
    method: 'post',
    params: data
  })
}

export function automaticPatrolInspection(data) {
  return request({
    url: syspre + '/automaticPatrolInspection',
    method: 'post',
    params: data
  })
}

export function overview(data) {
  return request({
    url: syspre + '/overview',
    method: 'post',
    params: data
  })
}
