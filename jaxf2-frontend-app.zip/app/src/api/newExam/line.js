import request from '@/utils/request'

const syspre = '/newExam/line'

export function lineList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function validatorUser(id) {
  return request({
    url: syspre + '/validatorUser/' + id,
    method: 'get'
  })
}

export function linePage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function linesearch(parameter) {
  return request({
    url: syspre + '/search',
    method: 'get',
    params: parameter
  })
}

export function lineDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function lineAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function lineUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function lineDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function lineExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function getAllPoint(unit_id) {
  return request({
    url: syspre + '/getAllPoint/' + unit_id,
    method: 'get'

  })
}

export function getUsedPoint(line_id) {
  return request({
    url: syspre + '/getUsedPoint/' + line_id,
    method: 'get'

  })
}

export function insertPoint(line_id, point_id) {
  return request({
    url: syspre + '/insertPoint/' + line_id + '/' + point_id,
    method: 'post'

  })
}

export function deletePoint(line_id, point_id) {
  return request({
    url: syspre + '/deletePoint/' + line_id + '/' + point_id,
    method: 'post'

  })
}

export function listAllLine(parameter) {
  return request({
    url: syspre + '/listAllLine/',
    method: 'get',
    params: parameter
  })
}

export function getUser(unit_id) {
  return request({
    url: syspre + '/listUser/' + unit_id,
    method: 'get'

  })
}

export function checkNameValidator(parameter) {
  return request({
    url: syspre + '/validatorName',
    method: 'get',
    params: parameter
  })
}
