import request from '@/utils/request'

const syspre = '/newExam/dangerType'

export function dangerTypePage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function dangerTypeList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function dangerTypeDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function dangerTypeAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function dangerTypeUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function dangerTypeDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

