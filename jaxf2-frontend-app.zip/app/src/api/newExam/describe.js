import request from '@/utils/request'

const syspre = '/newExam/describe'

export function describePage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function describeList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function describeAll(parameter) {
  return request({
    url: syspre + '/all',
    method: 'get',
    params: parameter
  })
}

export function describeDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function describeAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function describeUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function describeDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function describeExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function checkNameValidator(parameter) {
  return request({
    url: syspre + '/validatorName',
    method: 'get',
    params: parameter
  })
}

export function importDemo(data) {
  return request({
    url: syspre + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}

export function importExcel(data) {
  return request({
    url: syspre + '/import',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}
