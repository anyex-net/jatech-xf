import request from '@/utils/request'

const syspre = '/newExam/task'

export function taskPage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function selectTaskPage(parameter) {
  return request({
    url: syspre + '/selectTaskPage',
    method: 'get',
    params: parameter
  })
}

// 查询 未检查的任务
export function taskPageByUnitType(parameter) {
  return request({
    url: syspre + '/pageByUnitType',
    method: 'get',
    params: parameter
  })
}

export function taskList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function taskStatistics(parameter) {
  return request({
    url: syspre + '/statistics',
    method: 'get',
    params: parameter
  })
}

export function taskDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function taskAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function taskUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function taskUpdateById(data) {
  return request({
    url: syspre + '/updateById',
    method: 'put',
    data: data
  })
}

export function taskDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function taskExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function maintenanceTaskCount(parameter) {
  return request({
    url: syspre + '/maintenanceTaskCount',
    method: 'get',
    params: parameter
  })
}

export function patrolTaskCount(parameter) {
  return request({
    url: syspre + '/patrolTaskCount',
    method: 'get',
    params: parameter
  })
}
