import request from '@/utils/request'

const syspre = '/newExam/danger'

export function dangerPage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function dangerList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function dangerDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function dangerAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function dangerSave(data) {
  return request({
    url: syspre + '/save',
    method: 'post',
    data: data
  })
}

export function dangerUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function dangerHandle(data) {
  return request({
    url: syspre + '/handle',
    method: 'post',
    data: data
  })
}

export function dangerDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function hiddenDangersCount(parameter) {
  return request({
    url: syspre + '/hiddenDangersCount',
    method: 'get',
    params: parameter
  })
}
