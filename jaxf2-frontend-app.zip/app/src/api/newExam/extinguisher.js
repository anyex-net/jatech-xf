import request from '@/utils/request'

const URI = '/newExam/extinguisher'

export function extinguisherPage(parameter) {
  return request({
    url: URI + '/page',
    method: 'get',
    params: parameter
  })
}

export function extinguisherList(parameter) {
  return request({
    url: URI + '/list',
    method: 'get',
    params: parameter
  })
}

export function extinguisherDetail(id) {
  return request({
    url: URI + '/detail/' + id,
    method: 'get'
  })
}

export function extinguisherAdd(data) {
  return request({
    url: URI + '/add',
    method: 'post',
    data: data
  })
}

export function extinguisherUpdate(data) {
  return request({
    url: URI + '/edit',
    method: 'put',
    data: data
  })
}

export function extinguisherDel(data) {
  return request({
    url: URI + '/del',
    method: 'delete',
    data: data
  })
}

export function extinguisherImportDemo(data) {
  return request({
    url: URI + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}

export function extinguisherImport(data) {
  return request({
    url: URI + '/import',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}

export function getStatistics(parameter) {
  return request({
    url: URI + '/getStatistics',
    method: 'get',
    params: parameter
  })
}

export function verifyCode(data) {
  return request({
    url: URI + '/verifyCode',
    method: 'post',
    params: data
  })
}

export function getExtinguisherByCode(parameter) {
  return request({
    url: URI + '/getInfoByCode',
    method: 'get',
    params: parameter
  })
}
