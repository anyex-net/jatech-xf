import request from '@/utils/request'

const prefix = '/newExam/extinguisherType'

/**
 * 分页
 * @param params
 * @returns {AxiosPromise}
 */
export function extinguisherType_Page(params) {
  return request({
    url: prefix + '/page',
    method: 'get',
    params: params
  })
}

/**
 * 列表
 * @param params
 * @returns {AxiosPromise}
 */
export function extinguisherType_List(params) {
  return request({
    url: prefix + '/list',
    method: 'get',
    params: params
  })
}

/**
 * 详情
 * @param id
 * @returns {AxiosPromise}
 */
export function extinguisherType_Detail(id) {
  return request({
    url: prefix + '/detail/' + id,
    method: 'get'
  })
}

/**
 * 新增
 * @param data
 * @returns {AxiosPromise}
 */
export function extinguisherType_Add(data) {
  return request({
    url: prefix + '/add',
    method: 'post',
    data: data
  })
}

/**
 * 更新
 * @param data
 * @returns {AxiosPromise}
 */
export function extinguisherType_Update(data) {
  return request({
    url: prefix + '/edit',
    method: 'put',
    data: data
  })
}

/**
 * 删除
 * @param data
 * @returns {AxiosPromise}
 */
export function extinguisherType_Del(data) {
  return request({
    url: prefix + '/del',
    method: 'delete',
    data: data
  })
}

/**
 * 下载导入模板
 * @returns {AxiosPromise}
 */
export function extinguisherType_DownloadImportDemo() {
  return request({
    url: prefix + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}

/**
 * 导入
 * @param data
 * @returns {AxiosPromise}
 */
export function extinguisherType_Import(data) {
  return request({
    url: prefix + '/import',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}

/**
 * 导出
 * @param params
 * @returns {AxiosPromise}
 */
export function extinguisherType_Export(params) {
  return request({
    url: prefix + '/export',
    method: 'get',
    params: params,
    responseType: 'blob'
  })
}
