import request from '@/utils/request'

const syspre = '/newExam/type'

export function typePage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function typeList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function typeAll(parameter) {
  return request({
    url: syspre + '/all',
    method: 'get',
    params: parameter
  })
}

export function typeDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function typeAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function typeUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function typeDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function typeExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function checkNameValidator(parameter) {
  return request({
    url: syspre + '/validatorName',
    method: 'get',
    params: parameter
  })
}

export function importDemo(data) {
  return request({
    url: syspre + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}

export function importExcel(data) {
  return request({
    url: syspre + '/import',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}
