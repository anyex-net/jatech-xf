import sqliteDbUtil from '@/api/offline/sqliteDbUtil'

const sql = {
  selectList: '' +
    '        select *' +
    '        from (select medt.*' +
    '                   , sy.name   createUserName' +
    '                   , su.name   updateUserName' +
    '                   , un.`name` unitName' +
    '              from ms_new_exam_danger_type medt' +
    '                       left join sys_user sy on sy.id = medt.createUser' +
    '                       left join sys_user su on su.id = medt.updateUser' +
    '                       left join sys_unit un on un.id = medt.unitId' +
    '             ) ms_new_exam_danger_type'
}

export default {
  selectList(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.parentId !== null && queryInfo.parentId !== '' && queryInfo.parentId) {
      sqlQuery.where('parentId', '=', queryInfo.parentId)
    }
    return sqliteDbUtil.selectList(sql.selectList, sqlQuery.toString())
  }
}
