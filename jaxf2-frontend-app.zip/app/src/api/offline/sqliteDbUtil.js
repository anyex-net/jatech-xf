let mDbName = 'zhxf'
let mDbLocation = 'default'

import SnowflakeId from 'snowflake-id'
const snowflake = new SnowflakeId()

export default {
  setDatabase(dbName, dbLocation) {
    if (dbName !== null && dbName !== '') {
      mDbName = dbName
    }
    if (dbLocation !== null && dbLocation !== '') {
      mDbLocation = dbLocation
    }
  },
  sqlWhereChain() {
    let whereChain = ''

    function addCondition(key, operator, value) {
      if (whereChain.length > 0) {
        whereChain += ' AND '
      }

      switch (operator) {
        case 'in':
          whereChain += key + ' in (' + value + ')'
          break
        case 'between':
          whereChain += key + ' between "' + value[0] + '" AND ' + '"' + value[1] + '"'
          break
        case 'like':
          whereChain += key + ' like "%' + value + '%"'
          break
        default:
          whereChain += key + ' ' + operator + ' "' + value + '"'
          break
      }
    }

    function otherCondition(key, operator, value) {
      if (whereChain.length > 0) {
        whereChain += ' '
      }
      switch (operator) {
        case 'order by':
          if (whereChain.indexOf('order by') > 1) {
            whereChain += ', ' + key + ' ' + value + ' '
          } else {
            whereChain += operator + ' ' + key + ' ' + value
          }
          break
        case 'group by':
          whereChain += operator + ' ' + key + ' '
          break
        default:
          break
      }
    }

    return {
      where: function(key, operator, value) {
        addCondition(key, operator, value)
        return this
      },
      and: function(key, operator, value) {
        addCondition(key, operator, value)
        return this
      },
      groupBy: function(key) {
        otherCondition(key, 'group by')
        return this
      },
      orderByAsc: function(key) {
        otherCondition(key, 'order by', 'asc')
        return this
      },
      orderByDesc: function(key) {
        otherCondition(key, 'order by', 'desc')
        return this
      },
      toString: function() {
        if (whereChain.length > 0) {
          return ' where ' + whereChain
        } else {
          return whereChain
        }
      }
    }
  },
  sqlUpdateParameterChain() {
    let whereChain = ''

    function addCondition(key, value) {
      if (whereChain.length > 0) {
        whereChain += ', '
      }
      whereChain += key + ' = "' + value + '"'
    }

    return {
      and: function(key, value) {
        addCondition(key, value)
        return this
      },
      toString: function() {
        return whereChain
      }
    }
  },
  sqlUpdateParamChain(value) {
    let whereChain = ''
    const keys = Object.keys(value)
    const values = Object.values(value)
    for (let i = 0; i < keys.length; i++) {
      addCondition(keys[i], values[i])
    }

    function addCondition(key, value) {
      if (whereChain.length > 0) {
        whereChain += ', '
      }
      whereChain += key + ' = "' + value + '"'
    }

    return {
      toString: function() {
        return whereChain
      }
    }
  },

  /**
   * 删除数据库表
   * @param tableName 表名
   */
  dropDbTable(tableName) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(tableName && tableName !== '' && tableName !== null)) {
            reject('drop error: tableName is empty')
          }
          const sql = 'DROP TABLE IF EXISTS ' + tableName + '; '
          db.executeSql(sql, [], function(rs) {
            resolve(rs.rowsAffected)
          },
          function(error) {
            reject('drop error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 创建数据库表
   * @param tableName 表名
   * @param value 对象
   */
  createDbTable(tableName, value) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(tableName && tableName !== '' && tableName !== null)) {
            reject('create error: tableName is empty')
          }
          if (!(value && value !== '' && value !== null)) {
            reject('create error: value is empty')
          }
          const fields = "('" + Object.keys(value).join("' text, '") + "' text);"
          const sql = 'CREATE TABLE IF NOT EXISTS ' + tableName + ' ' + fields
          db.executeSql(sql, [], function(rs) {
            resolve(rs.rowsAffected)
          },
          function(error) {
            reject('create error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 插入数据
   * @param tableName 表名
   * @param value 数据数组
   */
  insert(tableName, value) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(tableName && tableName !== '' && tableName !== null)) {
            reject('insert error:  tableName is empty')
          }
          if (!(value && value !== '' && value !== null)) {
            reject('insert error:  value is empty')
          }
          if (!value.id || value.id === '' || value.id === null) {
            value.id = snowflake.generate()
          }
          const fields = "('" + Object.keys(value).join("','") + "')"
          const sql = 'INSERT INTO ' + tableName + ' ' + fields + " VALUES ('" + Object.values(value).join("','") + "');"
          db.executeSql(sql, [], function(rs) {
            resolve(rs.rowsAffected)
          },
          function(error) {
            reject('insert error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 批量插入数据
   * @param tableName 表名
   * @param value 数据数组
   */
  insertBatch(tableName, value) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(tableName && tableName !== '' && tableName !== null)) {
            reject('insertBatch error:  tableName is empty')
          }
          if (!(value && value !== '' && value !== null && value.length > 0)) {
            reject('insertBatch error:  value is empty')
          }
          const data = value.map(res => {
            if (!res.id || res.id === '' || res.id === null) {
              res.id = snowflake.generate()
            }
            return res
          })
          const fields = "('" + Object.keys(data[0]).join("','") + "')"
          const values = []
          for (let i = 0; i < data.length; i++) {
            values.push(Object.values(data[i]).map(res => { return res ? (Array.isArray(res) ? res.join(',') : res) : 'null' }).join("','"))
          }
          const sql = 'INSERT INTO ' + tableName + ' ' + fields + " VALUES ('" + values.join("'),('") + "');"
          db.executeSql(sql, [], function(rs) {
            resolve(rs.rowsAffected)
          },
          function(error) {
            reject('insert error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 查询总数根据条件
   * @param sql sql语句
   * @param sqlQuery 查询条件
   */
  selectCount(sql, sqlQuery) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(sql && sql !== '' && sql !== null)) {
            reject('select error:  sql is empty')
          }
          if (!(sqlQuery && sqlQuery !== '' && sqlQuery !== null)) {
            reject('select error:  sqlQuery is empty')
          }
          const sqlGrammar = sql + sqlQuery + ' ;'
          db.executeSql(sqlGrammar, [], function(rs) {
            resolve(rs.rows.length)
          },
          function(error) {
            reject('select error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 分页
   * @param sql
   * @param sqlQuery
   * @param pageNo
   * @param pageSize
   */
  selectPageBasis(sql, sqlQuery, pageNo, pageSize) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(sql && sql !== '' && sql !== null)) {
            reject('select error:  sql is empty')
          }
          if (!(sqlQuery && sqlQuery !== '' && sqlQuery !== null)) {
            reject('select error:  sqlQuery is empty')
          }
          if (!(pageNo && pageNo !== '' && pageNo !== null)) {
            reject('select error:  pageNo is empty')
          }
          if (!(pageSize && pageSize !== '' && pageSize !== null)) {
            reject('select error:  pageSize is empty')
          }
          let pageIndex = pageNo - 1
          const numRecords = pageSize
          if (pageIndex < 0) pageIndex = 0
          const offset = numRecords * pageIndex
          const sqlGrammar = sql + sqlQuery + ' limit ' + numRecords + ' offset ' + offset + ' ;'
          db.executeSql(sqlGrammar, [],
            function(rs) {
              const data = []
              for (let i = 0; i < rs.rows.length; i++) {
                data.push(rs.rows.item(i))
              }
              resolve(data)
            },
            function(error) {
              reject('select error: ' + error.message)
              db.close()
            })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 分页查询根据条件
   * @param sql sql语句
   * @param sqlQuery 查询条件
   * @param pageNo 页码
   * @param pageSize 条数
   */
  selectPage(sql, sqlQuery, pageNo, pageSize) {
    return new Promise((resolve, reject) => {
      this.selectPageBasis(sql, sqlQuery, pageNo, pageSize).then(res => {
        this.selectCount(sql, sqlQuery).then(count => {
          const totalPage = count <= pageSize ? pageNo : count / pageSize
          resolve({
            data: {
              rows: res,
              pageNo: pageNo,
              pageSize: pageSize,
              totalPage: totalPage,
              totalRows: count
            }
          })
        })
      })
    })
  },

  /**
   * 查询根据条件
   * @param sql sql语句
   * @param sqlQuery 查询条件
   */
  selectOne(sql, sqlQuery) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(sql && sql !== '' && sql !== null)) {
            reject('select error:  sql is empty')
          }
          if (!(sqlQuery && sqlQuery !== '' && sqlQuery !== null)) {
            reject('select error:  sqlQuery is empty')
          }
          const sqlGrammar = sql + sqlQuery + ' ;'
          db.executeSql(sqlGrammar, [], function(rs) {
            if (rs.rows.length === 0) {
              resolve(null)
            }
            if (rs.rows.length === 1) {
              resolve(rs.rows.item(0))
            }
            if (rs.rows.length > 1) {
              reject('select error: Multiple rows found')
            }
          },
          function(error) {
            reject('select error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 列表查询根据条件
   * @param sql sql语句
   * @param sqlQuery 查询条件
   */
  selectList(sql, sqlQuery) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(sql && sql !== '' && sql !== null)) {
            reject('select error:  sql is empty')
          }
          if (!(sqlQuery && sqlQuery !== '' && sqlQuery !== null)) {
            reject('select error:  sqlQuery is empty')
          }
          const sqlGrammar = sql + sqlQuery + ' ;'
          db.executeSql(sqlGrammar, [], function(rs) {
            const data = []
            for (let i = 0; i < rs.rows.length; i++) {
              data.push(rs.rows.item(i))
            }
            resolve(data)
          },
          function(error) {
            reject('select error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 更新
   * @param tableName 表名
   * @param parameters 更新字段
   * @param sqlQuery 条件
   */
  update(tableName, parameters, sqlQuery) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(tableName && tableName !== '' && tableName !== null)) {
            reject('update error:  tableName is empty')
          }
          if (!(parameters && parameters !== '' && parameters !== null)) {
            reject('update error:  parameters is empty')
          }
          if (!(sqlQuery && sqlQuery !== '' && sqlQuery !== null)) {
            reject('update error:  sqlQuery is empty')
          }
          const sqlGrammar = 'update ' + tableName + ' set ' + parameters + sqlQuery + ' ;'
          db.executeSql(sqlGrammar, [], function(rs) {
            resolve(rs.rowsAffected)
          },
          function(error) {
            reject('update error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  },

  /**
   * 删除
   * @param tableName
   * @param sqlQuery
   * @returns {Promise<unknown>}
   */
  delete(tableName, sqlQuery) {
    return new Promise((resolve, reject) => {
      const db = window.sqlitePlugin.openDatabase(
        {
          name: mDbName,
          location: mDbLocation
        },
        function() {
          if (!(tableName && tableName !== '' && tableName !== null)) {
            reject('delete error:  tableName is empty')
          }
          if (!(sqlQuery && sqlQuery !== '' && sqlQuery !== null)) {
            reject('delete error:  sqlQuery is empty')
          }
          const sqlGrammar = 'delete from ' + tableName + sqlQuery + ' ;'
          db.executeSql(sqlGrammar, [], function(rs) {
            resolve(rs.rowsAffected)
          },
          function(error) {
            reject('delete error: ' + error.message)
            db.close()
          })
        },
        function(error) {
          reject('open db fail: ' + error)
        })
    })
  }

}
