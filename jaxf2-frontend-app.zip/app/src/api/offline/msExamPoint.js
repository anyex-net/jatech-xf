import sqliteDbUtil from '@/api/offline/sqliteDbUtil'

/**
 * SQL
 * @type {{selectPage: string}}
 */
const sql = {
  selectPage: '' +
    '        SELECT *' +
    '        from (SELECT p.*, t.`name` typeName, u.`name` unitName,ms_new_exam_area.name areaName' +
    '              FROM ms_new_exam_point p' +
    '                       LEFT JOIN ms_new_exam_type t ON p.type = t.id' +
    '                       LEFT JOIN sys_unit u ON p.unitId = u.id' +
    '                       left join ms_new_exam_area on ms_new_exam_area.id = p.areaId' +
    '             ) ms_new_exam_point',
  selectList: 'select * from ms_new_exam_point'
}

export default {
  /**
   * 查询分页
   * @param queryInfo
   */
  selectPage(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.name !== null && queryInfo.name !== '' && queryInfo.name) {
      sqlQuery.where('name', 'like', queryInfo.name)
    }
    if (queryInfo.unitId !== null && queryInfo.unitId !== '' && queryInfo.unitId) {
      sqlQuery.and('unitId', '=', queryInfo.unitId)
    }
    if (queryInfo.unitName !== null && queryInfo.unitName !== '' && queryInfo.unitName) {
      sqlQuery.and('unitName', 'like', queryInfo.unitName)
    }
    if (queryInfo.code !== null && queryInfo.code !== '' && queryInfo.code) {
      sqlQuery.and('code', '=', queryInfo.code)
    }
    if (queryInfo.associationType !== null && queryInfo.associationType !== '' && queryInfo.associationType) {
      sqlQuery.and('associationType', '=', queryInfo.associationType)
      if (queryInfo.associationId !== null && queryInfo.associationId !== '' && queryInfo.associationId) {
        sqlQuery.and('associationId', '=', queryInfo.associationId)
      }
      if (queryInfo.associationIds !== null && queryInfo.associationIds !== '' && queryInfo.associationIds) {
        sqlQuery.and('associationIds', 'in', queryInfo.associationIds)
      }
    }
    return sqliteDbUtil.selectPage(sql.selectPage, sqlQuery.toString(), queryInfo.pageNo, queryInfo.pageSize)
  },
  /**
   * 根据code和单位获取点位信息
   * @param queryInfo
   */
  getInfoByCodeAndUnitId(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.unitId !== null && queryInfo.unitId !== '' && queryInfo.unitId) {
      sqlQuery.and('unitId', '=', queryInfo.unitId)
    }
    if (queryInfo.unitName !== null && queryInfo.unitName !== '' && queryInfo.unitName) {
      sqlQuery.and('unitName', 'like', queryInfo.unitName)
    }
    if (queryInfo.code !== null && queryInfo.code !== '' && queryInfo.code) {
      sqlQuery.and('code', '=', queryInfo.code)
    }
    return sqliteDbUtil.selectOne(sql.selectPage, sqlQuery)
  }

}
