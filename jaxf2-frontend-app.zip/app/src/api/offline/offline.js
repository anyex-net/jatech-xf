import request from '@/utils/request'

const prefix = '/newExam/offline'

/**
 * 任务下载
 * @param params
 * @returns {AxiosPromise}
 */
export function offlineDownTask(params) {
  return request({
    url: prefix + '/downTask',
    method: 'get',
    params: params
  })
}

/**
 * 任务上传
 * @param data
 * @returns {AxiosPromise}
 */
export function offlineUpdateTask(data) {
  return request({
    url: prefix + '/uploadTask',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}

/**
 * 分页
 * @param params
 * @returns {AxiosPromise}
 */
export function offlinePage(params) {
  return request({
    url: prefix + '/page',
    method: 'get',
    params: params
  })
}

/**
 * 列表
 * @param params
 * @returns {AxiosPromise}
 */
export function offlineList(params) {
  return request({
    url: prefix + '/list',
    method: 'get',
    params: params
  })
}

/**
 * 详情
 * @param id
 * @returns {AxiosPromise}
 */
export function offlineDetail(id) {
  return request({
    url: prefix + '/detail/' + id,
    method: 'get'
  })
}

/**
 * 新增
 * @param data
 * @returns {AxiosPromise}
 */
export function offlineAdd(data) {
  return request({
    url: prefix + '/add',
    method: 'post',
    data: data
  })
}

/**
 * 更新
 * @param data
 * @returns {AxiosPromise}
 */
export function offlineUpdate(data) {
  return request({
    url: prefix + '/edit',
    method: 'put',
    data: data
  })
}

/**
 * 删除
 * @param data
 * @returns {AxiosPromise}
 */
export function offlineDel(data) {
  return request({
    url: prefix + '/del',
    method: 'delete',
    data: data
  })
}

/**
 * 下载导入模板
 * @returns {AxiosPromise}
 */
export function offlineDownloadImportDemo() {
  return request({
    url: prefix + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}

/**
 * 导入
 * @param data
 * @returns {AxiosPromise}
 */
export function offlineImport(data) {
  return request({
    url: prefix + '/import',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}

/**
 * 导出
 * @param params
 * @returns {AxiosPromise}
 */
export function offlineExport(params) {
  return request({
    url: prefix + '/export',
    method: 'get',
    params: params,
    responseType: 'blob'
  })
}
