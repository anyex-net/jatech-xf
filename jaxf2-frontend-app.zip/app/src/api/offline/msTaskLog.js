import sqliteDbUtil from '@/api/offline/sqliteDbUtil'
import { parseTime } from '@/utils'

const sql = {
  selectPage: '' +
    '        select *' +
    '        from (' +
    '                 select mtl.*,ms_new_exam_task.name taskName,' +
    '                        su.name    checkUserName,' +
    '                        mep.position,' +
    '                        mty.`name` typeName,' +
    '                        sys_unit.name unitName,' +
    '                        ms_new_exam_area.name areaName,' +
    '                        ms_new_task_line.name taskLineName,' +
    '                        mep.`code`' +
    '                 from ms_new_task_log mtl' +
    '                          left join ms_new_exam_task on ms_new_exam_task.id = mtl.taskId' +
    '                          left join ms_new_task_line on ms_new_task_line.id = mtl.taskLineId' +
    '                          left join sys_unit on sys_unit.id = mtl.unitId' +
    '                          left join sys_user su on su.id = mtl.checkUser' +
    '                          left join ms_new_exam_point mep on mep.id = mtl.deviceId' +
    '                          left join ms_new_exam_area ms_new_exam_area on ms_new_exam_area.id = mep.areaId' +
    '                          left join ms_new_exam_type mty on mty.id = mep.type' +
    '             ) ms_new_task_log',
  selectCount: 'select * from ms_new_task_log'
}

export default {
  /**
   * 查询分页
   * @param queryInfo
   */
  selectPage(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.taskLineId !== null && queryInfo.taskLineId !== '' && queryInfo.taskLineId) {
      sqlQuery.where('taskLineId', '=', queryInfo.taskLineId)
    }
    if (queryInfo.taskId !== null && queryInfo.taskId !== '' && queryInfo.taskId) {
      sqlQuery.and('taskId', '=', queryInfo.taskId)
    }
    if (queryInfo.name !== null && queryInfo.name !== '' && queryInfo.name) {
      sqlQuery.and('name', 'like', queryInfo.name)
    }
    if (queryInfo.checkStatus !== null && queryInfo.checkStatus !== '' && queryInfo.checkStatus) {
      sqlQuery.and('checkStatus', '=', queryInfo.checkStatus)
    }
    if (queryInfo.deviceId !== null && queryInfo.deviceId !== '' && queryInfo.deviceId) {
      sqlQuery.and('deviceId', '=', queryInfo.deviceId)
    }
    if (queryInfo.type !== null && queryInfo.type !== '' && queryInfo.type) {
      sqlQuery.and('type', '=', queryInfo.type)
    }
    if (queryInfo.unitId !== null && queryInfo.unitId !== '' && queryInfo.unitId) {
      sqlQuery.and('unitId', '=', queryInfo.unitId)
    }
    return sqliteDbUtil.selectPage(sql.selectPage, sqlQuery, queryInfo.pageNo, queryInfo.pageSize)
  },
  updateTask(id) {
    return new Promise(async(resolve, reject) => {
      let msExamTaskEntity = null
      await sqliteDbUtil.selectOne('select * from ms_new_exam_task',
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', id)
          .toString()
      ).then(res => {
        msExamTaskEntity = res
      }).catch(err => reject(err))
      if (Number(msExamTaskEntity.type) === 0) {
        let count = null
        await sqliteDbUtil.selectCount('select * from ms_new_task_log',
          sqliteDbUtil.sqlWhereChain()
            .where('taskId', '=', id)
            .and('checkStatus', '=', 1)
            .and('type', '=', 0)
            .toString()
        ).then(res => {
          count = res
        }).catch(err => reject(err))
        if (Number(msExamTaskEntity.checkTotal) === Number(count)) {
          msExamTaskEntity.hasCheckTotal = count
          msExamTaskEntity.state = 1
          msExamTaskEntity.checkEndTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
          await sqliteDbUtil.update('ms_new_exam_task',
            sqliteDbUtil.sqlUpdateParamChain(msExamTaskEntity).toString(),
            sqliteDbUtil.sqlWhereChain()
              .where('id', '=', msExamTaskEntity.id)
              .toString()
          ).then(res => {
            resolve(res)
          }).catch(err => reject(err))
        }
      }
      if (Number(msExamTaskEntity.type) === 1) {
        let count = null
        await sqliteDbUtil.selectCount('select * from ms_new_task_line',
          sqliteDbUtil.sqlWhereChain()
            .where('taskId', '=', id)
            .and('state', '=', 1)
            .toString()
        ).then(res => {
          count = res
        }).catch(err => reject(err))
        msExamTaskEntity.hasCheckTotal = count
        if (Number(msExamTaskEntity.checkTotal) === Number(count)) {
          msExamTaskEntity.state = '1'
          msExamTaskEntity.checkEndTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
        }
        await sqliteDbUtil.update('ms_new_exam_task',
          sqliteDbUtil.sqlUpdateParamChain(msExamTaskEntity).toString(),
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', msExamTaskEntity.id)
            .toString()
        ).then(res => {
          resolve(res)
        }).catch(err => reject(err))
      }
    })
  },
  /**
   * 自动巡查
   * @param queryInfo
   */
  automaticPatrolInspection(queryInfo) {
    return new Promise(async(resolve, reject) => {
      const dateTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
      const msTaskLogEntity = {
        sign: queryInfo.sign,
        message: queryInfo.checkDescribe,
        checkUser: queryInfo.userId,
        checkTime: dateTime,
        checkStatus: 1
      }
      await sqliteDbUtil.update('ms_new_task_log',
        sqliteDbUtil.sqlUpdateParamChain(msTaskLogEntity).toString(),
        sqliteDbUtil.sqlWhereChain()
          .where('taskLineId', '=', queryInfo.taskLineId)
          .and('checkStatus', '=', 0)
          .toString()
      ).catch(err => reject(err))
      let count = null
      await sqliteDbUtil.selectCount('select * from ms_new_task_log',
        sqliteDbUtil.sqlWhereChain()
          .where('taskLineId', '=', queryInfo.taskLineId)
          .and('checkStatus', '=', 1)
          .toString()
      ).then(res => {
        count = res
      }).catch(err => reject(err))
      const msTaskLineEntity = {
        sign: queryInfo.sign,
        checkUser: queryInfo.userId,
        checkTime: dateTime,
        hasCheckTotal: count,
        checkDescribe: queryInfo.checkDescribe,
        state: 1
      }
      await sqliteDbUtil.update('ms_new_task_line',
        sqliteDbUtil.sqlUpdateParamChain(msTaskLineEntity).toString(),
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', queryInfo.taskLineId)
          .toString()
      ).then(res => {
        if (res > 0) {
          this.updateTask(queryInfo.taskId).then(res => {
            resolve(res)
          }).catch(err => reject(err))
        }
      }).catch(err => reject(err))
    })
  },
  /**
   * 结束巡查
   * @param queryInfo
   */
  endPatrolInspection(queryInfo) {
    return new Promise(async(resolve, reject) => {
      const dateTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
      const msTaskLogEntity = {
        sign: queryInfo.sign,
        message: queryInfo.checkDescribe,
        checkUser: queryInfo.userId,
        checkTime: dateTime
      }
      await sqliteDbUtil.update('ms_new_task_log',
        sqliteDbUtil.sqlUpdateParamChain(msTaskLogEntity).toString(),
        sqliteDbUtil.sqlWhereChain()
          .where('taskLineId', '=', queryInfo.taskLineId)
          .and('checkStatus', '=', 0)
          .toString()
      ).catch(err => reject(err))
      let count = null
      await sqliteDbUtil.selectCount('select * from ms_new_task_log',
        sqliteDbUtil.sqlWhereChain()
          .where('taskLineId', '=', queryInfo.taskLineId)
          .and('checkStatus', '=', 1)
          .toString()
      ).then(res => {
        count = res
      }).catch(err => reject(err))
      const msTaskLineEntity = {
        sign: queryInfo.sign,
        checkUser: queryInfo.userId,
        checkTime: dateTime,
        hasCheckTotal: count,
        checkDescribe: queryInfo.checkDescribe,
        state: 1
      }
      await sqliteDbUtil.update('ms_new_task_line',
        sqliteDbUtil.sqlUpdateParamChain(msTaskLineEntity).toString(),
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', queryInfo.taskLineId)
          .toString()
      ).then(res => {
        if (res > 0) {
          this.updateTask(queryInfo.taskId).then(res => {
            resolve(res)
          }).catch(err => reject(err))
        }
      }).catch(err => reject(err))
    })
  },
  /**
   * 表格上报获取数据
   * @param queryInfo
   * @returns {Promise<unknown>}
   */
  getPointInfoAndTables(queryInfo) {
    return new Promise(async(resolve, reject) => {
      if (queryInfo.taskId === null || queryInfo.taskId === '') {
        reject('任务ID不能为空')
      }
      if (queryInfo.code === null || queryInfo.code === '') {
        reject('设备码不能为空')
      }
      let taskEntity = null
      await sqliteDbUtil.selectOne('select * from ms_new_exam_task',
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', queryInfo.taskId)
          .toString()
      ).then(res => {
        taskEntity = res
      }).catch(err => reject(err))
      if (taskEntity === null) {
        reject('任务不存在')
      }
      let pointEntity = null
      await sqliteDbUtil.selectOne('select * from ms_new_exam_point',
        sqliteDbUtil.sqlWhereChain()
          .where('code', '=', queryInfo.code)
          .and('unitId', '=', taskEntity.unitId)
          .toString()
      ).then(res => {
        pointEntity = res
      }).catch(err => reject(err))
      if (pointEntity === null) {
        reject('点位不存在')
      }
      const result = new Map()
      if (pointEntity.associationType !== 'null' && pointEntity.associationType !== '') {
        if (pointEntity.associationType === '1') {
          let extinguisherInfo = null
          await sqliteDbUtil.selectOne('select extinguisher_new_info.*, sys_unit.name unitName, extinguisher_new_type.name typeName ' +
            'from extinguisher_new_info ' +
            'left join extinguisher_new_type on extinguisher_new_type.id = extinguisher_new_info.typeId ' +
            'left join sys_unit on sys_unit.id = extinguisher_new_info.unitId ',
          sqliteDbUtil.sqlWhereChain()
            .where('extinguisher_new_info.id', '=', pointEntity.associationId)
            .toString()
          ).then(res => {
            extinguisherInfo = res
          }).catch(err => reject(err))
          result.set('extinguisherInfo', extinguisherInfo)
        }
      }
      if (pointEntity.type !== null && pointEntity.type !== '') {
        let msExamTypeEntity = null
        await sqliteDbUtil.selectOne('select * from ms_new_exam_type',
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', pointEntity.type)
            .toString()
        ).then(res => {
          msExamTypeEntity = res
        }).catch(err => reject(err))
        if (msExamTypeEntity !== null) {
          pointEntity.typeName = msExamTypeEntity.name
        }
      }
      if (pointEntity.areaId !== null && pointEntity.areaId !== '') {
        let msExamAreaEntity = null
        await sqliteDbUtil.selectOne('select * from ms_new_exam_area',
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', pointEntity.areaId)
            .toString()
        ).then(res => {
          msExamAreaEntity = res
        }).catch(err => reject(err))
        if (msExamAreaEntity !== null) {
          pointEntity.areaName = msExamAreaEntity.name
        }
      }
      result.set('pointInfo', pointEntity)
      let tableId = 'null'
      if (Number(taskEntity.type) === 1) {
        if (queryInfo.taskLineId === null) {
          reject('任务线路ID不能为空')
        }
        let logEntity = null
        await sqliteDbUtil.selectOne('select * from ms_new_task_log',
          sqliteDbUtil.sqlWhereChain()
            .where('deviceId', '=', pointEntity.id)
            .and('taskLineId', '=', queryInfo.taskLineId)
            .toString()
        ).then(res => {
          logEntity = res
        }).catch(err => reject(err))
        if (logEntity === null) {
          reject('点位在线路上不存在')
        }
        if (taskEntity.isFill === 'true') {
          tableId = taskEntity.tableId
        }
        if (tableId === 'null') {
          let msExamTypeEntity = null
          await sqliteDbUtil.selectOne('select * from ms_new_exam_type',
            sqliteDbUtil.sqlWhereChain()
              .where('id', '=', pointEntity.type)
              .toString()
          ).then(res => {
            msExamTypeEntity = res
          }).catch(err => reject(err))
          if (msExamTypeEntity === null) {
            reject('类型不存在')
          }
          tableId = msExamTypeEntity.xcTableId
        }
      }
      if (Number(taskEntity.type) === 0) {
        if (taskEntity.isFill === 'true') {
          tableId = taskEntity.tableId
        }
        if (tableId === 'null') {
          let msExamTypeEntity = null
          await sqliteDbUtil.selectOne('select * from ms_new_exam_type',
            sqliteDbUtil.sqlWhereChain()
              .where('id', '=', pointEntity.type)
              .toString()
          ).then(res => {
            msExamTypeEntity = res
          }).catch(err => reject(err))
          if (msExamTypeEntity === null) {
            reject('类型不存在')
          }
          tableId = msExamTypeEntity.wbTableId
        }
      }
      if (tableId !== 'null') {
        let parents = null
        await sqliteDbUtil.selectList('select * from ms_new_exam_table',
          sqliteDbUtil.sqlWhereChain()
            .where('parentId', '=', tableId)
            .toString()
        ).then(res => {
          parents = res
        }).catch(err => reject(err))
        if (parents.length > 0) {
          const parentIds = parents.map(i => i.id)
          if (parentIds.length > 0) {
            let children = null
            await sqliteDbUtil.selectList('select * from ms_new_exam_table',
              sqliteDbUtil.sqlWhereChain()
                .where('parentId', 'in', parentIds)
                .toString()
            ).then(res => {
              children = res
            }).catch(err => reject(err))
            parents.map(i => {
              i.children = children.filter(j => Number(j.parentId) === Number(i.id))
            })
            const tableList = parents.filter(i => i.children.length > 0)
            result.set('tableList', tableList)
          }
        }
      }
      resolve(result)
    })
  },
  /**
   * 获取图片
   * @param id
   * @returns {string}
   */
  async getImgList(id) {
    return await new Promise(async(resolve, reject) => {
      // await sqliteDbUtil.selectList('select fileBucket from sys_file_info',
      //   sqliteDbUtil.sqlWhereChain()
      //     .where('id', '=', id)
      //     .toString()
      // ).then(res => resolve(res))
      //   .catch(err => reject(err))
      resolve([])
    })
  },
  /**
   * 获取详情
   * @param id
   * @returns {Promise<unknown>}
   */
  getPointInfoAndTablesById(id) {
    return new Promise(async(resolve, reject) => {
      let msExamFillingEntities = null
      await sqliteDbUtil.selectList('select * from ms_new_exam_filling',
        sqliteDbUtil.sqlWhereChain()
          .where('taskLogId', '=', id)
          .toString()
      ).then(res => {
        msExamFillingEntities = res
      }).catch(err => reject(err))
      let msTaskLogEntity = null
      await sqliteDbUtil.selectOne('select mtl.*, su.`name` checkUserName ' +
        'from ms_new_task_log mtl ' +
        'left join sys_user su on su.id = mtl.checkUser',
      sqliteDbUtil.sqlWhereChain()
        .where('mtl.id', '=', id)
        .toString()
      ).then(res => {
        msTaskLogEntity = res
      }).catch(err => reject(err))
      const result = new Map()
      const singInfo = {
        signImg: '',
        checkUserName: msTaskLogEntity.checkUserName,
        checkTime: msTaskLogEntity.checkTime
      }
      await this.getImgList(msTaskLogEntity.sign).then(res => {
        singInfo.signImg = res
      })
      result.set('singInfo', singInfo)
      let pointEntity = null
      await sqliteDbUtil.selectOne('select mep.*, mty.`name` typeName ' +
        'from ms_new_exam_point mep ' +
        'left join ms_new_exam_type mty on mty.id = mep.type',
      sqliteDbUtil.sqlWhereChain()
        .where('mep.id', '=', msTaskLogEntity.deviceId)
        .toString()
      ).then(res => {
        pointEntity = res
      }).catch(err => reject(err))
      pointEntity.message = msTaskLogEntity.message
      if (pointEntity.associationType !== 'null' && pointEntity.associationId !== 'null') {
        if (pointEntity.associationType === '1') {
          pointEntity.extinguisherState = msTaskLogEntity.extinguisherState
          await sqliteDbUtil.selectOne('select extinguisher_new_info.*, extinguisher_new_type.name typeName ' +
            'from extinguisher_new_info ' +
            'left join extinguisher_new_type on extinguisher_new_type.id = extinguisher_new_info.typeId',
          sqliteDbUtil.sqlWhereChain()
            .where('extinguisher_new_info.id', '=', pointEntity.associationId)
            .toString()
          ).then(res => {
            pointEntity.extinguisherInfo = res
          }).catch(err => reject(err))
        }
      }
      pointEntity.text = msTaskLogEntity.text
      pointEntity.state = msTaskLogEntity.state
      await this.getImgList(msTaskLogEntity.img).then(res => {
        pointEntity.img = res
      }).catch(err => reject(err))
      result.set('pointInfo', pointEntity)
      const ids = msExamFillingEntities.map(i => i.checkTableItemId)
      if (ids.length === 0) {
        return resolve(result)
      }
      let children = null
      await sqliteDbUtil.selectList('select * from ms_new_exam_table',
        sqliteDbUtil.sqlWhereChain()
          .where('id', 'in', ids)
          .toString()
      ).then(res => {
        children = res
      }).catch(err => reject(err))
      for (let i = 0; i < children.length; i++) {
        const e = children[i]
        const entity = msExamFillingEntities.filter(i => i.checkTableItemId && i.checkTableItemId === e.id)[0]
        if (entity) {
          // 图片
          if (entity.checkImgIds && entity.checkImgIds.length > 0) {
            await this.getImgList(entity.checkImgIds).then(res => {
              e.checkImgIdList = res
            }).catch(err => reject(err))
          }
          if (entity.dangersSolvedImgIds && entity.dangersSolvedImgIds.length > 0) {
            await this.getImgList(entity.dangersSolvedImgIds).then(res => {
              e.dangersSolvedImgIdList = res
            }).catch(err => reject(err))
          }
          e.isSolve = entity.isSolve === 'true'
          e.dangersSolvedDescribe = entity.dangersSolvedDescribe === 'null' ? null : entity.dangersSolvedDescribe
          e.checkDescribe = entity.checkDescribe === 'null' ? null : entity.checkDescribe
        }
        e.checkState = true
      }
      let parents = null
      await sqliteDbUtil.selectList('select * from ms_new_exam_table',
        sqliteDbUtil.sqlWhereChain()
          .where('parentId', '=', msTaskLogEntity.tableId)
          .toString()
      ).then(res => {
        parents = res
      }).catch(err => reject(err))
      if (parents.length > 0) {
        for (let i = 0; i < parents.length; i++) {
          parents[i].children = children.filter(j => j.parentId === parents[i].id)
        }
        const tableList = parents.filter(e => e.children.length > 0)
        result.set('tableList', tableList)
      }
      resolve(result)
    })
  }
}
