import sqliteDbUtil from '@/api/offline/sqliteDbUtil'
import { parseTime } from '@/utils'

const sql = {
  selectList: '' +
    ' select *' +
    ' from (' +
    '          select med.*,' +
    '                 met.`name`    taskName,' +
    '                 mtl.`name`    lineName,' +
    '                 mep.`name`    pointName,' +
    '                 mep.address,' +
    '                 mep.`code`,' +
    '                 medt.`name`   dangerTypeName,' +
    '                 medty.`name`  dangerTypeItemName,' +
    '                 su.name  createName,' +
    '                 syu.name solveName,' +
    '                 sys_unit.name unitName' +
    '          from ms_new_exam_danger med' +
    '                   left join ms_new_exam_point mep on mep.id = med.pointId' +
    '                   left Join ms_new_task_log mtg on mtg.id = med.taskLogId' +
    '                   left join ms_new_task_line mtl on mtl.id = mtg.taskLineId' +
    '                   left join ms_new_exam_task met on met.id = mtl.taskId' +
    '                   left join ms_new_exam_danger_type medt on medt.id = med.dangerTypeParentId' +
    '                   left join ms_new_exam_danger_type medty on medty.id = med.dangerTypeSubId' +
    '                   left join sys_user su on su.id = med.createUser' +
    '                   left join sys_user syu on syu.id = med.solveUser' +
    '                   left join sys_unit on sys_unit.id = med.unitId' +
    '      ) ms_new_exam_danger'
}

export default {
  selectList(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.unitId !== null && queryInfo.unitId !== '' && queryInfo.unitId) {
      sqlQuery.where('unitId', '=', queryInfo.unitId)
    }
    return sqliteDbUtil.selectOne(sql.selectPage, sqlQuery.toString())
  },
  dangerSave(queryInfo) {
    return new Promise(async(resolve, reject) => {
      if (queryInfo.position === null || queryInfo.position === '' && queryInfo.position) {
        reject('设备位置为null')
      }
      if (queryInfo.dangerTypeParentId === null || queryInfo.dangerTypeParentId === '' && queryInfo.dangerTypeParentId) {
        reject('隐患大类为null')
      }
      if (queryInfo.dangerTypeSubId === null || queryInfo.dangerTypeSubId === '' && queryInfo.dangerTypeSubId) {
        reject('隐患小类为null')
      }
      if (queryInfo.dangerTypeMessage === null || queryInfo.dangerTypeMessage === '' && queryInfo.dangerTypeMessage) {
        reject('隐患描述为null')
      }
      const dateTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
      const data = {
        taskLogId: null,
        checkTableItemId: null,
        checkImgIds: queryInfo.checkImgIds,
        isSolve: null,
        dangersSolvedImgIds: null,
        dangersSolvedDescribe: null,
        createUser: queryInfo.userId,
        createTime: dateTime,
        solveUser: null,
        solveTime: null,
        dangerTypeParentId: queryInfo.dangerTypeParentId,
        dangerTypeSubId: queryInfo.dangerTypeSubId,
        dangerTypeMessage: queryInfo.dangerTypeMessage,
        unitId: queryInfo.unitId,
        isFill: false,
        pointId: queryInfo.pointId,
        position: queryInfo.position,
        isDanger: true,
        isExam: false,
        isParts: false,
        assigner: null,
        isReferred: false
      }
      if (queryInfo.isSolve === true) {
        data.solveUser = queryInfo.userId
        data.solveTime = dateTime
        data.dangersSolvedImgIds = queryInfo.dangersSolvedImgIds
        data.dangersSolvedDescribe = queryInfo.dangersSolvedDescribe
      }
      let msTaskLogEntity = null
      await sqliteDbUtil.selectOne('select * from ms_new_task_log',
        sqliteDbUtil.sqlWhereChain()
          .where('taskLineId', '=', queryInfo.taskLineId)
          .and('deviceId', '=', queryInfo.pointId)
          .toString()
      ).then(res => {
        msTaskLogEntity = res
      }).catch(err => reject(err))
      if (msTaskLogEntity !== null) {
        data.taskLogId = msTaskLogEntity.id
      }
      sqliteDbUtil.insert('ms_new_exam_danger', data).then(res => {
        resolve('ok')
      }).catch(err => reject(err))
    })
  }
}
