import sqliteDbUtil from '@/api/offline/sqliteDbUtil'

const sql = {
  selectPage: '' +
    '        select *' +
    '        from (' +
    '                 select ms_new_task_line.*,' +
    '                        sys_user.name checkUserName,' +
    '                        sys_file_info.filePath signImg,' +
    '                        ms_new_exam_task.name taskName,' +
    '                        ms_new_exam_line.userIds userIds' +
    '                 from ms_new_task_line' +
    '                          left join ms_new_exam_line on ms_new_exam_line.id = ms_new_task_line.lineId' +
    '                          left join ms_new_exam_task on ms_new_exam_task.id = ms_new_task_line.taskId' +
    '                          left join sys_user on ms_new_task_line.checkUser = sys_user.id' +
    '                          left join sys_file_info on sys_file_info.id = ms_new_task_line.sign' +
    '             ) ms_new_task_line',
  selectById: '' +
    '        select *' +
    '        from (select ms_new_task_line.*,' +
    '                     sys_user.name checkUserName,' +
    '                     sys_file_info.filePath signImg' +
    '              from ms_new_task_line' +
    '                       left join sys_user on ms_new_task_line.checkUser = sys_user.id' +
    '                       left join sys_file_info on sys_file_info.id = ms_new_task_line.sign' +
    '         ) ms_new_task_line',
  selectCount: 'select * from ms_new_task_line'
}

export default {
  /**
   * 查询分页
   * @param queryInfo
   */
  selectPage(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.taskId !== null && queryInfo.taskId !== '' && queryInfo.taskId) {
      sqlQuery.where('taskId', '=', queryInfo.taskId)
    }
    if (queryInfo.name !== null && queryInfo.name !== '' && queryInfo.name) {
      sqlQuery.and('name', 'like', queryInfo.name)
    }
    if (queryInfo.unitId !== null && queryInfo.unitId !== '' && queryInfo.unitId) {
      sqlQuery.and('unitId', '=', queryInfo.unitId)
    }
    if (queryInfo.state !== null && queryInfo.state !== '' && queryInfo.state) {
      sqlQuery.and('state', '=', queryInfo.state)
    }
    if (queryInfo.id !== null && queryInfo.id !== '' && queryInfo.id) {
      sqlQuery.and('id', '=', queryInfo.id)
    }
    if (queryInfo.lineId !== null && queryInfo.lineId !== '' && queryInfo.lineId) {
      sqlQuery.and('lineId', '=', queryInfo.lineId)
    }
    return sqliteDbUtil.selectPage(sql.selectPage, sqlQuery.toString(), queryInfo.pageNo, queryInfo.pageSize)
  },
  updateById(queryInfo) {
    return sqliteDbUtil.update('ms_new_task_line',
      sqliteDbUtil.sqlUpdateParameterChain()
        .and('checkStartTime', queryInfo.checkStartTime)
        .toString(),
      sqliteDbUtil.sqlWhereChain()
        .where('id', '=', queryInfo.id)
        .toString()
    )
  },
  selectById(id) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (id !== null && id !== '' && id) {
      sqlQuery.where('id', '=', id)
    }
    return sqliteDbUtil.selectOne(sql.selectById, sqlQuery)
  },
  selectCount(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.taskId !== null && queryInfo.taskId !== '' && queryInfo.taskId) {
      sqlQuery.where('taskId', '=', queryInfo.taskId)
    }
    if (queryInfo.state !== null && queryInfo.state !== '' && queryInfo.state) {
      sqlQuery.where('state', '=', queryInfo.state)
    }
    if (queryInfo.checkEndTime !== null && queryInfo.checkEndTime !== '' && queryInfo.checkEndTime) {
      sqlQuery.where('checkEndTime', '=', queryInfo.checkEndTime)
    }
    return sqliteDbUtil.selectCount(sql.selectCount, sqlQuery)
  }
}
