import sqliteDbUtil from '@/api/offline/sqliteDbUtil'
import { parseTime } from '@/utils'

const sql = {
  selectPage: 'select * from ms_new_exam_describe',
  selectList: '' +
    '        select *' +
    '        from (' +
    '                 select de.*, un.`name` unitName, us.`name` createUserName, uss.`name` updateUserName' +
    '                 from ms_new_exam_describe de' +
    '                          left join sys_unit un on un.id = de.unitId' +
    '                          left join sys_user us on us.id = de.createUser' +
    '                          left join sys_user uss on uss.id = de.updateUser' +
    '             ) ms_new_exam_describe'
}

export default {
  selectList(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.unitId !== null && queryInfo.unitId !== '' && queryInfo.unitId) {
      sqlQuery.where('unitId', '=', queryInfo.unitId)
    }
    sqlQuery.orderByDesc('unitId')
    sqlQuery.orderByAsc('sort')
    return sqliteDbUtil.selectList(sql.selectPage, sqlQuery.toString())
  },
  overview(queryInfo) {
    return new Promise(async(resolve, reject) => {
      if (queryInfo.taskLogId === null) {
        reject('任务记录id为null')
      }
      let msTaskLogEntity = null
      await sqliteDbUtil.selectOne('select * from ms_new_task_log',
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', queryInfo.taskLogId)
          .toString()
      ).then(res => {
        msTaskLogEntity = res
      }).catch(err => reject(err))
      if (msTaskLogEntity === null) {
        reject('任务记录不存在')
      }
      if (Number(msTaskLogEntity.checkStatus) === 1) {
        reject('任务记录已完成')
      }
      if (queryInfo.message === null || queryInfo.message === '') {
        reject('情况说明为空')
      }
      msTaskLogEntity.message = queryInfo.message
      msTaskLogEntity.checkStatus = 1
      msTaskLogEntity.checkUser = queryInfo.userId
      msTaskLogEntity.checkTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
      msTaskLogEntity.sign = queryInfo.signId
      await sqliteDbUtil.delete('ms_new_exam_filling',
        sqliteDbUtil.sqlWhereChain()
          .where('taskLogId', '=', msTaskLogEntity.id)
          .toString()
      ).catch(err => reject(err))
      await sqliteDbUtil.delete('ms_new_exam_danger',
        sqliteDbUtil.sqlWhereChain()
          .where('taskLogId', '=', msTaskLogEntity.id)
          .toString()
      ).catch(err => reject(err))
      let msTaskLine = null
      await sqliteDbUtil.selectOne('select * from ms_new_task_line',
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', msTaskLogEntity.taskLineId)
          .toString()
      ).then(res => {
        msTaskLine = res
      }).catch(err => reject(err))
      msTaskLine.hasCheckTotal = 1 + msTaskLine.hasCheckTotal
      await sqliteDbUtil.update('ms_new_task_line',
        sqliteDbUtil.sqlUpdateParamChain(msTaskLine).toString(),
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', msTaskLine.id)
          .toString()
      ).catch(err => reject(err))
      await sqliteDbUtil.update('ms_new_task_log',
        sqliteDbUtil.sqlUpdateParamChain(msTaskLogEntity).toString(),
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', msTaskLogEntity.id)
          .toString()
      ).then(res => {
        resolve('ok')
      }).catch(err => reject(err))
    })
  }
}
