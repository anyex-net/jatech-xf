export default {
  fileDownload(unitId, userId, url, name) {
    return new Promise((resolve, reject) => {
      try {
        resolve(JSON.parse(window.AndroidWebView.remoteFileCreatedPath(unitId, userId, url, name)))
      } catch (err) {
        reject(err)
      }
    })
  },
  fileUpload(userId, token) {
    return new Promise((resolve, reject) => {
      try {
        resolve(JSON.parse(window.AndroidWebView.remoteFileUpload(userId, token)))
      } catch (err) {
        reject(err)
      }
    })
  },
  isNetWorkByAndroid() {
    return new Promise((resolve, reject) => {
      try {
        resolve(JSON.parse(window.AndroidWebView.isNetWork()))
      } catch (err) {
        reject(err)
      }
    })
  }
}
