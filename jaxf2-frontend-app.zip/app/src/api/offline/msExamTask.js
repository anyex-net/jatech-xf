import sqliteDbUtil from '@/api/offline/sqliteDbUtil'

const sql = {
  selectPage: '' +
    '        select *' +
    '        from (' +
    '                 select ms_new_exam_task.*, sys_unit.name unitName, sys_unit.id unitId,sys_user.name checkUserName' +
    '                 from ms_new_exam_task' +
    '                          left join sys_unit on ms_new_exam_task.unitId = sys_unit.id' +
    '                          left join sys_user on sys_user.id = ms_new_exam_task.checkUserId' +
    '             ) ms_new_exam_task'
}

export default {
  /**
   * 查询分页
   * @param queryInfo
   */
  selectPage(queryInfo) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (queryInfo.name !== null && queryInfo.name !== '' && queryInfo.name) {
      sqlQuery.where('name', 'like', queryInfo.name)
    }
    if (queryInfo.unitId !== null && queryInfo.unitId !== '' && queryInfo.unitId) {
      sqlQuery.and('unitId', '=', queryInfo.unitId)
    }
    return sqliteDbUtil.selectPage(sql.selectPage, sqlQuery.toString(), queryInfo.pageNo, queryInfo.pageSize)
  },
  selectById(id) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (id !== null && id !== '') {
      sqlQuery.where('id', '=', id)
    }
    return sqliteDbUtil.selectOne(sql.selectPage, sqlQuery.toString())
  },
  updateById(queryInfo) {
    return sqliteDbUtil.update('ms_new_exam_task',
      sqliteDbUtil.sqlUpdateParameterChain()
        .and('state', queryInfo.state)
        .toString(),
      sqliteDbUtil.sqlWhereChain()
        .where('id', '=', queryInfo.id)
        .toString()
    )
  }

}
