import sqliteDbUtil from '@/api/offline/sqliteDbUtil'

const sql = {
  selectById: 'select * from ms_new_exam_line'
}

export default {
  selectById(id) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (id !== null && id !== '' && id) {
      sqlQuery.where('id', '=', id)
    }
    return sqliteDbUtil.selectOne(sql.selectById, sqlQuery.toString())
  },
  updateById(queryInfo) {
    const data = {
      sign: queryInfo.sign,
      checkUser: queryInfo.checkUser,
      checkTime: queryInfo.checkTime,
      checkDescribe: queryInfo.checkDescribe,
      hasCheckTotal: queryInfo.hasCheckTotal,
      state: queryInfo.state
    }
    return sqliteDbUtil.update('ms_new_exam_line',
      sqliteDbUtil.sqlUpdateParamChain(data).toString(),
      sqliteDbUtil.sqlWhereChain()
        .where('id', '=', queryInfo.id)
        .toString()
    )
  }
}
