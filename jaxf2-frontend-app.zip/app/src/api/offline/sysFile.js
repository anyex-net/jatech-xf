import sqliteDbUtil from '@/api/offline/sqliteDbUtil'

export default {
  save(data) {
    return new Promise((resolve, reject) => {
      try {
        const flag = JSON.parse(window.AndroidWebView.uploadFileImg(data.fileOriginName, data.userId, data.content))
        if (flag) {
          sqliteDbUtil.insert('sys_file_info', { id: data.id, fileOriginName: data.fileOriginName }).then(res => {
            resolve(res > 0)
          }).catch(e => reject(e))
        } else {
          resolve(false)
        }
      } catch (e) {
        reject(e)
      }
    })
  },
  delete(data) {
    return new Promise((resolve, reject) => {
      try {
        const flag = JSON.parse(window.AndroidWebView.deleteUploadFileImg(data.fileOriginName, data.userId))
        if (flag) {
          sqliteDbUtil.delete('sys_file_info', sqliteDbUtil.sqlWhereChain()
            .where('id', '=', data.id)
            .toString()).then(r => {
            resolve(Number(r) === 1)
          }).catch(error => reject(error))
        } else {
          resolve(false)
        }
      } catch (e) {
        reject(e)
      }
    })
  }
}
