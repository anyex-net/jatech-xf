import sqliteDbUtil from '@/api/offline/sqliteDbUtil'
import { parseTime } from '@/utils'

const sql = {
  selectById: '' +
    '        select * from ms_new_exam_filling'
}

export default {
  selectById(id) {
    const sqlQuery = sqliteDbUtil.sqlWhereChain()
    if (id !== null && id !== '' && id) {
      sqlQuery.where('id', '=', id)
    }
    return sqliteDbUtil.selectOne(sql.selectById, sqlQuery.toString())
  },
  /**
   * 表格上报保存
   * @param queryInfo
   * @returns {Promise<unknown>}
   */
  formAdd(queryInfo) {
    return new Promise(async(resolve, reject) => {
      const taskId = queryInfo.taskId
      const deviceId = queryInfo.deviceId
      const taskLineId = queryInfo.taskLineId
      if (taskId === null) {
        reject('任务ID为null')
      }
      if (deviceId === null) {
        reject('点位ID为null')
      }
      let msExamTaskEntity = null
      await sqliteDbUtil.selectOne('select * from ms_new_exam_task',
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', taskId)
          .toString()
      ).then(res => {
        msExamTaskEntity = res
      }).catch(err => reject(err))
      if (msExamTaskEntity === null) {
        reject('任务不存在')
      }
      let msExamPointEntity = null
      await sqliteDbUtil.selectOne('select * from ms_new_exam_point',
        sqliteDbUtil.sqlWhereChain()
          .where('id', '=', deviceId)
          .toString()
      ).then(res => {
        msExamPointEntity = res
      }).catch(err => reject(err))
      if (msExamPointEntity === null) {
        reject('点位不存在')
      }
      const dateTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
      // 巡查 1 维保 0 运营 2
      if (msExamTaskEntity.type === '1') {
        if (taskLineId === null) {
          reject('线路ID为null')
        }
        let taskLineEntity = null
        await sqliteDbUtil.selectOne('select * from ms_new_task_line',
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', taskLineId)
            .toString()
        ).then(res => {
          taskLineEntity = res
        }).catch(err => reject(err))
        if (taskLineEntity === null) {
          reject('线路不存在')
        }
        let msTaskLogEntity = null
        await sqliteDbUtil.selectOne('select * from ms_new_task_log',
          sqliteDbUtil.sqlWhereChain()
            .where('deviceId', '=', deviceId)
            .and('taskLineId', '=', taskLineId)
            .and('taskId', '=', taskId)
            .and('type', '=', 1)
            .toString()
        ).then(res => {
          msTaskLogEntity = res
        }).catch(err => reject(err))
        if (msTaskLogEntity === null) {
          reject('点位任务不存在')
        } else {
          await sqliteDbUtil.delete('ms_new_exam_filling',
            sqliteDbUtil.sqlWhereChain()
              .where('taskLogId', '=', msTaskLogEntity.taskLogId)
              .toString()
          ).catch(err => reject(err))
          await sqliteDbUtil.delete('ms_new_exam_danger',
            sqliteDbUtil.sqlWhereChain()
              .where('taskLogId', '=', msTaskLogEntity.taskLogId)
              .toString()
          ).catch(err => reject(err))
        }
        msTaskLogEntity.sign = queryInfo.signId
        msTaskLogEntity.checkStatus = 1
        msTaskLogEntity.checkTime = dateTime
        msTaskLogEntity.checkUser = queryInfo.userId
        msTaskLogEntity.message = queryInfo.message
        msTaskLogEntity.lng = msExamPointEntity.mapLongitude
        msTaskLogEntity.lat = msExamPointEntity.mapLatitude
        msTaskLogEntity.extinguisherState = queryInfo.extinguisherState
        msTaskLogEntity.text = queryInfo.text
        msTaskLogEntity.state = queryInfo.state
        msTaskLogEntity.img = queryInfo.img
        await sqliteDbUtil.update('ms_new_task_log',
          sqliteDbUtil.sqlUpdateParamChain(msTaskLogEntity).toString(),
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', msTaskLogEntity.id)
            .toString()).catch(err => reject(err))
        let hasCheckCount = null
        await sqliteDbUtil.selectCount('select * from ms_new_task_log',
          sqliteDbUtil.sqlWhereChain()
            .where('taskId', '=', taskId)
            .and('taskLineId', '=', taskLineId)
            .and('checkStatus', '=', 1)
            .toString()
        ).then(res => {
          hasCheckCount = res
        }).catch(err => reject(err))

        // 更新任务线路完成情况
        taskLineEntity.hasCheckTotal = hasCheckCount
        await sqliteDbUtil.update('ms_new_task_line',
          sqliteDbUtil.sqlUpdateParamChain(taskLineEntity).toString(),
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', taskLineEntity.id)
            .toString()
        ).catch(err => reject(err))
        this.fillData(msTaskLogEntity.id, deviceId, msExamPointEntity.position, msExamTaskEntity, queryInfo).then(res => {
          resolve(res)
        }).catch(err => reject(err))
      }
      if (msExamTaskEntity.type === '0') {
        if (msExamTaskEntity.state === '1') {
          reject('任务已结束')
        }
        let msTaskLog = null
        await sqliteDbUtil.selectOne('select * from ms_new_task_log',
          sqliteDbUtil.sqlWhereChain()
            .where('deviceId', '=', deviceId)
            .and('taskId', '=', taskId)
            .and('type', '=', 0)
            .toString()
        ).then(res => {
          msTaskLog = res
        }).catch(err => reject(err))
        if (msTaskLog !== null) {
          await sqliteDbUtil.delete('ms_new_exam_filling',
            sqliteDbUtil.sqlWhereChain()
              .where('taskLogId', '=', msTaskLog.taskLogId)
              .toString()
          ).catch(err => reject(err))
          await sqliteDbUtil.delete('ms_new_exam_danger',
            sqliteDbUtil.sqlWhereChain()
              .where('taskLogId', '=', msTaskLog.taskLogId)
              .toString()
          ).catch(err => reject(err))
        }
        await sqliteDbUtil.delete('ms_new_task_log',
          sqliteDbUtil.sqlWhereChain()
            .where('deviceId', '=', deviceId)
            .and('taskId', '=', taskId)
            .and('type', '=', 0)
            .toString()
        ).catch(err => reject(err))
        const msTaskLogEntity = {
          deviceId: deviceId,
          checkStatus: 1,
          checkTime: dateTime,
          checkUser: queryInfo.userId,
          taskId: taskId,
          message: queryInfo.message,
          type: 0,
          lng: msExamPointEntity.mapLongitude,
          lat: msExamPointEntity.mapLatitude
        }
        if (msExamTaskEntity.tableId !== 'null') {
          msTaskLogEntity.tableId = msExamTaskEntity.tableId
        } else {
          let msTypeEntity = null
          await sqliteDbUtil.selectOne('select * from ms_new_exam_type',
            sqliteDbUtil.sqlWhereChain()
              .where('id', '=', msExamPointEntity.type)
              .toString()
          ).then(res => {
            msTypeEntity = res
          }).catch(err => reject(err))
          if (msTypeEntity !== null) {
            let msTableEntity = null
            await sqliteDbUtil.selectOne('select * from ms_new_exam_table',
              sqliteDbUtil.sqlWhereChain()
                .where('id', '=', msTypeEntity.xcTableId)
                .toString()
            ).then(res => {
              msTableEntity = res
            }).catch(err => reject(err))
            if (msTableEntity !== null) {
              msTaskLogEntity.tableId = msTableEntity.id
            }
          }
        }
        msTaskLogEntity.sign = queryInfo.signId
        msTaskLogEntity.unitId = msExamTaskEntity.unitId
        msTaskLogEntity.name = msExamPointEntity.name
        msTaskLogEntity.extinguisherState = queryInfo.extinguisherState
        msTaskLogEntity.text = queryInfo.text
        msTaskLogEntity.state = queryInfo.state
        msTaskLogEntity.img = queryInfo.img
        await sqliteDbUtil.insert('ms_new_task_log', msTaskLogEntity).catch(err => reject(err))
        await sqliteDbUtil.selectCount('select * from ms_new_task_log',
          sqliteDbUtil.sqlWhereChain()
            .where('taskId', '=', taskId)
            .and('checkStatus', '=', 1)
            .toString()
        ).then(res => {
          msExamTaskEntity.hasCheckTotal = res
        }).catch(err => reject(err))
        await sqliteDbUtil.update('ms_new_exam_task', msExamTaskEntity,
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', msExamTaskEntity.id)
        ).catch(err => reject(err))
        this.fillData(msTaskLogEntity.id, deviceId, msExamPointEntity.position, msExamTaskEntity, queryInfo).then(res => {
          resolve(res)
        }).catch(err => reject(err))
      }
    })
  },
  /**
   * 表格处理
   * @param taskLogId
   * @param pointId
   * @param position
   * @param msExamTaskEntity
   * @param queryInfo
   * @returns {Promise<unknown>}
   */
  fillData(taskLogId, pointId, position, msExamTaskEntity, queryInfo) {
    return new Promise(async(resolve, reject) => {
      const unitId = msExamTaskEntity.unitId
      const fillingEntities = []
      const dangerEntities = []
      if (msExamTaskEntity.isFill === 'true') {
        const checkList = queryInfo.checkboxGroup
        const createTime = parseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
        for (let i = 0; i < checkList.length; i++) {
          if (checkList[i].isSolve === null) {
            checkList[i].isSolve = false
          }
          if (checkList[i].checkIsDanger) {
            const dangerEntity = {
              taskLogId: taskLogId,
              pointId: pointId,
              position: position,
              checkTableItemId: checkList[i].checkTableItemId,
              checkImgIds: checkList[i].checkImgIds,
              dangersSolvedDescribe: checkList[i].dangersSolvedDescribe,
              dangersSolvedImgIds: checkList[i].dangersSolvedImgIds,
              dangerTypeMessage: checkList[i].checkDescribe,
              createTime: createTime,
              isDanger: true,
              createUser: queryInfo.userId,
              isSolve: checkList[i].isSolve,
              unitId: unitId,
              isFill: true,
              isExam: false,
              isParts: false,
              assigner: queryInfo.userId
            }
            let msExamTableEntity = null
            await sqliteDbUtil.selectOne('select * from ms_new_exam_table',
              sqliteDbUtil.sqlWhereChain()
                .where('id', '=', checkList[i].checkTableItemId)
                .toString()
            ).then(res => {
              msExamTableEntity = res
            }).catch(err => reject(err))
            dangerEntity.dangerTypeParentId = msExamTableEntity.dangerTypeParentId
            dangerEntity.dangerTypeSubId = msExamTableEntity.dangerTypeId
            if (checkList[i].isSolve) {
              dangerEntity.solveUser = queryInfo.userId
              dangerEntity.solveTime = createTime
            } else {
              dangerEntity.solveUser = 'null'
              dangerEntity.solveTime = 'null'
            }
            dangerEntities.push(dangerEntity)
          }
          checkList[i].taskLogId = taskLogId
          checkList[i].createTime = createTime
          checkList[i].createUser = queryInfo.userId
          checkList[i].updateTime = createTime
          checkList[i].updateUser = queryInfo.userId
          fillingEntities.push(checkList[i])
        }
      }
      if (fillingEntities.length > 0) {
        await sqliteDbUtil.insertBatch('ms_new_exam_filling', fillingEntities).catch(err => reject(err))
      }
      if (dangerEntities.length > 0) {
        await sqliteDbUtil.insertBatch('ms_new_exam_danger', dangerEntities).catch(err => reject(err))
      }

      // 灭火器报废
      if (queryInfo.extinguisherState === '2') {
        let pointEntity = null
        await sqliteDbUtil.selectOne('select * from ms_new_exam_point',
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', pointId)
            .toString()
        ).then(res => {
          pointEntity = res
        }).catch(err => reject(err))
        await sqliteDbUtil.update('extinguisher_new_info',
          sqliteDbUtil.sqlUpdateParameterChain()
            .and('state', -1)
            .toString(),
          sqliteDbUtil.sqlWhereChain()
            .where('id', '=', pointEntity.associationId)
            .toString()
        ).catch(err => reject(err))
      }
      resolve('ok')
    })
  }
}
