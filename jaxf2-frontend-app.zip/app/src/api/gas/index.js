import request from '@/utils/request'

export function devicePage(query) {
  return request({
    url: '/gas/device/page',
    method: 'get',
    params: query
  })
}

export function deviceCount(query) {
  return request({
    url: '/gas/device/count',
    method: 'get',
    params: query
  })
}

export function gasSetIsPush(data) {
  return request({
    url: "/gas/device/setIsPush",
    method: 'post',
    params: data
  })
}
