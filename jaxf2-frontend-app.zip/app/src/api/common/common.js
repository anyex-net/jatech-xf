import constant from '@/api/common/constant.js'
import request from '@/utils/request'

export function deviceCount(query) {
  return request({
    url: '/sys/device/count',
    method: 'get',
    params: query,
  })
}

export function warnCount(path, params) {
  return request({
    url: path,
    method: 'get',
    params: params
  })
}


export function devicePage(query, type) {
  if (type === 'switchs') type = 'switch'
  if (type === 'water') {
    return request({
      url: '/' + type + '/deviceSensor/page',
      method: 'get',
      params: query,
    })
  } else {
    return request({
      url: '/' + type + '/device/page',
      method: 'get',
      params: query,
    })
  }
}

export function deviceDetail(type, id) {
  if (type === 'switchs') type = 'switch'
  if (type === 'water') {
    return request({
      url: '/' + type + '/deviceSensor/detail/' + id,
      method: 'get',
    })
  } else {
    return request({
      url: '/' + type + '/device/getDeviceInfo/' + id,
      method: 'get',
    })
  }
}

export function deviceIssue(type, data) {
  if (type === 'switchs') type = 'switch'
  if (type === 'water') {
    return request({
      url: '/' + type + '/device/issue',
      method: 'get',
      params: data
    })
  } else {
    return request({
      url: '/' + type + '/device/issue',
      method: 'get',
      params: data
    })
  }
}

export function eventPage(type, query) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/event/page',
    method: 'get',
    params: query,
  })
}

export function eventProcessPage(type, query) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/event/processPage',
    method: 'get',
    params: query,
  })
}

export function eventDetail(type, id) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/event/detail/' + id,
    method: 'get',
  })
}

export function deviceAdd(type, data) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/device/add',
    method: 'post',
    data: data,
  })
}

export function noticeRecordPage(type, query) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + "/noticeRecord/page",
    method: 'get',
    params: query
  })
}

export function deviceEdit(type, data) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/device/edit',
    method: 'put',
    data: data,
  })
}

export function deviceDel(type, data) {
  if (type === 'switchs') type = 'switch'
  if (type === 'water') {
    return request({
      url: '/' + type + '/deviceSensor/del',
      method: 'delete',
      data: data
    })
  } else {
    return request({
      url: '/' + type + '/device/del',
      method: 'delete',
      data: data
    })
  }
}

export function deviceHandle(type, data) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/device/handle',
    method: 'post',
    params: data,
  })
}

export function eventHandle(type, data) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/event/handle',
    method: 'post',
    params: data,
  })
}

export function setIsPush(type, data) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/device/setIsPush',
    method: 'post',
    params: data,
  })
}

export function getDeviceState(item) {
  let warn = '';
  if (item.isWarn === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '报警'
  }
  if (item.isShield === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '屏蔽'
  }
  if (item.isAbnormal === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '异常'
  }
  if (item.isOther === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '其它'
  }
  if (item.isFault === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '故障'
  }
  if (item.isSensorFault === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '污染'
  }
  if (item.isLowVol === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '低电压'
  }
  if (item.isTest === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '测试报警'
  }
  if (item.isOpen === 1) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '拆除'
  }
  if (item.isOnline === 0 || item.isOnline === null) {
    if (warn !== '') warn = warn + ',';
    warn = warn + '离线'
  }
  if (warn === '') warn = '在线'
  return warn
};

export function getDeviceType(deviceType) {
  let value = '';
  constant.deviceTypeOptions.forEach(item => {
    if (item.key === deviceType) {
      value = item.value;
    }
  });
  return value;
};

export function deviceMonitorList(type, data) {
  if (type === 'switchs') type = 'switch'
  return request({
    url: '/' + type + '/deviceMonitor/list',
    method: 'get',
    params: data,
  })
}
