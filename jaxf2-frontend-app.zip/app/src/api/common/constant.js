const deviceTypeOptions = [
  {key: "xks", value: "消控室"},
  {key: "smoke", value: "烟感"},
  {key: "temp", value: "温感"},
  {key: "gas", value: "燃气"},
  {key: "btn", value: "手报"},
  {key: "elec", value: "电气"},
  {key: "water", value: "水系统"},
  {key: "xfs", value: "消防栓"},
  {key: "bottle", value: "气瓶"},
  {key: "switchs", value: "开关量"},
];

const eventTypeOptions = [
  {key: 0, value: "心跳"},
  {key: 1, value: "报警"},
  {key: 4, value: "故障"},
  {key: 8, value: "异常"},
  {key: 32, value: "探头失联"},
  {key: 64, value: "测试报警"},
  {key: 128, value: "低电压报警"},
  {key: 2048, value: "上线"},
  {key: 4096, value: "下线"},
  {key: 16384, value: "拆除报警"},
  {key: 32768, value: "系统消音"},
  {key: 65536, value: "系统消警"},
  {key: 131072, value: "系统复位"}
];

const xksDeviceStateOptions = [
  {key: '1', value: "报警"},
  {key: '3', value: "故障"},
  {key: '4', value: "屏蔽"},
  {key: '0,5', value: "其它"}
];

const deviceStateOptions = [
  {label: "全部状态", value: "0"},
  {label: "报警", value: "3"},
  {label: "故障", value: "5"},
  {label: "异常", value: "10"},
  {label: "屏蔽", value: "9"},
  {label: "在线", value: "1"},
  {label: "离线", value: "2"},
  {label: "自检", value: "4"},
  {label: "低电压", value: "6"},
  {label: "迷宫污染", value: "7"},
  {label: "拆除", value: "8"},
  {label: "其它", value: "11"},
];

const deviceStateObject = {
  all: "0",
  warn: "3",
  fault: "5",
  abnormal: "10",
  shield: "9",
  offline: '2',
};

const deviceTypeObject = {
  xks: "xks",
  smoke: "smoke",
  temp: "temp",
  gas: "gas",
  btn: "btn",
  elec: "elec",
  water: "water",
  xfs: "xfs",
  bottle: "bottle",
  switchs: "switchs"
}

const handleStateOptions = [
  {key: 0, type: 0, value: '未处理'},
  {key: 101, type: 1, value: '一级推送'},
  {key: 102, type: 1, value: '二级推送'},
  {key: 103, type: 1, value: '三级推送'},
  {key: 201, type: 2, value: '处理中'},
  {key: 301, type: 3, value: '误报'},
  {key: 302, type: 3, value: '确认'},
  {key: 305, type: 4, value: '不处理'},
  {key: 304, type: 4, value: '已处理'},
  {key: 303, type: 4, value: '已复位'}
];

const handleOptions = [
  {key: 201, type: 2, text: "处理中"},
  {key: 301, type: 3, text: "误报"},
  {key: 302, type: 3, text: "确认"},
];

const recordStateOptions = [
  {value: '待推送', key: 0},
  {value: '推送中', key: 1},
  {value: '推送失败', key: 2},
  {value: '推送成功', key: 3},
]

export default {
  deviceTypeOptions: deviceTypeOptions,
  deviceStateOptions: deviceStateOptions,
  deviceStateObject: deviceStateObject,
  deviceTypeObject: deviceTypeObject,
  handleStateOptions: handleStateOptions,
  recordStateOptions: recordStateOptions,
  handleOptions: handleOptions,
  eventTypeOptions: eventTypeOptions,
  xksDeviceStateOptions: xksDeviceStateOptions,
}
