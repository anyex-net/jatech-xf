import request from '@/utils/request'

export function getDeviceCount(type) {
  return request({
    url: '/' + type + '/device/count',
    method: 'get',
  })
}

export function addUserDevice(type, data) {
  return request({
    url: '/' + type + '/userManager/addUserDevice',
    method: 'post',
    params: data,
  })
}

export function userManagerPage(type, data) {
  return request({
    url: '/' + type + '/userManager/userDevicePage',
    method: 'post',
    params: data,
  })
}

export function userDeviceBind(type, data) {
  return request({
    url: '/' + type + '/userManager/userDeviceBind',
    method: 'post',
    params: data,
  })
}

export function deleteUserDevice(type, data) {
  return request({
    url: '/' + type + '/userManager/deleteUserDevice',
    method: 'delete',
    params: data,
  })
}

export function getProtocol(query) {
  return request({
    url: '/common/getProtocol',
    method: 'get',
    params: query
  })
}

export function getProvider(query) {
  return request({
    url: '/common/getProvider',
    method: 'get',
    params: query
  })
}

export function getPlatform(query) {
  return request({
    url: '/common/getPlatform',
    method: 'get',
    params: query
  })
}

export function getModel(query) {
  return request({
    url: '/common/getModel',
    method: 'get',
    params: query
  })
}

export function getEventProcessOptions(query) {
  return request({
    url: '/common/getEventProcessOption',
    method: 'get',
    params: query
  })
}

export function getAreaInfo(query) {
  return request({
    url: '/common/getAreaInfo',
    method: 'get',
    params: query
  })
}

export function getSysUnit(query) {
  return request({
    url: '/common/getSysUnit',
    method: 'get',
    params: query
  })
}

export function getSysRoleUnit(query) {
  return request({
    url: '/common/getSysRoleUnit',
    method: 'get',
    params: query
  })
}

export function getNoticeChannel(query) {
  return request({
    url: '/common/getNoticeChannel',
    method: 'get',
    params: query
  })
}

export function basePage(module, name, query) {
  return request({
    url: '/' + module + '/' + name + '/page',
    method: 'post',
    data: query
  })
}

export function baseList(module, name, query) {
  return request({
    url: '/' + module + '/' + name + '/list',
    method: 'post',
    data: query
  })
}

export function baseAdd(module, name, data) {
  return request({
    url: '/' + module + '/' + name + '/add',
    method: 'post',
    data: data
  })
}

export function baseEdit(module, name, data) {
  return request({
    url: '/' + module + '/' + name + '/edit',
    method: 'post',
    data: data
  })
}

export function baseDelete(module, name, id) {
  var ids = [];
  ids.push(id);
  return request({
    url: '/' + module + '/' + name + '/delete',
    method: 'post',
    data: ids
  })
}

export function baseLoad(module, name, id) {
  return request({
    url: '/' + module + '/' + name + '/get',
    method: 'get',
    params: {id: id}
  })
}

