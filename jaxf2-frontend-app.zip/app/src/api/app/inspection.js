import request from "@/utils/request";

const syspre = '/exam';


export function inspectionInit() {
  return request({
    url: syspre + '/inspection/init',
    method: 'get'
  })
}
