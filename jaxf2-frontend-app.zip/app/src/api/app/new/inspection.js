import request from '@/utils/request'

const syspre = '/newExam'

export function inspectionInit() {
  return request({
    url: syspre + '/inspection/init',
    method: 'get'
  })
}
