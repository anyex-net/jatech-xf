const deviceTypeOptions = [
  {id: "0", name: "室外消火栓"},
  {id: "1", name: "智能水系统主机"},
];

const deviceTypeObject = {
  "sensor": "1"
}
const sensorTypeOptions = [
  {id: 1, name: "水流", unit: "m³/h"},
  {id: 2, name: "水位", unit: "m"},
  {id: 3, name: "末端压力", unit: "Mpa"},
  {id: 4, name: "室内消火栓", unit: "Mpa"},
];

const sensorTypeOptions1 = [
  {id: '1', name: "水流", unit: "m³/h"},
  {id: '2', name: "水位", unit: "m"},
  {id: '3,4', name: "水压", unit: "Mpa"},
];

const positionOptions = [
  {typeId: 1, id: 1, name: "水流1", unit: "m³/h"},
  {typeId: 2, id: 1, name: "水位1", unit: "m"},
  {typeId: 2, id: 2, name: "水位2", unit: "m"},
  {typeId: 2, id: 3, name: "水位3", unit: "m"},
  {typeId: 3, id: 1, name: "水压1", unit: "Mpa"},
  {typeId: 3, id: 2, name: "水压2", unit: "Mpa"},
  {typeId: 3, id: 3, name: "水压3", unit: "Mpa"},
  {typeId: 3, id: 4, name: "水压4", unit: "Mpa"},
  {typeId: 3, id: 5, name: "水压5", unit: "Mpa"},
  {typeId: 3, id: 6, name: "水压6", unit: "Mpa"},
  {typeId: 3, id: 7, name: "水压7", unit: "Mpa"},
  {typeId: 4, id: 1, name: "水压1", unit: "Mpa"},
  {typeId: 4, id: 2, name: "水压2", unit: "Mpa"},
  {typeId: 4, id: 3, name: "水压3", unit: "Mpa"},
  {typeId: 4, id: 4, name: "水压4", unit: "Mpa"},
  {typeId: 4, id: 5, name: "水压5", unit: "Mpa"},
  {typeId: 4, id: 6, name: "水压6", unit: "Mpa"},
  {typeId: 4, id: 7, name: "水压7", unit: "Mpa"},
];

const deviceStateOptions = [
  {value: '全部', key: 0},
  {value: '在线', key: 1},
  {value: '离线', key: 2},
  {value: '报警', key: 3},
  {value: '故障', key: 4},
  {value: '低电压', key: 5},
  {value: '异常', key: 6},
];

const eventOptions = [
  {key: 0, value: "心跳"},
  {key: 1, value: "报警"},
  {key: 4, value: "故障"},
  {key: 8, value: "异常"},
  {key: 256, value: "低电压"},
  {key: 2048, value: "上线"},
  {key: 4096, value: "下线"},
];

const stateOptions = [
  {key: 0, type: 0, value: "未处理"},
  {key: 1, type: 1, value: "一级推送中"},
  {key: 2, type: 1, value: "一级推送失败"},
  {key: 3, type: 1, value: "一级推送成功"},
  {key: 4, type: 1, value: "二级推送中"},
  {key: 5, type: 1, value: "二级推送失败"},
  {key: 6, type: 1, value: "二级推送成功"},
  {key: 7, type: 1, value: "三级推送中"},
  {key: 8, type: 1, value: "三级推送失败"},
  {key: 9, type: 1, value: "三级推送成功"},
  {key: 10, type: 2, value: "处理中"},
  {key: 11, type: 3, value: "误报"},
  {key: 12, type: 4, value: "确认"},
  {key: 13, type: 3, value: "复位"},
  {key: 14, type: 3, value: "已处理"},
  {key: 15, type: 3, value: "不处理"},
];

export default {
  deviceTypeOptions: deviceTypeOptions,
  sensorTypeOptions: sensorTypeOptions,
  positionOptions: positionOptions,
  eventOptions: eventOptions,
  stateOptions: stateOptions,
  deviceStateOptions: deviceStateOptions,
  deviceTypeObject: deviceTypeObject,
  sensorTypeOptions1: sensorTypeOptions1
}
