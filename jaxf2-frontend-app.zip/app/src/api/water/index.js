import request from '@/utils/request'

export function getDeviceCount(query) {
  return request({
    url: '/water/deviceSensor/count',
    method: 'get',
    params: query
  })
}

export function deleteSensor(data) {
  return request({
    url: '/water/deviceSensor/del',
    method: 'delete',
    data: data
  })
}

export function addSensor(data) {
  return request({
    url: '/water/deviceSensor/add',
    method: 'post',
    data: data
  })
}

export function sensorHandle(data) {
  return request({
    url: '/water/deviceSensor/handle',
    method: 'post',
    params: data,
  })
}

export function updateSensor(data) {
  return request({
    url: '/water/deviceSensor/edit',
    method: 'put',
    data: data
  })
}

export function waterSensorDetail(id) {
  return request({
    url: '/water/deviceSensor/detail/' + id,
    method: 'get',
  })
}

export function getDeviceHandle(query) {
  return request({
    url: '/water/device/handle',
    method: 'post',
    params: query
  })
}

export function getDevicePage(query) {
  return request({
    url: '/water/device/page',
    method: 'get',
    params: query
  })
}

export function deleteDevice(data) {
  return request({
    url: '/water/device/del',
    method: 'delete',
    data: data
  })
}

export function addDevice(data) {
  return request({
    url: '/water/device/del',
    method: 'delete',
    data: data
  })
}

export function waterDetail(id) {
  return request({
    url: '/water/device/detail/' + id,
    method: 'get',
  })
}

export function addWater(data) {
  return request({
    url: "/water/device/add",
    method: 'post',
    data
  })
}

export function updateWater(data) {
  return request({
    url: "/water/device/edit",
    method: 'put',
    data
  })
}

export function getDeviceList(query) {
  return request({
    url: '/water/device/list',
    method: 'get',
    params: query
  })
}

export function waterSetIsPush(data) {
  return request({
    url: "/water/device/setIsPush",
    method: 'post',
    params: data
  })
}
