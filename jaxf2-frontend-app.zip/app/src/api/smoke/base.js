import request from '@/utils/request'



export function smokelist(query) {
  return request({
    url:   '/smoke/list',
    method: 'get',
    params: query
  })
}

export function deleteSmoke(pkid) {
  return request({
    url:  '/smoke/delete',
    method: 'get',
    params: {pkid} 
  })
}

export function addSmoke(data) {
  return request({
    url:  '/smoke/add',
    method: 'post',
    data
  })
}

export function updateSmoke(data) {
  return request({
    url:  '/smoke/update',
    method: 'post',
    data
  })
}