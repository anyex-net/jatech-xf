import request from '@/utils/request'

export function getDevicePage(query) {
  return request({
    url: '/smoke/device/page',
    method: 'get',
    params: query
  })
}

export function getDeviceCount(query) {
  return request({
    url: '/smoke/device/count',
    method: 'get',
    params: query
  })
}

export function smokeSetIsPush(data) {
  return request({
    url: "/smoke/device/setIsPush",
    method: 'post',
    params: data
  })
}
