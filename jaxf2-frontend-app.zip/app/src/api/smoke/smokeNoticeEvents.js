import request from "@/utils/request";

const url = '/smoke/smokeNoticeEvents';

export function getById(id) {
  return request({
    url: url + "/" + id,
    method: 'get'
  })
}

export function list(query) {
  return request({
    url: url + "/list",
    method: 'get',
    params: query
  })
}

export function del(id) {
  return request({
    url: url + "/delete",
    method: 'delete',
    params: {id}
  })
}

export function add(data) {
  return request({
    url: url + "/add",
    method: 'post',
    data
  })
}

export function update(data) {
  return request({
    url: url + "/edit",
    method: 'put',
    data
  })
}
