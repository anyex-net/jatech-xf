import request from "@/utils/request";

const url = '/smoke/smokeUserManager';

export function getUserDeviceList(id) {
  return request({
    url: url + "/" + id,
    method: 'get',
  })
}

export function updateUserDevice(data, id) {
  return request({
    url: url + "/update?id=" + id,
    method: 'put',
    data
  })
}

export function list(query) {
  return request({
    url: url + "/list",
    method: 'get',
    params: query
  })
}
