const smokeConstant = [
  {key: 1, value: "报警"},
  {key: 2, value: "断电或断网"},
  {key: 4, value: " 报错"},
  {key: 8, value: "待修"},
  {key: 16, value: "通讯异常"},
  {key: 32, value: "探头失联"},
  {key: 64, value: "测试报警"},
  {key: 128, value: "探头低电压报警"},
  {key: 256, value: "底座低电压"},
  {key: 512, value: "烟雾消警"},
  {key: 1024, value: "设备开机"},
  {key: 2048, value: "上线"},
  {key: 4096, value: "下线"},
  {key: 8192, value: "探头恢复正常"},
  {key: 16384, value: "拆除报警"},
  {key: 32768, value: "系统消音"},
  {key: 65536, value: "系统消警"},
  {key: 131072, value: "系统复位"}
];

const stateConstant = [
  {key: 0, type: 0, value: "未处理"},
  {key: 1, type: 0, value: "一级推送中"},
  {key: 2, type: 0, value: "一级推送失败"},
  {key: 3, type: 0, value: "一级推送成功"},
  {key: 4, type: 0, value: "二级推送中"},
  {key: 5, type: 0, value: "二级推送失败"},
  {key: 6, type: 0, value: "二级推送成功"},
  {key: 7, type: 0, value: "三级推送中"},
  {key: 8, type: 0, value: "三级推送失败"},
  {key: 9, type: 0, value: "三级推送成功"},
  {key: 10, type: 1, value: "核实中"},
  {key: 11, type: 2, value: "误报"},
  {key: 12, type: 2, value: "确认"},
  {key: 13, type: 2, value: "复位"},
  {key: 14, type: 2, value: "已处理"}
];


export default {
  eventOptions: smokeConstant,
  stateOptions: stateConstant
}
