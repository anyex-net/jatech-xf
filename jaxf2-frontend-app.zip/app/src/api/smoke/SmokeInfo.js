import request from '@/utils/request'

const url = '/smoke/smokedDeviceInfo'

export function smokeList (query) {
  return request({
    url: url + '/list',
    method: 'get',
    params: query
  })
}

export function smokeAppList (query) {
  return request({
    url: url + '/appList',
    method: 'get',
    params: query
  })
}

export function changeStatus (query) {
  return request({
    url: url + '/changeStatus',
    method: 'get',
    params: query,
  })
}

export function getInfoById (id) {
  return request({
    url: url + '/' + id,
    method: 'get'
  })
}

export function getSmokeById (id) {
  return request({
    url: url + '/smoke/' + id,
    method: 'get'
  })
}

export function deleteSmoke (id) {
  return request({
    url: url + '/delete',
    method: 'delete',
    params: {id}
  })
}

export function addSmoke (data) {
  return request({
    url: url + '/add',
    method: 'post',
    data
  })
}

export function updateSmoke (data) {
  return request({
    url: url + '/edit',
    method: 'put',
    data
  })
}

export function getAppSmokeIndex () {
  return request({
    url: url + '/appIndex',
    method: 'get',
  })
}
