import request from '@/utils/request'

export function smokeEventList (query) {
  return request({
    url: '/smoke/smokeEvent/list',
    method: 'get',
    params: query
  })
}

export function smokeEventAppList (query) {
  return request({
    url: '/smoke/smokeEvent/appList',
    method: 'get',
    params: query
  })
}

export function smokeNoticeList (query) {
  return request({
    url: '/smoke/smokeNoticeList',
    method: 'get',
    params: query
  })
}

export function smokeProcessList (query) {
  return request({
    url: '/smoke/smokeEventProcess/list',
    method: 'get',
    params: query
  })
}

export function appUpdateEvent (data) {
  return request({
    url: '/smoke/smokeEvent/appUpdate',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    method: 'post',
    data: data
  })
}

export function updateSmokeEvent (data) {
  return request({
    url: '/smoke/smokeEvent/update',
    method: 'post',
    data
  })
}

export function getById (query) {
  return request({
    url: '/smoke/smokeEvent/getById',
    method: 'get',
    params: query
  })
}
