import request from '@/utils/request'

export function getDevicePage(query) {
  return request({
    url: '/temp/device/page',
    method: 'get',
    params: query
  })
}

export function getDeviceCount(query) {
  return request({
    url: '/temp/device/count',
    method: 'get',
    params: query
  })
}

export function tempSetIsPush(data) {
  return request({
    url: "/temp/device/setIsPush",
    method: 'post',
    params: data
  })
}
