import request from '@/utils/request'

export function deviceCount(query) {
  return request({
    url: '/water/device/count',
    method: 'get',
    params: query
  })
}
