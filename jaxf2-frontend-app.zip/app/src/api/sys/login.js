/**
 *
 * @author qiuhk
 * @date 2020/8/26 19:06
 */
import request from '@/utils/request'

const syspre = '/sys'

/**
 * 登录
 *
 * @author qiuhk
 * @date 2020/8/26 19:06
 */
export function login(parameter) {
  return request({
    url: syspre + '/login',
    method: 'post',
    data: parameter
  })
}

export function loginByOpenId(parameter) {
  return request({
    url: syspre + '/loginByOpenId',
    method: 'post',
    params: parameter
  })
}

/**
 * 获取guid
 * @returns {AxiosPromise}
 */
export function getGuid() {
  return request({
    url: syspre + '/guid',
    method: 'get'
  })
}

/**
 * 登出
 *
 * @author qiuhk
 * @date 2020/8/26 19:07
 */
export function logout(parameter) {
  return request({
    url: syspre + '/logout',
    method: 'get',
    params: parameter
  })
}

/**
 * 获取登录用户信息
 *
 * @author qiuhk
 * @date 2020/8/26 19:08
 */
export function getLoginUser(parameter) {
  return request({
    url: syspre + '/getLoginUser',
    method: 'get',
    params: parameter
  })
}

/**
 * 获取用户头像
 *
 * @author qiuhk
 * @date 2020/8/26 19:08
 */
export function previewAvatar(parameter) {
  return request({
    url: syspre + '/system/previewAvatar',
    method: 'get',
    params: parameter
  })
}

/**
 * 获取短信验证码
 *
 * @author qiuhk
 * @date 2020/8/26 19:29
 */
export function getSmsCaptcha(parameter) {
  return request({
    url: syspre + '/getSmsCaptcha',
    method: 'get',
    params: parameter
  })
}

/**
 *
 *
 * @author qiuhk
 * @date 2020/8/26 19:29
 */
export function twoStepCode(parameter) {
  return request({
    url: syspre + '/auth/2step-code',
    method: 'get',
    params: parameter
  })
}

