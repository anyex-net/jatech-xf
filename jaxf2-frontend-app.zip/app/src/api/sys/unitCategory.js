import request from '@/utils/request'

const syspre = '/sys/unitCategory'


export function unitCategoryList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}


