import request from "@/utils/request";

export function getAreaTree(parameter) {
  return request({
    url: 'common/area/nextTree',
    method: 'get',
    params: parameter
  })
}

export function getAreaListByName(name) {
  return request({
    url: 'common/area/' + name,
    method: 'get'
  })
}

export function getAreaInfoById(id) {
  return request({
    url: 'common/areaInfo/' + id,
    method: 'get'
  })
}
