import request from '@/utils/request'

const syspre = '/sys/unitType'


export function unitTypeList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}
