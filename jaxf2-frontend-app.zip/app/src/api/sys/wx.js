import request from '@/utils/request'

const syspre = '/sys/wx'

export function getAuth(parameter) {
  return request({
    url: syspre + '/getAuth',
    method: 'get',
    params: parameter
  })
}

export function getSignature(parameter) {
  return request({
    url: syspre + '/getSignature',
    method: 'get',
    params: parameter
  })
}


export function getOpenId(data) {
  return request({
    url: syspre + '/getOpenId',
    method: 'get',
    params: data
  })
}
