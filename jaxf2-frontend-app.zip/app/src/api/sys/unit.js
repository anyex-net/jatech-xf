import request from '@/utils/request'

const syspre = '/sys'

export function getUnitDetail(id) {
  return request({
    url: syspre + '/unit/detail/' + id,
    method: 'get'
  })
}

export function unitEdit(data) {
  return request({
    url: syspre + '/unit/edit',
    method: 'put',
    data: data
  })
}

export function getOnlineUnitDetail(id) {
  return request({
    url: syspre + '/onlineUnit/detail/' + id,
    method: 'get'
  })
}

export function getUnitPage(data) {
  return request({
    url: syspre + '/unit/page',
    method: 'get',
    params: data,
  })
}

export function getUnitList(data) {
  return request({
    url: syspre + '/unit/list',
    method: 'get',
    params: data,
  })
}

export function getOperateUnitList() {
  return request({
    url: syspre + '/onlineUnit/getOperateUnitList',
    method: 'get',
  })
}

export function getExamUnitList() {
  return request({
    url: syspre + '/onlineUnit/getExamUnitList',
    method: 'get',
  })
}

/**
 * 删除
 * @param data
 * @returns {AxiosPromise}
 */
export function unit_Del(data) {
  return request({
    url: syspre + '/onlineUnit/del',
    method: 'delete',
    data: data
  })
}

export function getUnitTree(parameter) {
  return request({
    url: syspre + '/unit/nextTree',
    method: 'get',
    params: parameter
  })
}

export function getSelectorList(parameter) {
  return request({
    url: syspre + '/unit/selectorList',
    method: 'get',
    params: parameter
  })
}

export function sysUnitOwnChannel(parameter) {
  return request({
    url: syspre + '/unit/sysUnitOwnChannel',
    method: 'get',
    params: parameter
  })
}

export function sysUnitGrantChannel(data, unitId) {
  return request({
    url: syspre + '/unit/sysUnitGrantChannel?unitId=' + unitId,
    method: 'post',
    data
  })
}

export function unitList(parameter) {
  return request({
    url: syspre + '/unit/list',
    method: 'get',
    params: parameter
  })
}

export function onlineUnitAdd(data) {
  return request({
    url: syspre + '/onlineUnit/add',
    method: 'post',
    data: data
  })
}

export function onlineUnitUpdate(data) {
  return request({
    url: syspre + '/onlineUnit/edit',
    method: 'put',
    data: data
  })
}

export function onlineUnitSetProhibitPushTime(data) {
  return request({
    url: syspre + "/onlineUnit/setProhibitPushTime",
    method: 'post',
    params: data,
  })
}

export function onlineUnitCancelProhibitPush(data) {
  return request({
    url: syspre + "/onlineUnit/cancelProhibitPush",
    method: 'post',
    params: data,
  })
}
