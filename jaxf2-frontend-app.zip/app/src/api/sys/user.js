import request from '@/utils/request'

const syspre = '/sys/user'

export function userExist(parameter) {
  return request({
    url: syspre + '/exist',
    method: 'get',
    params: parameter
  })
}

export function updatePwd(data) {
  return request({
    url: syspre + '/updatePwd',
    method: 'post',
    params: data
  })
}
