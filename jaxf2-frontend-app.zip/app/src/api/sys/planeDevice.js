import request from '@/utils/request'

const syspre = '/sys/planeDevice'

/**
 * 获取平面图列表
 *
 * @author hb
 * @date 2020/4/26 12:08
 */
export function getPlanDeviceList(parameter) {
  return request({
    url: syspre + "/list",
    method: 'get',
    params: parameter
  })
}

/**
 * 根据设备获取平面图定位
 * @param parameter
 * @returns {AxiosPromise}
 */
export function getPlaneByDevice(parameter) {
  return request({
    url: syspre + "/getPlaneByDevice",
    method: 'get',
    params: parameter
  })
}
