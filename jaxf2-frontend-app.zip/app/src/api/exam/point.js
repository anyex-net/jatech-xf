import request from '@/utils/request'

const syspre = '/exam/point'

export function getInfoByCode(parameter) {
  return request({
    url: syspre + '/getInfoByCode',
    method: 'get',
    params: parameter
  })
}

export function getInfoByCodeAndUnitId(parameter) {
  return request({
    url: syspre + '/getInfoByCodeAndUnitId',
    method: 'get',
    params: parameter
  })
}

export function pointList(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function pointSearch(parameter) {
  return request({
    url: syspre + '/search',
    method: 'get',
    params: parameter
  })
}

export function pointDetail(params) {
  return request({
    url: syspre + '/detail',
    method: 'get',
    params: params
  })
}

export function pointDetail1(params) {
  return request({
    url: syspre + '/detail',
    method: 'get',
    params: params
  })
}

export function pointAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function pointUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function pointDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function pointExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function listAll(parameter) {
  return request({
    url: syspre + '/listall',
    method: 'get',
    params: parameter
  })
}

export function listUnit() {
  return request({
    url: syspre + '/getunit',
    method: 'get',
  })
}


export function checkNameValidator(parameter) {
  return request({
    url: syspre + '/validatorName',
    method: 'get',
    params: parameter
  })
}

export function checkCodeValidator(parameter) {
  return request({
    url: syspre + '/validatorCode',
    method: 'get',
    params: parameter
  })
}

export function importDemo(data) {
  return request({
    url: syspre + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}


export function importExcel(data) {
  return request({
    url: syspre + '/import',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}
