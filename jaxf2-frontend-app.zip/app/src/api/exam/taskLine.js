import request from '@/utils/request'

const syspre = '/exam/taskLine'

export function taskLinePage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function taskLineList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function taskLineDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function taskLineAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function taskLineUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function taskLineDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function taskLineExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}
