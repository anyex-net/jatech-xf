import request from '@/utils/request'

const syspre = '/exam/part'

export function partPage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function partList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function partDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}

export function partAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function partUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function partDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function partExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function importDemo(data) {
  return request({
    url: syspre + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}

export function importExcel(data) {
  return request({
    url: syspre + '/import',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}
