import request from '@/utils/request'

const syspre = '/exam/area'

export function areaList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}
