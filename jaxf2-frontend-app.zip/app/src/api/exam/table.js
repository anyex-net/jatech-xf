import request from '@/utils/request'

const syspre = '/exam/table'

export function tablePage(parameter) {
  return request({
    url: syspre + '/page',
    method: 'get',
    params: parameter
  })
}

export function tableList(parameter) {
  return request({
    url: syspre + '/list',
    method: 'get',
    params: parameter
  })
}

export function tableAll(parameter) {
  return request({
    url: syspre + '/all',
    method: 'get',
    params: parameter
  })
}

export function tableDetail(id) {
  return request({
    url: syspre + '/detail/' + id,
    method: 'get'
  })
}
export function tableDetailId(id) {
  return request({
    url: syspre + '/tableDetail/' + id,
    method: 'get'
  })
}
export function tableAdd(data) {
  return request({
    url: syspre + '/add',
    method: 'post',
    data: data
  })
}

export function tableUpdate(data) {
  return request({
    url: syspre + '/edit',
    method: 'put',
    data: data
  })
}

export function tableDelete(data) {
  return request({
    url: syspre + '/del',
    method: 'delete',
    data: data
  })
}

export function tableExport(query) {
  return request({
    url: syspre + '/export',
    method: 'get',
    params: query,
    responseType: 'blob'
  })
}

export function moveUp(query) {
  return request({
    url: syspre + '/moveUp',
    method: 'post',
    params: query
  })
}

export function moveDown(query) {
  return request({
    url: syspre + '/moveDown',
    method: 'post',
    params: query
  })
}

export function checkNameValidator(parameter) {
  return request({
    url: syspre + '/validatorName',
    method: 'get',
    params: parameter
  })
}

export function checkContentValidator(parameter) {
  return request({
    url: syspre + '/validatorContent',
    method: 'get',
    params: parameter
  })
}

export function importDemo(data) {
  return request({
    url: syspre + '/importDemo',
    method: 'post',
    responseType: 'blob'
  })
}

export function importExcel(data, id) {
  return request({
    url: syspre + '/import/' + id,
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    method: 'post',
    responseType: 'blob',
    data: data
  })
}

