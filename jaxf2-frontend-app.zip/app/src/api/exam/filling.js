import request from '@/utils/request'

const syspre = '/exam/msExamPointFromFilling'


export function fillingTableList(parameter) {
  return request({
    url: syspre + '/getTableList',
    method: 'get',
    params: parameter
  })
}


export function fillingFormAdd(data) {
  return request({
    url: syspre + '/formAdd',
    method: 'post',
    data: data
  })
}
export function getTableList(parameter) {
  return request({
    url: syspre + '/getFromFilling',
    method: 'get',
    params: parameter
  })
}
