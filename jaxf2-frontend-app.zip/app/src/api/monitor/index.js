import request from '@/utils/request'

export function getVideoUrl(query) {
  return request({
    url: "/monitor/device/getVideoUrl",
    method: 'get',
    params: query
  })
}
