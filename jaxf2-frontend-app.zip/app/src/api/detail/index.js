import request from '@/utils/request'



// export function getElecInfo(id) {
//     return request({
//         url: '/elec/device/getElecInfo/{id}',
//         method: 'get',
//         params: id
//     })
// }

export function getElecInfo(id) {
    return request({
        url: '/elec/device/getElecInfo/' + id,
        method: 'get',
    })
}

export function getWaterInfo(id) {
    return request({
        url: '/water/device/getWaterInfo/' + id,
        method: 'get',
    })
}

export function getXksDeviceInfo(id) {
    return request({
        url: '/xks/device/getXksDeviceInfo/' + id,
        method: 'get',
    })
}

export function getSmokeInfo(id) {
    return request({
        url: '/smoke/device/getSmokeInfo/' + id,
        method: 'get',
    })
}
export function getBtnInfo(id) {
    return request({
        url: '/btn/device/getBtnInfo/' + id,
        method: 'get',
    })
}
export function getTempInfo(id) {
    return request({
        url: '/temp/device/getTempInfo/' + id,
        method: 'get',
    })
}
export function getGasInfo(id) {
    return request({
        url: '/gas/device/getTempInfo/' + id,
        method: 'get',
    })
}

export function gethandle(query) {
    return request({
        url: '/elec/event/handle',
        method: 'post',
        params: query
    })
}

export function getEventPage(query) {
    return request({
        url: '/smoke/event/page',
        method: 'get',
        params: query
    })
}


export function getProcessPage(query) {
    return request({
        url: '/elec/event/processPage',
        method: 'get',
        params: query
    })
}


export function getWaterEventPage(query) {
    return request({
        url: '/water/event/page',
        method: 'get',
        params: query
    })
}

export function getSmokeHandle(query) {
    return request({
        url: '/smoke/device/handle',
        method: 'post',
        params: query
    })
}
export function getSmokeEventHandle(query) {
    return request({
        url: '/smoke/event/handle',
        method: 'post',
        params: query
    })
}

export function getSmokeEventPage(query) {
    return request({
        url: '/smoke/event/page',
        method: 'get',
        params: query
    })
}

export function sysFileInfo(data) {
    return request({
        url: '/sys/sysFileInfo/upload',
        headers: {
            'Content-Type': 'multipart/form-data',
          },
        method: 'post',
        data: data
    })
}

export function getElecEventPage(query) {
    return request({
        url: '/elec/event/page',
        method: 'get',
        params: query
    })
}

//手报
export function getBtnEventPage(query) {
    return request({
        url: '/btn/event/page',
        method: 'get',
        params: query
    })
}
//温感
export function getTempEventPage(query) {
    return request({
        url: '/temp/event/page',
        method: 'get',
        params: query
    })
}

//燃气
export function getGasEventPage(query) {
    return request({
        url: '/gas/event/page',
        method: 'get',
        params: query
    })
}

//消控室
export function getXksEventPage(query) {
    return request({
        url: '/xks/event/page',
        method: 'get',
        params: query
    })
}