import Vue from 'vue'
import App from './App.vue'
import router from '@/router'
import 'babel-polyfill' // 放置顶部
import Es6Promise from 'es6-promise' // 放置顶部
import '@/styles/index.less' // global css
import '@/permission' // permission control
import Vant from 'vant'
// import Toast from 'vant'
import store from '@/store'
import 'vant/lib/index.css'
import 'vant/lib/index.less'
import '@/styles/common.less'
import 'amfe-flexible'
import '@/icons' // icon
import VueAMap from 'vue-amap'
import VueTouch from 'vue-touch'
import vueEsign from 'vue-esign'
import Viewer from 'v-viewer'
import 'viewerjs/dist/viewer.css'
import '@/assets/css/common.css'
import {hasBtnPermission} from '@/utils/permission'
import wx from 'weixin-js-sdk'
import 'vant/lib/icon/local.css'
import '@/assets/font/font.css'
import 'video.js/dist/video-js.css'
import '@/api/offline/sqlitePlugin'
// import VConsole from 'vconsole'
// new VConsole()
// Vue.prototype.$host = process.env.VUE_APP_BASE_API
Vue.prototype.$host = 'https://iot.jatech.cloud:9529'
// Vue.prototype.$host = 'http://176.1.1.8:9529'

Vue.use(Viewer)
Viewer.setDefaults({
  Options: {
    'inline': true,
    'button': true,
    'navbar': true,
    'title': true,
    'toolbar': false,
    'tooltip': true,
    'movable': true,
    'zoomable': true,
    'rotatable': true,
    'scalable': true,
    'transition': true,
    'fullscreen': true,
    'keyboard': true,
    'url': 'data-source'
  }
})

Vue.use(VueTouch, {name: 'v-touch'})
Vue.use(vueEsign, {name: 'vue-esign'})
Es6Promise.polyfill()
VueTouch.config.swipe = {
  threshold: 100 // 手指左右滑动距离
}
Vue.use(router)
Vue.use(Vant)
Vue.use(VueAMap)

VueAMap.initAMapApiLoader({
  key: '6109f3a03ecd4e54afcf35700b1fd57b',
  plugin: ['AMap.Autocomplete', 'AMap.Geocoder', 'AMap.Geolocation'],
  v: '1.4.15',
  uiVersion: '1.1'
})

window._AMapSecurityConfig = {
  securityJsCode: 'd03d2fd4796fe4d4e8590fb3b54844dd' // "安全密钥",
}

Vue.config.productionTip = false
Vue.prototype.hasPerm = hasBtnPermission
Vue.prototype.$wx = wx
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
