import axios from 'axios'
import store from '@/store'
import { getToken } from '@/utils/auth'
import { Toast } from 'vant'
// create an axios instance
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API,
  // baseURL: 'https://iot.jatech.cloud:9529',
  // baseURL: 'http://176.1.1.8:9529',
  // withCredentials: true,
  timeout: 50000
})

// request interceptor
service.interceptors.request.use(
  config => {
    // store.commit('showLoading')
    // do something before request is sent
    if (store.getters.token) {
      // let each request carry token
      // ['X-Token'] is a custom headers key
      // please modify it according to the actual situation
      config.headers['X-Token'] = getToken()
      /*      config.headers['Content-Type'] = 'multipart/form-data'*/
    }

    return config
  },
  error => {
    // do something with request error
    // store.commit('hideLoading')
    console.log(error) // for debug
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
   */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  response => {
    const res = response.data
    // store.commit('hideLoading')
    // if the custom code is not 20000, it is judged as an error.
    if (res.code != null && res.code !== 20000 && res.code !== 200) {
      if (res.code === 600) {
        store.dispatch('user/resetToken').then(() => {
          Toast('登陆已过期,需要重新登录')
          location.reload()
        })
      } else {
        Toast.fail(res.message)
      }
      return Promise.reject(new Error(res.message || 'Error'))
    } else {
      return res
    }
  },
  error => {
    // store.commit('hideLoading')
    Toast.fail(error.message)
    return Promise.reject(error)
  }
)

export default service
