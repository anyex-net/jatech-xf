import Cookies from 'js-cookie'

const TokenKey = 'Admin-Token'

export function getToken() {
  return Cookies.get(TokenKey)
  // return sessionStorage.getItem(TokenKey)
}

export function setToken(token) {
  return Cookies.set(TokenKey, token)
  // Cookies.set(TokenKey, token)
  // sessionStorage.setItem(TokenKey, token)
  // return 0
}

export function removeToken() {
  return Cookies.remove(TokenKey)
}
