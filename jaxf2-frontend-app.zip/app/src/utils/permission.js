import store from '@/store'

/**
 * @param {Array} value
 * @returns {Boolean}
 * @example see @/views/permission/directive.vue
 */
export default function checkPermission(value) {
  if (value && value.length > 0) {
    const roles = store.getters && store.getters.permissions
    const permissionRoles = value
    const hasPermission = roles.some(role => {
      return permissionRoles === role
    })
    return hasPermission
  } else {
    console.error(`need roles! Like v-permission="['admin','editor']"`)
    return false
  }
}

/**
 * 控制按钮是否显示
 *
 * @author wangxinhui
 * @date 2020-9-16 15:13:23
 * 次函数在Main.js中使用了全局变量hasPerm
 */
export function hasBtnPermission(permission) {
  let result = checkPermission(permission);
  return result;
}
