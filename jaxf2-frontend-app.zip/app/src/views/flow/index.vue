<template>
  <div>
    <div class="home-nav">
      <van-nav-bar :border="false">
        <template #title>
          <span class="van-nav-bar__content">{{ form.name }}</span>
        </template>
      </van-nav-bar>
    </div>
    <van-row>
      <flow-form :fields="form.json.fields"  v-model="data">
      </flow-form>
    </van-row>
  </div>
</template>

<script>
import { NavBar, Row} from "vant";
import FlowForm from "@/views/flow/form"

export default {
  components: { FlowForm, NavBar },
  data () {
    return {
      form: {
        code: 'weibao',
        name: '测试表单',
        version: 1,
        json:  {
          fields: [
            { code: '维修方案', label: '描述', type: 'text', edit: true },
            { code: 'result', label: '方案结果', type: 'select', edit: true, data: ['修理', '无法修理'] },
            { code: 'device', label: '配件', type:'table', edit: true, feilds: [
                { code: 'name', label: '名称', type: 'input', },
                { code: 'count', label: '数量', type: 'number', },
                { code: 'price', label: '价格', type: 'number', },
              ] },
            { code: 'memo1', label: '物业意见', type: 'text', edit: true },
            { code: 'result1', label: '物业结果', type: 'select', edit: true, data: ['修理', '退回'] },
            { code: 'memo2', label: '领导意见', type: 'text', edit: true },
            { code: 'result2', label: '审批结果', type: 'select', edit: true, data: ['修理', '退回'] },
            { code: 'memo3', label: '维修描述', type: 'text', edit: true },
            { code: 'result3', label: '维修结果', type: 'select', edit: true, data: ['完成', '未完成'] },
            { code: 'memo4', label: '核查意见', type: 'text', edit: true },
            { code: 'result4', label: '核查结果', type: 'select', edit: true, data: ['通过', '重修'] },
          ],
        }
      },
      data: {},
    }
  },
  created() {
  },
  methods: {
    async onSubmit () {
      const params = {
        username: this.username,
        password: this.password
      }
      this.loading = true
      this.$store.dispatch('user/login', params)
        .then(() => {
          this.$router.push('/index')
          this.$parent.isShowNav = true
          this.loading = false
        })
        .catch((err) => {
          this.loading = false
          this.$toast(err + '')
        })
    }
  }
}
</script>

<style>
</style>
