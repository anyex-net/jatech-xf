<template>
  <div>
    <van-row v-for="col in cols" :key="col.code">
      <van-field v-if="col.type=='text'" type="textarea" v-model="val[col.code]" Mu :label="col.label"></van-field>
      <van-field v-if="col.type=='number'" type="number" v-model="val[col.code]" :label="col.label"></van-field>
      <van-cell :title="col.label" v-if="col.type=='select'">
        <van-radio-group v-model="val[col.code]" direction="horizontal">
          <van-radio v-for="v in col.data" :key="v" :name="v">{{v}}</van-radio>
        </van-radio-group>
      </van-cell>
      <van-field v-if="col.type=='input'" :label="col.label"></van-field>
      <van-tabs v-model="active" v-if="col.type =='table'">
        <van-tab :title="col.label">
          <van-row v-for="tcol in col.feilds" :key="col.code+'-'+tcol.code">
            <van-field v-if="tcol.type=='text'" type="textarea" v-model="val[tcol.code]" Mu
                       :label="tcol.label"></van-field>
            <van-field v-if="tcol.type=='number'" type="number" v-model="val[tcol.code]"
                       :label="tcol.label"></van-field>
            <van-field v-if="tcol.type=='input'" :label="tcol.label"></van-field>
            <van-radio-group v-model="val[col.code]" v-if="col.type=='select'" direction="horizontal">
              <van-radio v-for="v in col.data" :key="v" :name="v">{{v}}</van-radio>
            </van-radio-group>
          </van-row>
        </van-tab>
      </van-tabs>
    </van-row>
  </div>
</template>

<script>

  export default {
    name: 'FlowForm',
    components: {},
    props: {
      fields: {
        required: true,
        type: Array
      },
      value: {
        required: true,
        type: Object,
      }
    },
    data() {
      return {
        cols: [],
        val: {},
        callback: function () {
        },
        showDialog: false
      }
    },
    created() {
      this.cols = this.fields
      this.val = this.value
    },
    mounted() {
      this.cols.forEach((item) => {
        if (item.relation && item.type == 'select') {
          item.data = []
          baseList(item.relation.module, item.relation.name, {query: [], sort: '', dir: 'asc'}).then((res) => {
            item.data = res.data
          })
        }
      });
    },
    methods: {}
  }
</script>
