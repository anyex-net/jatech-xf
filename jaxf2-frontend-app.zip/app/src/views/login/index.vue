<template>
  <div v-show="showLogin" style="width: 100%;height:100%">
    <!-- <van-image width="100%" height="auto" src="http://www.nb-jetron.com/upfile/2019/06/20190628174944_604.png" /> -->
    <!--    <van-image width="100%" height="auto" :src="require('@/assets/login.jpg')"/>-->
    <div id="login">
      <div style="top:16%;left:8%;position:absolute">
        <van-image width="40" :src="require('@/assets/images/new/logo.png')" />
        <br>
        <br>
        <div style="color: #333333; font-size:15px;letter-spacing: 2px">您好,欢迎使用</div>
        <div style="color: #333333; font-size:15px;letter-spacing: 2px">金安智慧消防管理系统~</div>
      </div>
      <div style="position:absolute;top:43%;left:8%;width:84%">
        <van-form class="login" @submit="onSubmit">
          <van-field
            v-model="username"
            class="field"
            placeholder="请输入账号"
            :rules="[{ required: true, message: '' }]"
          />
          <br>
          <van-field
            v-model="password"
            class="field"
            :type="isShowPassword? 'text':'password'"
            eyes
            placeholder="请输入密码"
            :rules="[{ required: true, message: '' }]"
          >
            <template #right-icon>
              <van-icon name="eye-o" @click="()=>{isShowPassword=!isShowPassword}" />
            </template>
          </van-field>
          <br>
          <van-field
            style="display: flex;align-items: center;background: transparent;"
            :border="false"
            input-align="right"
          >
            <template #label>
              <van-checkbox v-model="remember" icon-size="16"><span style="color: #B4B4B4">记住密码</span></van-checkbox>
            </template>
          </van-field>
          <div id="button">
            <van-button
              style="background: linear-gradient(90deg, #306BFF 0%, #08D1FE 100%);border-radius: 6px"
              :loading="loading"
              round
              block
              type="default"
              native-type="submit"
            >
              <span style="color: #ffffff;letter-spacing: 6px">登录</span>
            </van-button>
          </div>
        </van-form>
      </div>

      <div style="color:#777A82;font-size: 12px;position:absolute;top:93%;width:100%">
        <div style="text-align: center">
          技术支持-浙江金安公共安全技术有限公司
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import AESUtils from '@/utils/AESUtils'
import { getGuid } from '@/api/sys/login'
import { loginByOpenId } from '../../api/sys/login'
import { getAuth, getOpenId } from '../../api/sys/wx'
import { getInfoByCode } from '../../api/exam/point'
import { getInfoByCodeNew } from '../../api/newExam/point'
import { setToken } from '../../utils/auth'
import store from '../../store'
import { getExtinguisherByCode } from '../../api/newExam/extinguisher'

export default {
  data() {
    return {
      isShowPassword: false,
      showLogin: false,
      username: '',
      password: '',
      loading: false,
      guid: null,
      remember: true,
      openId: null
    }
  },
  beforeCreate() {
    store.commit('SET_TOKEN', '')
    setToken('')
  },
  created() {
    if (this.$route.query.isWx) {
      this.showLogin = false
      let isAutoLogin = true
      if (this.$route.query.isAutoLogin) {
        isAutoLogin = this.$route.query.isAutoLogin
      }
      let path1 = null
      if (this.$route.query.path1 && this.$route.query.path1 !== '') {
        path1 = this.$route.query.path1
      }
      getAuth({ isAutoLogin: isAutoLogin, path1: path1 }).then(response => {
        if (response.success) {
          location.href = response.data
        }
      })
    } else if (this.$route.query.openId) {
      this.showLogin = false
      loginByOpenId({ openId: this.$route.query.openId }).then(response => {
        if (response.success) {
          this.openId = response.data.openId
          if (response.success) {
            this.$store.dispatch('user/loginByToken', response.data.token)
              .then(() => {
                if (this.$route.query.path && this.$route.query.path !== '') {
                  this.goPointPath()
                } else if (this.$route.query.path1 && this.$route.query.path1 !== '') {
                  const path1 = decodeURIComponent(this.$route.query.path1)
                  this.$router.push(path1)
                } else this.$router.push('/index')
                this.$parent.isShowNav = true
                this.loading = false
              })
              .catch((err) => {
                this.loading = false
                this.$toast(err + '')
              })
          }
        }
      }
      ).catch(err => {
        if (this.$route.query.path && this.$route.query.path !== '') {
          this.goPointPath()
        }
      })
    } else if (this.$route.query.code) {
      this.showLogin = false
      let isAutoLogin = true
      if (this.$route.query.isAutoLogin) {
        isAutoLogin = this.$route.query.isAutoLogin
      }
      // alert("开始获取openID")
      getOpenId({ code: this.$route.query.code, isAutoLogin: isAutoLogin }).then(response => {
        if (response.success) {
          this.openId = response.data.openId
          // alert("openID为" + this.openId)
          if (isAutoLogin && response.data.token) {
            // alert("开始登录")
            this.$store.dispatch('user/loginByToken', response.data.token)
              .then(() => {
                // alert("登录完成准备跳转")
                if (this.$route.query.path && this.$route.query.path !== '') {
                  this.goPointPath()
                } else if (this.$route.query.path1 && this.$route.query.path1 !== '') {
                  const path1 = decodeURIComponent(this.$route.query.path1)
                  this.$router.push(path1)
                } else this.$router.push('/index')
                this.$parent.isShowNav = true
                this.loading = false
              })
              .catch((err) => {
                this.loading = false
                this.$toast(err + '')
              })
          } else {
            if (this.$route.query.path && this.$route.query.path !== '') {
              this.goPointPath()
            } else {
              this.showLogin = true
            }
          }
        }
      }
      ).catch(err => {

      })
    } else if (this.$route.query.path) {
      if (this.$route.query.path && this.$route.query.path !== '') {
        this.goPointPath()
      }
    } else {
      this.showLogin = true
    }
    this.$parent.isShowNav = false
    this.getGuid_()
    this.getCookie()
  },
  methods: {
    goPointPath() {
      if (this.$route.query.pointCode && this.$route.query.pointCode !== '') {
        // alert("开始获取点位信息")
        getInfoByCode({ code: this.$route.query.pointCode }).then(res => {
          if (res.data) {
            this.$router.push({
              path: this.$route.query.path,
              query: {
                id: res.data.id,
                unitId: res.data.unitId,
                isBack: false
              }
            })
          } else {
            getInfoByCodeNew({ code: this.$route.query.pointCode }).then(res => {
              if (res.data) {
                this.$router.push({
                  path: '/app/new/inspection/point/index',
                  query: {
                    id: res.data.id,
                    unitId: res.data.unitId,
                    isBack: false
                  }
                })
              } else {
                getExtinguisherByCode({ code: this.$route.query.pointCode }).then(res => {
                  if (res.data) {
                    this.$router.push({
                      path: '/app/extinguisher/operation/index',
                      query: { extinguisherId: res.data.id, operationType: 'showDetails' }
                    })
                  } else {
                    this.$router.push({
                      path: this.$route.query.path,
                      query: {
                        id: null,
                        unitId: null,
                        isBack: false
                      }
                    })
                  }
                })
              }
            })
          }
        })
      }
    },
    getGuid_() {
      getGuid().then(res => {
        this.guid = res.data
      })
    },
    async onSubmit() {
      const params = {
        username: this.username,
        password: this.password,
        openId: this.openId
      }
      // AES-128-ECB 加密
      params.password = AESUtils.encrypt(this.password, this.guid)
      this.loading = true
      if (this.remember === true) {
        localStorage.setItem('ms_username', this.username)
        // 保存用户名和密码到cookie
        this.setCookie(this.username, this.password, 7)
      }
      this.$store.dispatch('user/login', params)
        .then(() => {
          this.$router.push('/index')
          this.$parent.isShowNav = true
          this.loading = false
        })
        .catch((err) => {
          this.loading = false
          this.$toast(err + '')
        })
    },
    setCookie(c_name, c_pwd, exdays) {
      const exdate = new Date() // 获取时间
      exdate.setTime(exdate.getTime() + 24 * 60 * 60 * 1000 * exdays) // 保存的天数
      // 字符串拼接cookie
      window.document.cookie = 'userName' + '=' + c_name + ';path=/;expires=' + exdate.toGMTString()
      window.document.cookie = 'userPwd' + '=' + c_pwd + ';path=/;expires=' + exdate.toGMTString()
    },
    // 读取cookie
    getCookie() {
      if (document.cookie.length > 0) {
        const arr = document.cookie.split('; ') // 这里显示的格式需要切割一下自己可输出看下
        for (let i = 0; i < arr.length; i++) {
          const arr2 = arr[i].split('=') // 再次切割
          // 判断查找相对应的值
          if (arr2[0] === 'userName') {
            this.username = arr2[1] // 保存到保存数据的地方
          } else if (arr2[0] === 'userPwd') {
            this.password = arr2[1]
          }
        }
      }
    }

  }
}
</script>

<style scoped>
  html, body, #app {
    height: 100%;
    position: absolute;
    width: 100%;
  }

  input:-webkit-autofill {
    box-shadow: 0 0 0px 1000px #ff4d51 inset;
    border: 1px solid #444 !important;
  }

  #login {
    background: url("../../assets/images/new/loginBackground.png") 0 0 no-repeat;
    background-size: 100% 100%;
    height: 100%;
    width: 100%;
  }

  #form {
    height: 100%;
  }

  #button {
    margin-top: 50px;
  }

  .login >>> .van-cell {
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    padding: 0px 0px;
    height: 40px;
    overflow: hidden;
    color: #323233;
    font-size: 14px;
    line-height: 24px;
    align-items: center;
    background-color: #fff;
  }
</style>
