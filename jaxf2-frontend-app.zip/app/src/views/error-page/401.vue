<template>
  <div>
    <van-empty description="401">
      <van-button round type="info" class="bottom-button" @click="backToHome">返回首页</van-button>
    </van-empty>
  </div>
</template>

<script>
  export default {
    methods: {
      backToHome() {
        this.$router.push("/index/index");
      }
    }
  };
</script>

<style scoped>
  .bottom-button {
    width: 160px;
  }
</style>
