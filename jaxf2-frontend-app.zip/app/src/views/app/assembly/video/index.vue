<template>
  <div>
    <v-video style="width: 100%;height:100%" v-if="videoShow" :url="videoSourceUrl" :video-height="videoHeight"/>
  </div>
</template>

<script>
  import {getVideoSource} from '@/views/app/assembly/video/videoRequest'
  import vVideo from '@/components/Video/index'

  export default {
    name: 'Index',
    components: {vVideo},
    props: {
      id: {
        type: String,
        default: null
      },
      type: {
        type: String,
        default: null
      },
      videoHeight: {
        type: String,
        default: '100%'
      }
    },
    data() {
      return {
        videoSourceUrl: null,
        videoShow: false
      }
    },
    // 计算属性
    computed: {},
    // 侦听属性
    watch: {},
    // 实例创建完成执行的钩子
    created() {
      this.$nextTick(() => {
        this.getVideoUrl()
      })
    },
    // 编译好的html挂载到页面完成后执行的事件钩子
    // 在整个实例中只执行一次
    mounted() {
    },
    methods: {
      getVideoUrl() {
        const query = {
          deviceId: this.id,
          deviceType: this.type
        }
        console.log(query)
        if (query.deviceId !== null && query.deviceType !== null) {
          getVideoSource(query).then(res => {
            this.videoSourceUrl = res.data
            if (res.data) {
              this.videoShow = true
              // this.goVideo()
            }
            console.log("视频结果", res)
          })
        } else {
          console.log('id 或者 type 为 null!')
          this.$message.error('id 或者 type 为 null!')
        }
      },
      goVideo() {
        this.$router.push({path: "/app/warn/shipin", query: {url: this.videoSourceUrl}});
      },
    }
  }
</script>

<style scoped>

</style>
