import request from '@/utils/request'

const prefix = '/monitor/device'

/**
 * 获取视频源
 * @param params
 * @returns {AxiosPromise}
 */
export function getVideoSource(params) {
  return request({
    url: prefix + '/getMonitorUrl',
    method: 'get',
    params: params
  })
}
