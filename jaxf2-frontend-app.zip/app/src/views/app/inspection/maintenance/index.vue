<template>
  <div style="background-color: #F4F4F4;height:100%">
    <common-head :is-close="true" title="维保" :scan="isButton === true" @close="back" @scanData="goFillingByScan" />
    <div class="content" style="font-size: 0.3rem">
      <div class="cards-navbar">
        <div class="body_con">
          <div style="margin: 15px 16px 0;font-size: 14px;color:#979797">任务信息:</div>
          <div v-if="taskData != null" class="white-circle">
            <van-row style="margin: 11px 16px 0;padding-bottom: 10px;align-items: center;font-size:14px" type="flex">
              <van-col style="display: flex;flex-direction: column;align-items: stretch;width:100%">
                <span style="color: #333333;margin:8px 0;font-weight: bold">{{ taskData.name }}
                  <span v-if="taskData.state === 0">(未完成)</span>
                  <span v-if="taskData.state === 1">(已完成)</span>
                  <span v-if="taskData.state === 2">(进行中)</span>
                </span>
                <div class="van-hairline--bottom" style="width:100%" />
                <span style="color: #979797;margin:8px 0">任务开始：
                  <span
                    style="color:  #333333;margin-left: 9px"
                  >{{ taskData.startTime }}</span>
                </span>
                <span style="color: #979797;margin:8px 0">任务结束：
                  <span style="color:  #333333;margin-left: 9px">{{ taskData.endTime }}</span>
                </span>
                <span v-if="taskData.state !== 0" style="color: #979797;margin:8px 0">开始时间：
                  <span style="color:  #333333;margin-left: 9px">{{ taskData.checkStartTime }}</span>
                </span>
                <span v-if="taskData.state === 1" style="color: #979797;margin:8px 0">维保人员：
                  <span style="color:  #333333;margin-left: 9px">{{ taskData.checkUserName }}</span>
                </span>
                <span v-if="taskData.state === 1" style="color: #979797;margin:8px 0">结束时间：
                  <span style="color:  #333333;margin-left: 9px">{{ taskData.checkEndTime }}</span>
                </span>
              </van-col>
            </van-row>
          </div>
          <div v-if="checkedList && checkedList.length>0" style="margin: 15px 16px 0;font-size: 14px;color:#979797">已完成列表:</div>
          <van-list
            v-model="checkedLoading"
            :finished="checkedFinished"
            finished-text="没有更多了"
            @load="checkedOnLoad"
          >
            <div class="white-circle">
              <template v-for="(item, index) in checkedList">
                <div :key="index">
                  <div class="checkedList" style="font-size: 14px">
                    <van-row
                      type="flex"
                      justify="space-between"
                      style="padding: 15px 16px 11px;align-content: center;align-items: center;"
                    >
                      <div style="display: flex;align-items: center;">
                        <span style="color: #979797;margin:8px 0">设备编号：
                          <span style="color: #333333;margin-left: 9px;">{{ item.code }}</span>
                        </span>
                      </div>
                      <div class="span_color" style="display: flex;align-items: center;">
                        <van-button
                          v-if="isButton === 'true'"
                          style="border: solid 1px #1989FA;border-radius:5px;height: 30px;width: 80px"
                          @click="goFilling(item)"
                        >
                          <span style="color:#1989FA"> 编辑</span>
                        </van-button>
                        <van-button
                          style="border: solid 1px #979797;border-radius:5px;height: 30px;width: 80px;margin-left: 20px;margin-right: 10px;"
                          @click="goFillingDetails(item)"
                        >
                          <span style="color:#979797"> 详情</span>
                        </van-button>
                      </div>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row style="margin: 11px 16px 0;padding-bottom: 10px;align-items: center;" type="flex">
                      <van-col style="display: flex;flex-direction: column;align-items: stretch;">
                        <!-- <span style="color: #979797;margin:8px 0">设备类型：
                           <span style="color:  #333333;margin-left: 9px">{{ item.typeName }}</span>
                         </span>-->
                        <span v-if="item.areaName" style="color: #979797;margin:8px 0">设备区域：
                          <span style="color:  #333333;margin-left: 9px">{{ item.areaName }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">设备位置：
                          <span style="color:  #333333;margin-left: 9px">{{ item.position }}</span>
                        </span>
                        <span v-if="item.message" style="color: #979797;margin:8px 0">情况说明：
                          <span style="color:  #333333;margin-left: 9px">{{ item.message }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">维保人员：
                          <span style="color:  #333333;margin-left: 9px">{{ item.checkUserName }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">维保时间：
                          <span style="color:  #333333;margin-left: 9px">{{ item.checkTime }}</span>
                        </span>
                      </van-col>
                    </van-row>
                  </div>
                  <div style="height: 3px;background: #f4f4f4" />
                </div>
              </template>
            </div>
          </van-list>
        </div>
        <div v-if="isButton === 'true'" class="bottom" />
        <div v-if="isButton === 'true'" class="bar-footer" style="width: 100%">
          <van-row
            class="button1"
            justify="space-between"
            type="flex"
          >
            <van-button
              style="background: #3E3E3E;height:80%;width:48%"
              class="button"
              @click="onClose"
            >
              结束
            </van-button>
            <van-button style="background: #1989FA;height:80%;width:48%" class="button" @click="onClick">
              检查
            </van-button>
          </van-row>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { taskLogPage } from '@/api/exam/taskLog'
import commonHead from '@/views/app/common/head'
import { taskUpdateById } from '@/api/exam/task'
import store from '@/store'
import { taskDetail } from '@/api/exam/task'

export default {
  name: 'Index',
  components: {
    commonHead
  },
  data() {
    return {
      checkedQuery: {
        checkStatus: 1,
        pageNo: 1,
        pageSize: 10,
        taskId: null
      },
      taskData: null,
      checkedList: [],
      checkedSum: 0,
      checkedLoading: true,
      checkedFinished: false,
      taskId: this.$route.query.taskId,
      unitId: this.$route.query.unitId,
      isButton: this.$route.query.isButton,
      isFill: null,
      isSign: null
    }
  },
  created() {
    this.getCheckedList()
    if (this.$route.query.taskId) {
      this.getTaskDetail()
    }
  },
  methods: {
    getTaskDetail() {
      taskDetail(this.taskId).then(res => {
        this.taskData = res.data
        this.isSign = res.data.isSign
        this.isFill = res.data.isFill
      }).catch(err => {
        console.log('err', err)
      })
    },
    back() {
      this.$router.push({
        path: '/app/inspection/index',
        query: {
          unitId: this.unitId,
          active: 'maintenance'
        }
      })
    },
    /**
       * 结束维保任务
       */
    onClose() {
      const data = {
        id: this.taskId,
        state: 1
      }
      this.$dialog
        .confirm({
          confirmButtonColor: '#1989FA',
          message: "<span style='color:#606060'>确认维保结束</span>"
        }).then(() => {
          store.commit('showLoading')
          taskUpdateById(data).then(res => {
            store.commit('hideLoading')
            if (res.success) {
              this.$router.push({
                path: '/app/inspection/index',
                unitId: this.unitId
              })
            }
          }).catch(err => {
            store.commit('hideLoading')
          })
        }).catch(() => {
          // on cancel
        })
    },
    /**
       * 获取维保任务
       */
    getCheckedList() {
      this.checkedQuery.taskId = this.taskId
      taskLogPage(this.checkedQuery).then(res => {
        this.checkedList = this.checkedList.concat(res.data.rows)
        this.checkedSum = res.data.totalRows
        // 加载状态
        // 结束
        this.checkedLoading = false
        // 数据全部加载完成
        if (this.checkedList.length >= res.data.totalRows) {
          this.checkedFinished = true
        }
      })
    },
    /**
       * 加载
       */
    checkedOnLoad() {
      this.checkedQuery.pageNo++
      this.getCheckedList()
    },
    /**
       * 已检查点位详情
       */
    goFillingDetails(val) {
      this.$router.push({
        path: '/app/inspection/filling/details/index',
        query: {
          taskLogId: val.id,
          isSign: this.isSign,
          isFill: this.isFill
        }
      })
    },
    /**
       * 编辑 表格页面跳转
       */
    goFilling(val) {
      this.$router.push({
        path: '/app/inspection/filling/index',
        query: {
          taskId: val.taskId,
          scanCode: val.code,
          operationType: 'edit',
          isSign: this.isSign,
          isFill: this.isFill
        }
      })
    },
    /**
       * 检查
       */
    onClick() {
      const data = {
        id: this.taskId,
        state: 2
      }
      taskUpdateById(data).then(res => {
        if (res.success) {
          this.$router.push({
            path: '/app/inspection/filling/index',
            query: {
              taskId: this.taskId,
              isSign: this.isSign,
              isFill: this.isFill
            }
          })
        }
      })
    },
    /**
       * 扫描二维码跳转到表格填写页面
       * @param val
       */
    goFillingByScan(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      this.$router.push({
        path: '/app/inspection/filling/index',
        query: {
          operationType: 'scan',
          scanCode: val.code,
          codeType: val.type,
          isSign: this.isSign,
          isFill: this.isFill
        }
      })
    }
  }
}
</script>

<style scoped>

  .checkedList >>> .van-cell__value {
    position: relative;
    overflow: hidden;
    color: #3A3A44;
    text-align: right;
    vertical-align: middle;
    word-wrap: break-word;
  }

  .checkedList >>> .van-cell__title {
    position: relative;
    overflow: hidden;
    color: #979797;
    text-align: left;
    flex: 0.4;
    vertical-align: middle;
    word-wrap: break-word;
  }

  .checked-content >>> .van-cell {
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    padding: 5px 16px;
    overflow: hidden;
    height: 35px;
    color: #323233;
    font-size: 14px;
    line-height: 24px;
    background-color: #fff;
  }
</style>
