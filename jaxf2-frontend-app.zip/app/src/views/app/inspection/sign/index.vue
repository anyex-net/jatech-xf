<template>
  <div style="font-family: PingFang SC Bold;font-size: 14px;">
    <van-popup v-if="endPopupSignShow" v-model="endPopupSignShow" round position="bottom" style="height:360px">
      <div
        style="padding: 14px 16px;width:100%;position: fixed;background-color: #FFFFFF;
      border-radius: 16px 16px 0 0;z-index: 99;"
      >
        <div style="display: flex;align-items: center;justify-content: center;height: 18px;line-height: 18px;">
          <span style="font-weight: bolder;font-size: 18px;color: #606060">检查人员签名</span>
        </div>
        <div style="display: flex;justify-content: flex-end;align-items: center;height: 18px;margin-top: -18px;">
          <van-icon color="#949494" name="cross" size="large" @click="signClose" />
        </div>
      </div>
      <div style="margin:55px 12px 20px;border-radius: 6px;background-color: #FAFAFA;width: 100%">
        <vue-esign
          ref="sign"
          :bg-color.sync="sign.bgColor"
          :height="500"
          :is-crop="sign.isCrop"
          :line-color="sign.lineColor"
          :line-width="sign.lineWidth"
        />
        <van-icon
          class="refresh"
          :name="require('@/assets/preflight_images/refresh.png')"
          size="20"
          @click="handleResetSureSign"
        />
      </div>
      <div style="position: fixed;margin:0 12px;bottom: 10px;left: 0;right: 0;">
        <van-button style="border-radius: 6px" class="but" size="large" type="info" @click="signUpload">确定</van-button>
      </div>

    </van-popup>
  </div>
</template>

<script>
import { sysFileInfoUpload } from '@/api/system/fileManage'

export default {
  name: 'Index',
  components: {},
  props: {
    signShow: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      sign: {
        isCrop: false,
        lineWidth: 6,
        lineColor: '#000000',
        bgColor: ''
      },
      endPopupSignShow: this.signShow
    }
  },
  // 侦听属性
  watch: {
    signShow(newObj, oldObj) {
      this.endPopupSignShow = newObj
    },
    endPopupSignShow(newObj, oldObj) {
      this.$emit('signShowState', newObj)
    },
    immediate: true
  },
  // 实例创建完成执行的钩子
  created() {
  },
  // 编译好的html挂载到页面完成后执行的事件钩子
  // 在整个实例中只执行一次
  mounted() {
  },
  methods: {
    signClose() {
      this.endPopupSignShow = false
      this.handleResetSureSign()
    },
    // 清除签名
    handleResetSureSign() {
      this.$refs.sign.reset()
    },
    // 签名上传
    signUpload() {
      this.$refs.sign.generate().then(res => {
        let randNum = Math.random() * 10000000000000
        randNum = Math.floor(randNum)
        const fileName = randNum + '.png'
        const file = this.dataURLtoFile(res, fileName)
        const fileFormData = new FormData()
        fileFormData.append('file', file)
        sysFileInfoUpload(fileFormData).then((response) => {
          if (response.success) {
            this.$emit('signId', response.data)
            this.endPopupSignShow = false
          }
        }).catch((err) => {
          this.$toast(err + '')
        })
      })
    },
    dataURLtoFile(dataUrl, filename) {
      const arr = dataUrl.split(',')
      const mime = arr[0].match(/:(.*?);/)[1]
      const str = atob(arr[1])
      let n = str.length
      const u8arr = new Uint8Array(n)
      while (n--) {
        u8arr[n] = str.charCodeAt(n)
      }
      return new File([u8arr], filename, { type: mime })
    }
  }
}
</script>

<style scoped>
  .refresh {
    position: fixed;
    float: right;
    padding: 15px;
    margin-top: -50px;
    right: 15px;
  }

  @keyframes run {
    from {
      transform: rotate(360deg);
    }
    to {
      transform: rotate(0deg);
    }
  }

  .refresh:active {
    animation: run 0.4s linear infinite;
  }
</style>
