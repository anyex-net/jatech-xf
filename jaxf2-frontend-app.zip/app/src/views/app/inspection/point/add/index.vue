<template>
  <div id="pointContent">
    <common-head
      :back-img="require('@/assets/images/new/back1.png')"
      :custom-right="true"
      :custom-title="true"
      :is-back="true"
      back-img-style="width: 10px;height: 20px"
      background-color="#FFFFFF"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">点位信息</span>
      </template>
      <template #right>
        <van-button
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF"
          @click="handleSave"
        >保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <div class="card">
          <van-form id="tempForm" ref="tempForm" validate-first @submit="submit">
            <van-field
              v-model="temp.code"
              required
              placeholder="请填写点位编码"
              input-align="right"
              label="点位编码:"
              name="code"
              :rules="rules.code"
              @blur="pointCodeValidator(temp.code)"
            >
              <template #right-icon>
                <scan width="12" @scanData="pointAddScan">
                  <template #icon>
                    <van-icon name="scan" style="font-size: 16px;line-height: inherit;" />
                  </template>
                </scan>
              </template>
            </van-field>
            <my-select
              ref="areaRef"
              :is-bottom="true"
              :options="areaList"
              placeholder="请选择区域"
              filterable
              required
              input-align="right"
              label="区　　域:"
              s-label="name"
              s-value="id"
              :rules="rules.area"
              @confirm="(value)=>{this.temp.areaId = value;}"
            />
            <my-select
              ref="typeRef"
              :is-bottom="true"
              :options="typeColumns"
              placeholder="请选择点位类型"
              filterable
              required
              input-align="right"
              label="点位类型:"
              s-label="name"
              s-value="id"
              :rules="rules.type"
              @confirm="onTypeConfirm"
            />
            <my-select
              ref="codeTypeRef"
              :is-bottom="true"
              :options="codeTypeColumns"
              placeholder="请选择编码类型"
              filterable
              required
              input-align="right"
              label="编码类型:"
              s-label="text"
              s-value="type"
              :rules="rules.codeType"
              @confirm="onCodeTypeConfirm"
            />
            <van-field
              v-model="temp.name"
              label="点位名称:"
              input-align="right"
              placeholder="请填写点位名称"
              name="name"
              required
              :rules="rules.name"
            />
            <van-field
              v-model="temp.position"
              placeholder="请填写设备位置"
              input-align="right"
              label="设备位置:"
              name="position"
              :rules="rules.position"
              required
            />
            <van-field
              v-model="temp.address"
              placeholder="请填写设备地址"
              input-align="right"
              label="设备地址:"
              name="address"
              :rules="rules.address"
              required
            />
            <div style="margin: 10px">
              <base-map-search
                ref="mapSearch"
                :is-edit="this.$route.query.operationType === operationTypes.edit"
                :is-hide="true"
                :latitude="temp.mapLatitude"
                :longitude="temp.mapLongitude"
                :value="temp.address"
                @updateLocation="updateLocation"
              />
            </div>
            <van-field
              v-model="temp.mapLongitude"
              placeholder="请填写经度"
              input-align="right"
              label="经　　度:"
              name="mapLongitude"
            />
            <van-field
              v-model="temp.mapLatitude"
              placeholder="请填写纬度"
              input-align="right"
              label="纬　　度:"
              name="mapLatitude"
            />
          </van-form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import commonHead from '@/views/app/common/head'
import BaseMapSearch from '@/components/Map/baseMapSearch'
import mySelect from '@/views/app/common/my-select/index'
import { checkCodeValidator, checkNameValidator, pointAdd, pointDetail, pointUpdate } from '@/api/exam/point'
import { typeList } from '@/api/exam/type'
import store from '@/store'
import { Toast } from 'vant'
import { areaList } from '@/api/exam/area'
import Scan from '@/views/app/common/scan'

export default {
  name: 'Index',
  components: { commonHead, BaseMapSearch, mySelect, Scan },
  data() {
    return {
      temp: {
        areaId: null,
        unitId: null,
        name: null,
        code: null,
        type: null,
        codeType: null,
        position: null,
        mapLongitude: null,
        mapLatitude: null,
        address: null
      },
      codeTypeColumns: [{ text: 'RFID', type: '0' }, { text: '二维码', type: '1' }],
      typeColumns: [],
      areaList: [],
      rules: {
        area: [{ required: true, message: '' }],
        address: [{ required: true, message: '' }],
        name: [{ required: true, message: '' },
          { validator: this.pointNameValidator, message: '点位名称已存在！' }
        ],
        code: [{ required: true, message: '' },
          { validator: this.pointCodeValidator, message: '点位编码已存在！' }
        ],
        position: [{ required: true, message: '' }],
        type: [{ required: true, message: '' }],
        codeType: [{ required: true, message: '' }]
      },
      unitId: this.$route.query.unitId,
      id: this.$route.query.id,
      operationType: this.$route.query.operationType,
      operationTypes: {
        add: 'add',
        edit: 'edit'
      },
      tempCode: '',
      tempName: ''
    }
  },
  // 侦听属性
  watch: {},
  // 实例创建完成执行的钩子
  created() {
    this.init()
  },
  beforeDestroy() {
  },
  // 编译好的html挂载到页面完成后执行的事件钩子
  // 在整个实例中只执行一次
  mounted() {
  },
  methods: {
    init() {
      this.getTypeList()
      this.getAreaList()
      if (this.operationTypes.edit === this.operationType) {
        this.doSelectInfo()
      }
    },
    getSignUrl() {
      let signLink = ''
      const ua = navigator.userAgent.toLowerCase()
      if (/iphone|ipad|ipod/.test(ua)) {
        signLink = localStorage.getItem('firstUrl')
        if (!signLink) signLink = location.href
      } else {
        signLink = location.href
      }
      return signLink
    },
    pointAddScan(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      this.temp.code = val.code
      Toast.loading('验证中...')
      checkCodeValidator({ code: val.code }).then(res => {
        Toast.clear()
        if (res.data) {
          Toast.fail('点位编码已存在!')
        }
      })
    },
    pointNameValidator(val) {
      if (this.tempName !== this.temp.name) {
        const query = {
          unitId: this.unitId,
          name: val
        }
        return new Promise((resolve) => {
          Toast.loading('验证中...')
          resolve(
            checkNameValidator(query).then(res => {
              Toast.clear()
              return !res.data
            })
          )
        })
      } else {
        return true
      }
    },
    pointCodeValidator(val) {
      if (this.tempCode !== this.temp.code) {
        const query = {
          code: val
        }
        return new Promise((resolve) => {
          Toast.loading('验证中...')
          resolve(
            checkCodeValidator(query).then(res => {
              Toast.clear()
              return !res.data
            })
          )
        })
      } else {
        return true
      }
    },
    submit(values) {
      this.$refs.tempForm.validate().then(() => {
        console.log('校验通过')
        if (this.operationTypes.add === this.operationType) {
          this.doAddInfo()
        }
        if (this.operationTypes.edit === this.operationType) {
          this.doEditInfo()
        }
      }).catch(() => {
        console.log('校验失败')
      })
    },
    handleSave() {
      this.$refs.tempForm.submit()
    },
    /**
       * 查询点位信息
       */
    doSelectInfo() {
      pointDetail({ id: this.id }).then(res => {
        this.temp = res.data
        const codeType = this.codeTypeColumns.find(item => item.type === this.temp.codeType)
        this.temp.codeTypeName = codeType ? codeType.text : ''
        this.$refs.codeTypeRef.value = this.temp.codeTypeName
        this.$refs.areaRef.value = this.temp.areaName
        this.$refs.typeRef.value = this.temp.typeName
        this.$nextTick(() => {
          this.$refs.mapSearch.updateAddress(this.temp.address, this.temp.mapLongitude, this.temp.mapLatitude)
        })
        this.tempCode = res.data.code
        this.tempName = res.data.name
      })
    },
    /**
       * 编辑点位信息
       */
    doEditInfo() {
      store.commit('showLoading')
      pointUpdate(this.temp).then(res => {
        if (res.success) {
          this.$toast({
            type: 'success',
            message: '保存成功！'
          })
          const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
          const path = routeArray[routeArray.length - 1]
          this.$router.push(path)
        }
        store.commit('hideLoading')
      }).catch(err => {
        this.$toast(err + '')
      })
    },
    /**
       * 添加点位信息
       */
    doAddInfo() {
      store.commit('showLoading')
      this.temp.unitId = this.unitId
      pointAdd(this.temp).then(res => {
        if (res.success) {
          this.$toast({
            type: 'success',
            message: '添加成功！'
          })
          const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
          const path = routeArray[routeArray.length - 1]
          this.$router.push(path)
        }
        store.commit('hideLoading')
      }).catch(err => {
        this.$toast(err + '')
      })
    },
    /**
       * 获取类型
       */
    getTypeList() {
      this.typeColumns = []
      typeList({ unitId: this.unitId }).then(res => {
        this.typeColumns = res.data
      })
    },
    /**
       * 获取区域列表
       */
    getAreaList() {
      this.areaList = []
      areaList({ unitId: this.unitId }).then(res => {
        this.areaList = res.data
      })
    },
    /**
       * 获取编码类型
       * @param value
       */
    onCodeTypeConfirm(value) {
      this.temp.codeType = value
    },
    /**
       * 确认类型
       * @param value
       */
    onTypeConfirm(value) {
      this.temp.type = value
    },
    /**
       * 更新地图位置
       * @param mapLongitude
       * @param mapLatitude
       * @param address
       */
    updateLocation(mapLongitude, mapLatitude, address) {
      this.$nextTick(() => {
        this.temp.mapLongitude = mapLongitude
        this.temp.mapLatitude = mapLatitude
        this.temp.address = address
      })
    }
  }
}
</script>

<style scoped>
  #pointContent {
    font-family: PingFang SC Bold;
    font-size: 14px;
  }

  #tempForm ::v-deep .van-cell__title {
    color: #979797 !important;
  }
</style>
