<template>
  <div class="body_">
    <common-head
      :back-img="require('@/assets/images/new/back1.png')"
      :is-back="true"
      :custom-title="true"
      :custom-right="true"
      back-img-style="width: 10px;height: 20px"
      background-color="#FFFFFF"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">{{ operationType === 'handle' ? '隐患处理' : '隐患信息' }}</span>
      </template>
      <template v-if="operationType === 'handle'" #right>

        <van-button
          v-if="saveState"
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #1989FA"
          @click="handleSave"
        >提交
        </van-button>
        <van-button
          v-else
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #BDBDBD"
          disabled
        >提交
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <div class="white-circle">
          <div class="danger">
            <van-cell title="设备编号：" :value="temp.code" />
            <van-cell title="设备名称：" :value="temp.name" />
            <van-cell title="设备位置：" :value="temp.position" />
            <van-cell title="隐患大类：" :value="temp.dangerTypeParentName" />
            <van-cell title="隐患小类：" :value="temp.dangerTypeSubName" />
            <van-cell title="隐患描述：" :value="temp.dangerTypeMessage" />
            <div v-show="temp.checkImg" style="background-color: #FFFFFF !important;padding: 10px 15px">
              <van-image
                v-for="(item,index) in temp.checkImg"
                :key="index"
                width="60"
                height="60"
                :src="item"
                @click="sceneImg(temp.checkImg,index)"
              />
            </div>
          </div>
          <div v-if="operationType === 'select'">
            <van-cell title="是否是隐患：" :value="temp.isDanger ? '是' : '否'" />
            <van-cell title="是否转交维保公司：" :value="temp.isExam ? '是' : '否'" />
            <van-cell title="处理人：" :value="temp.solveName" />
            <van-cell title="处理时间：" :value="temp.solveTime" />
            <van-cell title="处理描述：" :value="temp.dangersSolvedDescribe" />
            <div v-show="temp.dangersSolvedImg" style="padding: 10px 15px">
              <van-image
                v-for="(item,index) in temp.dangersSolvedImg"
                :key="index"
                width="60"
                height="60"
                :src="item"
                @click="sceneImg(temp.dangersSolvedImg,index)"
              />
            </div>
            <div v-if="temp.isParts" style="background-color: #FFFFFF !important;">
              <van-cell title-style="color:#979797" title="配件列表" />
              <div v-for="(item,index) in partsList" :key="index">
                <van-swipe-cell>
                  <van-cell-group style="margin-bottom: 10px">
                    <van-cell title-style="color:#979797" title="配件类型" :value="item.partTypeName" />
                    <van-cell title-style="color:#979797" title="配件名称" :value="item.partName" />
                    <van-cell title-style="color:#979797" title="数量" :value="item.quantity" />
                  </van-cell-group>
                </van-swipe-cell>
              </div>
            </div>
          </div>
          <div v-if="operationType === 'handle'" class="white-circle" style="background-color: #FFFFFF">
            <van-row v-if="Number(userInfo.unitType) !== 3" type="flex" justify="space-between" style="align-items: center;padding: 10px 15px">
              <span style="font-size: 16px;color: #333333;font-weight: bolder">是否隐患？</span>
              <van-row type="flex" justify="space-between">
                <custom-switch v-model="isDangerButton" />
              </van-row>
            </van-row>
            <van-row v-if="Number(userInfo.unitType) !== 3 && isDangerButton" type="flex" justify="space-between" style="align-items: center;padding: 10px 15px">
              <span style="font-size: 16px;color: #333333;font-weight: bolder">是否转交给维保公司？</span>
              <van-row type="flex" justify="space-between">
                <custom-switch v-model="isExamButton" />
              </van-row>
            </van-row>
            <van-row v-if="Number(userInfo.unitType) === 3 && isDangerButton" type="flex" justify="space-between" style="align-items: center;padding: 10px 15px">
              <span style="font-size: 16px;color: #333333;font-weight: bolder">是否退回？</span>
              <van-row type="flex" justify="space-between">
                <custom-switch v-model="isReturnButton" />
              </van-row>
            </van-row>
            <van-row v-if="isDangerButton && !isExamButton && !isReturnButton" type="flex" justify="space-between" style="align-items: center;padding: 10px 15px">
              <span style="font-size: 16px;color: #333333;font-weight: bolder">是否更换配件？</span>
              <van-row type="flex" justify="space-between">
                <custom-switch v-model="isPartsButton" />
              </van-row>
            </van-row>
            <div v-if="isPartsButton" style="padding: 11px 16px;background-color: #FFFFFF">
              <div style="padding: 11px 16px;background-color: #FFFFFF">
                <van-row type="flex" justify="space-between">
                  <span style="font-size: 16px;color: #333333;font-weight: bolder">配件列表</span>
                  <van-button
                    native-type="button"
                    type="info"
                    style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;"
                    @click="partsShow = true"
                  >新增
                  </van-button>
                </van-row>
              </div>
              <div style="margin: 11px 11px;background-color: #F4F4F4">
                <div v-for="(item,index) in partsList" :key="index">
                  <van-swipe-cell>
                    <van-cell-group style="margin-bottom: 10px">
                      <van-cell title-style="color:#979797" title="配件类型" :value="item.partTypeName" />
                      <van-cell title-style="color:#979797" title="配件名称" :value="item.partName" />
                      <van-cell title-style="color:#979797" title="数量" :value="item.quantity" />
                    </van-cell-group>
                    <template #right>
                      <van-button
                        style="height: 100%"
                        square
                        type="danger"
                        text="删除"
                        @click="delParts(index)"
                      />
                    </template>
                  </van-swipe-cell>
                </div>
              </div>
            </div>
            <van-form ref="dangerForm" @submit="onSubmit">
              <div v-if="formTextState" style="padding: 11px 16px;background-color: #FFFFFF">
                <van-field
                  v-model="temp.dangersSolvedDescribe"
                  :autosize="true"
                  input-align="left"
                  maxlength="50"
                  name="dangersSolvedDescribe"
                  placeholder="请输入处理描述"
                  rows="2"
                  show-word-limit
                  type="textarea"
                  style="background-color: #FAFAFA;border-radius: 6px;"
                  :rules="[{ required: true, message: '请输入处理描述' }]"
                />
                <van-field name="dangersSolvedImg" style="padding:10px 0">
                  <template #input>
                    <van-uploader
                      v-model="temp.dangersSolvedImg"
                      :after-read="offlineUpload"
                      preview-size="60"
                      style="padding-top: 10px;"
                    />
                  </template>
                </van-field>
              </div>
            </van-form>
          </div>
        </div>
      </div>
    </div>
    <van-popup v-model="partsShow" round style="width: 80%;padding: 10px 0 0 5px">
      <van-form ref="partsForm" validate-first @submit="addParts">
        <van-field
          v-model="partsInfo.partTypeName"
          placeholder="请选择配件类型"
          clickable
          input-align="right"
          label="配件类型"
          name="partTypeName"
          required
          right-icon="arrow"
          :rules="[{ required: true, message: '请选择配件类型' }]"
          @click="onPartsTypeShow"
        />
        <van-field
          v-model="partsInfo.partName"
          placeholder="请选择配件"
          clickable
          input-align="right"
          label="配件"
          name="parts"
          required
          right-icon="arrow"
          :rules="[{ required: true, message: '请选择配件' }]"
          @click="onPartsShow"
        />
        <van-field name="quantity" label="数量" required input-align="right">
          <template #input>
            <van-stepper v-model="partsInfo.quantity" />
          </template>
        </van-field>
        <div style="margin: 16px;">
          <van-button round block type="info" native-type="submit">提交</van-button>
        </div>
      </van-form>
    </van-popup>
    <van-popup v-model="partsType.show" position="bottom" round>
      <van-picker
        :columns="partsType.columns"
        value-key="name"
        :loading="partsType.loading"
        show-toolbar
        @cancel="partsType.show = false"
        @confirm="onPartsTypeConfirm"
      />
    </van-popup>
    <van-popup v-model="parts.show" position="bottom" round>
      <van-picker
        :columns="parts.columns"
        value-key="name"
        :loading="parts.loading"
        show-toolbar
        @cancel="parts.show = false"
        @confirm="onPartsConfirm"
      />
    </van-popup>
  </div>
</template>

<script>

import { sysFileInfoUpload } from '@/api/system/fileManage'
import { dangerDetail, dangerHandle } from '@/api/exam/danger'
import commonHead from '@/views/app/common/head'
import { ImagePreview } from 'vant'
import CustomSwitch from '@/components/Switch'
import store from '@/store'
import { partTypeList } from '@/api/exam/partType'
import { partList } from '@/api/exam/part'

export default {
  components: {
    commonHead, CustomSwitch
  },
  data() {
    return {
      temp: {
        id: null,
        address: null,
        solveUser: null,
        solveName: null,
        code: null,
        name: null,
        position: null,
        checkImg: [],
        isDanger: true,
        isExam: true,
        solveTime: null,
        dangersSolvedDescribe: '',
        dangersSolvedImgIds: null,
        dangersSolvedImg: [],
        dangerTypeParentName: null,
        dangerTypeSubName: null,
        dangerTypeMessage: null
      },
      id: this.$route.query.id,
      operationType: this.$route.query.operationType,
      isDangerButton: true,
      isExamButton: false,
      isReturnButton: false,
      isPartsButton: false,
      partsShow: false,
      partsInfo: {
        quantity: 1,
        dangerId: null,
        partId: null,
        partName: null,
        partTypeId: null,
        partTypeName: null,
        unitId: null
      },
      partsList: [],
      partsType: {
        loading: true,
        show: false,
        columns: []
      },
      parts: {
        loading: true,
        show: false,
        columns: []
      },
      formTextState: false,
      saveState: false,
      unitId: null,
      // 隐患处理
      dangerHandleData: {
        id: null,
        isDanger: null,
        isExam: null,
        isParts: null,
        partsList: null,
        dangersSolvedDescribe: null,
        dangersSolvedImgIds: null,
        isReturn: null,
        isText: null
      }
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  watch: {
    isDangerButton(newVal, odlObj) {
      this.initSolvedContent()
      this.isExamButton = false
      this.isReturnButton = false
      this.isPartsButton = false
      this.initFormTextState()
      this.saveState = !newVal
    },
    isExamButton(newVal, odlObj) {
      this.initSolvedContent()
      if (newVal) {
        this.isReturnButton = false
        this.isPartsButton = false
      }
      this.initFormTextState()
      if (this.isDangerButton) {
        this.saveState = newVal
      }
    },
    isReturnButton(newVal, odlObj) {
      this.initSolvedContent()
      if (newVal) {
        this.isPartsButton = false
      }
      this.initFormTextState()
      this.saveState = newVal
    },
    isPartsButton(newVal, odlObj) {
      this.temp.partsList = []
      this.initFormTextState()
    },
    'temp.dangersSolvedDescribe'(newVal, odlObj) {
      if (this.isDangerButton && !this.isExamButton) {
        this.saveState = newVal !== null && newVal !== '' && this.formTextState === true
      }
    },
    immediate: true
  },
  created() {
    this.init()
  },
  methods: {
    initFormTextState() {
      if (Number(this.userInfo.unitType) === 3) {
        this.formTextState = !this.isReturnButton
      } else {
        this.formTextState = this.isDangerButton && !this.isExamButton
      }
    },
    offlineUpload(file) {
      store.commit('showLoading')
      file.status = 'uploading'
      file.message = '上传中...'
      const content = file.file
      const formData = new FormData()
      formData.append('file', content)
      sysFileInfoUpload(formData).then((response) => {
        store.commit('hideLoading')
        if (response.success) {
          file.fileId = response.data
          file.status = 'success'
          file.message = ''
        } else {
          file.status = 'failed'
          file.message = '上传失败'
        }
      }).catch((err) => {
        store.commit('hideLoading')
        this.$toast(err + '')
      })
    },
    addParts(values) {
      if (values) {
        this.partsInfo.dangerId = this.temp.id
        this.partsInfo.unitId = this.unitId
        const index = this.partsList.findIndex(e => e.partId === this.partsInfo.partId)
        if (index === -1) {
          this.partsList.push(this.partsInfo)
        } else {
          this.partsList[index].quantity += this.partsInfo.quantity
        }
        this.partsInfo = {
          quantity: 1,
          dangerId: null,
          partId: null,
          partName: null,
          partTypeId: null,
          partTypeName: null,
          unitId: null
        }
        this.partsShow = false
      }
    },
    delParts(index) {
      this.partsList.splice(index, 1)
    },
    /**
       * 获取配件类型
       */
    onPartsTypeShow() {
      this.partsType.show = true
      store.commit('showLoading')
      partTypeList({ unitId: this.unitId }).then(res => {
        store.commit('hideLoading')
        if (res.success) {
          if (res.data !== null) {
            this.partsType.columns = res.data
            this.partsType.loading = false
          } else {
            this.$toast({
              type: 'warning',
              message: '无数据'
            })
          }
        }
      }).catch(err => {
        store.commit('hideLoading')
        this.$toast(err + '')
      })
    },
    /**
       * 确认配件类型
       * @param value
       */
    onPartsTypeConfirm(value) {
      this.partsInfo.partTypeId = value.id
      this.partsInfo.partTypeName = value.name
      this.partsInfo.partId = null
      this.partsInfo.partName = null
      this.partsType.show = false
    },
    /**
       * 获取配件
       */
    onPartsShow() {
      if (this.partsInfo.partTypeId === null) {
        this.$toast({
          type: 'warning',
          message: '请先选择配件类型'
        })
        return
      }
      this.parts.show = true
      store.commit('showLoading')
      partList({ unitId: this.unitId, typeId: this.partsInfo.partTypeId }).then(res => {
        store.commit('hideLoading')
        if (res.success) {
          if (res.data !== null) {
            this.parts.columns = res.data
            this.parts.loading = false
          } else {
            this.$toast({
              type: 'warning',
              message: '无数据'
            })
          }
        }
      }).catch(err => {
        store.commit('hideLoading')
        this.$toast(err + '')
      })
    },
    /**
       * 确认配件
       * @param value
       */
    onPartsConfirm(value) {
      this.partsInfo.partId = value.id
      this.partsInfo.partName = value.name
      this.parts.show = false
    },
    initSolvedContent() {
      this.temp.dangersSolvedDescribe = ''
      this.temp.dangersSolvedImgIds = null
      this.temp.dangersSolvedImg = []
    },
    handleSave() {
      this.$refs.dangerForm.submit()
    },
    /**
       * 初始化
       */
    init() {
      this.getInfo()
    },
    /**
       * 获取点位信息
       */
    async getInfo() {
      store.commit('showLoading')
      await dangerDetail(this.id).then(res => {
        store.commit('hideLoading')
        this.temp.id = res.data.id
        this.temp.position = res.data.position
        this.temp.name = res.data.pointName
        this.temp.code = res.data.code
        this.temp.dangerTypeParentName = res.data.dangerTypeName
        this.temp.dangerTypeSubName = res.data.dangerTypeItemName
        this.temp.dangerTypeMessage = res.data.dangerTypeMessage
        this.temp.isSolve = res.data.isSolve
        this.temp.dangersSolvedDescribe = res.data.dangersSolvedDescribe
        this.temp.checkImg = res.data.checkImgList ? res.data.checkImgList.map(e => this.$host + e) : []
        this.temp.dangersSolvedImg = res.data.dangersSolvedImgList ? res.data.dangersSolvedImgList.map(e => this.$host + e) : []
        this.temp.solveName = res.data.solveName
        this.temp.solveTime = res.data.solveTime
        this.temp.isExam = res.data.isExam
        this.unitId = res.data.unitId
        this.temp.isParts = res.data.isParts
        this.partsList = res.data.partsList && true && res.data.partsList.length > 0 ? res.data.partsList : []
        if (this.temp.isSolve) {
          this.temp.isDanger = res.data.isDanger
        }
        if (Number(this.userInfo.unitType) !== 3 && !this.temp.isSolve && this.temp.isDanger) {
          this.initSolvedContent()
          this.formTextState = true
        }
        if (Number(this.userInfo.unitType) === 3 && !this.temp.isSolve && this.temp.isDanger) {
          this.isReturnButton = !this.temp.isExam
          this.initSolvedContent()
          this.formTextState = true
        }
      }).catch(err => {
        console.log(err)
        store.commit('hideLoading')
      })
    },
    // 图片预览
    sceneImg(images, index) {
      ImagePreview({
        images: images, // 需要预览的图片 URL 数组
        showIndex: true, // 是否显示页码
        loop: false, // 是否开启循环播放
        startPosition: index // 图片预览起始位置索引
      })
    },
    /**
       * 提交
       */
    onSubmit(values) {
      this.dangerHandleData.id = this.temp.id
      this.dangerHandleData.isDanger = this.isDangerButton
      this.dangerHandleData.isParts = this.isPartsButton
      this.dangerHandleData.isReturn = this.isReturnButton
      this.dangerHandleData.isExam = this.isExamButton
      this.dangerHandleData.isText = this.formTextState
      if (this.isPartsButton) {
        if (this.partsList.length === 0) {
          return this.$toast({
            type: 'warning',
            message: '请添加配件'
          })
        } else {
          this.dangerHandleData.partsList = this.partsList
        }
      }
      if (this.formTextState) {
        if (this.temp.dangersSolvedImg) {
          if (this.temp.dangersSolvedImg.filter(item => item.status === 'uploading').length !== 0) {
            return this.$toast({
              type: 'warning',
              message: '处理图片正在上传'
            })
          }
          this.dangerHandleData.dangersSolvedImgIds = this.temp.dangersSolvedImg.filter(item => item.status === 'success').map(i => i.fileId).join(',')
        }
        if (this.temp.dangersSolvedDescribe === '') {
          return this.$toast({
            type: 'warning',
            message: '请输入处理描述'
          })
        } else {
          this.dangerHandleData.dangersSolvedDescribe = this.temp.dangersSolvedDescribe
        }
      }
      store.commit('showLoading')
      dangerHandle(this.dangerHandleData).then(res => {
        if (res.success) {
          store.commit('hideLoading')
          this.goBackMethod()
        }
      }).catch(err => {
        store.commit('hideLoading')
        this.$toast(err + '')
      })
    },
    // 返回
    goBackMethod() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
  .body_ {
    font-family: PingFang SC Bold;
    font-size: 14px;
  }

  .button_active_before ::v-deep .van-button__text {
    font-family: PingFang SC Bold;
    color: #333333;
  }

  .button_active ::v-deep .van-button__text {
    font-family: PingFang SC Bold;
    color: #FFFFFF;
  }

  .danger >>> .van-cell__title {
    color: #979797;
    font-size: 14px;
    line-height: 24px;
  }

  .danger >>> .van-cell__value {
    color: #333333;
    font-size: 14px;
    line-height: 24px;
  }

</style>
