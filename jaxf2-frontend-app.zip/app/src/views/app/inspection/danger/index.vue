<template>
  <div class="body_">
    <common-head
      :back-img="require('@/assets/images/new/back1.png')"
      :is-back="true"
      :custom-title="true"
      :custom-right="true"
      back-img-style="width: 10px;height: 20px"
      background-color="#FFFFFF"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">隐患上报</span>
      </template>
      <template #right>
        <van-button
          v-if="temp.code === null || temp.code === ''"
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #BDBDBD"
          disabled
        >提交
        </van-button>
        <van-button
          v-else
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #1989FA"
          @click="handleSave"
        >提交
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <van-form ref="dangerForm" @submit="onSubmit">
          <div style="margin: 12px 10px;background-color: #FFFFFF">
            <div v-if="scanShow">
              <van-row
                type="flex"
                justify="space-between"
                style="height: 123px;align-items: center;padding: 0 15px 0 30px"
              >
                <van-row type="flex" style="align-items: center;">
                  <scan @scanData="dangerIndexScan">
                    <template #icon>
                      <van-icon name="scan" color="#1989FA" size="40" style="line-height: inherit;" />
                    </template>
                  </scan>
                  <div
                    style="margin-left: 26px;display: flex;flex-direction: column;align-items: flex-start;
                font-size: 14px;color: #1989FA;font-weight: bolder;"
                  >
                    <span>扫一扫</span>
                    <span>获取设备信息</span>
                  </div>
                </van-row>
                <div
                  class="span_color"
                  style="display: flex;align-items: center;color: #979797"
                  @click="scanShow = false"
                >
                  <span>二维码失效</span>
                  <van-icon name="arrow" />
                </div>
              </van-row>
              <div
                style="margin: 10px 17px;border-bottom: 1px solid #F3F3F3"
                class="van-hairline--bottom"
              />
            </div>
            <div style="padding: 10px 16px">
              <div v-if="!scanShow">
                <van-field
                  v-model="temp.code"
                  placeholder="请输入设备编号"
                  input-align="right"
                  label="设备编号"
                  name="code"
                  required
                  @blur="setCode()"
                >
                  <template #right-icon>
                    <scan width="12" @scanData="dangerIndexScan">
                      <template #icon>
                        <van-icon name="scan" style="font-size: 16px;line-height: inherit;" />
                      </template>
                    </scan>
                  </template>
                </van-field>
                <van-field
                  v-model="temp.name"
                  placeholder="请输入设备名称"
                  input-align="right"
                  label="设备名称"
                  name="name"
                  required
                />
                <van-field
                  v-model="temp.position"
                  placeholder="请输入设备位置"
                  input-align="right"
                  label="设备位置"
                  name="position"
                />
              </div>
              <van-field
                v-model="temp.dangerTypeParentName"
                placeholder="请输入隐患大类"
                clickable
                input-align="right"
                label="隐患大类"
                name="generalCategory"
                required
                readonly
                right-icon="arrow"
                @click="onParentShow"
              />
              <van-popup v-model="dangerTypeParent.show" position="bottom" round>
                <van-picker
                  :columns="dangerTypeParent.columns"
                  value-key="name"
                  :loading="dangerTypeParent.loading"
                  show-toolbar
                  @cancel="dangerTypeParent.show = false"
                  @confirm="onDangerTypeParentConfirm"
                />
              </van-popup>
              <van-field
                v-model="temp.dangerTypeSubName"
                placeholder="请输入隐患小类"
                clickable
                input-align="right"
                label="隐患小类"
                name="type"
                required
                readonly
                right-icon="arrow"
                @click="onSubShow"
              />
              <van-popup v-model="dangerTypeSub.show" position="bottom" round>
                <van-picker
                  :columns="dangerTypeSub.columns"
                  :loading="dangerTypeSub.loading"
                  value-key="name"
                  show-toolbar
                  @cancel="dangerTypeSub.show = false"
                  @confirm="onDangerTypeSubConfirm"
                />
              </van-popup>
              <van-field
                v-model="temp.dangerTypeMessage"
                placeholder="请输入描述"
                input-align="left"
                maxlength="50"
                name="dangerTypeMessage"
                rows="2"
                show-word-limit
                type="textarea"
                style="background-color: #FAFAFA;border-radius: 6px;margin-top: 10px;"
              />
              <van-field name="checkImg" style="padding:10px 0">
                <template #input>
                  <van-uploader
                    v-model="temp.checkImg"
                    :after-read="offlineUpload"
                    preview-size="60"
                    style="padding-top: 10px;"
                  />
                </template>
              </van-field>
              <van-field
                input-align="right"
                label="是否当场处理"
                name="isSolve"
                style="padding: 10px 0"
              >
                <template #input>
                  <van-switch
                    v-model="temp.isSolve"
                    :active-value="true"
                    :inactive-value="false"
                    @change="()=>{if(!temp.isSolve) {this.temp.dangersSolvedDescribe = ''}}"
                  />
                </template>
              </van-field>
              <div v-if="temp.isSolve">
                <van-field
                  v-model="temp.dangersSolvedDescribe"
                  :autosize="true"
                  input-align="left"
                  maxlength="50"
                  name="dangersSolvedDescribe"
                  placeholder="请输入描述"
                  rows="2"
                  show-word-limit
                  type="textarea"
                  style="background-color: #FAFAFA;border-radius: 6px;margin-top: 10px;"
                />
                <van-field name="dangersSolvedImg" style="padding:10px 0">
                  <template #input>
                    <van-uploader
                      v-model="temp.dangersSolvedImg"
                      :after-read="offlineUpload"
                      preview-size="60"
                      style="padding-top: 10px;"
                    />
                  </template>
                </van-field>
              </div>
              <van-field v-if="false" input-align="right" label="是否隐患" name="isDanger">
                <template #input>
                  <van-switch
                    v-model="temp.isDanger"
                    :active-value="true"
                    :inactive-value="false"
                  />
                </template>
              </van-field>
            </div>
          </div>
        </van-form>
      </div>
    </div>
  </div>
</template>

<script>

import { sysFileInfoUpload } from '@/api/system/fileManage'
import { dangerSave } from '@/api/exam/danger'
import { getInfoByCodeAndUnitId } from '@/api/exam/point'
import { dangerTypeList } from '@/api/exam/dangerType'
import commonHead from '@/views/app/common/head'
import store from '@/store'
import Scan from '@/views/app/common/scan'

export default {
  components: {
    commonHead, Scan
  },
  data() {
    return {
      title: '隐患上报',
      scanShow: true,
      temp: {
        code: null,
        name: null,
        pointId: null,
        checkImgIds: null,
        checkImg: [],
        isSolve: false,
        dangersSolvedImgIds: null,
        dangersSolvedImg: [],
        dangersSolvedDescribe: null,
        dangerTypeParentId: null,
        dangerTypeParentName: null,
        dangerTypeSubId: null,
        dangerTypeSubName: null,
        dangerTypeMessage: null,
        unitId: this.$route.query.unitId,
        taskLineId: this.$route.query.taskLineId
      },
      dangerTypeParent: {
        loading: true,
        show: false,
        columns: []
      },
      dangerTypeSub: {
        loading: true,
        show: false,
        columns: []
      },
      codeType: null,
      codeAndType: [
        { code: 0, type: 'nfc', name: 'NFC' },
        { code: 1, type: 'barcode', name: '二维码' }
      ],
      isScanCodeType: false
    }
  },
  computed: {},
  created() {
  },
  beforeDestroy() {
  },
  methods: {
    offlineUpload(file) {
      store.commit('showLoading')
      file.status = 'uploading'
      file.message = '上传中...'
      const content = file.file
      const formData = new FormData()
      formData.append('file', content)
      sysFileInfoUpload(formData).then((response) => {
        store.commit('hideLoading')
        if (response.success) {
          file.fileId = response.data
          file.status = 'success'
          file.message = ''
        } else {
          file.status = 'failed'
          file.message = '上传失败'
        }
      }).catch((err) => {
        store.commit('hideLoading')
        this.$toast(err + '')
      })
    },
    handleSave() {
      this.$refs.dangerForm.submit()
    },
    getSignUrl() {
      let signLink = ''
      const ua = navigator.userAgent.toLowerCase()
      if (/iphone|ipad|ipod/.test(ua)) {
        signLink = localStorage.getItem('firstUrl')
        if (!signLink) signLink = location.href
      } else {
        signLink = location.href
      }
      return signLink
    },
    dangerIndexScan(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      this.temp.code = val.code
      this.codeType = val.type === 'wx' ? 'barcode' : val.type
      this.scanShow = false
      this.isScanCodeType = true
      this.setCode()
    },
    reset() {
      this.temp = {
        code: null,
        name: null,
        pointId: null,
        checkImgIds: null,
        checkImg: [],
        isSolve: false,
        dangersSolvedImgIds: null,
        dangersSolvedImg: [],
        dangersSolvedDescribe: null,
        dangerTypeParentId: null,
        dangerTypeParentName: null,
        dangerTypeSubId: null,
        dangerTypeSubName: null,
        dangerTypeMessage: null,
        unitId: this.$route.query.unitId,
        taskLineId: this.$route.query.taskLineId
      }
    },
    setCode() {
      const qrCode = this.temp.code
      this.reset()
      this.temp.code = qrCode
      this.getInfo()
    },
    /**
       * 获取点位信息
       */
    getInfo() {
      const data = {
        code: this.temp.code,
        unitId: this.temp.unitId
      }
      getInfoByCodeAndUnitId(data).then(res => {
        if (res.success) {
          if (res.data !== null) {
            if (this.isScanCodeType) {
              this.isScanCodeType = false
              const tempCodeType = this.codeAndType.find(item => item.code === Number(res.data.codeType))
              if (this.codeType !== tempCodeType.type) {
                return this.$toast('请使用' + tempCodeType.name)
              }
            }
            this.temp.position = res.data.position
            this.temp.code = res.data.code
            this.temp.name = res.data.name
            this.temp.pointId = res.data.id
          } else {
            this.$toast({
              type: 'warning',
              message: '此设备不属于当前单位'
            })
          }
        }
      })
    },
    /**
       * 获取隐患大类
       */
    onParentShow() {
      this.dangerTypeParent.show = true
      dangerTypeList({ parentId: 0, unitId: this.$route.query.unitId }).then(res => {
        if (res.success) {
          if (res.data !== null) {
            this.dangerTypeParent.columns = res.data
            this.dangerTypeParent.loading = false
          } else {
            this.$toast({
              type: 'warning',
              message: '无数据'
            })
          }
        }
      })
    },
    /**
       * 确认隐患大类类型
       * @param value
       */
    onDangerTypeParentConfirm(value) {
      this.temp.dangerTypeParentName = value.name
      this.temp.dangerTypeParentId = value.id
      this.dangerTypeParent.show = false
      this.temp.dangerTypeSubName = null
    },
    /**
       * 获取隐患小类
       */
    onSubShow() {
      if (this.temp.dangerTypeParentId !== null) {
        this.dangerTypeSub.show = true
        dangerTypeList({ parentId: this.temp.dangerTypeParentId }).then(res => {
          if (res.success) {
            if (res.data !== null) {
              this.dangerTypeSub.columns = res.data
              this.dangerTypeSub.loading = false
            } else {
              this.$toast({
                type: 'warning',
                message: '无数据'
              })
            }
          }
        })
      } else {
        this.$toast({
          type: 'warning',
          message: '请先选择隐患大类'
        })
      }
    },
    /**
       * 确认隐患小类类型
       * @param value
       */
    onDangerTypeSubConfirm(value) {
      this.temp.dangerTypeSubName = value.name
      this.temp.dangerTypeSubId = value.id
      this.dangerTypeSub.show = false
    },
    /**
       * 提交
       */
    onSubmit(values) {
      if (this.temp.pointId !== null) {
        if (this.temp.checkImg) {
          if (this.temp.checkImg.find(item => item.status === 'uploading')) {
            this.$toast('描述图片正在上传')
            return
          }
          this.temp.checkImgIds = this.temp.checkImg.filter(item => item.status === 'success').map(i => i.fileId).join(',')
        }
        if (this.temp.dangersSolvedImg) {
          if (this.temp.dangersSolvedImg.find(item => item.status === 'uploading')) {
            this.$toast('处理图片正在上传')
            return
          }
          this.temp.dangersSolvedImgIds = this.temp.dangersSolvedImg.filter(item => item.status === 'success').map(i => i.fileId).join(',')
        }
        store.commit('showLoading')
        dangerSave(this.temp).then(res => {
          store.commit('hideLoading')
          if (res.success) {
            this.$toast({
              type: 'success',
              message: '操作成功'
            })
            this.goBackMethod()
          }
        }).catch(err => {
          console.log(err)
          store.commit('hideLoading')
        })
      } else {
        this.$toast({
          type: 'warning',
          message: '请扫描设备'
        })
      }
    },
    // 图片处理
    afterRead(file) {
      file.status = 'uploading'
      file.message = '上传中...'
      const content = file.file
      const data = new FormData()
      data.append('file', content)
      sysFileInfoUpload(data).then((response) => {
        if (response.success) {
          file.fileId = response.data
          file.status = 'success'
          file.message = ''
        } else {
          file.status = 'failed'
          file.message = '上传失败'
        }
      }).catch((err) => {
        this.$toast(err + '')
      })
    },
    // 返回
    goBackMethod() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>
  .body_ {
    font-family: PingFang SC Bold;
    font-size: 14px;
  }

  .butDiv_ {
    text-align: center;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 0.3rem 40px;
    color: #9e9ea6;
    background-color: white;
    z-index: 99;
  }

  .but {
    border-radius: 10px;
    height: 40px;
  }

  .body_div {
    margin: 10px 10px 80px 10px;
  }

  .form_div1 {
    box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
  }

  .form_div2 {
    /*margin-top: 10px;*/
    background-color: #fff;
    box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
  }
</style>
