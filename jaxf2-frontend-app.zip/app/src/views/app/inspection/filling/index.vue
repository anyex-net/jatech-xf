<template>
  <div style="font-family: PingFang SC Bold;font-size: 14px;">
    <common-head
      :back-img="require('@/assets/images/new/back1.png')"
      :is-back="true"
      :custom-title="true"
      :custom-right="true"
      back-img-style="width: 10px;height: 20px"
      background-color="#FFFFFF"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">表格填写</span>
      </template>
      <template #right>
        <van-button
          v-if="temp.code === null || temp.code === ''"
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #BDBDBD"
          disabled
        >提交
        </van-button>
        <van-button
          v-else
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #1989FA"
          @click="handleSave"
        >提交
        </van-button>
      </template>
    </common-head>

    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <van-form id="fillForm" ref="fillForm" validate-first @submit="onSubmit">
          <div style="margin: 12px 10px;background-color: #FFFFFF">
            <div v-if="scanShow">
              <van-row
                type="flex"
                justify="space-between"
                style="height: 123px;align-items: center;padding: 0 15px 0 30px"
              >
                <van-row type="flex" style="align-items: center;">
                  <scan @scanData="fillingIndexScan">
                    <template #icon>
                      <van-icon name="scan" color="#1989FA" size="40" style="line-height: inherit;" />
                    </template>
                  </scan>
                  <div
                    style="margin-left: 26px;display: flex;flex-direction: column;align-items: flex-start;
                font-size: 14px;color: #1989FA;font-weight: bolder;"
                  >
                    <span>扫一扫</span>
                    <span>获取设备信息</span>
                  </div>
                </van-row>
                <div
                  class="span_color"
                  style="display: flex;align-items: center;color: #979797"
                  @click="scanShow = false"
                >
                  <span>二维码失效</span>
                  <van-icon name="arrow" />
                </div>
              </van-row>
              <div
                style="margin: 10px 17px;border-bottom: 1px solid #F3F3F3"
                class="van-hairline--bottom"
              />
            </div>
            <div v-if="!scanShow">
              <van-field
                v-model="temp.code"
                placeholder="请输入二维码"
                input-align="right"
                label="二维码："
                name="code"
                :border="false"
                @blur="setCode"
              >
                <template #right-icon>
                  <scan width="12" @scanData="fillingIndexScan">
                    <template #icon>
                      <van-icon name="scan" style="font-size: 16px;line-height: inherit;" />
                    </template>
                  </scan>
                </template>
              </van-field>
              <van-field
                v-model="temp.name"
                readonly
                input-align="right"
                label="名　称："
                name="name"
                :border="false"
              />
              <van-field
                v-model="temp.typeName"
                readonly
                input-align="right"
                label="类　型："
                name="typeName"
                :border="false"
              />
              <van-field
                v-model="temp.areaName"
                readonly
                input-align="right"
                label="区　域："
                name="areaName"
                :border="false"
              />
              <van-field
                v-model="temp.position"
                readonly
                input-align="right"
                label="位　置："
                name="position"
                :border="false"
              />
            </div>
            <div style="padding: 15px">
              <van-field
                v-model="temp.message"
                :autosize="true"
                input-align="left"
                maxlength="50"
                name="message"
                placeholder="请输入留言"
                rows="2"
                show-word-limit
                type="textarea"
                style="background-color: #FAFAFA;border-radius: 6px;"
              />
            </div>
          </div>

          <div
            v-if="isFill === 'true'&& temp.tableList && temp.tableList.length > 0"
            style="margin: 12px 10px;padding: 13px 16px;background-color: #FFFFFF"
          >
            <van-row style="padding-bottom: 10px">
              <span style="font-size: 16px;color: #606060;font-weight: bolder">检查项</span>
            </van-row>
            <div class="van-hairline--bottom" style="margin-bottom: 19px" />
            <van-field name="checkboxGroup" style="padding:0">
              <template #input>
                <van-checkbox-group v-model="result" style="width: 100%;">
                  <van-collapse v-model="activeName">
                    <div v-for="(item,index) in temp.tableList" :key="index">
                      <van-collapse-item
                        ref="vanCollapseItem"
                        :name="item.id"
                        :title="'检查项'+(index + 1)+'：' + item.name"
                        class="item_collapse"
                      >
                        <template #title="prop">
                          <span style="color:#3A3A44">检查项{{ index + 1 }}：{{ item.name }}</span>
                        </template>
                        <div v-for="(children,index1) in item.children" :key="index1">
                          <van-checkbox
                            shape="square"
                            style="margin: 10px;color:#707070"
                            :name="children"
                          >
                            {{ children.content }}
                            <van-tag v-if="children.isDanger" plain type="warning">隐患
                            </van-tag>
                          </van-checkbox>
                          <div
                            v-if="result.includes(children)"
                            style="padding: 10px 0 10px 40px;"
                          >
                            <van-field
                              v-model="children.checkDescribe"
                              placeholder="请输入描述"
                              clearable
                              maxlength="50"
                              rows="2"
                              show-word-limit
                              style="border: 1px solid #f3f3f3;padding-left: 12px;border-radius: 10px"
                              type="textarea"
                              :rules="[{ required: true, message: '请输入描述' }]"
                            />
                            <van-uploader
                              v-model="children.checkImgIdList"
                              :after-read="offlineUpload"
                              preview-size="60"
                              style="padding-top: 10px;"
                            />
                            <div
                              class="van-hairline--bottom"
                              style="margin-bottom: 10px"
                            />
                            <van-field
                              :border="false"
                              label="是否当场解决:"
                              label-width="90px"
                              style="padding: 0"
                            >
                              <template #input>
                                <van-switch v-model="children.isSolve" size="20" />
                              </template>
                            </van-field>
                            <div v-if="children.isSolve" style="padding: 10px 0">
                              <van-field
                                v-model="children.dangersSolvedDescribe"
                                placeholder="请输入解决描述"
                                clearable
                                maxlength="50"
                                rows="2"
                                show-word-limit
                                style="border: 1px solid #f3f3f3;padding-left: 12px;border-radius: 10px"
                                type="textarea"
                                :rules="[{ required: true, message: '请输入解决描述' }]"
                              />
                              <van-uploader
                                v-model="children.dangersSolvedImgIdList"
                                :after-read="offlineUpload"
                                preview-size="60"
                                style="padding-top: 10px;"
                              />
                            </div>
                          </div>
                          <div
                            v-if="result.includes(children)"
                            class="van-hairline--bottom"
                          />
                        </div>
                      </van-collapse-item>
                    </div>
                  </van-collapse>
                </van-checkbox-group>
              </template>
            </van-field>
          </div>
        </van-form>
      </div>
    </div>

    <sign
      :sign-show="endPopupSignShow"
      @signId="setSignId"
      @signShowState="(e)=>{this.endPopupSignShow = e}"
    />
  </div>
</template>

<script>

import { sysFileInfoUpload } from '@/api/system/fileManage'
import commonHead from '@/views/app/common/head'
import sign from '@/views/app/inspection/sign'
import { taskLogInfo } from '@/api/exam/taskLog'
import { fillingFormAdd } from '@/api/exam/filling'
import store from '@/store'
import Scan from '@/views/app/common/scan'

export default {
  components: {
    commonHead, sign, Scan
  },
  data() {
    return {
      result: [],
      activeName: [],
      scanShow: true,
      endPopupSignShow: false,
      temp: {
        id: null,
        code: null,
        name: null,
        signId: null,
        typeName: null,
        areaName: null,
        position: null,
        message: null,
        tableList: []
      },
      taskId: this.$route.query.taskId,
      taskLineId: this.$route.query.taskLineId,
      operationType: this.$route.query.operationType,
      scanCode: this.$route.query.scanCode,
      isFill: this.$route.query.isFill,
      isSign: this.$route.query.isSign,
      codeType: null,
      codeAndType: [
        { code: 0, type: 'nfc', name: 'NFC' },
        { code: 1, type: 'barcode', name: '二维码' }
      ],
      isScanCodeType: false,
      autoSubmit: false
    }
  },
  computed: {},
  created() {
    this.init()
  },
  beforeDestroy() {
  },
  methods: {
    offlineUpload(file, data) {
      file.status = 'uploading'
      file.message = '上传中...'
      const content = file.file
      const formData = new FormData()
      formData.append('file', content)
      sysFileInfoUpload(formData).then((response) => {
        if (response.success) {
          file.fileId = response.data
          file.status = 'success'
          file.message = ''
        } else {
          file.status = 'failed'
          file.message = '上传失败'
        }
      }).catch((err) => {
        this.$toast(err + '')
      })
    },
    init() {
      if (this.operationType === 'scan' || this.operationType === 'edit') {
        this.scanShow = false
        this.temp.code = this.scanCode
        const codeTypeTemp = this.$route.query.codeType ? this.$route.query.codeType : null
        this.codeType = codeTypeTemp === 'wx' ? 'barcode' : codeTypeTemp
        this.isScanCodeType = this.operationType === 'scan'
        this.setCode()
      }
    },
    fillingIndexScan(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      this.temp.code = val.code
      this.codeType = val.type === 'wx' ? 'barcode' : val.type
      this.scanShow = false
      this.isScanCodeType = true
      this.setCode()
    },
    setSignId(e) {
      this.temp.signId = e
      this.$refs.fillForm.submit()
    },
    handleSave() {
      if (this.isFill === 'true' && this.temp.tableList && this.temp.tableList.length > 0) {
        for (let i = 0; i < this.$refs.vanCollapseItem.length; i++) {
          this.activeName.push(this.$refs.vanCollapseItem[i].name)
        }
      }
      if (this.isSign === 'true') {
        this.endPopupSignShow = true
      } else {
        this.$refs.fillForm.submit()
      }
    },
    async onSubmit(values) {
      let checkboxGroup = null
      if (this.isFill === 'true') {
        checkboxGroup = values.checkboxGroup && values.checkboxGroup.length > 0 ? values.checkboxGroup.map(e => {
          return {
            checkTableItemId: e.id,
            checkIsDanger: e.isDanger,
            isSolve: e.isSolve,
            checkDescribe: e.checkDescribe,
            checkImgIds: e.checkImgIdList && e.checkImgIdList.length > 0 ? e.checkImgIdList
              .filter(item => item.status === 'success')
              .map(i => i.fileId)
              .join(',') : '',
            dangersSolvedDescribe: e.dangersSolvedDescribe,
            dangersSolvedImgIds: e.dangersSolvedImgIdList && e.dangersSolvedImgIdList.length > 0 ? e.dangersSolvedImgIdList
              .filter(item => item.status === 'success')
              .map(i => i.fileId)
              .join(',') : ''
          }
        }) : []
      }
      let singId = null
      if (this.isSign === 'true') {
        singId = this.temp.signId
      }
      const fillTemp = {
        taskLineId: this.taskLineId,
        deviceId: this.temp.id,
        taskId: this.taskId,
        signId: singId,
        message: values.message,
        checkboxGroup: checkboxGroup
      }
      this.endPopupSignShow = false
      store.commit('showLoading')
      await fillingFormAdd(fillTemp).then(res => {
        if (res.success) {
          store.commit('hideLoading')
          const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
          const path = routeArray[routeArray.length - 1]
          this.$router.push(path)
        }
      }).catch((err) => {
        store.commit('hideLoading')
        this.$toast(err + '')
      })
    },
    /**
       * 重置
       */
    resetTemp() {
      this.temp = {
        id: null,
        code: null,
        name: null,
        signId: null,
        typeName: null,
        areaName: null,
        position: null,
        message: null,
        parents: [],
        children: [],
        tableList: []
      }
    },
    /**
       * 设置二维码code
       */
    setCode() {
      const qrCode = this.temp.code
      this.resetTemp()
      this.temp.code = qrCode
      const query = {
        code: qrCode,
        taskId: this.taskId,
        taskLineId: this.taskLineId
      }
      store.commit('showLoading')
      taskLogInfo(query).then(res => {
        if (res.success) {
          store.commit('hideLoading')
          if (res.data.pointInfo && this.isScanCodeType) {
            this.isScanCodeType = false
            const tempCodeType = this.codeAndType.find(item => item.code === Number(res.data.pointInfo.codeType))
            // console.log('tempCodeType', tempCodeType)
            if (this.codeType !== tempCodeType.type) {
              return this.$toast('请使用' + tempCodeType.name)
            }
          }
          console.log(this.isFill === 'true')
          if (this.isFill === 'true') {
            this.temp.tableList = res.data.tableList
            this.autoSubmit = false
          } else {
            this.autoSubmit = true
          }
          this.temp.id = res.data.pointInfo.id
          this.temp.code = res.data.pointInfo.code
          this.temp.name = res.data.pointInfo.name
          this.temp.typeName = res.data.pointInfo.typeName
          this.temp.areaName = res.data.pointInfo.areaName
          this.temp.position = res.data.pointInfo.position
          this.temp.message = res.data.pointInfo.message
          if (this.autoSubmit) {
            this.$refs.fillForm.submit()
          }
        }
      }).catch(err => {
        console.log(err)
        store.commit('hideLoading')
      })
    },
    afterRead(file) {
      file.status = 'uploading'
      file.message = '上传中...'
      const content = file.file
      const data = new FormData()
      data.append('file', content)
      sysFileInfoUpload(data).then((response) => {
        if (response.success) {
          file.fileId = response.data
          file.status = 'success'
          file.message = ''
        } else {
          file.status = 'failed'
          file.message = '上传失败'
        }
      }).catch((err) => {
        this.$toast(err + '')
      })
    }

  }
}
</script>

<style scoped>
  #fillForm ::v-deep .van-cell__title {
    color: #979797 !important;
  }

  .item_collapse {
    border: 1px solid #F3F3F3;
    border-radius: 6px;
    margin-bottom: 10px;
  }

  .item_collapse:active {
    border: 1px solid #F3F3F3;
    border-radius: 6px;
  }

  .item_collapse ::v-deep .van-cell--clickable {
    border-radius: 6px;
  }

  .item_collapse ::v-deep .van-collapse-item__wrapper {
    border-radius: 6px;
  }

  #content_2 .van-cell {
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    padding: 10px 16px 10px 0px;
    overflow: hidden;
    color: #323233;
    font-size: 14px;
    line-height: 24px;
    background-color: #fff;
  }

</style>
