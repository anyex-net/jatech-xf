<template>
  <div style="font-family: PingFang SC Bold;font-size: 14px;">
    <common-head
      :back-img="require('@/assets/images/new/back1.png')"
      :is-back="true"
      :custom-title="true"
      back-img-style="width: 10px;height: 20px"
      background-color="#FFFFFF"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">检查详情</span>
      </template>
    </common-head>

    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <div style="margin: 12px 10px">
          <div style="background-color: #FFFFFF;padding: 10px;margin-bottom: 10px">
            <van-row style="margin-bottom: 18px">
              检查时间：
              <span style="font-weight: bolder">{{ temp.singInfo.checkTime }}</span>
            </van-row>
            <van-row style="margin-bottom: 18px">
              检查人员：
              <span style="font-weight: bolder">{{ temp.singInfo.checkUserName }}</span>
            </van-row>
            <van-row v-if="isSign === 'true' && temp.singInfo.signImg && temp.singInfo.signImg.length > 0" type="flex">
              人员签名：
              <van-image
                v-for="(item,index) in temp.singInfo.signImg"
                :key="index"
                :src="item"
                style="background-color: #FAFAFA;width:4rem;height: 3rem;padding-left: 10px;margin-top: 10px;border-radius: 6px"
              />
            </van-row>
          </div>
          <van-row style="padding:8px 17px;align-items: center;background-color: #FFFFFF" type="flex">
            <van-col style="display: flex;flex-direction: column;align-items: stretch;">
              <span style="color: #979797;margin:8px 0">点位编号：
                <span style="color:  #333333;margin-left: 9px">{{ temp.pointInfo.code }}</span>
              </span>
              <span style="color: #979797;margin:8px 0">点位名称：
                <span style="color:  #333333;margin-left: 9px">{{ temp.pointInfo.name }}</span>
              </span>
              <span style="color: #979797;margin:8px 0">点位位置：
                <span style="color:  #333333;margin-left: 9px">{{ temp.pointInfo.position }}</span>
              </span>
              <span style="color: #979797;margin:8px 0">点位类型：
                <span style="color:  #333333;margin-left: 9px">{{ temp.pointInfo.typeName }}</span>
              </span>
              <span style="color: #979797;margin:8px 0">检查留言：
                <span style="color:  #333333;margin-left: 9px">{{ temp.pointInfo.message }}</span>
              </span>
            </van-col>
          </van-row>

          <div v-if="isFill === 'true' && temp.tableList && temp.tableList.length > 0" style="background-color: #FFFFFF;padding: 10px;margin-top: 10px">
            <van-collapse v-model="activeName" accordion>
              <div v-for="(item, index) in temp.tableList" :key="index">
                <van-collapse-item :name="item.id" :title="item.name" class="item_collapse">
                  <div v-for="(children, index) in item.children" :key="index">
                    <van-checkbox v-model="children.checkState" disabled shape="square" style="margin: 10px;">
                      {{ children.content }}
                      <van-tag v-if="children.isDanger" plain type="warning">隐患</van-tag>
                    </van-checkbox>
                    <div v-if="children.checkState" style="padding: 10px 0 10px 40px;">
                      <van-field
                        v-model="children.checkDescribe"
                        placeholder="请输入描述"
                        clearable
                        disabled
                        maxlength="50"
                        rows="2"
                        show-word-limit
                        style="border: 1px solid #f3f3f3;padding-left: 12px;border-radius: 10px"
                        type="textarea"
                      />
                      <div v-for="(img,index) in children.checkImgIdList" :key="index">
                        <van-image
                          width="60"
                          height="60"
                          :src="img"
                          @click="sceneImg(children.checkImgIdList,index)"
                        />
                      </div>
                      <div class="van-hairline--bottom" style="margin-bottom: 10px" />
                      <van-field :border="false" label="是否当场解决:" label-width="90px" style="padding: 0">
                        <template #input>
                          <van-switch v-model="children.isSolve" disabled size="20" />
                        </template>
                      </van-field>
                      <div v-if="children.isSolve" style="padding: 10px 0">
                        <van-field
                          v-model="children.dangersSolvedDescribe"
                          placeholder="请输入解决描述"
                          clearable
                          disabled
                          maxlength="50"
                          rows="2"
                          show-word-limit
                          style="border: 1px solid #f3f3f3;padding-left: 12px;border-radius: 10px"
                          type="textarea"
                        />
                        <div v-for="(img,index) in children.dangersSolvedImgIdList" :key="index">
                          <van-image
                            width="60"
                            height="60"
                            :src="img"
                            @click="sceneImg(children.dangersSolvedImgIdList,index)"
                          />
                        </div>
                      </div>
                    </div>
                    <div v-if="children.checkState" class="van-hairline--bottom" />
                  </div>
                </van-collapse-item>
              </div>
            </van-collapse>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>

import commonHead from '@/views/app/common/head'
import { ImagePreview } from 'vant'
import { taskLogInfoDetail } from '@/api/exam/taskLog'

export default {
  components: {
    commonHead
  },
  data() {
    return {
      activeName: '1',
      temp: {
        pointInfo: {},
        singInfo: {
          signImg: [],
          checkUserName: null,
          checkTime: null
        },
        tableList: []
      },
      taskLogId: this.$route.query.taskLogId,
      isFill: this.$route.query.isFill,
      isSign: this.$route.query.isSign
    }
  },
  computed: {},
  created() {
    this.init()
  },
  methods: {
    // 图片预览
    sceneImg(images, index) {
      ImagePreview({
        images: images, // 需要预览的图片 URL 数组
        showIndex: true, // 是否显示页码
        loop: false, // 是否开启循环播放
        startPosition: index // 图片预览起始位置索引
      })
    },
    /**
       * 初始化
       */
    init() {
      this.getInspectInfo()
    },
    /**
       * 检查详情获取信息
       */
    getInspectInfo() {
      taskLogInfoDetail(this.taskLogId).then(res => {
        if (res.data.tableList) {
          this.temp.tableList = res.data.tableList
          this.temp.tableList = this.temp.tableList ? this.temp.tableList.map(j => {
            j.children = j.children ? j.children.map(e => {
              e.checkImgIdList = e.checkImgIdList ? e.checkImgIdList.map(i => this.$host + i) : []
              e.dangersSolvedImgIdList = e.dangersSolvedImgIdList ? e.dangersSolvedImgIdList.map(i => this.$host + i) : []
              return e
            }) : []
            return j
          }) : []
        }
        this.temp.singInfo = res.data.singInfo
        this.temp.singInfo.signImg = this.temp.singInfo.signImg ? this.temp.singInfo.signImg.map(e => this.$host + e) : []
        this.temp.pointInfo = res.data.pointInfo
      })
    }
  }
}
</script>

<style scoped>
  .item_collapse {
    border: 1px solid #F3F3F3;
    border-radius: 6px;
    margin-bottom: 10px;
  }

  .item_collapse:active {
    border: 1px solid #F3F3F3;
    border-radius: 6px;
  }

  .item_collapse ::v-deep .van-cell--clickable {
    border-radius: 6px;
  }

  .item_collapse ::v-deep .van-collapse-item__wrapper {
    border-radius: 6px;
  }
</style>
