<template>
  <div style="font-family: PingFang SC Bold;">
    <van-popup
      v-model="endPopupRouteShow"
      :safe-area-inset-bottom="true"
      position="bottom"
      round
      style="height: 80%"
    >
      <div
        style="padding: 14px 16px;width:100%;position: fixed;background-color: #FFFFFF;
      border-radius: 16px 16px 0 0;z-index: 99;"
      >
        <div style="display: flex;align-items: center;justify-content: center;height: 18px;line-height: 18px;">
          <span style="font-weight: bolder">选择您巡查的路线</span>
        </div>
        <div style="display: flex;justify-content: flex-end;align-items: center;height: 18px;margin-top: -18px;">
          <van-icon color="#949494" name="cross" @click="endPopupRouteShow = false" />
        </div>
      </div>

      <van-list
        v-model="routeData.loading"
        :finished="routeData.finished"
        :finished-text="routeData.message"
        style="margin-top: 66px"
        @load="onRouteLoad"
      >
        <template v-for="(item,index) in routeData.list">
          <custom-card :key="index" shadow style="border-radius: 6px;margin: 8px 10px;padding: 17px 16px;">
            <template #content>
              <van-row justify="space-between" style="align-items: center;" type="flex">
                <div style="display: flex;flex-direction: column;align-items: center;">
                  <span style="margin-bottom: 12px">{{ item.name }}</span>
                  <span style="font-size: 12px">本月已巡查
                    <span style="font-size: 12px;color:#5FC48D;">{{ item.taskLineCompleteCountByMonth }}</span>
                    次</span>
                </div>
                <div>
                  <div v-if="Number(item.state) === 0">
                    <van-button
                      v-if="item.userIds === null || item.userIds === '' || (item.userIds && item.userIds.indexOf(userInfo.id) !== -1)"
                      size="small"
                      style="border-radius: 6px;"
                      type="info"
                      @click="routeToInspectClick(item)"
                    >
                      去巡查
                    </van-button>
                    <van-button
                      v-else-if="item.userIds && item.userIds.indexOf(userInfo.id) === -1"
                      plain
                      size="small"
                      style="border-radius: 6px;color:#CECECE;border: 1px solid #CECECE"
                    >
                      已指定人员
                    </van-button>
                  </div>

                  <van-button
                    v-if="Number(item.state) === 1"
                    plain
                    size="small"
                    style="border-radius: 6px;color:#CECECE;border: 1px solid #CECECE"
                    @click="routeToInfoClick(item)"
                  >
                    已巡查
                  </van-button>
                </div>
              </van-row>
            </template>
          </custom-card>
        </template>
      </van-list>
      <div v-if="isNavBottom" class="nav-bottom" />
    </van-popup>
  </div>
</template>

<script>

import { taskLinePage, taskLineUpdate } from '@/api/exam/taskLine'
import { validatorUser } from '@/api/exam/line'
import customCard from '@/views/app/common/card/customCard'
import { taskUpdateById } from '@/api/exam/task'
import { parseTime } from '@/utils'

export default {
  components: {
    customCard
  },
  props: {
    routeShow: {
      type: Boolean,
      default: false
    },
    isNavBottom: {
      type: Boolean,
      default: false
    },
    taskId: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      endPopupRouteShow: this.routeShow,
      routeData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          pageNo: 1,
          pageSize: 10,
          taskId: null
        }
      }
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  // 侦听属性
  watch: {
    routeShow(newObj, oldObj) {
      this.endPopupRouteShow = newObj
    },
    endPopupRouteShow(newObj, oldObj) {
      this.$emit('routeShowState', newObj)
    },
    immediate: true
  },
  created() {
    this.init()
  },
  methods: {
    toParseTime(time, format) {
      return parseTime(time, format)
    },
    init() {
      this.reset()
      this.getRouteList()
    },
    reset() {
      this.routeData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          pageNo: 1,
          pageSize: 10,
          taskId: null
        }
      }
    },
    getRouteList() {
      this.routeData.query.taskId = this.taskId
      taskLinePage(this.routeData.query).then(res => {
        this.routeData.list = this.routeData.list.concat(res.data.rows)
        // 加载状态结束
        this.routeData.loading = false
        this.routeData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.routeData.list.length >= res.data.totalRows) {
          this.routeData.finished = true
        }
      })
    },
    routeToInspectClick(val) {
      if (Number(this.userInfo.adminType) === 0) {
        this.updateTask(val)
      } else {
        validatorUser(val.lineId).then(res => {
          if (res.data.type) {
            this.updateTask(val)
          } else {
            this.$toast({
              type: 'warning',
              message: '路线已指定人员！'
            })
          }
        })
      }
    },
    updateTask(val) {
      const query = {
        id: this.taskId,
        state: 2
      }
      taskUpdateById(query).then(res => {
        if (res.success) {
          const data = {
            id: val.id,
            checkStartTime: this.toParseTime(new Date(), '{y}-{m}-{d} {h}:{i}:{s}')
          }
          taskLineUpdate(data).then(res => {
            if (res.success) {
              this.toInspect(val)
            }
          })
        }
      })
    },
    routeToInfoClick(val) {
      if (val.state === 1) {
        this.toInspect(val)
      }
    },
    onRouteLoad() {
      this.routeData.query.pageNo++
      this.getRouteList()
    },
    toInspect(val) {
      this.$router.push({
        path: '/app/inspection/inspect/index',
        query: {
          taskLineId: val.id,
          taskId: val.taskId,
          unitId: val.unitId
        }
      })
    }
  }
}

</script>
<style scoped>

</style>
