<template>
  <div>
    <div
      v-if="vanSearchShow"
      v-show="vanNeedSearch"
      id="searchContent"
      style="padding:16px 10px;background-color: #FFFFFF"
    >
      <van-field
        v-if="vanTabsActive === 'hiddenDanger'"
        v-model="searchData.code"
        clearable
        placeholder="请输入设备编码"
        style="border-radius: 6px;border: 1px solid #DADFE6;height: 40px;line-height: 18px;margin-bottom: 10px"
      />
      <van-row type="flex" justify="space-between" style="align-items: center">
        <van-col span="11">
          <van-field
            readonly
            clickable
            name="datetimePicker"
            :value="searchData.startTime"
            placeholder="选择起始时间"
            style="border-radius: 6px;border: 1px solid #DADFE6;height: 40px;line-height: 18px"
            @click="searchData.startTimeShowPicker = true"
          />
          <van-popup v-model="searchData.startTimeShowPicker" round position="bottom">
            <van-datetime-picker
              v-model="currentDate"
              type="datetime"
              title="选择起始时间"
              @confirm="onStartTimeConfirm"
              @cancel="searchData.startTimeShowPicker = false"
            />
          </van-popup>
        </van-col>
        <span>-</span>
        <van-col span="11">
          <van-field
            readonly
            clickable
            name="datetimePicker"
            :value="searchData.endTime"
            placeholder="选择结束时间"
            style="border-radius: 6px;border: 1px solid #DADFE6;height: 40px;line-height: 18px"
            @click="searchData.endTimeShowPicker = true"
          />
          <van-popup v-model="searchData.endTimeShowPicker" round position="bottom">
            <van-datetime-picker
              v-model="currentDate"
              type="datetime"
              title="选择结束时间"
              @confirm="onEndTimeConfirm"
              @cancel="searchData.endTimeShowPicker = false"
            />
          </van-popup>
        </van-col>
      </van-row>
      <van-row type="flex" justify="space-between">
        <van-col span="7">
          <van-button
            block
            color="#1989FA"
            style="margin: 10px 0;border-radius: 6px;height: 42px"
            @click="onSearchQuery"
          >搜索
          </van-button>
        </van-col>
        <van-col span="7">
          <van-button
            block
            color="#1989FA"
            style="margin: 10px 0;border-radius: 6px;height: 42px"
            @click="onSearchQueryReset"
          >重置
          </van-button>
        </van-col>
        <van-col span="7">
          <van-button
            block
            color="#1989FA"
            style="margin: 10px 0;border-radius: 6px;height: 42px"
            @click="onSearchQueryClose"
          >关闭
          </van-button>
        </van-col>
      </van-row>
    </div>

    <div id="tabContent">
      <van-tabs id="tabs" v-model="vanTabsActive">
        <van-tab v-if="hasPerm(hasPermission.point)" name="point" title="点位">
          <div style="padding: 14px 15px">
            <van-row type="flex" justify="space-between" style="align-items: center;">
              <van-checkbox v-model="pointChecked" checked-color="#1989FA" shape="square" />
              <van-search
                v-model="pointSearchValue"
                clearable
                input-align="center"
                placeholder="请输入编码"
                shape="round"
                style="width: 70%"
                @search="searchPoint"
              />
              <van-button
                v-if="pointCheckedToButtonState && hasBtnPermission('exam:point:add')"
                icon="plus"
                size="small"
                style="border-radius: 6px;font-size: 12px;padding: 12px 12px;
                          height: 18px;background-color: #1989FA!important;"
                type="info"
                @click="goPointAdd"
              >
                新增
              </van-button>
              <van-button
                v-if="hasBtnPermission('exam:point:del') && !pointCheckedToButtonState"
                size="small"
                style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #FF4E61!important;border: 1px solid #FF4E61"
                type="info"
                @click="pointBatchDelete"
              >
                删除
              </van-button>
            </van-row>
          </div>
          <van-checkbox-group ref="checkboxGroup" v-model="pointCheckedResult">
            <van-list
              v-model="pointData.loading"
              :finished="pointData.finished"
              :finished-text="pointData.message"
              style="height: calc(100vh - 158px - 82px - 48px - 75px);overflow-x: scroll;"
              @load="onPointLoad"
            >
              <template v-for="(item, index) in pointData.list">
                <div :key="index" style="padding: 0 15px">
                  <div style="padding: 15px 0 11px 0">
                    <van-row type="flex" justify="space-between" style="align-content: center;align-items: center;">
                      <div style="display: flex;align-items: center;">
                        <van-checkbox
                          :name="item.id"
                          checked-color="#1989FA"
                          shape="square"
                          @click="pointItemCheckedClick(item.id)"
                        />
                        <span class="font_crude" style="margin-left: 8px">{{ item.name }}</span>
                      </div>
                      <div class="span_color" style="display: flex;align-items: center;" @click="goPointSelect(item)">
                        <span>详情</span>
                        <van-icon name="arrow" />
                      </div>
                    </van-row>
                  </div>
                  <div class="van-hairline--bottom" />
                  <van-row style="padding: 11px 0;align-items: center;" type="flex">
                    <van-col span="12" style="display: flex;flex-direction: column;align-items: stretch;">
                      <span class="span_color van-ellipsis" style="margin: 8px 0">点位编码：
                        <span style="color: black;">{{ item.code }}</span>
                      </span>
                      <span class="span_color van-ellipsis" style="margin: 8px 0">点位类型：
                        <span style="color: black;">{{ item.typeName }}</span>
                      </span>
                      <span class="span_color van-ellipsis" style="margin: 8px 0">点位位置：
                        <span style="color: black;">{{ item.position }}</span>
                      </span>
                    </van-col>
                    <van-col
                      span="12"
                      style="display:flex;justify-content: flex-end"
                    >
                      <van-button
                        v-if="hasBtnPermission('exam:point:edit')"
                        size="small"
                        style="border-radius: 6px;padding:5px;width: 50px"
                        type="info"
                        @click="goPointEdit(item)"
                      ><span
                        style="font-size: 14px;"
                      >编辑</span>
                      </van-button>
                      <van-button
                        v-if="hasBtnPermission('exam:point:del')"
                        size="small"
                        style="border-radius: 6px;background-color: #FF4E61;color: #FFFFFF;padding:5px;margin-left: 10px;width: 50px"
                        @click="pointDel(item)"
                      >删除
                      </van-button>
                    </van-col>
                  </van-row>
                </div>
              </template>
            </van-list>
          </van-checkbox-group>
        </van-tab>
        <van-tab v-if="hasPerm(hasPermission.maintenance)" name="maintenance" title="维保">
          <van-tabs id="itemTab" v-model="maintenanceActiveName" @click="onClickMaintenanceActive">
            <van-tab name="maintenance_not_start" title="待维保">
              <van-list
                v-model="maintenanceData.loading"
                :finished="maintenanceData.finished"
                :finished-text="maintenanceData.message"
                class="autoHeightList"
                @load="onMaintenanceLoad"
              >
                <template v-for="(item, index) in maintenanceData.list">
                  <div :key="index">
                    <van-row type="flex" style="padding: 15px 16px 11px">
                      <van-col span="16">
                        <span class="font_crude">{{ item.name }}</span>
                      </van-col>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row type="flex" style="margin: 11px 16px;align-items: center;">
                      <van-col span="16" style="display: flex;flex-direction: column;align-items: stretch;">
                        <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：<span
                          style="color: black;font-size:12px"
                        >{{ item.startTime }}</span></span>
                        <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：<span
                          style="color: black;font-size:12px"
                        >{{ item.endTime }}</span></span>
                      </van-col>
                      <van-col span="8" style="display: flex;justify-content: flex-end;">
                        <van-button
                          v-if="hasPerm(hasPermission.maintenanceStart)"
                          v-show="item.state !== 1"
                          plain
                          size="small"
                          style="border-radius: 6px"
                          type="info"
                          @click="goStart(item)"
                        >
                          <span style="font-size: 14px;font-weight: bold">开始维保</span>
                        </van-button>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </van-tab>
            <van-tab name="maintenance_closed" title="已维保">
              <van-list
                v-model="maintenanceData.loading"
                :finished="maintenanceData.finished"
                :finished-text="maintenanceData.message"
                class="autoHeightList"
                @load="onMaintenanceLoad"
              >
                <template v-for="(item, index) in maintenanceData.list">
                  <div :key="index" @click="goMaintenance(item)">
                    <van-row type="flex" style="padding: 15px 16px 11px">
                      <van-col span="16">
                        <span class="font_crude">{{ item.name }}</span>
                      </van-col>
                      <van-col span="8" style="display: flex;justify-content: flex-end;">
                        <span style="color: #979797;font-size: 14px">已完成
                        </span>
                      </van-col>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                      <van-col span="8" style="display: flex;flex-direction: column;align-items: stretch;">
                        <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：</span>
                        <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：</span>
                      </van-col>
                      <van-col
                        span="16"
                        style="display: flex;flex-direction: column;align-items: stretch;"
                      >
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;font-size:12px"
                        >{{ item.startTime }}</span></div>
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;font-size:12px"
                        >{{ item.endTime }}</span></div>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </van-tab>
          </van-tabs>
        </van-tab>
        <van-tab v-if="hasPerm(hasPermission.patrol)" name="patrol" title="巡查">
          <van-tabs id="itemTab" v-model="patrolActiveName" @click="onClickPatrolActive">
            <van-tab name="patrol_no_patrol_inspection" title="待巡查">
              <van-list
                v-model="patrolData.loading"
                :finished="patrolData.finished"
                :finished-text="patrolData.message"
                class="autoHeightList"
                @load="onPatrolLoad"
              >
                <template v-for="(item, index) in patrolData.list">
                  <div :key="index">
                    <van-row type="flex" style="padding: 15px 16px 11px">
                      <span class="font_crude">{{ item.name }}</span>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                      <van-col span="16" style="display: flex;flex-direction: column;align-items: stretch;">
                        <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：<span
                          style="color: black;font-size:12px"
                        >{{ item.startTime }}</span></span>
                        <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：<span
                          style="color: black;font-size:12px"
                        >{{ item.endTime }}</span></span>
                      </van-col>
                      <van-col span="8" style="display: flex;justify-content: flex-end;">
                        <van-button
                          v-if="hasPerm(hasPermission.patrolStart)"
                          v-show="item.state === 0"
                          plain
                          size="small"
                          style="border-radius: 6px"
                          type="info"
                          @click="goStart(item)"
                        >
                          <span style="font-size: 14px;font-weight: bold">开始巡查</span>
                        </van-button>
                        <van-button
                          v-if="hasPerm(hasPermission.patrolInProgress)"
                          v-show="item.state === 2"
                          plain
                          size="small"
                          style="border-radius: 6px"
                          type="info"
                          @click="showPatrolRoute(item)"
                        >
                          <span style="font-size: 14px;font-weight: bold">巡查中</span>
                        </van-button>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </van-tab>
            <!--            <van-tab name="patrol_in_patrol_inspection" title="巡查中">-->
            <!--              <van-list-->
            <!--                v-model="patrolData.loading"-->
            <!--                :finished="patrolData.finished"-->
            <!--                :finished-text="patrolData.message"-->
            <!--                class="autoHeightList"-->
            <!--                @load="onPatrolLoad"-->
            <!--              >-->
            <!--                <template v-for="(item, index) in patrolData.list">-->
            <!--                  <div :key="index">-->
            <!--                    <van-row type="flex" style="padding: 15px 16px 11px">-->
            <!--                      <span class="font_crude">{{ item.name }}</span>-->
            <!--                    </van-row>-->
            <!--                    <div class="van-hairline&#45;&#45;bottom" style="margin: 0 16px;" />-->
            <!--                    <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">-->
            <!--                      <van-col span="16" style="display: flex;flex-direction: column;align-items: stretch;">-->
            <!--                        <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：<span-->
            <!--                          style="color: black;font-size:12px"-->
            <!--                        >{{ item.startTime }}</span></span>-->
            <!--                        <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：<span-->
            <!--                          style="color: black;font-size:12px"-->
            <!--                        >{{ item.endTime }}</span></span>-->
            <!--                      </van-col>-->
            <!--                      <van-col span="8" style="display: flex;justify-content: flex-end;">-->
            <!--                        <van-button-->
            <!--                          v-if="hasPerm(hasPermission.patrolInProgress)"-->
            <!--                          v-show="item.state === 2"-->
            <!--                          plain-->
            <!--                          size="small"-->
            <!--                          style="border-radius: 6px"-->
            <!--                          type="info"-->
            <!--                          @click="showPatrolRoute(item)"-->
            <!--                        >-->
            <!--                          <span style="font-size: 14px;font-weight: bold">巡查中</span>-->
            <!--                        </van-button>-->
            <!--                      </van-col>-->
            <!--                    </van-row>-->
            <!--                  </div>-->
            <!--                </template>-->
            <!--              </van-list>-->
            <!--            </van-tab>-->
            <van-tab name="patrol_patrolled" title="已巡查">
              <van-list
                v-model="patrolData.loading"
                :finished="patrolData.finished"
                :finished-text="patrolData.message"
                class="autoHeightList"
                @load="onPatrolLoad"
              >
                <template v-for="(item, index) in patrolData.list">
                  <div :key="index" @click="showPatrolRoute(item)">
                    <van-row
                      justify="space-between"
                      style="align-content: center;align-items: center;padding: 15px 16px 11px"
                      type="flex"
                    >
                      <van-col span="16">
                        <span class="font_crude">{{ item.name }}</span>
                      </van-col>
                      <van-col span="8" style="display: flex;justify-content: flex-end;">
                        <span style="color: #979797;font-size: 14px">
                          巡查结束
                        </span>
                      </van-col>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                      <van-col span="8" style="display: flex;flex-direction: column;align-items: stretch;">
                        <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：</span>
                        <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：</span>
                      </van-col>
                      <van-col
                        span="16"
                        style="display: flex;flex-direction: column;align-items: stretch;"
                      >
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;font-size:12px"
                        >{{ item.startTime }}</span></div>
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;font-size:12px"
                        >{{ item.endTime }}</span></div>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </van-tab>
          </van-tabs>
        </van-tab>
        <van-tab v-if="hasPerm(hasPermission.hiddenDanger)" name="hiddenDanger" title="隐患">
          <van-tabs id="itemTab" v-model="hiddenDangerActiveName" @click="onClickHiddenDangerActive">
            <van-tab name="hiddenDanger_unhandled" title="未处理">
              <van-list
                v-model="hiddenDangerData.loading"
                :finished="hiddenDangerData.finished"
                :finished-text="hiddenDangerData.message"
                class="autoHeightList"
                @load="onHiddenDangerLoad"
              >
                <template v-for="(item, index) in hiddenDangerData.list">
                  <div :key="index">
                    <van-row
                      justify="space-between"
                      style="padding: 15px 16px 11px"
                      type="flex"
                    >
                      <span style="font-weight: bold;">{{ item.pointName }}</span>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                      <van-col span="14" style="display: flex;flex-direction: column;align-items: stretch;">
                        <span class="span_color van-ellipsis" style="margin:8px 0">设备编号：<span
                          style="color: black"
                        >{{ item.code }}</span></span>
                        <span class="span_color van-ellipsis" style="margin:8px 0">设备位置：<span
                          style="color: black"
                        >{{ item.position }}</span>
                        </span>
                        <span class="span_color van-ellipsis" style="margin:8px 0">上报人员：<span
                          style="color: black;font-size:12px"
                        >{{ item.createName }}</span></span>
                        <span class="span_color van-ellipsis" style="margin:8px 0">上报时间：<span
                          style="color: black;font-size:12px"
                        >{{ item.createTime }}</span></span>
                      </van-col>
                      <van-col span="10" style="display: flex;justify-content: flex-end;">
                        <div v-if="hasPerm(hasPermission.hiddenDangerHandle)">
                          <div v-if="item.isExam">
                            <van-button
                              v-if="!item.isSolve && Number(userInfo.unitType) === 3"
                              style="border-radius: 6px"
                              plain
                              size="small"
                              type="info"
                              @click="goHidden(item,'handle')"
                            ><span
                              style="font-size: 14px;font-weight: bold"
                            >去处理</span>
                            </van-button>
                            <van-button
                              v-else
                              color="#979797"
                              style="border-radius: 6px"
                              plain
                              size="small"
                              type="info"
                            ><span
                              style="font-size: 14px;font-weight: bold"
                            >已转交维保公司</span>
                            </van-button>
                          </div>
                          <div v-else>
                            <van-button
                              v-show="!item.isSolve"
                              style="border-radius: 6px"
                              plain
                              size="small"
                              type="info"
                              @click="goHidden(item,'handle')"
                            ><span
                              style="font-size: 14px;font-weight: bold"
                            >去处理</span>
                            </van-button>
                          </div>
                        </div>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </van-tab>
            <van-tab name="hiddenDanger_processed" title="已处理">
              <van-list
                v-model="hiddenDangerData.loading"
                :finished="hiddenDangerData.finished"
                :finished-text="hiddenDangerData.message"
                class="autoHeightList"
                @load="onHiddenDangerLoad"
              >
                <template v-for="(item, index) in hiddenDangerData.list">
                  <div :key="index" @click="goHidden(item,'select')">
                    <van-row type="flex" justify="space-between" style="padding: 15px 16px 11px">
                      <van-col span="16">
                        <span class="font_crude">{{ item.pointName }}</span>
                      </van-col>
                      <van-col span="8" style="display: flex;justify-content: flex-end;">
                        <span style="color: #979797;font-size: 14px">已处理
                        </span>
                      </van-col>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                      <van-col span="8" style="display: flex;flex-direction: column;align-items: stretch;">
                        <span
                          class="span_color van-ellipsis"
                          style="margin:8px 0;"
                        >设备编号：</span>
                        <span
                          class="span_color van-ellipsis"
                          style="margin:8px 0;"
                        >设备位置：</span>
                        <span
                          class="span_color van-ellipsis"
                          style="margin:8px 0;"
                        >处理人员：</span>
                        <span
                          class="span_color van-ellipsis"
                          style="margin:8px 0;"
                        >处理时间：</span>
                      </van-col>
                      <van-col
                        span="16"
                        style="display: flex;flex-direction: column;align-items: stretch;"
                      >
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;"
                        >{{ item.code }}</span></div>
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;"
                        >{{ item.position }}</span></div>
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;"
                        >{{ item.solveName }}</span></div>
                        <div
                          class="span_color van-ellipsis"
                          style="margin:8px 0;display: flex;justify-content:flex-end;"
                        ><span
                          style="color: black;"
                        >{{ item.solveTime }}</span></div>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </van-tab>
          </van-tabs>
        </van-tab>
      </van-tabs>
      <route
        v-if="routeShow"
        :is-nav-bottom="true"
        :route-show="routeShow"
        :task-id="taskId"
        @routeShowState="e => { this.routeShow = e }"
      />
    </div>
  </div>

</template>

<script>
import { pointDelete, pointList } from '@/api/exam/point'
import { selectTaskPage, taskPage } from '@/api/exam/task'
import { dangerPage } from '@/api/exam/danger'
import store from '@/store'
import route from '@/views/app/inspection/route'
import { hasBtnPermission } from '@/utils/permission'
import { parseTime } from '@/utils'

export default {
  name: 'Index',
  components: {
    route
  },
  props: {
    unitId: {
      type: String,
      default: ''
    },
    searchShow: {
      type: Boolean,
      default: false
    },
    needSearch: {
      type: Boolean,
      default: false
    },
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      hasPermission: {
        point: 'app:exam:inspection:point',
        maintenance: 'app:exam:inspection:maintenance',
        maintenanceStart: 'app:exam:inspection:maintenance:start',
        patrol: 'app:exam:inspection:patrol',
        patrolStart: 'app:exam:inspection:patrol:start',
        patrolInProgress: 'app:exam:inspection:patrol:patrolInProgress',
        hiddenDanger: 'app:exam:inspection:hiddenDanger',
        hiddenDangerHandle: 'app:exam:inspection:hiddenDanger:handle'
      },
      currentDate: new Date(),
      searchData: {
        code: null,
        startTime: null,
        startTimeShowPicker: false,
        endTime: null,
        endTimeShowPicker: false
      },
      vanNeedSearch: this.needSearch,
      vanSearchShow: this.searchShow,
      vanTabsActive: this.value,
      pointData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          code: null,
          unitId: null,
          pageNo: 1,
          pageSize: 5
        }
      },
      maintenanceData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 5,
          type: 0,
          stateArray: null,
          today: null,
          startTime: null,
          endTime: null
        }
      },
      maintenanceActiveName: null,
      patrolData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 5,
          type: 1,
          state: null,
          today: null,
          startTime: null,
          endTime: null,
          userIds: null
        }
      },
      patrolActiveName: null,
      hiddenDangerData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 5,
          isSolve: null,
          code: null,
          startTime: null,
          endTime: null,
          isExam: null
        }
      },
      hiddenDangerActiveName: null,
      tempUnitId: this.unitId,
      pointQueryOperation: {
        select: 'select',
        add: 'add',
        edit: 'edit',
        scan: 'scan'
      },
      pointChecked: false,
      pointCheckedResult: [],
      pointCheckedToButtonState: true,
      taskId: null,
      routeShow: false,
      pointSearchValue: null
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  // 侦听属性
  watch: {
    needSearch(newObj, oldObj) {
      this.vanNeedSearch = newObj
    },
    vanNeedSearch(newObj, oldObj) {
      this.$emit('needSearch', newObj)
    },
    searchShow(newObj, oldObj) {
      this.vanSearchShow = newObj
    },
    vanSearchShow(newObj, oldObj) {
      this.$emit('searchShow', newObj)
    },
    value(newObj, oldObj) {
      this.vanTabsActive = newObj
    },
    vanTabsActive(newObj, oldObj) {
      if (newObj !== oldObj) {
        this.setUrlParameter()
        this.$emit('input', newObj)
      }
      this.onClickActive(newObj)
    },
    unitId(newObj, oldObj) {
      this.tempUnitId = newObj
      this.setUrlParameter()
      this.init()
    },
    pointChecked(newObj, oldObj) {
      this.$refs.checkboxGroup.toggleAll(newObj)
      this.pointCheckedToButtonState = !newObj
    },
    immediate: true
  },
  // 实例创建完成执行的钩子
  created() {
    this.init()
  },
  // 编译好的html挂载到页面完成后执行的事件钩子
  // 在整个实例中只执行一次
  mounted() {
  },
  methods: {
    hasBtnPermission(value) {
      if (value != null) {
        return hasBtnPermission(value)
      } else {
        return false
      }
    },
    goPointEdit(item) {
      this.$router.push({
        path: '/app/inspection/point/add/index',
        query: {
          id: item.id,
          unitId: this.unitId,
          operationType: 'edit'
        }
      })
    },
    pointDel(item) {
      this.$dialog
        .confirm({
          message: '是否删除'
        }).then(() => {
          store.commit('showLoading')
          pointDelete([item.id]).then(res => {
            store.commit('hideLoading')
            if (res.success) {
              this.searchPoint()
            } else {
              this.$toast(res.message)
            }
          })
            .catch((err) => {
              store.commit('hideLoading')
              this.$toast(err + '')
            })
        }).catch(() => {
        })
    },
    toParseTime(time, format) {
      return parseTime(time, format)
    },
    onStartTimeConfirm(time) {
      this.searchData.startTime = this.toParseTime(time, '{y}-{m}-{d} {h}:{i}:{s}')
      this.searchData.startTimeShowPicker = false
    },
    onEndTimeConfirm(time) {
      this.searchData.endTime = this.toParseTime(time, '{y}-{m}-{d} {h}:{i}:{s}')
      this.searchData.endTimeShowPicker = false
    },
    onSearchQuery() {
      this.onClickActive(this.vanTabsActive, '')
    },
    onSearchQueryReset() {
      this.searchData = {
        code: null,
        startTime: null,
        startTimeShowPicker: false,
        endTime: null,
        endTimeShowPicker: false
      }
    },
    onSearchQueryClose() {
      this.onSearchQueryReset()
      this.vanNeedSearch = false
      this.vanSearchShow = false
    },

    pointBatchDelete() {
      this.$dialog
        .confirm({
          message: '是否删除'
        }).then(() => {
          store.commit('showLoading')
          pointDelete(this.pointCheckedResult)
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.onClickActive(this.vanTabsActive, '')
              } else {
                this.$toast(response.message)
              }
              this.pointCheckedToButtonState = true
            }).catch((err) => {
              store.commit('hideLoading')
              this.$toast(err + '')
            })
        }).catch(() => {
        // on cancel
        })
    },
    pointItemCheckedClick(val) {
      this.pointCheckedToButtonState = !this.pointCheckedResult.length > 0
      if (this.pointCheckedResult.length <= 0) {
        this.pointChecked = false
      }
    },
    init() {
      this.onClickActive(this.vanTabsActive, '')
    },
    /**
     * 重置
     */
    reset() {
      this.pointData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          pageNo: 1,
          pageSize: 5
        }
      }
      this.maintenanceData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 5,
          type: 0,
          stateArray: null,
          today: null,
          startTime: null,
          endTime: null
        }
      }
      this.patrolData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 5,
          type: 1,
          state: null,
          today: null,
          startTime: null,
          endTime: null,
          userIds: null
        }
      }
      this.hiddenDangerData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 5,
          isSolve: null,
          code: null,
          startTime: null,
          endTime: null,
          isExam: null
        }
      }
    },
    /**
     * tab页切换
     */
    onClickActive(name, title) {
      this.reset()
      switch (name) {
        case 'point':
          this.vanNeedSearch = true
          this.vanSearchShow = false
          this.onSearchQueryReset()
          if (this.hasPerm(this.hasPermission.point)) {
            this.getPointList()
          }
          break
        case 'maintenance':
          this.vanNeedSearch = true
          if (this.maintenanceActiveName === null) {
            this.maintenanceActiveName = 'maintenance_not_start'
          }
          if (this.hasPerm(this.hasPermission.maintenance)) {
            this.onClickMaintenanceActive(this.maintenanceActiveName)
          }
          break
        case 'patrol':
          this.vanNeedSearch = true
          if (this.patrolActiveName === null) {
            this.patrolActiveName = 'patrol_no_patrol_inspection'
          }
          if (this.hasPerm(this.hasPermission.patrol)) {
            this.onClickPatrolActive(this.patrolActiveName)
          }
          break
        case 'hiddenDanger':
          this.vanNeedSearch = true
          if (this.hiddenDangerActiveName === null) {
            this.hiddenDangerActiveName = 'hiddenDanger_unhandled'
          }
          if (this.hasPerm(this.hasPermission.hiddenDanger)) {
            this.onClickHiddenDangerActive(this.hiddenDangerActiveName)
          }
          break
      }
    },
    searchPoint(value) {
      this.reset()
      this.pointData.query.code = value
      this.getPointList()
    },
    /**
     * 获取点位列表
     */
    getPointList() {
      this.pointData.query.unitId = this.tempUnitId
      pointList(this.pointData.query).then(res => {
        this.pointData.list = this.pointData.list.concat(res.data.rows)
        // 加载状态结束
        this.pointData.loading = false
        this.pointData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.pointData.list.length >= res.data.totalRows) {
          this.pointData.finished = true
        }
      })
    },
    /**
     * 点位列表加载
     */
    onPointLoad() {
      this.pointData.query.pageNo++
      this.getPointList()
    },
    /**
     * 获取维保任务列表
     */
    getMaintenanceList() {
      this.maintenanceData.query.unitId = this.tempUnitId
      taskPage(this.maintenanceData.query).then(res => {
        this.maintenanceData.list = this.maintenanceData.list.concat(res.data.rows)
        // 加载状态结束
        this.maintenanceData.loading = false
        this.maintenanceData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.maintenanceData.list.length >= res.data.totalRows) {
          this.maintenanceData.finished = true
        }
      })
    },
    /**
     * 维保任务列表加载
     */
    onMaintenanceLoad() {
      this.maintenanceData.query.pageNo++
      this.getMaintenanceList()
    },
    /**
     * 维保tab页切换
     */
    onClickMaintenanceActive(name, title) {
      this.reset()
      switch (name) {
        case 'maintenance_not_start':
          this.maintenanceData.query.stateArray = '0,2'
          this.maintenanceData.query.today = true
          break
        case 'maintenance_closed':
          this.maintenanceData.query.stateArray = '1'
          this.maintenanceData.query.today = false
          break
      }
      if (this.searchData.startTime !== null && this.searchData.endTime !== null) {
        this.maintenanceData.query.today = false
        this.maintenanceData.query.startTime = this.searchData.startTime
        this.maintenanceData.query.endTime = this.searchData.endTime
      }
      this.getMaintenanceList()
    },
    /**
     * 获取巡查任务列表
     */
    getPatrolList() {
      this.patrolData.query.unitId = this.tempUnitId
      this.patrolData.query.userIds = this.userInfo.id + ''
      selectTaskPage(this.patrolData.query).then(res => {
        this.patrolData.list = this.patrolData.list.concat(res.data.rows)
        // 加载状态结束
        this.patrolData.loading = false
        this.patrolData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.patrolData.list.length >= res.data.totalRows) {
          this.patrolData.finished = true
        }
      })
    },
    /**
     * 巡查任务列表加载
     */
    onPatrolLoad() {
      this.patrolData.query.pageNo++
      this.getPatrolList()
    },
    /**
     * 巡查tab页切换
     */
    onClickPatrolActive(name, title) {
      this.reset()
      switch (name) {
        case 'patrol_no_patrol_inspection':
          this.patrolData.query.stateArray = '0,2'
          this.patrolData.query.today = true
          break
        case 'patrol_patrolled':
          this.patrolData.query.stateArray = '1'
          this.patrolData.query.today = false
          break
      }
      if (this.searchData.startTime !== null && this.searchData.endTime !== null) {
        this.patrolData.query.today = false
        this.patrolData.query.startTime = this.searchData.startTime
        this.patrolData.query.endTime = this.searchData.endTime
      }
      this.getPatrolList()
    },
    /**
     * 获取隐患列表
     */
    getHiddenDangerList() {
      this.hiddenDangerData.query.unitId = this.tempUnitId
      if (Number(this.userInfo.unitType) === 3) {
        this.hiddenDangerData.query.isExam = true
      }
      dangerPage(this.hiddenDangerData.query).then(res => {
        this.hiddenDangerData.list = this.hiddenDangerData.list.concat(res.data.rows)
        // 加载状态结束
        this.hiddenDangerData.loading = false
        this.hiddenDangerData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.hiddenDangerData.list.length >= res.data.totalRows) {
          this.hiddenDangerData.finished = true
        }
      })
    },
    /**
     * 隐患列表加载
     */
    onHiddenDangerLoad() {
      this.hiddenDangerData.query.pageNo++
      this.getHiddenDangerList()
    },
    /**
     * 隐患tab页切换
     */
    onClickHiddenDangerActive(name, title) {
      this.reset()
      switch (name) {
        case 'hiddenDanger_unhandled':
          this.hiddenDangerData.query.isSolve = false
          break
        case 'hiddenDanger_processed':
          this.hiddenDangerData.query.isSolve = true
          break
      }
      if (this.searchData.code !== null) {
        this.hiddenDangerData.query.code = this.searchData.code
      }
      if (this.searchData.startTime !== null && this.searchData.endTime !== null) {
        this.hiddenDangerData.query.startTime = this.searchData.startTime
        this.hiddenDangerData.query.endTime = this.searchData.endTime
      }
      this.getHiddenDangerList()
    },
    /**
     * 当前路由修改参数
     * history.pushState() 添加
     * history.replaceState() 修改
     */
    setUrlParameter() {
      this.$router.replace({
        query: {
          unitId: this.tempUnitId,
          active: this.vanTabsActive
        }
      })
    },
    /**
     * 前往点位详情页面
     * @param val
     */
    goPointSelect(val) {
      this.$router.push({
        path: '/app/inspection/point/index',
        query: {
          id: val.id,
          unitId: val.unitId
        }
      })
    },
    goPointAdd() {
      this.$router.push({
        path: '/app/inspection/point/add/index',
        query: {
          unitId: this.tempUnitId,
          operationType: this.pointQueryOperation.add
        }
      })
    },
    /**
     * 前往开始页面
     */
    goStart(val) {
      this.$router.push({
        path: '/app/inspection/start/index',
        query: {
          taskType: val.type,
          taskId: val.id,
          taskState: val.state,
          unitId: val.unitId
        }
      })
    },
    goMaintenance(val) {
      this.$router.push({
        path: '/app/inspection/maintenance/index',
        query: {
          taskId: val.id,
          unitId: val.unitId,
          isButton: false
        }
      })
    },
    showPatrolRoute(val) {
      this.taskId = val.id
      this.routeShow = true
    },
    /**
     * 隐患页面跳转
     */
    goHidden(val, type) {
      this.$router.push({
        path: '/app/inspection/danger/handle/index',
        query: {
          id: val.id,
          operationType: type
        }
      })
    }
  }
}
</script>

<style scoped>
  .span_color {
    font-family: PingFang SC Bold;
    color: #979797;
  }

  .font_crude {
    font-family: PingFang SC Bold;
    font-weight: bolder !important;
  }

  #searchContent {
    margin-bottom: 63px;
  }

  #tabContent {
    padding: 15px 10px;
    margin-top: -63px;
    font-family: PingFang SC Bold;
    font-size: 14px;
  }

  #tabs {
    font-family: PingFang SC Bold;
  }

  #tabs ::v-deep .van-tabs__nav {
    background-color: transparent !important;
  }

  #tabs ::v-deep .van-tab {
    border-radius: 6px !important;
    margin: 0 4px 5px 4px !important;
    padding: 0 !important;
    background-color: #FFFFFF !important;
    font-weight: bolder !important;
  }

  #tabs ::v-deep .van-tabs__line {
    width: 0;
    height: 0;
    background-color: #FFFFFF !important;
  }

  #tabs ::v-deep .van-tab__pane {
    margin: 0 4px 0 4px !important;
    width: auto !important;
    background-color: #FFFFFF !important;
  }

  #tabs ::v-deep .van-tab--active {
    color: #1989FA !important;
    font-weight: bolder !important;
    height: 50px !important;
  }

  #tabs ::v-deep .van-tab__text {
    font-size: 18px;
  }

  #itemTab {
    font-family: PingFang SC Bold;

  }

  #itemTab ::v-deep .van-tab {
    border-radius: 6px !important;
    background-color: #FFFFFF !important;
    font-weight: normal !important;
  }

  #itemTab ::v-deep .van-tab__text {
    font-size: 14px;
  }

  #itemTab ::v-deep .van-tab--active {
    color: #1989FA !important;
    font-weight: bolder !important;
    height: auto !important;
  }
  .autoHeightList{
    height: calc(100vh - 158px - 44px - 48px - 75px);
    overflow-x: scroll
  }
</style>
