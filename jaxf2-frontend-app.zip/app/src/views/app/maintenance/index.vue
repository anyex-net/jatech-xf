<template>
  <div>
    <div class="home-nav">
      <van-nav-bar :border="false">
        <template #title>
          <span class="van-nav-bar__content">维保</span>
        </template>
      </van-nav-bar>
    </div>
  </div>
</template>

<script>

  export default {
    components: {},
    computed: {},
    methods: {
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path)
      },
    },
    data() {
      return {
        active: 0,
      }
    }
  }
</script>
