<template>
  <div id="inspectContent">
    <common-head
      :is-back="true"
      :scan="taskLineState"
      title="巡查"
      @scanData="goFillingByScan"
    />
    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4F4;">
        <div
          v-if="taskLineState !== null && taskLineState===false"
          style="margin:10px;background-color: #FFFFFF;padding: 16px"
        >
          <van-row style="margin-bottom: 18px">
            线路名称：
            <span style="font-weight: bolder">{{ lineInfo.name }}</span>
          </van-row>
          <van-row style="margin-bottom: 18px">
            巡查时间：
            <span style="font-weight: bolder">{{ lineInfo.checkTime }}</span>
          </van-row>
          <van-row style="margin-bottom: 18px">
            巡查人员：
            <span style="font-weight: bolder">{{ lineInfo.checkUserName }}</span>
          </van-row>
          <van-row v-if="lineInfo.signImg !== null && lineInfo.signImg !== '' " type="flex">
            人员签名：
            <div>
              <img
                :src="lineInfo.signImg"
                style="background-color: #FAFAFA;width:4rem;height: 3rem;padding-left: 10px;margin-top: 10px;border-radius: 6px"
              >
            </div>
          </van-row>
        </div>
        <van-tabs
          v-if="taskLineState !== null"
          id="tabs"
          v-model="tabsActive"
          style="margin: 12px 10px"
          line-height="1px"
          line-width="90px"
        >
          <!--        未查-->
          <van-tab :title="'未完成(' + notChecked.sum + ')'">
            <van-list
              v-model="notChecked.loading"
              :finished="notChecked.finished"
              finished-text="没有更多了"
              style="height: calc(100vh - 44px - 60px - 12px);overflow-x: scroll;"
              @load="onNotCheckedLoad"
            >
              <template v-for="(item,index) in notChecked.list">
                <div :key="index" style="margin-top: 2px;background-color: #FFFFFF">
                  <van-row
                    style="height:43px;padding-left:5%;align-items: center;width:95%"
                    type="flex"
                    justify="space-between"
                  >
                    <span style="color: #979797;">设备编号：
                      <span
                        style="color: #333333;margin-left: 5px;font-weight:bold;font-size:14px;"
                      >{{ item.code }}</span>
                    </span>
                  </van-row>
                  <div class="van-hairline--bottom" style="margin: 0 16px;" />
                  <div style="height:15px;" />
                  <van-row
                    style="padding-left:5%;align-items: center;width:100%"
                    type="flex"
                  >
                    <van-col :span="18" style="display: flex;flex-direction: column;align-items: stretch;">
                      <div style="color: #979797;height:35px">设备区域：
                        <span style="color:  #333333;margin-left: 9px;">{{ item.areaName }}</span>
                      </div>
                      <div style="color: #979797;height:35px">设备位置：
                        <span style="color:  #333333;margin-left: 9px;">{{ item.position }}</span>
                      </div>
                    </van-col>
                    <van-col :span="6" style="display: flex;align-items: center;text-align: center">
                      <van-button
                        v-if="taskLineState"
                        style="background: linear-gradient(90deg, #F9DC66 0%, #F6C962 100%);
                    border: 1px solid transparent;color: #FFFFFF;border-radius: 6px;height: 28px;"
                        size="small"
                        @click="goDetails(item)"
                      >情况说明
                      </van-button>
                    </van-col>
                  </van-row>
                  <div style="height:5px;" />
                </div>
              </template>
            </van-list>
          </van-tab>
          <!--        已查-->
          <van-tab :title="'已完成(' + checked.sum + ')'">
            <van-list
              v-model="checked.loading"
              :finished="checked.finished"
              finished-text="没有更多了"
              style="height: calc(100vh - 44px - 60px - 12px);overflow-x: scroll;"
              @load="onCheckedLoad"
            >
              <template v-for="(item, index) in checked.list">
                <div :key="index" style="margin-top: 2px;background-color: #FFFFFF" @click="goFillingDetails(item)">
                  <van-row style="padding: 15px 16px 11px" type="flex">
                    <span style="color: #979797;margin:8px 0">设备编号：
                      <span
                        style="color: #333333;margin-left: 4px;font-weight: bold;font-size:14px;"
                      >{{ item.code }}</span>
                    </span>
                  </van-row>
                  <div class="van-hairline--bottom" style="margin: 0 16px;" />
                  <van-row style="margin: 11px 16px 0;padding-bottom: 10px;align-items: center;" type="flex">
                    <van-col style="display: flex;flex-direction: column;align-items: stretch;">
                      <!-- <span style="color: #979797;margin:8px 0">设备类型：
                         <span style="color:  #333333;margin-left: 9px">{{ item.typeName }}</span>
                       </span>-->
                      <span v-if="item.areaName" style="color: #979797;margin:8px 0">设备区域：
                        <span style="color:  #333333;margin-left: 9px">{{ item.areaName }}</span>
                      </span>
                      <span style="color: #979797;margin:8px 0">设备位置：
                        <span style="color:  #333333;margin-left: 9px">{{ item.position }}</span>
                      </span>
                      <span v-if="item.message" style="color: #979797;margin:8px 0">情况说明：
                        <span style="color:  #333333;margin-left: 9px">{{ item.message }}</span>
                      </span>
                      <span style="color: #979797;margin:8px 0">巡查人员：
                        <span style="color:  #333333;margin-left: 9px">{{ item.checkUserName }}</span>
                      </span>
                      <span style="color: #979797;margin:8px 0">巡查时间：
                        <span style="color:  #333333;margin-left: 9px">{{ item.checkTime }}</span>
                      </span>
                    </van-col>
                  </van-row>
                </div>
              </template>
            </van-list>
          </van-tab>
        </van-tabs>
      </div>
    </div>

    <div v-if="tabsActive===0 && taskLineState" class="bottom" />
    <div v-if="tabsActive===0 && taskLineState" class="bar-footer" style="width: 100%">
      <van-row class="button1" gutter="2" justify="space-around" type="flex">
        <van-button
          style="background-color: #1989FA;border: 1px solid #1989FA"
          class="but"
          size="normal"
          type="info"
          @click="goFilling"
        >
          表格填写
        </van-button>
        <van-button
          style="background: linear-gradient(90deg, #F9DC66 0%, #F6C962 100%);border: 1px solid transparent;"
          class="but"
          size="normal"
          @click="goDanger"
        >隐患上报
        </van-button>
        <van-button
          style="background-color: #3E3E3E;border: 1px solid #3E3E3E"
          class="but"
          size="normal"
          type="info"
          @click="onEndButton"
        >结束巡查
        </van-button>
      </van-row>
    </div>

    <sign :sign-show="endPopupSignShow" @signId="setSignId" @signShowState="(e)=>{this.endPopupSignShow = e}" />

    <van-popup v-model="endPopupShow" round position="bottom" :style="{ height: '45%' }">
      <div
        style="padding: 14px 16px;width:100%;position: fixed;background-color: #FFFFFF;
      border-radius: 16px 16px 0 0;z-index: 99;"
      >
        <div style="display: flex;align-items: center;justify-content: center;height: 18px;line-height: 18px;">
          <span style="font-weight: bolder;font-size: 18px;color: #606060">提示</span>
        </div>
        <div style="display: flex;justify-content: flex-end;align-items: center;height: 18px;margin-top: -18px;">
          <van-icon color="#949494" name="cross" size="large" @click="endPopupShow = false" />
        </div>
      </div>
      <div style="margin:55px 12px 20px;">
        <van-radio-group v-model="inspectionData.checkDescribe">
          <van-cell-group>
            <div v-for="(item, index) in actions" :key="index">
              <van-cell
                :title="item.text"
                clickable
                class="details_option"
                :class="{details_option_active: item.text === tempText}"
                @click="itemChecked(item.text)"
              >
                <template #right-icon>
                  <van-radio :name="item.text">
                    <template #icon="props">
                      <img class="img-icon" :src="''">
                    </template>
                  </van-radio>
                </template>
              </van-cell>
            </div>
          </van-cell-group>
        </van-radio-group>
      </div>
      <div
        style="position: fixed;margin:0 12px;bottom:calc(10px + constant(safe-area-inset-bottom));
      bottom:10px; bottom: calc(10px + env(safe-area-inset-bottom));left: 0;right: 0;"
      >
        <van-row type="flex" gutter="2" justify="space-around">
          <van-col span="11">
            <van-button
              style="background-color: #1989FA;border: 1px solid transparent;width: 100%"
              class="but"
              size="normal"
              @click="automaticPatrol"
            >自动巡查
            </van-button>
          </van-col>
          <van-col span="11">
            <van-button
              style="background-color: #3E3E3E;border: 1px solid #3E3E3E;;width: 100%"
              class="but"
              size="normal"
              type="info"
              @click="endPatrol"
            >结束巡查
            </van-button>
          </van-col>
        </van-row>
      </div>
    </van-popup>
  </div>
</template>

<script>
import { automaticPatrolInspection, endPatrolInspection, taskLogPage } from '@/api/newExam/taskLog'
import { Dialog } from 'vant'
import commonHead from '@/views/app/common/head'
import { taskDetail } from '@/api/newExam/task'
import sign from '@/views/app/new/inspection/sign'
import { taskLineDetail } from '@/api/newExam/taskLine'
import msExamTask from '@/api/offline/msExamTask'
import msTaskLine from '@/api/offline/msTaskLine'
import msTaskLog from '@/api/offline/msTaskLog'
import store from '@/store'

export default {
  name: 'Index',
  components: {
    commonHead,
    [Dialog.Component.name]: Dialog.Component,
    sign
  },
  data() {
    return {
      tempText: null,
      test: null,
      taskLineState: null,
      notChecked: {
        query: {
          taskLineId: null,
          checkStatus: 0,
          pageNo: 1,
          pageSize: 10
        },
        list: [],
        sum: 0,
        loading: true,
        finished: false
      },
      checked: {
        query: {
          taskLineId: null,
          checkStatus: 1,
          pageNo: 1,
          pageSize: 10
        },
        list: [],
        sum: 0,
        loading: true,
        finished: false
      },
      tabsActive: 0,
      endPopupSignShow: false,
      taskId: this.$route.query.taskId,
      unitId: this.$route.query.unitId,
      taskLineId: this.$route.query.taskLineId,
      isFill: null,
      isSign: null,
      isLineSign: null,
      lineInfo: {
        name: null,
        checkUserName: null,
        checkTime: null,
        signImg: null
      },
      endPopupShow: false,
      inspectionData: {
        taskId: null,
        taskLineId: null,
        sign: null,
        checkDescribe: null
      },
      actions: [{ text: '--' }, { text: '工作另有安排' }, { text: '其他原因' }],
      isOffline: false
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  created() {
    this.init()
  },
  methods: {
    async init() {
      this.isOffline = sessionStorage.getItem('isOffline')
      await this.getTaskDetail()
      await this.getTaskLineDetail()
      await this.getNotCheckedList()
      await this.getCheckedList()
    },
    itemChecked(val) {
      this.tempText = val
      this.inspectionData.checkDescribe = val
    },
    setSignId(e) {
      this.inspectionData.sign = e
      if (this.notChecked.sum === 0) {
        this.endPatrol()
      } else {
        this.endPopupShow = true
      }
    },
    async getTaskDetail() {
      if (this.isOffline === 'true') {
        await msExamTask.selectById(this.taskId).then(res => {
          if (res) {
            this.isSign = res.isSign
            this.isLineSign = res.isLineSign
            this.isFill = res.isFill
          }
        })
      } else {
        await taskDetail(this.taskId).then(res => {
          this.isSign = res.data.isSign
          this.isLineSign = res.data.isLineSign
          this.isFill = res.data.isFill
        }).catch(err => {
          console.log('err', err)
        })
      }
    },
    /**
       * 查看完成的线路信息
       */
    async getTaskLineDetail() {
      if (this.isOffline === 'true') {
        await msTaskLine.selectById(this.taskLineId).then(res => {
          if (res) {
            if (res.state === 1) {
              this.tabsActive = 1
              this.taskLineState = false
              this.lineInfo.name = res.name
              this.lineInfo.checkUserName = res.checkUserName
              this.lineInfo.checkTime = res.checkTime
              if (res.signImg !== null && res.signImg !== '') {
                this.lineInfo.signImg = '/file/' + res.signImg
              }
            } else {
              this.taskLineState = true
            }
          }
        })
      } else {
        await taskLineDetail(this.taskLineId).then(res => {
          if (res.data.state === 1) {
            this.tabsActive = 1
            this.taskLineState = false
            this.lineInfo.name = res.data.name
            this.lineInfo.checkUserName = res.data.checkUserName
            this.lineInfo.checkTime = res.data.checkTime
            if (res.data.signImg !== null && res.data.signImg !== '') {
              this.lineInfo.signImg = this.$host + '/file/' + res.data.signImg
            }
          } else {
            this.taskLineState = true
          }
        }).catch(err => {
          console.log('err', err)
        })
      }
    },
    /**
       * 获取未检查列表
       */
    async getNotCheckedList() {
      this.notChecked.query.taskLineId = this.taskLineId
      if (this.isOffline === 'true') {
        this.notChecked.query.checkStatus = '0'
        await msTaskLog.selectPage(this.notChecked.query).then(res => {
          if (res) {
            this.notChecked.list = this.notChecked.list.concat(res.data.rows)
            this.notChecked.sum = res.data.totalRows
            // 结束
            this.notChecked.loading = false
            // 数据全部加载完成
            if (this.notChecked.list.length >= res.data.totalRows) {
              this.notChecked.finished = true
            }
          }
        })
      } else {
        await taskLogPage(this.notChecked.query).then(res => {
          this.notChecked.list = this.notChecked.list.concat(res.data.rows)
          this.notChecked.sum = res.data.totalRows
          // 结束
          this.notChecked.loading = false
          // 数据全部加载完成
          if (this.notChecked.list.length >= res.data.totalRows) {
            this.notChecked.finished = true
          }
        })
      }
    },
    /**
       * 未检查列表加载
       */
    onNotCheckedLoad() {
      this.notChecked.query.pageNo++
      this.getNotCheckedList()
    },
    /**
       * 获取已检查列表
       */
    async getCheckedList() {
      this.checked.query.taskLineId = this.taskLineId
      if (this.isOffline === 'true') {
        await msTaskLog.selectPage(this.checked.query).then(res => {
          if (res) {
            this.checked.list = this.checked.list.concat(res.data.rows)
            this.checked.sum = res.data.totalRows
            // 加载状态结束
            this.checked.loading = false
            // 数据全部加载完成
            if (this.checked.list.length >= res.data.totalRows) {
              this.checked.finished = true
            }
          }
        })
      } else {
        await taskLogPage(this.checked.query).then(res => {
          this.checked.list = this.checked.list.concat(res.data.rows)
          this.checked.sum = res.data.totalRows
          // 加载状态结束
          this.checked.loading = false
          // 数据全部加载完成
          if (this.checked.list.length >= res.data.totalRows) {
            this.checked.finished = true
          }
        })
      }
    },
    /**
       * 已检查列表加载
       */
    onCheckedLoad() {
      this.checked.query.pageNo++
      this.getCheckedList()
    },
    /**
       * 情况说明页面跳转
       */
    goDetails(val) {
      this.$router.push({
        path: '/app/new/inspection/details/index',
        query: {
          unitId: this.unitId,
          taskLogId: val.id,
          isSign: this.isSign
        }
      })
    },
    /**
       * 扫描二维码跳转到表格填写页面
       * @param val
       */
    goFillingByScan(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      this.$router.push({
        path: '/app/new/inspection/filling/index',
        query: {
          operationType: 'scan',
          scanCode: val.code,
          codeType: val.type,
          taskId: this.taskId,
          taskLineId: this.taskLineId,
          isSign: this.isSign,
          isFill: this.isFill
        }
      })
    },
    /**
       * 表格页面跳转
       */
    goFilling() {
      this.$router.push({
        path: '/app/new/inspection/filling/index',
        query: {
          taskId: this.taskId,
          taskLineId: this.taskLineId,
          isSign: this.isSign,
          isFill: this.isFill
        }
      })
    },
    /**
       * 已检查点位详情
       */
    goFillingDetails(val) {
      this.$router.push({
        path: '/app/new/inspection/filling/details/index',
        query: {
          taskLogId: val.id,
          isSign: this.isSign,
          isFill: this.isFill
        }
      })
    },
    /**
       * 隐患上报页面跳转
       */
    goDanger() {
      this.$router.push({
        path: '/app/new/inspection/danger/index',
        query: {
          unitId: this.unitId,
          taskLineId: this.taskLineId
        }
      })
    },
    /**
       * 结束按钮
       */
    onEndButton() {
      if (this.isLineSign && this.inspectionData.sign === null) {
        this.endPopupSignShow = true
      } else if (!this.isLineSign && this.notChecked.sum === 0) {
        this.endPatrol()
      } else {
        this.endPopupShow = true
      }
    },
    /**
     * 自动巡查
     */
    automaticPatrol() {
      this.inspectionData.taskId = this.taskId
      this.inspectionData.taskLineId = this.taskLineId
      store.commit('showLoading')
      if (this.isOffline === 'true') {
        this.inspectionData.userId = this.userInfo.id
        msTaskLog.automaticPatrolInspection(this.inspectionData).then(res => {
          store.commit('hideLoading')
          if (res) {
            this.$router.push({
              path: '/app/new/inspection/offline/list',
              query: {
                unitId: this.unitId
              }
            })
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      } else {
        automaticPatrolInspection(this.inspectionData).then(res => {
          store.commit('hideLoading')
          if (res.success) {
            this.$router.push({
              path: '/app/new/inspection/index',
              query: {
                unitId: this.unitId
              }
            })
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      }
    },
    /**
       * 结束巡查
       */
    endPatrol() {
      this.inspectionData.taskId = this.taskId
      this.inspectionData.taskLineId = this.taskLineId
      store.commit('showLoading')
      if (this.isOffline === 'true') {
        this.inspectionData.userId = this.userInfo.id
        msTaskLog.endPatrolInspection(this.inspectionData).then(res => {
          store.commit('hideLoading')
          if (res) {
            this.$router.push({
              path: '/app/new/inspection/offline/list',
              query: {
                unitId: this.unitId
              }
            })
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      } else {
        endPatrolInspection(this.inspectionData).then(res => {
          store.commit('hideLoading')
          if (res.success) {
            this.$router.push({
              path: '/app/new/inspection/index',
              query: {
                unitId: this.unitId
              }
            })
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      }
    }
  }
}
</script>

<style scoped>
  #inspectContent {
    font-family: PingFang SC Bold;
    background-color: #F4F4F4 !important;
    font-size: 14px;
  }

  #tabs {
    font-family: PingFang SC Bold;
  }

  #tabs ::v-deep .van-tabs__nav {
    background-color: transparent !important;
  }

  #tabs ::v-deep .van-tab {
    padding: 0 !important;
    background-color: #FFFFFF !important;
    color: #979797;
  }

  #tabs ::v-deep .van-tabs__line {
    width: 0;
    height: 0;
    background-color: #FFFFFF !important;
  }

  #tabs ::v-deep .van-tab__pane {
    width: auto !important;
    background-color: #F4F4F4 !important;
  }

  #tabs ::v-deep .van-tab--active {
    color: #1989FA !important;
    font-weight: bolder !important;
  }

  #tabs ::v-deep .van-tab__text {
    font-size: 14px;
  }

  .details_option {
    background-color: #F5F7FA;
    margin-bottom: 13px;
    border-radius: 6px;
    text-align: left;
    font-size: 16px;
    font-weight: normal;
    color: #313131
  }

  .details_option_active {
    background-color: #1989FA;
    color: #FFFFFF;
  }

  .butDiv_ {
    text-align: center;
    position: fixed;
    bottom: constant(safe-area-inset-bottom);
    bottom: 0px;
    bottom: env(safe-area-inset-bottom);
    left: 0;
    right: 0;
    padding: 0.3rem 0;
    color: #fff;
    background-color: #f7f7f8;
  }

  .but {
    border-radius: 6px;
    height: 50px;
    font-size: 16px;
    color: #FFFFFF;
  }

</style>
