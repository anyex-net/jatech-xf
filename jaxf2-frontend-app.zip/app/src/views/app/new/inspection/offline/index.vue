<template>
  <div style="background-color: #F4F4F4;height: 100vh">
    <common-head
      :custom-left="true"
      :custom-right="true"
      :scan="false"
      title="巡查任务"
    >
      <template #left>
        <img
          ref="backRef"
          style="width: 16px"
          alt=""
          :src="require('@/assets/images/new/back.png')"
          width="20"
          @click="goBack"
        >
      </template>
      <template #right>
        <van-button
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #1989FA"
          @click="offlineUpload"
        >离线上传
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <van-list
        v-model="patrolData.loading"
        :finished="patrolData.finished"
        :finished-text="patrolData.message"
        @load="onPatrolLoad"
      >
        <template v-for="(item,index) in patrolData.list">
          <div :key="index">
            <van-row style="padding: 15px 16px 11px" type="flex">
              <span class="font_crude">{{ toParseTime(item.startTime, '{m}/{d} {h}') + "点" + item.name }}</span>
            </van-row>
            <div class="van-hairline--bottom" style="margin: 0 16px;" />
            <van-row justify="space-between" style="margin: 11px 16px;align-items: center;" type="flex">
              <van-col span="13" style="display: flex;flex-direction: column;align-items: stretch;">
                <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：<span
                  style="color: black;font-size:12px"
                >{{ toParseTime(item.startTime, '{y}/{m}/{d} {h}:{i}') }}</span></span>
                <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：<span
                  style="color: black;font-size:12px"
                >{{ toParseTime(item.endTime, '{y}/{m}/{d} {h}:{i}') }}</span></span>
              </van-col>
              <van-col span="11" style="display: flex;justify-content: flex-end;">
                <van-button
                  v-show="Number(item.state) === 0"
                  plain
                  size="small"
                  style="border-radius: 6px"
                  type="info"
                  @click="goStart(item)"
                >
                  <span style="font-size: 14px;font-weight: bold">开始巡查</span>
                </van-button>

                <van-button
                  v-show="Number(item.state) === 2"
                  plain
                  size="small"
                  style="border-radius: 6px"
                  type="info"
                  @click="showPatrolRoute(item,false)"
                >
                  <span style="font-size: 14px;font-weight: bold">巡查中</span>
                </van-button>
                <van-button
                  v-show="Number(item.state) === 1"
                  color="#979797"
                  plain
                  size="small"
                  style="border-radius: 6px"
                  type="info"
                  @click="showPatrolRoute(item,false)"
                >
                  <span style="font-size: 14px;font-weight: bold">巡查结束</span>
                </van-button>
              </van-col>
            </van-row>
          </div>
        </template>
      </van-list>
    </div>
    <!--    线路弹窗-->
    <route
      v-if="routeShow"
      :is-nav-bottom="true"
      :route-show="routeShow"
      :route-state="routeState"
      :task-id="taskId"
      :title="routeTitle"
      @routeShowState="e => { this.routeShow = e }"
    />
  </div>
</template>

<script>
import commonHead from '@/views/app/common/head'
import route from '@/views/app/new/inspection/route/index'
import msExamTask from '@/api/offline/msExamTask'
import { parseTime } from '@/utils'
import androidShellApi from '@/api/offline/androidShellApi'
import store from '@/store'
import { getToken } from '@/utils/auth'

export default {
  name: 'Index',
  components: {
    commonHead, route
  },
  data() {
    return {
      routeTitle: '选择您巡查的路线',
      routeState: false,
      routeShow: false,
      patrolData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 10,
          type: 1,
          state: null,
          today: null,
          startTime: null,
          endTime: null
        }
      },
      taskId: null,
      unitId: this.$route.query.unitId
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  created() {
    this.patrolData.list = []
    this.getPatrolList()
  },
  methods: {
    goBack() {
      this.$router.push({
        path: '/app/new/inspection/offline',
        query: {
          unitId: this.unitId
        }
      })
    },
    toParseTime(time, format) {
      return parseTime(time, format)
    },
    /**
     * 巡查任务列表加载
     */
    onPatrolLoad() {
      this.patrolData.query.pageNo++
      this.getPatrolList()
    },
    /**
     * 获取巡查任务列表
     */
    getPatrolList() {
      this.patrolData.query.unitId = this.userInfo.unitId
      msExamTask.selectPage(this.patrolData.query).then(res => {
        if (res) {
          this.patrolData.list = this.patrolData.list.concat(res.data.rows)
          // 加载状态结束
          this.patrolData.loading = false
          this.patrolData.total = res.data.totalRows
          // 数据全部加载完成
          if (this.patrolData.list.length >= res.data.totalRows) {
            this.patrolData.finished = true
          }
        }
      })
    },
    /**
     * 前往开始页面
     */
    goStart(val) {
      this.$router.push({
        path: '/app/new/inspection/start/index',
        query: {
          taskType: val.type,
          taskId: val.id,
          taskState: val.state,
          unitId: val.unitId
        }
      })
    },
    showPatrolRoute(val, routeState) {
      this.routeState = routeState
      if (routeState) {
        this.routeTitle = '请选择查看轨迹的线路'
      }
      if (this.patrolValue !== 0) {
        this.taskId = val.id
        this.routeShow = true
      }
    },
    /**
     * 离线上传
     */
    offlineUpload() {
      androidShellApi.isNetWorkByAndroid().then(res => {
        if (res) {
          store.commit('showLoading')
          setTimeout(() => {
            androidShellApi.fileUpload(this.userInfo.id, getToken())
              .then(res => {
                store.commit('hideLoading')
                if (res.success) {
                  this.$toast('上传成功')
                  this.goBack()
                } else {
                  this.$toast('上传失败：' + res.message)
                }
              }).catch(err => {
                store.commit('hideLoading')
                this.$toast('上传失败：' + err)
              })
          }, 1000)
        } else {
          this.$toast('上传失败：请检查网络链接！！！')
        }
      }).catch(err => {
        console.log(err)
      })
    }
  }
}
</script>

<style scoped>
.span_color {
  font-family: PingFang SC Bold;
  color: #979797;
}

.font_crude {
  font-family: PingFang SC Bold;
  font-weight: bolder !important;
}
</style>
