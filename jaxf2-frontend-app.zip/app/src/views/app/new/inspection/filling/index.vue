<template>
  <div style="font-family: PingFang SC Bold;font-size: 14px;">
    <common-head
      :back-img="require('@/assets/images/new/back1.png')"
      :custom-right="true"
      :custom-title="true"
      :is-back="true"
      back-img-style="width: 10px;height: 20px"
      background-color="#FFFFFF"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">表格填写</span>
      </template>
      <template #right>
        <div v-if="!autoSubmit" style="display: flex;align-items: center;">
          <van-count-down
            v-if="temp.delayedSubmission && timerState"
            style="margin-right: 2px"
            :time="parseInt(temp.delayedSubmission * 1000)"
          >
            <template #default="timeData">
              <span>延迟{{ timeData.seconds }}秒后</span>
            </template>
          </van-count-down>
          <van-button
            v-if="temp.code === null || temp.code === '' || timerState"
            disabled
            size="small"
            style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #BDBDBD"
          >提交
          </van-button>
          <van-button
            v-else
            size="small"
            style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;color: #FFFFFF;background-color: #1989FA"
            @click="handleSave"
          >提交
          </van-button>
        </div>
      </template>
    </common-head>

    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <van-form id="fillForm" ref="fillForm" validate-first @submit="onSubmit">
          <div style="margin: 12px 10px;background-color: #FFFFFF">
            <div v-if="scanShow">
              <van-row
                justify="space-between"
                style="height: 123px;align-items: center;padding: 0 15px 0 30px"
                type="flex"
              >
                <van-row type="flex" style="align-items: center;">
                  <scan @scanData="newFillingIndexScan">
                    <template #icon>
                      <van-icon name="scan" color="#1989FA" size="40" style="line-height: inherit;" />
                    </template>
                  </scan>
                  <div
                    style="margin-left: 26px;display: flex;flex-direction: column;align-items: flex-start;
                font-size: 14px;color: #1989FA;font-weight: bolder;"
                  >
                    <span>扫一扫</span>
                    <span>获取设备信息</span>
                  </div>
                </van-row>
                <div
                  class="span_color"
                  style="display: flex;align-items: center;color: #979797"
                  @click="scanShow = false"
                >
                  <span>二维码失效</span>
                  <van-icon name="arrow" />
                </div>
              </van-row>
              <div
                class="van-hairline--bottom"
                style="margin: 10px 17px;border-bottom: 1px solid #F3F3F3"
              />
            </div>
            <div v-if="!scanShow">
              <van-field
                v-model="temp.code"
                :border="false"
                placeholder="请输入二维码"
                input-align="right"
                label="二维码："
                name="code"
                @blur="setCode"
              >
                <template #right-icon>
                  <scan width="12" @scanData="newFillingIndexScan">
                    <template #icon>
                      <van-icon name="scan" style="font-size: 16px;line-height: inherit;" />
                    </template>
                  </scan>
                </template>
              </van-field>
              <van-field
                v-model="temp.name"
                readonly
                input-align="right"
                label="名　称："
                name="name"
                :border="false"
              />
              <van-field
                v-model="temp.typeName"
                readonly
                input-align="right"
                label="类　型："
                name="typeName"
                :border="false"
              />
              <van-field
                v-model="temp.areaName"
                readonly
                input-align="right"
                label="区　域："
                name="areaName"
                :border="false"
              />
              <van-field
                v-model="temp.position"
                readonly
                input-align="right"
                label="位　置："
                name="position"
                :border="false"
              />
              <van-field
                v-if="extinguisherShow"
                v-model="temp.address"
                readonly
                input-align="right"
                label="详细地址："
                name="address"
                :border="false"
              />
              <van-field
                v-if="extinguisherShow"
                v-model="temp.extinguisherTypeName"
                readonly
                input-align="right"
                label="设备类型："
                name="extinguisherTypeName"
                :border="false"
              />
              <van-field
                v-if="extinguisherShow"
                v-model="temp.factoryDate"
                readonly
                input-align="right"
                label="生产日期："
                name="factoryDate"
                :border="false"
              />
              <van-field
                v-if="extinguisherShow"
                v-model="temp.scrapDate"
                readonly
                input-align="right"
                label="报废时间："
                name="scrapDate"
                :border="false"
              />
              <van-field v-if="valueState" input-align="right" name="state" label="状　态：">
                <template #input>
                  <van-radio-group v-model="temp.state" direction="horizontal">
                    <van-radio name="1" shape="square" @click="setExtinguisherAbnormalState(false)">正常</van-radio>
                    <van-radio name="2" shape="square" @click="setExtinguisherAbnormalState(true)">异常</van-radio>
                  </van-radio-group>
                </template>
              </van-field>
              <van-field
                v-if="extinguisherAbnormalState && extinguisherShow"
                input-align="right"
                name="extinguisherState"
                label="操作内容："
              >
                <template #input>
                  <van-radio-group v-model="temp.extinguisherState" direction="horizontal">
                    <van-radio name="1" shape="square">更换</van-radio>
                    <van-radio name="2" shape="square">报废</van-radio>
                  </van-radio-group>
                </template>
              </van-field>
              <van-field
                v-if="textState || temp.extinguisherState === '2'"
                v-model="temp.text"
                :border="false"
                :rules="[{ required: true, message: '请填写文字' }]"
                input-align="right"
                label="文　字："
                name="text"
              />
              <van-field v-if="imgState || temp.extinguisherState === '2'" name="uploader" label="图　片：">
                <template #input>
                  <van-uploader
                    v-model="temp.img"
                    :after-read="offlineUpload"
                    preview-size="60"
                    style="padding-top: 10px;"
                    @delete="offlineDelete"
                  />
                </template>
              </van-field>
            </div>
            <div style="padding: 15px">
              <van-field
                v-model="temp.message"
                :autosize="true"
                input-align="left"
                maxlength="50"
                name="message"
                placeholder="请输入留言"
                rows="2"
                show-word-limit
                type="textarea"
                style="background-color: #FAFAFA;border-radius: 6px;"
              />
            </div>
          </div>
          <!--          检查项-->
          <div
            v-if="isFill === 'true' && temp.tableList && temp.tableList.length > 0"
            style="margin: 12px 10px;padding: 13px 16px;background-color: #FFFFFF"
          >
            <van-row style="padding-bottom: 10px">
              <span style="font-size: 16px;color: #606060;font-weight: bolder">检查项</span>
            </van-row>
            <div class="van-hairline--bottom" style="margin-bottom: 19px" />
            <van-field name="checkboxGroup" style="padding:0">
              <template #input>
                <van-checkbox-group v-model="result" style="width: 100%;">
                  <van-collapse v-model="activeName">
                    <div v-for="(item,index) in temp.tableList" :key="index">
                      <van-collapse-item
                        ref="vanCollapseItem"
                        :name="item.id"
                        :title="'检查项'+(index + 1)+'：' + item.name"
                        class="item_collapse"
                      >
                        <template #title="prop">
                          <span style="color:#3A3A44">检查项{{ index + 1 }}：{{ item.name }}</span>
                        </template>
                        <div v-for="(children,index1) in item.children" :key="index1">
                          <van-checkbox
                            :name="children"
                            shape="square"
                            style="margin: 10px;color:#707070"
                          >
                            {{ children.content }}
                            <van-tag v-if="Number(children.isDanger) === 1" plain type="warning">隐患
                            </van-tag>
                          </van-checkbox>
                          <div
                            v-if="result.includes(children)"
                            style="padding: 10px 0 10px 40px;"
                          >
                            <van-field
                              v-model="children.checkDescribe"
                              placeholder="请输入描述"
                              clearable
                              maxlength="50"
                              rows="2"
                              show-word-limit
                              style="border: 1px solid #f3f3f3;padding-left: 12px;border-radius: 10px"
                              type="textarea"
                              :rules="[{ required: true, message: '请输入解决描述' }]"
                            />
                            <van-uploader
                              v-model="children.checkImgIdList"
                              :after-read="offlineUpload"
                              preview-size="60"
                              style="padding-top: 10px;"
                              @delete="offlineDelete"
                            />
                            <div
                              class="van-hairline--bottom"
                              style="margin-bottom: 10px"
                            />
                            <van-field
                              :border="false"
                              label="是否当场解决:"
                              label-width="90px"
                              style="padding: 0"
                            >
                              <template #input>
                                <van-switch v-model="children.isSolve" :active-value="true" :inactive-value="false" size="20" />
                              </template>
                            </van-field>
                            <div v-if="children.isSolve" style="padding: 10px 0">
                              <van-field
                                v-model="children.dangersSolvedDescribe"
                                placeholder="请输入解决描述"
                                clearable
                                maxlength="50"
                                rows="2"
                                show-word-limit
                                style="border: 1px solid #f3f3f3;padding-left: 12px;border-radius: 10px"
                                type="textarea"
                                :rules="[{ required: true, message: '请输入解决描述' }]"
                              />
                              <van-uploader
                                v-model="children.dangersSolvedImgIdList"
                                :after-read="offlineUpload"
                                preview-size="60"
                                style="padding-top: 10px;"
                                @delete="offlineDelete"
                              />
                            </div>
                          </div>
                          <div
                            v-if="result.includes(children)"
                            class="van-hairline--bottom"
                          />
                        </div>
                      </van-collapse-item>
                    </div>
                  </van-collapse>
                </van-checkbox-group>
              </template>
            </van-field>
          </div>
        </van-form>
      </div>
    </div>

    <sign
      :sign-show="endPopupSignShow"
      @signId="setSignId"
      @signShowState="(e)=>{this.endPopupSignShow = e}"
    />
  </div>
</template>

<script>

import { sysFileInfoUpload } from '@/api/system/fileManage'
import commonHead from '@/views/app/common/head'
import sign from '@/views/app/new/inspection/sign'
import { taskLogInfo } from '@/api/newExam/taskLog'
import { fillingFormAdd } from '@/api/newExam/filling'
import store from '@/store'
import sysFile from '@/api/offline/sysFile'
import msTaskLog from '@/api/offline/msTaskLog'
import msExamFilling from '@/api/offline/msExamFilling'
import SnowflakeId from 'snowflake-id'
const snowflake = new SnowflakeId()
import Scan from '@/views/app/common/scan'

export default {
  components: {
    commonHead, sign, Scan
  },
  data() {
    return {
      result: [],
      activeName: [],
      scanShow: true,
      endPopupSignShow: false,
      imgState: false,
      valueState: false,
      textState: false,
      temp: {
        id: null,
        code: null,
        name: null,
        signId: null,
        typeName: null,
        areaName: null,
        position: null,
        message: null,
        parents: [],
        children: [],
        tableList: [],
        text: null,
        state: null,
        img: [],
        delayedSubmission: null,
        extinguisherState: null,
        scrapDate: null,
        factoryDate: null,
        extinguisherTypeName: null,
        address: null
      },
      taskId: this.$route.query.taskId,
      taskLineId: this.$route.query.taskLineId,
      operationType: this.$route.query.operationType,
      scanCode: this.$route.query.scanCode,
      timerState: true,
      extinguisherShow: false,
      extinguisherAbnormalState: false,
      isOffline: false,
      isFill: this.$route.query.isFill,
      isSign: this.$route.query.isSign,
      autoSubmit: false,
      codeType: null,
      codeAndType: [
        { code: 0, type: 'nfc', name: 'NFC' },
        { code: 1, type: 'barcode', name: '二维码' }
      ],
      isScanCodeType: false
    }
  },
  computed: {
    userName() {
      return this.$store.getters.name
    },
    userInfo() {
      return this.$store.getters.user
    }
  },
  watch: {
    'temp.delayedSubmission'(val, oldVal) {
      this.timerState = true
      const timer = setTimeout(() => {
        this.timerState = false
        clearTimeout(timer)
      }, val * 1000)
    }
  },
  created() {
    this.init()
  },
  beforeDestroy() {
  },
  methods: {
    offlineDelete(file) {
      if (this.isOffline === 'true') {
        store.commit('showLoading')
        const fileName = file.fileId + '.png'
        sysFile.delete({ id: file.fileId, fileOriginName: fileName, userId: this.userInfo.id }).then(res => {
          store.commit('hideLoading')
          if (res) {
            this.$toast({ type: 'success', message: '删除成功' })
          } else {
            this.$toast({ type: 'fail', message: '删除失败' })
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      }
    },
    offlineUpload(file) {
      store.commit('showLoading')
      if (this.isOffline === 'true') {
        const randNum = snowflake.generate()
        const fileName = randNum + '.png'
        sysFile.save({ id: randNum, content: file.content, fileOriginName: fileName, userId: this.userInfo.id }).then(res => {
          store.commit('hideLoading')
          if (res) {
            file.fileId = randNum
            file.status = 'success'
            file.message = '上传成功'
            this.$toast({
              type: 'success',
              message: '上传成功'
            })
          } else {
            file.status = 'failed'
            file.message = '上传失败'
            this.$toast({
              type: 'warning',
              message: '上传失败'
            })
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      } else {
        file.status = 'uploading'
        file.message = '上传中...'
        const content = file.file
        const formData = new FormData()
        formData.append('file', content)
        sysFileInfoUpload(formData).then((response) => {
          store.commit('hideLoading')
          if (response.success) {
            file.fileId = response.data
            file.status = 'success'
            file.message = '上传成功'
          } else {
            file.status = 'failed'
            file.message = '上传失败'
          }
        }).catch((err) => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      }
    },
    setExtinguisherAbnormalState(val) {
      this.extinguisherAbnormalState = val
      this.temp.extinguisherState = null
    },
    init() {
      this.isOffline = sessionStorage.getItem('isOffline')
      if (this.operationType === 'scan' || this.operationType === 'edit') {
        this.scanShow = false
        this.temp.code = this.scanCode
        const codeTypeTemp = this.$route.query.codeType ? this.$route.query.codeType : null
        this.codeType = codeTypeTemp === 'wx' ? 'barcode' : codeTypeTemp
        this.isScanCodeType = this.operationType === 'scan'
        this.setCode()
      }
    },
    newFillingIndexScan(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      this.codeType = val.type === 'wx' ? 'barcode' : val.type
      this.temp.code = val.code
      this.scanShow = false
      this.isScanCodeType = true
      this.setCode()
    },
    async setSignId(e) {
      this.temp.signId = e
      this.$refs.fillForm.submit()
    },
    handleSave() {
      if (this.isFill === 'true' && this.temp.tableList && this.temp.tableList.length > 0) {
        for (let i = 0; i < this.$refs.vanCollapseItem.length; i++) {
          this.activeName.push(this.$refs.vanCollapseItem[i].name)
        }
      }
      if (this.isSign === 'true') {
        this.endPopupSignShow = true
      } else {
        this.$refs.fillForm.submit()
      }
    },
    async onSubmit(values) {
      if (!this.autoSubmit) {
        if (this.textState) {
          if (this.temp.text === null || this.temp.text === '') {
            return this.$toast('文字必填')
          }
        }
        if (this.valueState) {
          if (this.temp.state === null) {
            return this.$toast('状态必选')
          }
        }
        if (this.imgState) {
          if (this.temp.img === null || this.temp.img.length === 0) {
            return this.$toast('图片必须上传')
          }
        }
        if (this.extinguisherShow && Number(this.temp.state) === 2) {
          if (this.temp.extinguisherState === null || this.temp.extinguisherState === '') {
            return this.$toast('操作内容必须选择')
          }
        }
      }
      let checkboxGroup = null
      if (this.isFill === 'true') {
        checkboxGroup = values.checkboxGroup && values.checkboxGroup.length > 0 ? values.checkboxGroup.map(e => {
          return {
            checkTableItemId: e.id,
            checkIsDanger: e.isDanger,
            isSolve: e.isSolve,
            checkDescribe: e.checkDescribe,
            checkImgIds: e.checkImgIdList && e.checkImgIdList.length > 0 ? e.checkImgIdList
              .filter(item => item.status === 'success')
              .map(i => i.fileId)
              .join(',') : '',
            dangersSolvedDescribe: e.dangersSolvedDescribe,
            dangersSolvedImgIds: e.dangersSolvedImgIdList && e.dangersSolvedImgIdList.length > 0 ? e.dangersSolvedImgIdList
              .filter(item => item.status === 'success')
              .map(i => i.fileId)
              .join(',') : ''
          }
        }) : []
        if (checkboxGroup.length > 0) {
          const checkboxGroupList = checkboxGroup.filter(e => e.checkDescribe === null || e.checkDescribe === '')
          if (checkboxGroupList.length > 0) {
            return this.$toast('检查项描述必须填写！')
          }
          const checkboxSolvedGroupList = checkboxGroup.filter(e => e.isSolve === true)
          if (checkboxSolvedGroupList.length > 0) {
            const checkboxSolvedDescribeGroupList = checkboxSolvedGroupList.filter(e => e.dangersSolvedDescribe === null || e.dangersSolvedDescribe === '')
            if (checkboxSolvedDescribeGroupList.length > 0) {
              return this.$toast('检查项处理描述必须填写！')
            }
          }
        }
      }
      let singId = null
      if (this.isSign === 'true') {
        singId = this.temp.signId
      }
      const fillTemp = {
        taskLineId: this.taskLineId,
        deviceId: this.temp.id,
        taskId: this.taskId,
        signId: singId,
        message: values.message,
        text: this.temp.text,
        state: this.temp.state,
        extinguisherState: this.temp.extinguisherState,
        img: this.temp.img && this.temp.img.length > 0 ? this.temp.img
          .filter(item => item.status === 'success')
          .map(i => i.fileId)
          .join(',') : '',
        checkboxGroup: checkboxGroup
      }
      this.endPopupSignShow = false
      store.commit('showLoading')
      if (this.isOffline === 'true') {
        fillTemp.userId = this.userInfo.id
        msExamFilling.formAdd(fillTemp).then(res => {
          if (res) {
            store.commit('hideLoading')
            const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
            const path = routeArray[routeArray.length - 1]
            this.$router.push(path)
          } else {
            store.commit('hideLoading')
            this.$toast(res + '')
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      } else {
        await fillingFormAdd(fillTemp).then(res => {
          if (res.success) {
            store.commit('hideLoading')
            const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
            const path = routeArray[routeArray.length - 1]
            this.$router.push(path)
          }
        }).catch((err) => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      }
    },
    /**
     * 重置
     */
    resetTemp() {
      this.temp = {
        id: null,
        code: null,
        name: null,
        signId: null,
        typeName: null,
        areaName: null,
        position: null,
        message: null,
        parents: [],
        children: [],
        tableList: [],
        text: null,
        state: null,
        img: [],
        delayedSubmission: null,
        extinguisherState: null,
        scrapDate: null,
        factoryDate: null,
        extinguisherTypeName: null,
        address: null
      }
    },
    /**
     * 设置二维码code
     */
    setCode() {
      const qrCode = this.temp.code
      this.resetTemp()
      this.temp.code = qrCode
      const query = {
        code: qrCode,
        taskId: this.taskId,
        taskLineId: this.taskLineId
      }
      store.commit('showLoading')
      if (this.isOffline === 'true') {
        msTaskLog.getPointInfoAndTables(query).then(res => {
          store.commit('hideLoading')
          if (res) {
            if (res.get('pointInfo') && this.isScanCodeType) {
              this.isScanCodeType = false
              const tempCodeType = this.codeAndType.find(item => item.code === Number(res.get('pointInfo').codeType))
              // console.log('tempCodeType', tempCodeType)
              if (this.codeType !== tempCodeType.type) {
                return this.$toast('请使用' + tempCodeType.name)
              }
            }
            if (this.isFill === 'true') {
              this.temp.tableList = res.get('tableList')
              this.autoSubmit = false
            } else {
              this.autoSubmit = true
            }
            this.temp.id = res.get('pointInfo').id
            this.temp.code = res.get('pointInfo').code
            this.temp.name = res.get('pointInfo').name
            this.temp.typeName = res.get('pointInfo').typeName
            this.temp.areaName = res.get('pointInfo').areaName
            this.temp.position = res.get('pointInfo').position
            this.temp.message = res.get('pointInfo').message
            this.temp.delayedSubmission = res.get('pointInfo').delayedSubmission
            this.countDownTime = res.get('pointInfo').delayedSubmission * 1000
            const submissionRequirements = res.get('pointInfo').submissionRequirements
            if (submissionRequirements && submissionRequirements.length > 0) {
              this.imgState = submissionRequirements.indexOf('图片') !== -1
              this.valueState = submissionRequirements.indexOf('状态') !== -1
              this.textState = submissionRequirements.indexOf('文字') !== -1
            } else {
              this.imgState = false
              this.valueState = false
              this.textState = false
            }
            if (res.get('pointInfo').associationType === '1') {
              this.extinguisherShow = true
              this.temp.extinguisherTypeName = res.get('extinguisherInfo').typeName
              this.temp.factoryDate = res.get('extinguisherInfo').factoryDate
              this.temp.scrapDate = res.get('extinguisherInfo').scrapDate
              this.temp.address = res.get('pointInfo').address
            }
            if (this.autoSubmit) {
              this.$refs.fillForm.submit()
            }
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      } else {
        taskLogInfo(query).then(res => {
          if (res.success) {
            store.commit('hideLoading')
            if (res.data.pointInfo && this.isScanCodeType) {
              this.isScanCodeType = false
              const tempCodeType = this.codeAndType.find(item => item.code === Number(res.data.pointInfo.codeType))
              console.log('tempCodeType', tempCodeType)
              if (this.codeType !== tempCodeType.type) {
                return this.$toast('请使用' + tempCodeType.name)
              }
            }
            if (this.isFill === 'true') {
              this.temp.tableList = res.data.tableList
              this.autoSubmit = false
            } else {
              this.autoSubmit = true
            }
            this.temp.id = res.data.pointInfo.id
            this.temp.code = res.data.pointInfo.code
            this.temp.name = res.data.pointInfo.name
            this.temp.typeName = res.data.pointInfo.typeName
            this.temp.areaName = res.data.pointInfo.areaName
            this.temp.position = res.data.pointInfo.position
            this.temp.message = res.data.pointInfo.message
            this.temp.delayedSubmission = res.data.pointInfo.delayedSubmission
            this.countDownTime = res.data.pointInfo.delayedSubmission * 1000
            const submissionRequirements = res.data.pointInfo.submissionRequirements
            if (submissionRequirements && submissionRequirements.length > 0) {
              this.imgState = submissionRequirements.indexOf('图片') !== -1
              this.valueState = submissionRequirements.indexOf('状态') !== -1
              this.textState = submissionRequirements.indexOf('文字') !== -1
            } else {
              this.imgState = false
              this.valueState = false
              this.textState = false
            }
            if (res.data.pointInfo.associationType === 1) {
              this.extinguisherShow = true
              this.temp.extinguisherTypeName = res.data.extinguisherInfo.typeName
              this.temp.factoryDate = res.data.extinguisherInfo.factoryDate
              this.temp.scrapDate = res.data.extinguisherInfo.scrapDate
              this.temp.address = res.data.pointInfo.address
            }
            if (this.autoSubmit) {
              this.$refs.fillForm.submit()
            }
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      }
    }
  }
}
</script>

<style scoped>
  #fillForm ::v-deep .van-cell__title {
    color: #979797 !important;
  }

  .item_collapse {
    border: 1px solid #F3F3F3;
    border-radius: 6px;
    margin-bottom: 10px;
  }

  .item_collapse:active {
    border: 1px solid #F3F3F3;
    border-radius: 6px;
  }

  .item_collapse ::v-deep .van-cell--clickable {
    border-radius: 6px;
  }

  .item_collapse ::v-deep .van-collapse-item__wrapper {
    border-radius: 6px;
  }

  #content_2 .van-cell {
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    padding: 10px 16px 10px 0px;
    overflow: hidden;
    color: #323233;
    font-size: 14px;
    line-height: 24px;
    background-color: #fff;
  }

</style>
