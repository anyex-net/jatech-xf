<template>
  <div>
    <common-head
      :is-back="true"
      :scan="false"
      title="查看轨迹"
    />
    <div class="content">
      <div id="map" />
      <div class="amap-wrapper" style="height: 100vh;">
        <el-amap
          ref="amap"
          class="amap-box"
          :amap-manager="amapManager"
          :vid="'amap-vue'"
          :zoom="17"
          :plugin="plugin"
          :center="center"
          :events="events"
          :drag-enable="true"
          :show-indoor-map="false"
          :animate-enable="true"
        >
          <!-- 标记 -->
          <template v-for="(marker, index) in markers">
            <el-amap-marker
              :key="index"
              :offset="[-5,-7]"
              :position="marker"
              :icon="require('@/assets/inspection/trajectoryPoint.png')"
            />
          </template>
          <el-amap-polyline
            :path="markers"
            stroke-color="#47FF99"
            :stroke-opacity="1"
            :stroke-weight="6"
          />
        </el-amap>
      </div>
    </div>

  </div>
</template>

<script>
import { taskLogList } from '@/api/newExam/taskLog'
import commonHead from '@/views/app/common/head'
import { AMapManager } from 'vue-amap'

const amapManager = new AMapManager()

export default {
  name: 'Trajectory',
  components: { commonHead },
  data() {
    return {
      amapManager,
      center: [121.329402, 31.228667],
      markers: [],
      events: {
        init(m) {
          // 事件监听
          m.on('mouseover', () => {
            console.log(m)
          })
          m.on('mouseout', () => {
            console.log(m)
          })
        }
      },
      // 一些工具插件
      plugin: []
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      const query = {
        taskLineId: this.$route.query.taskLineId,
        taskId: this.$route.query.taskId,
        unitId: this.$route.query.unitId
      }
      taskLogList(query).then(res => {
        if (res.success) {
          res.data.forEach(e => {
            this.markers.push([e.lng, e.lat])
          })
          if (this.markers && this.markers.length > 0) {
            const lng = this.markers[0][0]
            const lat = this.markers[0][1]
            this.center = [lng, lat]
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.content ::v-deep .amap-icon img {
  width: 17px !important;
  height: 17px !important;
}
</style>
