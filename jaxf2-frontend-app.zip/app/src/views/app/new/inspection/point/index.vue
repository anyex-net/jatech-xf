<template>
  <div id="pointInfo">
    <common-head
      :back-img="require('@/assets/images/new/back1.png')"
      :custom-title="true"
      :is-back="isBack"
      back-img-style="width: 10px;height: 20px"
      background-color="#FFFFFF"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">点位信息</span>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <van-tabs id="tabs" v-model="vanTabsActive" @click="onClickActive">
          <van-tab name="info" title="基础信息">
            <div id="pointInfoData" style="margin: 12px 10px">
              <van-field
                v-model="pointInfoData.name"
                input-align="right"
                label="点位名称:"
                readonly
              />
              <van-field
                v-model="pointInfoData.typeName"
                input-align="right"
                label="点位类型:"
                readonly
              />
              <van-field
                v-model="pointInfoData.code"
                input-align="right"
                label="点位编码:"
                readonly
              />
              <van-field
                v-model="pointInfoData.codeTypeName"
                input-align="right"
                label="编码类型:"
                readonly
              />
              <van-field
                v-model="pointInfoData.areaName"
                input-align="right"
                label="设备区域:"
                readonly
              />
              <van-field
                v-model="pointInfoData.position"
                input-align="right"
                label="设备位置:"
                readonly
              />
              <van-field
                v-model="pointInfoData.mapLongitude"
                input-align="right"
                label="经　　度:"
                readonly
              />
              <van-field
                v-model="pointInfoData.mapLatitude"
                input-align="right"
                label="纬　　度:"
                readonly
              />
              <van-field
                v-model="pointInfoData.address"
                input-align="right"
                label="安装地址:"
                readonly
              />
              <van-field
                v-model="pointInfoData.lastExamTime"
                input-align="right"
                label="维保时间:"
                readonly
              />
              <van-field
                v-model="pointInfoData.lastXcTime"
                input-align="right"
                label="巡查时间:"
                readonly
              />
            </div>
            <div
              v-if="hasPerm(hasPermission.pointEdit) || hasPerm(hasPermission.pointDel) "
              class="bottom"
            />
            <div
              v-if="hasPerm(hasPermission.pointEdit) || hasPerm(hasPermission.pointDel) "
              style="position: fixed; left: 0;right: 0;bottom:constant(safe-area-inset-bottom);bottom:0px; bottom: env(safe-area-inset-bottom);background-color: #FFFFFF;padding: 10px"
            >
              <van-row type="flex" justify="space-around">
                <van-col v-if="hasPerm(hasPermission.pointDel)" span="11">
                  <van-button
                    plain
                    style="width: 100%;border-radius: 6px;border: 1px solid #C2C2C2"
                    type="default"
                    @click="pointDel"
                  >
                    <span style="font-size: 18px;font-family: PingFang SC Bold;">删除</span>
                  </van-button>
                </van-col>
                <van-col v-if="hasPerm(hasPermission.pointEdit)" span="11">
                  <van-button
                    style="width: 100%;border-radius: 6px;"
                    type="info"
                    @click="goPointEdit"
                  >
                    <span style="font-size: 18px;font-family: PingFang SC Bold;">编辑</span>
                  </van-button>
                </van-col>
              </van-row>
            </div>
          </van-tab>
          <van-tab v-if="getToken() === true" name="maintenance" title="维保记录">
            <div>
              <van-list
                v-model="maintenanceData.loading"
                :finished="maintenanceData.finished"
                :finished-text="maintenanceData.message"
                @load="onMaintenanceLoad"
              >
                <template v-for="(item,index) in maintenanceData.list">
                  <div
                    :key="index"
                    style="margin: 12px 10px 0;background-color: #FFFFFF"
                    @click="goFillingDetails(item)"
                  >
                    <van-row style="padding: 15px 16px 11px" type="flex">
                      <span style="font-weight: bolder">{{ item.taskName }}</span>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row
                      justify="space-between"
                      style="margin: 11px 16px;padding-bottom: 15px;align-items: center;"
                      type="flex"
                    >
                      <van-col style="display: flex;flex-direction: column;align-items: stretch;">
                        <span style="color: #979797;margin:8px 0">设备类型：
                          <span style="color:  #333333;margin-left: 9px">{{ item.typeName }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">设备位置：
                          <span style="color:  #333333;margin-left: 9px">{{ item.position }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">检察人员：
                          <span style="color:  #333333;margin-left: 9px">{{ item.checkUserName }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">检察时间：
                          <span style="color:  #333333;margin-left: 9px">{{ item.checkTime }}</span>
                        </span>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </div>
          </van-tab>
          <van-tab v-if="getToken() === true" name="patrol" title="巡查记录">
            <div>
              <van-list
                v-model="patrolData.loading"
                :finished="patrolData.finished"
                :finished-text="patrolData.message"
                @load="onPatrolLoad"
              >
                <template v-for="(item,index) in patrolData.list">
                  <div
                    :key="index"
                    style="margin: 12px 10px 0;background-color: #FFFFFF"
                    @click="goFillingDetails(item)"
                  >
                    <van-row style="padding: 15px 16px 11px" type="flex">
                      <span style="color: #979797;margin:8px 0">
                        <span style="color: #333333;margin-left: 9px;font-weight: bold;">{{ item.taskName }}</span>
                      </span>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row
                      style="margin: 11px 16px;padding-bottom: 15px;align-items: center;"
                      type="flex"
                    >
                      <van-col style="display: flex;flex-direction: column;align-items: stretch;">
                        <span style="color: #979797;margin:8px 0">设备类型：
                          <span style="color:  #333333;margin-left: 9px">{{ item.typeName }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">设备位置：
                          <span style="color:  #333333;margin-left: 9px">{{ item.position }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">检察人员：
                          <span style="color:  #333333;margin-left: 9px">{{ item.checkUserName }}</span>
                        </span>
                        <span style="color: #979797;margin:8px 0">检察时间：
                          <span style="color:  #333333;margin-left: 9px">{{ item.checkTime }}</span>
                        </span>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </div>
          </van-tab>
          <van-tab v-if="getToken() === true" name="hiddenDanger" title="隐患记录">
            <div>
              <van-list
                v-model="hiddenDangerData.loading"
                :finished="hiddenDangerData.finished"
                :finished-text="hiddenDangerData.message"
                @load="onHiddenDangerLoad"
              >
                <template v-for="(item,index) in hiddenDangerData.list">
                  <div :key="index" style="margin: 12px 10px 0;background-color: #FFFFFF" @click="goHidden(item)">
                    <van-row justify="space-between" style="padding: 15px 16px 11px" type="flex">
                      <span style="font-weight: bolder">{{ item.dangerTypeMessage }}</span>
                      <span style="font-weight: bolder;color: #1989FA">{{ item.isSolve ? '已处理' : '未处理' }}</span>
                    </van-row>
                    <div class="van-hairline--bottom" style="margin: 0 16px;" />
                    <van-row
                      justify="space-between"
                      style="margin: 11px 16px;padding-bottom: 15px;align-items: center;"
                      type="flex"
                    >
                      <van-col
                        span="12"
                        style="display: flex;flex-direction: column;align-items: stretch;"
                      >
                        <span style="color: #979797;margin:8px 0">上报人员：</span>
                        <span style="color: #979797;margin:8px 0">上报时间：</span>
                      </van-col>
                      <van-col
                        span="12"
                        class="van-ellipsis"
                        style="display: flex;flex-direction: column;align-items: flex-end;"
                      >
                        <span style="color: #333333;margin:8px 0">{{ item.createName }}</span>
                        <span style="color: #333333;margin:8px 0">{{ item.createTime }}</span>
                      </van-col>
                    </van-row>
                  </div>
                </template>
              </van-list>
            </div>
          </van-tab>
        </van-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import commonHead from '@/views/app/common/head'
import { dangerPage } from '@/api/newExam/danger'
import { pointDelete, pointDetail1 } from '@/api/newExam/point'
import store from '@/store'
import { taskLogPage } from '@/api/newExam/taskLog'
import { getToken } from '@/utils/auth'
import { taskDetail } from '@/api/newExam/task'

export default {
  name: 'Index',
  components: { commonHead },
  data() {
    return {
      hasPermission: {
        pointEdit: 'newExam:point:edit',
        pointDel: 'newExam:point:del'
      },
      id: this.$route.query.id,
      unitId: this.$route.query.unitId,
      vanTabsActive: null,
      pointInfoData: {
        lastExamTime: null,
        lastXcTime: null,
        name: null,
        typeName: null,
        code: null,
        codeTypeName: null,
        position: null,
        mapLongitude: null,
        mapLatitude: null,
        address: null,
        areaName: null
      },
      maintenanceData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 10,
          type: 0,
          checkStatus: 1,
          deviceId: null
        }
      },
      patrolData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 10,
          type: 1,
          checkStatus: 1,
          deviceId: null
        }
      },
      isBack: true,
      hiddenDangerData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 10,
          pointId: null,
          isDanger: true,
          isSolve: 1
        }
      }
    }
  },
  // 侦听属性
  watch: {
    vanTabsActive(newObj, oldObj) {
      if (newObj !== oldObj && oldObj !== null) {
        this.setUrlParameter()
      }
    },
    immediate: true
  },
  // 实例创建完成执行的钩子
  created() {
    if (this.$route.query.isBack) {
      this.isBack = this.$route.query.isBack
    }
    this.init()
  },
  // 编译好的html挂载到页面完成后执行的事件钩子
  // 在整个实例中只执行一次
  mounted() {
  },
  methods: {
    getToken() {
      return !!(getToken() && getToken() !== '')
    },
    init() {
      const pointActive = sessionStorage.getItem('pointActive')
      if (pointActive) {
        this.vanTabsActive = pointActive
      } else {
        this.vanTabsActive = 'info'
      }
      this.onClickActive(this.vanTabsActive, '')
    },
    /**
       * tab页切换
       */
    onClickActive(name, title) {
      this.reset()
      switch (name) {
        case 'info':
          this.getPointInfo()
          break
        case 'patrol':
          this.getPatrolList()
          break
        case 'maintenance':
          this.getMaintenanceList()
          break
        case 'hiddenDanger':
          this.getHiddenDangerList()
          break
      }
    },
    reset() {
      this.pointInfoData = {
        name: null,
        typeName: null,
        code: null,
        codeTypeName: null,
        position: null,
        mapLongitude: null,
        mapLatitude: null,
        address: null,
        areaName: null
      }
      this.maintenanceData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 10,
          type: 0,
          checkStatus: 1,
          deviceId: null
        }
      }
      this.patrolData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 10,
          type: 1,
          checkStatus: 1,
          deviceId: null
        }
      }
      this.hiddenDangerData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: null,
          pageNo: 1,
          pageSize: 10,
          pointId: null,
          isDanger: true,
          isSolve: 1
        }
      }
    },
    /**
       * 查询点位信息
       */
    getPointInfo() {
      if (this.id) {
        pointDetail1({ id: this.id }).then(res => {
          this.pointInfoData = res.data
          const codeTypeColumns = [{ text: 'RFID', type: '0' }, { text: '二维码', type: '1' }]
          const codeType = codeTypeColumns.find(item => item.type === res.data.codeType)
          this.pointInfoData.codeTypeName = codeType ? codeType.text : ''
        })
      } else {
        this.pointInfoData.name = '点位不存在'
      }
    },
    pointDel() {
      this.$dialog
        .confirm({
          message: '是否删除'
        }).then(() => {
          store.commit('showLoading')
          pointDelete([this.id]).then(res => {
            store.commit('hideLoading')
            if (res.success) {
              const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
              const path = routeArray[routeArray.length - 1]
              this.$router.push(path)
            } else {
              this.$toast(res.message)
            }
          })
            .catch((err) => {
              store.commit('hideLoading')
              this.$toast(err + '')
            })
        }).catch(() => {
        })
    },
    goPointEdit() {
      this.$router.push({
        path: '/app/new/inspection/point/add/index',
        query: {
          id: this.id,
          unitId: this.unitId,
          operationType: 'edit'
        }
      })
    },
    /**
       * 获取维保任务列表
       */
    getMaintenanceList() {
      this.maintenanceData.query.unitId = this.unitId
      this.maintenanceData.query.deviceId = this.id
      taskLogPage(this.maintenanceData.query).then(res => {
        this.maintenanceData.list = this.maintenanceData.list.concat(res.data.rows)
        // 加载状态结束
        this.maintenanceData.loading = false
        this.maintenanceData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.maintenanceData.list.length >= res.data.totalRows) {
          this.maintenanceData.finished = true
        }
      })
    },
    /**
       * 维保任务列表加载
       */
    onMaintenanceLoad() {
      this.maintenanceData.query.pageNo++
      this.getMaintenanceList()
    },
    /**
       * 获取巡查任务列表
       */
    getPatrolList() {
      this.patrolData.query.unitId = this.unitId
      this.patrolData.query.deviceId = this.id
      taskLogPage(this.patrolData.query).then(res => {
        this.patrolData.list = this.patrolData.list.concat(res.data.rows)
        // 加载状态结束
        this.patrolData.loading = false
        this.patrolData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.patrolData.list.length >= res.data.totalRows) {
          this.patrolData.finished = true
        }
      })
    },
    /**
       * 巡查任务列表加载
       */
    onPatrolLoad() {
      this.patrolData.query.pageNo++
      this.getPatrolList()
    },
    /**
       * 获取隐患列表
       */
    getHiddenDangerList() {
      this.hiddenDangerData.query.unitId = this.unitId
      this.hiddenDangerData.query.pointId = this.id
      dangerPage(this.hiddenDangerData.query).then(res => {
        this.hiddenDangerData.list = this.hiddenDangerData.list.concat(res.data.rows)
        // 加载状态结束
        this.hiddenDangerData.loading = false
        this.hiddenDangerData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.hiddenDangerData.list.length >= res.data.totalRows) {
          this.hiddenDangerData.finished = true
        }
      })
    },
    /**
       * 隐患列表加载
       */
    onHiddenDangerLoad() {
      this.hiddenDangerData.query.pageNo++
      this.getHiddenDangerList()
    },
    /**
       * 已检查点位详情
       */
    goFillingDetails(val) {
      taskDetail(val.taskId).then(res => {
        this.$router.push({
          path: '/app/new/inspection/filling/details/index',
          query: {
            taskLogId: val.id,
            isSign: res.data.isSign,
            isFill: res.data.isFill
          }
        })
      }).catch(err => {
        console.log('err', err)
      })
    },
    /**
       * 隐患页面跳转
       */
    goHidden(val) {
      this.$router.push({
        path: '/app/new/inspection/danger/handle/index',
        query: {
          id: val.id,
          operationType: 'select'
        }
      })
    },
    /**
       * 当前路由修改参数
       * history.pushState() 添加
       * history.replaceState() 修改
       */
    setUrlParameter() {
      sessionStorage.setItem('pointActive', this.vanTabsActive)
    }
  }
}
</script>

<style scoped>
  #pointInfo {
    font-family: PingFang SC Bold;
    font-size: 14px;
  }

  #tabs {
    font-family: PingFang SC Bold;
  }

  #tabs ::v-deep .van-tabs__nav {
    background-color: transparent !important;
  }

  #tabs ::v-deep .van-tab {
    padding: 0 !important;
    background-color: #FFFFFF !important;
    color: #979797;
  }

  #tabs ::v-deep .van-tabs__line {
    width: 0;
    height: 0;
    background-color: #FFFFFF !important;
  }

  #tabs ::v-deep .van-tab__pane {
    width: auto !important;
    background-color: #F4F4F4 !important;
  }

  #tabs ::v-deep .van-tab--active {
    color: #1989FA !important;
    font-weight: bolder !important;
  }

  #tabs ::v-deep .van-tab__text {
    font-size: 14px;
  }

  #pointInfoData ::v-deep .van-cell__title {
    color: #979797 !important;
  }

  #pointInfoData >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: autop;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }
</style>
