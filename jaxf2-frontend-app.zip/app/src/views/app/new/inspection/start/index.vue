<template>
  <div id="startContent">
    <common-head :is-back="true" :title="title" />
    <div class="content content_">
      <div class="cards-navbar">
        <div style="text-align: center;">
          <p>智慧{{ text }}须知</p>
        </div>
        <div style="padding: 10px;">您好!请务必认真填写{{ text }}内容，若在{{ text }}过程中发现安全隐患的，请完整仔细的填写相关隐患内容并提交。</div>
        <div class="bottom" />
        <div class="bar-footer">
          <van-row class="button1" style="width: 100%;" justify="space-between" type="flex">
            <van-col span="24">
              <van-button v-if="taskType === '0'" class="big_button_" @click="updateTask">
                开始维保
              </van-button>
              <van-button v-if="taskType === '1'" class="big_button_" @click="routeShow = true">
                开始巡查
              </van-button>
            </van-col>
          </van-row>
        </div>
      </div>
    </div>
    <route title="选择您巡查的路线" :task-id="taskId" :route-show="routeShow" @routeShowState="e => { this.routeShow = e }" />
  </div>
</template>

<script>

import commonHead from '@/views/app/common/head'
import route from '@/views/app/new/inspection/route'
import { taskUpdateById } from '@/api/newExam/task'

export default {
  components: {
    commonHead,
    route
  },
  data() {
    return {
      title: '巡查',
      routeShow: false,
      text: null,
      taskType: this.$route.query.taskType,
      taskState: this.$route.query.taskState,
      taskId: this.$route.query.taskId,
      unitId: this.$route.query.unitId
    }
  },
  computed: {},
  created() {
    this.init()
  },
  methods: {
    updateTask() {
      if (this.taskState === '0') {
        const query = {
          id: this.taskId,
          state: 2
        }
        taskUpdateById(query).then(res => {
          if (res.success) {
            this.toMaintenance()
          }
        })
      }
      if (this.taskState === '2') {
        this.toMaintenance()
      }
    },
    toMaintenance() {
      this.$router.push({
        path: '/app/new/inspection/maintenance/index',
        query: {
          taskId: this.taskId,
          unitId: this.unitId,
          isButton: true
        }
      })
    },
    /**
       * 初始化
       */
    init() {
      if (this.taskType === '0') {
        this.title = '维保'
        this.text = '维保'
      }
      if (this.taskType === '1') {
        this.title = '巡查'
        this.text = '巡查'
        if (this.taskState !== '1') {
          this.routeShow = true
        }
      }
    }
  }
}
</script>
<style scoped>
  #startContent {
    font-family: PingFang SC Bold;
    font-size: 18px;
  }

  .content_ {
    color: #FF1F1F;
    font-weight: bolder;
    padding: 10px;
  }

  .big_button_ {
    background-color: #1989FA;
    color: #FFFFFF;
    font-size: 16px;
    width: 100%;
    border-radius: 6px;
  }

</style>
