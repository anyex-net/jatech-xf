<template>
  <div style="font-family: PingFang SC Bold;">
    <van-popup
      v-model="endPopupRouteShow"
      :safe-area-inset-bottom="true"
      position="bottom"
      round
      style="height: 80%"
    >
      <div
        style="padding: 14px 16px;width:100%;position: fixed;background-color: #FFFFFF;
      border-radius: 16px 16px 0 0;z-index: 99;"
      >
        <div style="display: flex;align-items: center;justify-content: center;height: 18px;line-height: 18px;">
          <span style="font-weight: bolder">{{ title }}</span>
        </div>
        <div style="display: flex;justify-content: flex-end;align-items: center;height: 18px;margin-top: -18px;">
          <van-icon color="#949494" name="cross" @click="endPopupRouteShow = false" />
        </div>
      </div>

      <van-list
        v-model="routeData.loading"
        :finished="routeData.finished"
        :finished-text="routeData.message"
        style="margin-top: 66px"
        @load="onRouteLoad"
      >
        <template v-for="(item,index) in routeData.list">
          <custom-card :key="index" shadow style="border-radius: 6px;margin: 8px 10px;padding: 17px 16px;">
            <template #content>
              <van-row justify="space-between" style="align-items: center;" type="flex">
                <div style="display: flex;flex-direction: column;align-items: center;">
                  <span style="margin-bottom: 12px">{{ item.name }}</span>
                  <span style="font-size: 12px">本月已巡查
                    <span style="font-size: 12px;color:#5FC48D;">{{ item.taskLineCompleteCountByMonth ? item.taskLineCompleteCountByMonth : 0 }}</span>
                    次</span>
                </div>
                <div>
                  <div v-if="Number(item.state) === 0 && !routeState">
                    <van-button
                      v-if="item.userIds === null || item.userIds === '' || item.userIds === 'null' || (item.userIds && item.userIds !== 'null' && item.userIds.indexOf(userInfo.id) !== -1)"
                      size="small"
                      style="border-radius: 6px;"
                      type="info"
                      @click="routeToInspectClick(item)"
                    >
                      去巡查
                    </van-button>
                    <van-button
                      v-else-if="item.userIds && item.userIds !== 'null' && item.userIds.indexOf(userInfo.id) === -1"
                      plain
                      size="small"
                      style="border-radius: 6px;color:#CECECE;border: 1px solid #CECECE"
                    >
                      已指定人员
                    </van-button>
                  </div>
                  <van-button
                    v-if="Number(item.state) === 1 && !routeState"
                    plain
                    size="small"
                    style="border-radius: 6px;color:#CECECE;border: 1px solid #CECECE"
                    @click="routeToInfoClick(item)"
                  >
                    已巡查
                  </van-button>
                  <van-button
                    v-if="routeState"
                    type="info"
                    size="small"
                    style="border-radius: 6px;"
                    @click="routeToTrajectoryClick(item)"
                  >
                    查看轨迹
                  </van-button>
                </div>
              </van-row>
            </template>
          </custom-card>
        </template>
      </van-list>
      <div v-if="isNavBottom" class="nav-bottom" />
    </van-popup>
  </div>
</template>

<script>

import { taskLinePage, taskLineUpdate } from '@/api/newExam/taskLine'
import { validatorUser } from '@/api/newExam/line'
import customCard from '@/views/app/common/card/customCard'
import { taskUpdateById } from '@/api/newExam/task'
import { parseTime } from '@/utils'
import msTaskLine from '@/api/offline/msTaskLine'
import msExamLine from '@/api/offline/msExamLine'
import msExamTask from '@/api/offline/msExamTask'

export default {
  components: {
    customCard
  },
  props: {
    routeShow: {
      type: Boolean,
      default: false
    },
    isNavBottom: {
      type: Boolean,
      default: false
    },
    taskId: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    routeState: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      endPopupRouteShow: this.routeShow,
      routeData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          pageNo: 1,
          pageSize: 10,
          taskId: null
        }
      },
      isOffline: false
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  // 侦听属性
  watch: {
    routeShow(newObj, oldObj) {
      this.endPopupRouteShow = newObj
    },
    endPopupRouteShow(newObj, oldObj) {
      this.$emit('routeShowState', newObj)
    },
    immediate: true
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.isOffline = sessionStorage.getItem('isOffline')
      this.reset()
      this.getRouteList()
    },
    reset() {
      this.routeData = {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          pageNo: 1,
          pageSize: 10,
          taskId: null
        }
      }
    },
    getRouteList() {
      this.routeData.query.taskId = this.taskId
      if (this.isOffline === 'true') {
        msTaskLine.selectPage(this.routeData.query).then(res => {
          if (res) {
            this.routeData.list = this.routeData.list.concat(res.data.rows)
            // 加载状态结束
            this.routeData.loading = false
            this.routeData.total = res.data.totalRows
            // 数据全部加载完成
            if (this.routeData.list.length >= res.data.totalRows) {
              this.routeData.finished = true
            }
          }
        })
      } else {
        taskLinePage(this.routeData.query).then(res => {
          this.routeData.list = this.routeData.list.concat(res.data.rows)
          // 加载状态结束
          this.routeData.loading = false
          this.routeData.total = res.data.totalRows
          // 数据全部加载完成
          if (this.routeData.list.length >= res.data.totalRows) {
            this.routeData.finished = true
          }
        })
      }
    },
    routeToInspectClick(val) {
      if (this.userInfo.isAdmin) {
        this.updateTask(val)
      } else {
        if (this.isOffline === 'true') {
          msExamLine.selectById(val.lineId).then(res => {
            if (res) {
              if (res.userIds !== null && res.userIds !== 'null') {
                if (res.userIds.indexOf(this.userInfo.id) !== -1) {
                  this.updateTask(val)
                } else {
                  this.$toast({
                    type: 'warning',
                    message: '路线已指定人员！'
                  })
                }
              } else {
                this.updateTask(val)
              }
            }
          })
        } else {
          validatorUser(val.lineId).then(res => {
            if (res.data.type) {
              this.updateTask(val)
            } else {
              this.$toast({
                type: 'warning',
                message: '路线已指定人员！'
              })
            }
          })
        }
      }
    },
    updateTask(val) {
      const query = {
        id: this.taskId,
        state: 2
      }
      if (this.isOffline === 'true') {
        msExamTask.updateById(query).then(res => {
          if (res) {
            const data = {
              id: val.id,
              checkStartTime: parseTime(new Date())
            }
            msTaskLine.updateById(data).then(res => {
              if (res) {
                this.toInspect(val)
              }
            })
          }
        })
      } else {
        taskUpdateById(query).then(res => {
          if (res.success) {
            const data = {
              id: val.id,
              checkStartTime: parseTime(new Date())
            }
            taskLineUpdate(data).then(res => {
              if (res.success) {
                this.toInspect(val)
              }
            })
          }
        })
      }
    },
    routeToInfoClick(val) {
      if (val.state === 1) {
        this.toInspect(val)
      }
    },
    onRouteLoad() {
      this.routeData.query.pageNo++
      this.getRouteList()
    },
    toInspect(val) {
      this.$router.push({
        path: '/app/new/inspection/inspect/index',
        query: {
          taskLineId: val.id,
          taskId: val.taskId,
          unitId: val.unitId
        }
      })
    },
    routeToTrajectoryClick(val) {
      this.$router.push({
        path: '/app/new/inspection/tabs/patrol/trajectory',
        query: {
          taskLineId: val.id,
          taskId: val.taskId,
          unitId: val.unitId
        }
      })
    }
  }
}

</script>
<style scoped>

</style>
