<template>
  <div class="body_">
    <common-head
      :is-back="true"
      :custom-title="true"
      :custom-right="true"
      background-color="#FFFFFF"
      :back-img="require('@/assets/images/new/back1.png')"
      back-img-style="width: 10px;height: 20px"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">情况说明</span>
      </template>
      <template #right>
        <van-button
          size="small"
          :class="temp.type === null ? 'submit_btn2' : 'submit_btn1'"
          :disabled="temp.type === null"
          @click="handleSave"
        >提交
        </van-button>
      </template>
    </common-head>

    <div class="content content_">
      <div class="cards-navbar" style="background-color: #F4F4F4">
        <van-form ref="detailsForm" @submit="onSubmit">
          <div style="margin: 12px 10px 0;background-color: #FFFFFF;">
            <div style="padding: 20px 16px;">
              <van-radio-group v-model="temp.type">
                <van-cell-group>
                  <div v-for="(item,index) in list" :key="index">
                    <van-cell
                      :title="item.content"
                      clickable
                      class="details_option"
                      :class="{details_option_active: item.id === tempId}"
                      @click="itemChecked(item)"
                    >
                      <template #right-icon>
                        <van-radio :name="item.content">
                          <template #icon="props">
                            <img class="img-icon" :src="''">
                          </template>
                        </van-radio>
                      </template>
                    </van-cell>
                  </div>
                </van-cell-group>
              </van-radio-group>
              <van-field
                v-if="temp.type === '其他'"
                v-model="temp.message"
                maxlength="50"
                name="message"
                placeholder="请输入情况说明"
                rows="2"
                show-word-limit
                type="textarea"
                style="background-color: #FAFAFA;border-radius: 6px;"
              />
            </div>

          </div>
        </van-form>
      </div>
    </div>

    <sign
      :sign-show="end_popup_sign_show"
      @signId="setSignId"
      @signShowState="(e)=>{this.end_popup_sign_show = e}"
    />
  </div>
</template>

<script>

import { describeList } from '@/api/newExam/describe'
import { overview } from '@/api/newExam/taskLog'
import commonHead from '@/views/app/common/head'
import sign from '@/views/app/new/inspection/sign'
import store from '@/store'
import msExamDescribe from '@/api/offline/msExamDescribe'

export default {
  components: {
    commonHead, sign
  },
  data() {
    return {
      list: [],
      tempId: null,
      taskLogId: this.$route.query.taskLogId,
      unitId: this.$route.query.unitId,
      isSign: this.$route.query.isSign,
      temp: {
        type: null,
        message: null,
        taskLogId: null,
        signId: null
      },
      end_popup_sign_show: false,
      detailsOptionActive: '',
      isOffline: false
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  created() {
    this.init()
  },
  methods: {
    setSignId(e) {
      this.temp.signId = e
      this.detailsAdd()
    },
    init() {
      this.isOffline = sessionStorage.getItem('isOffline')
      this.getList()
    },
    itemChecked(item) {
      this.temp.type = item.content
      this.tempId = item.id
    },
    handleSave() {
      this.$refs.detailsForm.submit()
    },
    /**
     * 获取数据
     */
    getList() {
      const unitId = this.unitId
      if (this.isOffline === 'true') {
        msExamDescribe.selectList({ unitId: unitId }).then(res => {
          if (res) {
            this.list = res
            this.list.push({ content: '其他', id: '-1' })
          } else {
            this.$toast({
              type: 'warning',
              message: '当前单位没有配置详情列表'
            })
          }
        })
      } else {
        describeList({ unitId: unitId }).then(res => {
          if (res.data !== null) {
            this.list = res.data
            this.list.push({ content: '其他', id: '-1' })
          } else {
            this.$toast({
              type: 'warning',
              message: '当前单位没有配置详情列表'
            })
          }
        })
      }
    },
    /**
     * 返回
     */
    goBack() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    },
    /**
     * 提交
     * @param values
     */
    onSubmit(values) {
      if (this.temp.type !== null) {
        if (this.isSign === 'true') {
          this.end_popup_sign_show = true
        } else {
          this.detailsAdd()
        }
      }
    },
    /**
     * 选择原因
     */
    detailsAdd() {
      if (this.temp.type === null) {
        this.$toast({
          type: 'warning',
          message: '请选择原因'
        })
        return
      }
      if (this.temp.type === '其他' && this.temp.message === null && this.temp.message === '') {
        this.$toast({
          type: 'warning',
          message: '请输入情况说明'
        })
        return
      }
      let signId
      if (this.isSign === 'true') {
        signId = this.temp.signId
      }
      store.commit('showLoading')
      if (this.isOffline === 'true') {
        msExamDescribe.overview({
          taskLogId: this.taskLogId,
          message: this.temp.type === '其他' ? this.temp.message : this.temp.type,
          signId: signId,
          userId: this.userInfo.id
        }).then(res => {
          if (res) {
            store.commit('hideLoading')
            this.goBack()
          } else {
            store.commit('hideLoading')
          }
        }).catch(err => {
          store.commit('hideLoading')
          this.$toast(err + '')
        })
      } else {
        overview({
          taskLogId: this.taskLogId,
          message: this.temp.type === '其他' ? this.temp.message : this.temp.type,
          signId: this.temp.signId
        }).then(res => {
          store.commit('hideLoading')
          this.goBack()
        }).catch(er => {
          store.commit('hideLoading')
        })
      }
    }
  }
}
</script>
<style scoped>
  .details_option {
    background-color: #F5F7FA;
    margin-bottom: 13px;
    border-radius: 6px;
    text-align: left;
    font-size: 16px;
    font-weight: normal;
    color: #313131
  }

  .details_option_active {
    background-color: #1989FA;
    color: #FFFFFF;
  }

  .submit_btn1 {
    border-radius: 6px;
    font-size: 12px;
    padding: 12px 15px;
    height: 18px;
    background-color: #1989FA !important;
    color: #FFFFFF
  }

  .submit_btn2 {
    border-radius: 6px;
    font-size: 12px;
    padding: 12px 15px;
    height: 18px;
    background-color: #BDBDBD !important;
    color: #FFFFFF
  }

  .body_ {
    font-family: PingFang SC Bold;
    font-size: 14px;
  }

  .butDiv_ {
    text-align: center;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 0.3rem 40px;
    color: #9e9ea6;
  }

  .but {
    border-radius: 10px;
    height: 40px;
  }

  .content_ {
    text-align: center
  }

  .text_ {
    padding: 20px;
    font-size: 15px
  }

  .span_ {
    color: #999999
  }
</style>
