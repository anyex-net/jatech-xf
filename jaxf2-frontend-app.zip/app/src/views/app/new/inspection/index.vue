<template>
  <div style="background-color: #F4F4F4;height: 100vh">
    <common-head
      :custom-title="true"
      :is-back="false"
      :custom-right="tabsShow"
      :scan="!tabsShow"
      @scanData="goPointByScan"
    >
      <template #title>
        <my-select
          ref="infoRef"
          :is-link="false"
          :is-select-white="true"
          :options="columns"
          :readonly="mySelectReadonly"
          filterable
          input-align="center"
          s-label="name"
          s-value="id"
          @confirm="onClickItem"
        />
      </template>
      <template #right>
        <van-popover
          v-model="headRightShowPopover"
          trigger="click"
          placement="bottom-end"
        >
          <van-cell-group>
            <scan width="16" @scanData="goPointByScan">
              <template #icon>
                <van-cell title="扫一扫">
                  <template #icon>
                    <van-icon name="scan" style="font-size: 16px;line-height: inherit;" />
                  </template>
                </van-cell>
              </template>
            </scan>
            <van-cell v-if="active !== 'point'" title="搜索" @click="doSearch">
              <template #icon>
                <van-icon name="search" style="font-size: 16px;line-height: inherit;" />
              </template>
            </van-cell>
            <van-cell v-if="active === 'hiddenDanger'" title="隐患上报" @click="doDanger">
              <template #icon>
                <van-icon name="edit" style="font-size: 16px;line-height: inherit;" />
              </template>
            </van-cell>
          </van-cell-group>
          <template #reference>
            <div style="display: flex;align-items: center">
              <van-icon size="25" name="ellipsis" color="#FFFFFF" style="margin-right: 16px" />
            </div>
          </template>
        </van-popover>
      </template>
    </common-head>

    <div class="content">
      <div class="cards-navbar cards-navbar-extend">
        <!--        卡片展示-->
        <div v-if="!searchShow" id="info">
          <van-row type="flex" justify="space-around">
            <van-col v-if="this.hasPerm(hasPermission.point)" span="6">
              <div @click="onClickActive('point')">
                <span>{{ info.pointSum }}</span>
                <van-icon name="arrow" />
              </div>
              <span class="span_font">点位信息</span>
            </van-col>
            <van-col v-if="this.hasPerm(hasPermission.maintenance)" span="6">
              <div @click="onClickActive('maintenance')">
                <span>{{ info.maintenanceSum }}</span>
                <van-icon name="arrow" />
              </div>
              <span class="span_font">维保任务</span>
            </van-col>
            <van-col v-if="this.hasPerm(hasPermission.patrol)" span="6">
              <div @click="onClickActive('patrol')">
                <span>{{ info.patrolSum }}</span>
                <van-icon name="arrow" />
              </div>
              <span class="span_font">巡查任务</span>
            </van-col>
            <van-col v-if="this.hasPerm(hasPermission.hiddenDanger)" span="6">
              <div @click="onClickActive('hiddenDanger')">
                <span>{{ info.hiddenDangerSum }}</span>
                <van-icon name="arrow" />
              </div>
              <span class="span_font">隐患任务</span>
            </van-col>
          </van-row>
        </div>
        <div v-else style="margin-bottom: 64px" />
        <!-- 内容-->
        <div id="infoContent">
          <div v-if="!tabsShow" id="exhibition">
            <div class="title">
              <span>我的任务</span>
            </div>
            <van-loading
              v-if="isLoading"
              color="#1989fa"
              style="width: 100%;height:90px;display: flex;align-items: center;justify-content: center"
              vertical
            >
              <span style="color:#1989fa">加载中...</span>
            </van-loading>
            <div v-if="!isLoading">
              <div v-show="info.patrolShow" class="infoCard">
                <van-row type="flex" justify="space-between" style="padding: 15px 16px 11px">
                  <van-checkbox-group v-if="patrolCheckboxGroupShow" v-model="patrolCheckboxGroup">
                    <van-checkbox :name="info.patrolInfo.id" shape="square">
                      <div class="font_crude">
                        <van-icon color="#1989FA" name="location-o" />
                        <span style="color: #1989FA;margin:0 14px 0 7.5px;">巡查</span>
                        <span>{{ info.patrolInfo.name }}</span>
                      </div>
                    </van-checkbox>
                  </van-checkbox-group>
                  <div v-else class="font_crude">
                    <van-icon name="location-o" color="#1989FA" />
                    <span style="color: #1989FA;margin:0 14px 0 7.5px;">巡查</span>
                    <span>{{ info.patrolInfo.name }}</span>
                  </div>
                  <div class="span_color" style="display: flex;align-items: center;" @click="onClickActive('patrol')">
                    <span>更多</span>
                    <van-icon name="arrow" />
                  </div>
                </van-row>
                <div style="margin: 0 16px;" class="van-hairline&#45;&#45;bottom" />
                <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                  <van-col span="16" style="display: flex;flex-direction: column;align-items: stretch;">
                    <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：<span
                      style="color: black"
                    >{{ info.patrolInfo.startTime }}</span></span>
                    <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：<span
                      style="color: black"
                    >{{ info.patrolInfo.endTime }}</span></span>
                  </van-col>
                  <van-col span="8" style="display: flex;justify-content: flex-end;">
                    <van-button
                      v-if="info.patrolInfo.state === 0 && !patrolCheckboxGroupShow"
                      style="border-radius: 6px"
                      plain
                      size="small"
                      type="info"
                      @click="goStart(info.patrolInfo)"
                    ><span style="font-weight: bold">开始巡查</span>
                    </van-button>
                    <van-button
                      v-else-if="info.patrolInfo.state === 2 && !patrolCheckboxGroupShow"
                      style="border-radius: 6px"
                      plain
                      size="small"
                      type="info"
                      @click="openRoute(info.patrolInfo)"
                    ><span style="font-weight: bold">巡查中</span>
                    </van-button>
                  </van-col>
                </van-row>
              </div>
              <div v-show="info.maintenanceShow" class="infoCard">
                <van-row type="flex" justify="space-between" style="padding: 15px 16px 11px">
                  <div class="font_crude">
                    <van-icon :name="require('@/assets/preflight_images/weibao.png')" color="#E7BF74" />
                    <span style="color: #E7BF74;margin:0 14px 0 7.5px;">维保</span>
                    <span>{{ info.maintenanceInfo.name }}</span>
                  </div>
                  <div
                    class="span_color"
                    style="display: flex;align-items: center;"
                    @click="onClickActive('maintenance')"
                  >
                    <span>更多</span>
                    <van-icon name="arrow" />
                  </div>
                </van-row>
                <div style="margin: 0 16px;" class="van-hairline&#45;&#45;bottom" />
                <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                  <van-col span="16" style="display: flex;flex-direction: column;align-items: stretch;">
                    <span class="span_color van-ellipsis" style="margin:8px 0">开始时间：<span
                      style="color: black"
                    >{{ info.maintenanceInfo.startTime }}</span></span>
                    <span class="span_color van-ellipsis" style="margin:8px 0">结束时间：<span
                      style="color: black"
                    >{{ info.maintenanceInfo.endTime }}</span></span>
                  </van-col>
                  <van-col span="8" style="display: flex;justify-content: flex-end;">
                    <van-button
                      v-if="info.maintenanceInfo.state !== 1 && !patrolCheckboxGroupShow"
                      style="border-radius: 6px"
                      plain
                      size="small"
                      type="info"
                      @click="goStart(info.maintenanceInfo)"
                    ><span style="font-weight: bold">开始维保</span>
                    </van-button>
                  </van-col>
                </van-row>
              </div>
              <div v-show="info.hiddenDangerShow" class="infoCard">
                <van-row type="flex" justify="space-between" style="padding: 15px 16px 11px">
                  <div class="font_crude">
                    <van-icon :name="require('@/assets/preflight_images/yinghuan.png')" color="#FF6C50" />
                    <span style="color: #ff6c50;margin:0 14px 0 7.5px;">隐患</span>
                    <span>{{ info.hiddenDangerInfo.pointName }}</span>
                  </div>
                  <div
                    class="span_color"
                    style="display: flex;align-items: center;"
                    @click="onClickActive('hiddenDanger')"
                  >
                    <span>更多</span>
                    <van-icon name="arrow" />
                  </div>
                </van-row>
                <div style="margin: 0 16px;" class="van-hairline&#45;&#45;bottom" />
                <van-row type="flex" justify="space-between" style="margin: 11px 16px;align-items: center;">
                  <van-col span="14" style="display: flex;flex-direction: column;align-items: stretch;">
                    <span class="span_color van-ellipsis" style="margin:8px 0">设备编号：<span
                      style="color: black"
                    >{{ info.hiddenDangerInfo.code }}</span></span>
                    <span class="span_color van-ellipsis" style="margin:8px 0">上报时间：<span
                      style="color: black"
                    >{{ info.hiddenDangerInfo.createTime }}</span></span>
                    <span class="span_color van-ellipsis" style="margin:8px 0">设备地址：<span
                      style="color: black"
                    >{{ info.hiddenDangerInfo.position }}</span></span>
                  </van-col>
                  <van-col span="10" style="display: flex;justify-content: flex-end;">
                    <div v-if="!patrolCheckboxGroupShow">
                      <div v-if="info.hiddenDangerInfo.isReferred">
                        <van-button
                          v-if="!info.hiddenDangerInfo.isSolve && (userInfo.id === info.hiddenDangerInfo.assigner)"
                          style="border-radius: 6px"
                          plain
                          size="small"
                          type="info"
                          @click="goHidden(info.hiddenDangerInfo,'handle')"
                        ><span
                          style="font-size: 14px;font-weight: bold"
                        >去处理</span>
                        </van-button>
                        <van-button
                          v-else
                          color="#979797"
                          style="border-radius: 6px"
                          plain
                          size="small"
                          type="info"
                        ><span
                          style="font-size: 14px;font-weight: bold"
                        >已转交指定人</span>
                        </van-button>
                      </div>
                      <div v-else-if="info.hiddenDangerInfo.isExam">
                        <van-button
                          v-if="!info.hiddenDangerInfo.isSolve && Number(userInfo.unitType) === 3"
                          style="border-radius: 6px"
                          plain
                          size="small"
                          type="info"
                          @click="goHidden(info.hiddenDangerInfo,'handle')"
                        ><span
                          style="font-size: 14px;font-weight: bold"
                        >去处理</span>
                        </van-button>
                        <van-button
                          v-else
                          color="#979797"
                          style="border-radius: 6px"
                          plain
                          size="small"
                          type="info"
                        ><span
                          style="font-size: 14px;font-weight: bold"
                        >已转交维保公司</span>
                        </van-button>
                      </div>
                      <div v-else>
                        <van-button
                          v-show="!info.hiddenDangerInfo.isSolve"
                          style="border-radius: 6px"
                          plain
                          size="small"
                          type="info"
                          @click="goHidden(info.hiddenDangerInfo,'handle')"
                        ><span
                          style="font-size: 14px;font-weight: bold"
                        >去处理</span>
                        </van-button>
                      </div>
                    </div>
                  </van-col>
                </van-row>
              </div>
              <div
                v-show="info.patrolShow === false && info.maintenanceShow === false && info.hiddenDangerShow === false"
                style="text-align: center;display: flex;align-items: center;justify-content: center;"
              >
                <div
                  style="border: 1px dashed #D1D1D1;
              width: 153px;margin: 110px 0;
              display: flex;flex-direction: column;
              align-content: center;align-items: center;"
                >
                  <img :src="require('@/assets/preflight_images/noTask.png')" alt="">
                  <span style="margin-top: -15px">当前无任务</span>
                </div>
              </div>
            </div>
          </div>
          <div v-else>
            <tabs-content
              v-model="active"
              :unit-id="temp.unitId"
              :search-show="searchShow"
              :need-search="needSearch"
              :patrol-checkbox-group-parent="patrolCheckboxGroup"
              :patrol-checkbox-group-show="patrolCheckboxGroupShow"
              @needSearch="e => { this.needSearch = e }"
              @searchShow="e => { this.searchShow = e }"
              @updatePatrolCheckboxGroup="e => { this.patrolCheckboxGroup = e }"
            />
          </div>
        </div>
        <!-- footer-->
        <div class="nav-bottom" />
        <div
          v-if="patrolCheckboxGroupShow"
          class="bar-footer"
          style="background: #FFFFFF;"
        >
          <van-row
            v-if="active !== 'point' && active !== 'maintenance' && active !== 'hiddenDanger'"
            justify="space-between"
            style="width: 100%;"
            type="flex"
          >
            <van-col class="button_font" span="9" style="background: #3E3E3E;" @click="goBack">退出</van-col>
            <van-col class="button_font" span="14" style="background: #1989FA;" @click="download">下载</van-col>
          </van-row>
          <van-row v-else style="width: 100%;">
            <van-col class="button_font" span="24" style="background: #3E3E3E;" @click="goBack">退出</van-col>
          </van-row>
        </div>
      </div>
    </div>

    <route
      v-if="routeShow"
      :is-nav-bottom="true"
      :task-id="taskId"
      :route-show="routeShow"
      title="选择您巡查的路线"
      @routeShowState="e => { this.routeShow = e }"
    />
  </div>
</template>

<script>
import { selectTaskPage, taskPage } from '@/api/newExam/task'
import { dangerPage } from '@/api/newExam/danger'
import { inspectionInit } from '@/api/app/new/inspection'
import { getInfoByCodeAndUnitId, pointList } from '@/api/newExam/point'
import mySelect from '@/views/app/common/my-select/index'
import commonHead from '@/views/app/common/head'
import tabsContent from '@/views/app/new/inspection/tabs/index'
import route from '@/views/app/new/inspection/route/index'
import store from '@/store'
import { offlineDownTask } from '@/api/offline/offline'
import androidShellApi from '@/api/offline/androidShellApi'
import Scan from '@/views/app/common/scan'

export default {
  components: {
    mySelect, commonHead, tabsContent, route, Scan
  },
  data() {
    return {
      patrolCheckboxGroupShow: false,
      patrolCheckboxGroup: [],
      hasPermission: {
        point: 'app:newExam:inspection:point',
        maintenance: 'app:newExam:inspection:maintenance',
        patrol: 'app:newExam:inspection:patrol',
        hiddenDanger: 'app:newExam:inspection:hiddenDanger'
      },
      headRightShowPopover: false,
      columns: [],
      temp: {
        unitId: null,
        unitName: null
      },
      mySelectReadonly: false,
      tabsShow: false,
      searchShow: false,
      needSearch: false,
      isLoading: true,
      info: {
        pointSum: 0,
        patrolSum: 0,
        patrolInfo: {
          name: null,
          state: null,
          startTime: null,
          endTime: null
        },
        patrolShow: false,
        maintenanceSum: 0,
        maintenanceInfo: {
          name: null,
          state: null,
          startTime: null,
          endTime: null
        },
        maintenanceShow: false,
        hiddenDangerSum: 0,
        hiddenDangerInfo: {
          code: null,
          createTime: null,
          isSolve: null,
          position: null,
          pointName: null
        },
        hiddenDangerShow: false
      },
      active: null,
      routeShow: false,
      taskId: null,
      unitId: this.$route.query.unitId,
      unitName: this.$route.query.unitName
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  watch: {
    immediate: true
  },
  created() {
    this.init()
  },
  mounted() {
  },
  beforeDestroy() {
  },
  methods: {
    /**
     * 下载离线数据
     */
    download() {
      const data = {
        unitId: this.unitId,
        taskIds: this.patrolCheckboxGroup.join(',')
      }
      if (data.unitId === '' || data.taskIds === '') {
        this.$toast({
          type: 'warning',
          message: '请选择下载任务！'
        })
        return
      }
      androidShellApi.isNetWorkByAndroid().then(res => {
        if (res) {
          store.commit('showLoading')
          offlineDownTask(data).then(res => {
            if (res.success) {
              androidShellApi.fileDownload(this.userInfo.unitId, this.userInfo.id, res.data.url, res.data.dbName)
                .then(res1 => {
                  if (res1) {
                    store.commit('hideLoading')
                    this.$toast({
                      type: 'success',
                      message: '下载成功！'
                    })
                    this.goOffline()
                  } else {
                    store.commit('hideLoading')
                    this.$toast({
                      type: 'warning',
                      message: '下载失败！'
                    })
                  }
                }).catch(err => {
                  store.commit('hideLoading')
                  this.$toast({
                    type: 'warning',
                    message: '下载失败:' + err
                  })
                })
            } else {
              store.commit('hideLoading')
              this.$toast({
                type: 'warning',
                message: '下载失败！'
              })
            }
          }).catch(err => {
            store.commit('hideLoading')
            this.$toast({
              type: 'warning',
              message: '下载失败: ' + err
            })
          })
        } else {
          this.$toast('上传失败：请检查网络链接！！！')
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 离线列表页面
     */
    goOffline() {
      this.$router.push({
        path: '/app/new/inspection/offline/list',
        query: {
          unitId: this.unitId
        }
      })
    },
    /**
     * 离线返回
     */
    goBack() {
      this.$router.push('/index')
    },
    doSearch() {
      this.searchShow = true
      this.needSearch = true
    },
    doDanger() {
      this.$router.push({
        path: '/app/new/inspection/danger/index',
        query: {
          unitId: this.$route.query.unitId
        }
      })
    },
    /**
       * 隐患页面跳转
       */
    goHidden(val, type) {
      this.$router.push({
        path: '/app/new/inspection/danger/handle/index',
        query: {
          id: val.id,
          operationType: type
        }
      })
    },
    /**
       * 前往开始页面
       */
    goStart(val) {
      this.$router.push({
        path: '/app/new/inspection/start/index',
        query: {
          taskType: val.type,
          taskId: val.id,
          taskState: val.state,
          unitId: val.unitId
        }
      })
    },
    openRoute(val) {
      this.taskId = val.id
      this.routeShow = true
    },
    /**
       * 初始化
       */
    init() {
      this.patrolCheckboxGroupShow = !this.$route.meta.showTab
      sessionStorage.setItem('isOffline', this.patrolCheckboxGroupShow)
      inspectionInit().then(res => {
        if (this.unitId && !this.$route.query.active) {
          this.temp.unitId = this.unitId
          this.setUnit(res.data.list)
          this.useMethods()
        } else {
          this.setUnit(res.data.list)
        }
      })
    },
    /**
       * 重置
       */
    restTemp() {
      this.info = {
        pointSum: 0,
        patrolSum: 0,
        patrolInfo: {
          name: null,
          state: null,
          startTime: null,
          endTime: null
        },
        patrolShow: false,
        maintenanceSum: 0,
        maintenanceInfo: {
          name: null,
          state: null,
          startTime: null,
          endTime: null
        },
        maintenanceShow: false,
        hiddenDangerSum: 0,
        hiddenDangerInfo: {
          code: null,
          createTime: null,
          isSolve: null,
          position: null,
          pointName: null
        },
        hiddenDangerShow: false
      }
    },
    /**
       * 自动选择单位并设置单位名称
       */
    setUnit(val) {
      if (val && val.length > 0) {
        const unitID = this.$route.query.unitId
        let listToUnitId = null
        if (val.find(item => Number(item.id) === Number(this.userInfo.unitId))) {
          listToUnitId = val.find(item => Number(item.id) === Number(this.userInfo.unitId)).id
        } else {
          listToUnitId = val[0].id
        }
        const tempUnitId = unitID || listToUnitId
        const unit = val.find(item => item.id === tempUnitId)
        this.temp.unitName = unit ? unit.name : ''
        this.$refs.infoRef.value = this.temp.unitName
        this.onClickItem(tempUnitId)
      } else {
        this.$toast({
          type: 'warning',
          message: '没有单位！'
        })
      }
      this.columns = val
    },
    /**
       * 选择单位
       */
    onClickItem(val) {
      if (this.temp.unitId !== val) {
        this.temp.unitId = val
      }
      if (this.columns && this.columns.length > 0) {
        const unit = this.columns.find(item => item.id === val)
        this.temp.unitName = unit ? unit.name : ''
        this.setUrlParameter1()
      }
      this.useMethods()
      const active = this.$route.query.active
      if (active) {
        this.onClickActive(active)
      }
    },
    /**
       * 查询（任务进度、任务列表、隐患列表）
       */
    async useMethods() {
      this.isLoading = true
      this.restTemp()
      if (this.hasPerm(this.hasPermission.point)) {
        this.getPointSum()
      }
      if (this.hasPerm(this.hasPermission.patrol)) {
        await this.getPatrolSumAndOneData()
      }
      if (this.hasPerm(this.hasPermission.maintenance)) {
        await this.getMaintenanceSumAndOneData()
      }
      if (this.hasPerm(this.hasPermission.hiddenDanger)) {
        await this.getHiddenDangerSumAndOneData()
      }
      this.isLoading = false
    },
    /**
       * 点位数量
       */
    getPointSum() {
      const query = {
        unitId: this.temp.unitId,
        pageNo: 1,
        pageSize: 1
      }
      pointList(query).then(res => {
        this.info.pointSum = res.data.totalRows
      })
    },
    /**
       * 维保数量和一条数据
       */
    async getMaintenanceSumAndOneData() {
      const query = {
        unitId: this.temp.unitId,
        pageNo: 1,
        pageSize: 1,
        type: 0,
        stateArray: '0,2',
        today: true
      }
      await taskPage(query).then(res => {
        this.info.maintenanceSum = res.data.totalRows
        if (res.data.rows.length > 0) {
          this.info.maintenanceShow = true
          this.info.maintenanceInfo = res.data.rows[0]
        } else {
          this.info.maintenanceShow = false
        }
      })
    },
    /**
       * 巡查数量和一条数据
       */
    async getPatrolSumAndOneData() {
      const query = {
        unitId: this.temp.unitId,
        pageNo: 1,
        pageSize: 1,
        type: 1,
        stateArray: '0,2',
        today: true,
        userIds: this.userInfo.id + ''
      }
      await selectTaskPage(query).then(res => {
        this.info.patrolSum = res.data.totalRows
        if (res.data.rows.length > 0) {
          this.info.patrolShow = true
          this.info.patrolInfo = res.data.rows[0]
        } else {
          this.info.patrolShow = false
        }
      })
    },
    /**
       * 隐患数量和一条数据
       */
    async getHiddenDangerSumAndOneData() {
      const query = {
        unitId: this.temp.unitId,
        pageNo: 1,
        pageSize: 1,
        isSolve: false
      }
      if (Number(this.userInfo.unitType) === 3) {
        query.isExam = true
      }
      await dangerPage(query).then(res => {
        this.info.hiddenDangerSum = res.data.totalRows
        if (res.data.rows.length > 0) {
          this.info.hiddenDangerShow = true
          this.info.hiddenDangerInfo = res.data.rows[0]
        } else {
          this.info.hiddenDangerShow = false
        }
      })
    },
    /**
       *
       */
    onClickActive(name) {
      this.active = name
      const active = this.$route.query.active
      if (name !== active && !this.tabsShow) {
        this.setUrlParameter()
      }
      this.tabsShow = true
    },
    /**
       * 扫一扫回调函数
       */
    goPointByScan(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      let unitId
      if (this.unitId) {
        unitId = this.unitId
      } else {
        unitId = this.temp.unitId
      }
      getInfoByCodeAndUnitId({ code: val.code, unitId: unitId }).then(res => {
        if (res.data) {
          this.$router.push({
            path: '/app/new/inspection/point/index',
            query: {
              id: res.data.id,
              unitId: res.data.unitId
            }
          })
        } else {
          this.$toast({
            type: 'warning',
            message: '点位不存在！'
          })
        }
      })
    },
    /**
       * 当前路由修改参数
       * history.pushState() 添加
       * history.replaceState() 修改
       */
    setUrlParameter() {
      this.$router.replace({
        query: {
          unitId: this.temp.unitId,
          active: this.active
        }
      })
    },
    setUrlParameter1() {
      this.$router.replace({
        query: {
          unitId: this.temp.unitId,
          unitName: this.temp.unitName
        }
      })
    }
  }
}
</script>
<style scoped>
  .cards-navbar-extend {
    background-color: #F4F4F4 !important;
    position: static !important;
  }

  #info {
    background: linear-gradient(180deg, #1989FA 0%, rgba(25, 137, 250, 0.00) 100%);
    height: 158px;
    color: #FFFFFF;
  }

  #infoContent {
    margin-top: -64px;
  }

  #info .van-row {
    padding: 31px 0 22px 0
  }

  #info .van-row .van-col {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  #info .van-row .van-col div {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  #info .van-row .van-col span {
    font-family: PingFang SC Bold;
    font-size: 12px;
  }

  #info .van-row .van-col div span {
    font-family: PingFang SC Bold;
    font-size: 22px;
    font-weight: bolder;
  }

  #info .van-row .van-col div .van-icon {
    font-size: 18px;
    line-height: 22px;
    /*font-weight: bolder;*/
  }

  #exhibition {
    background-color: #FFFFFF;
    margin: 15px 10px;
    font-family: PingFang SC Bold;
  }

  #exhibition .title {
    font-size: 18px;
    line-height: 18px;
    font-weight: bolder;
    padding: 11px 0 13px 15px;
  }

  #exhibition .infoCard {
    margin-bottom: 8px;
  }

  .span_color {
    font-family: PingFang SC Bold;
    color: #979797;
  }

  .span_font {
    font-family: PingFang SC Bold;
  }

  .font_crude {
    font-family: PingFang SC Bold;
    font-weight: bolder !important;
  }

  .button_font {
    height: 40px;
    border-radius: 6px;

    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;

    font-family: PingFangSC-Regular;
    font-size: 18px;
    font-weight: normal;
    line-height: 18px;
    letter-spacing: 0em;
    color: #FFFFFF;
  }
</style>
