<template>
  <div>
    <common-head :background-color="'#0668CB'" :title="'E消防'" />
    <div class="cards-navbar" style="background: #F4F4F4;">
      <div class="me-card">
        <van-image
          v-if="avatarPath == null || avatarPath == ''"
          class="display-center"
          round
          width="65"
          :src="require('@/assets/images/new/userImage.png')"
        />
        <van-image
          v-if="avatarPath != null && avatarPath != ''"
          class="display-center"
          round
          width="65"
          :src="'/file/'+avatarPath"
        />
        <div
          class="display-center font-PingFang"
          style="font-size: 16px;height:30px;"
        >
          {{ userName }} <img
            :height="15"
            style="position: relative;left:10px"
            :src="require('@/assets/images/new/edit.png')"
          >
        </div>
        <div
          class="display-center font-PingFang"
          style="height:35px;font-size: 16px;"
        >
          {{ unitName }}
        </div>
      </div>
      <div style="color: #3A3A44;margin-top:-37px">
        <div v-if="false" class="white-circle" style="padding-top:10px">
          <div
            class="display-center font-PingFang"
            style="height:30px;font-size: 15px;font-weight: bold"
          >我的任务
          </div>
          <van-grid class="font-PingFang" style="color: #474747;" :border="false" :column-num="3">
            <van-grid-item @click="goMaintenance">
              <span style="font-size: 20px;font-weight: bold">{{ statistics.maintenanceCount }}</span>
              今日维保
            </van-grid-item>
            <van-grid-item @click="goPatrol">
              <span style="font-size: 20px;font-weight: bold">{{ statistics.patrolCount }}</span>
              今日巡查
            </van-grid-item>
            <van-grid-item @click="goHiddenDanger">
              <span style="font-size: 20px;font-weight: bold">{{ statistics.hiddenDangersCount }}</span>
              今日隐患
            </van-grid-item>
          </van-grid>
          <br>
        </div>

        <div class="white-circle">
          <van-cell-group class="font-PingFang" style="border-radius: 20px;color:#474747;">
            <van-cell style="border-radius: 20px" title="密码修改" is-link @click="openPwdUpdate" />
            <van-cell
              v-if="hasBtnPermission('sys:unit:edit')"
              style="border-radius: 20px"
              title="单位修改"
              is-link
              @click="onUnitEdit"
            />
            <van-cell
              v-if="hasBtnPermission('sys:unit:user')"
              style="border-radius: 20px"
              title="用户管理"
              is-link
              @click="onUserManagement"
            />
            <van-cell
              v-if="hasBtnPermission('sys:unit:edit')"
              style="border-radius: 20px"
              title="推送暂停"
              is-link
              @click="setUnitPush"
            />
            <van-cell title="使用规则" is-link />
            <van-cell title="问题上报" is-link />
            <van-cell title="联系我们" value="057463020119" />
            <van-cell v-if="isApp" title="检查新版本" is-link @click="checkUpdate" />
          </van-cell-group>
        </div>

        <div
          style="height: 40px;display: flex; justify-content: center;align-items: center;color:#1477FF;font-size:14px;font-weight: normal"
          class="white-circle font-PingFang"
          @click="logout"
        >
          退出登录
        </div>
        <div class="nav-bottom" />
      </div>
    </div>
  </div>
</template>

<script>
import { Toast } from 'vant'
import commonHead from '@/views/app/common/head'
import { maintenanceTaskCount, patrolTaskCount } from '@/api/exam/task'
import { hiddenDangersCount } from '@/api/exam/danger'
import { hasBtnPermission } from '@/utils/permission'

export default {
  components: { commonHead },
  data() {
    return {
      active: 0,
      statistics: {
        patrolCount: 0,
        maintenanceCount: 0,
        hiddenDangersCount: 0
      },
      avatarPath: this.$store.getters.avatarPath
    }
  },
  computed: {
    unitName() {
      return this.$store.getters.unitName
    },
    userName() {
      return this.$store.getters.name
    },
    email() {
      return this.$store.getters.email
    },
    userInfo() {
      return this.$store.getters.user
    },
    isApp() {
      if (window.AndroidWebView) return true
      return false
    }
  },
  created() {
    this.init()
  },
  methods: {
    hasBtnPermission(value) {
      if (value != null) {
        value = value.replace('switchs', 'switch')
        return hasBtnPermission(value)
      } else {
        return false
      }
    },
    onUnitEdit() {
      const id = this.userInfo.unitId
      if (id) {
        this.$router.push({
          path: '/app/me/unitUpdate',
          query: {
            id: id,
            operationType: 'edit',
            limit: 'edit-1'
          }
        })
      }
    },
    setUnitPush() {
      this.$router.push({
        path: '/app/sys/unit/index',
        query: {
          type: 2
        }
      })
    },
    checkUpdate() {
      if (window.AndroidWebView) {
        window.AndroidWebView.checkUpdate()
      }
    },
    onUserManagement() {
      const id = this.userInfo.unitId
      if (id) {
        this.$router.push({
          path: '/app/me/user/index',
          query: {
            unitId: id
          }
        })
      }
    },
    init() {
      this.getPatrolCount()
      this.getMaintenanceCount()
      this.getHiddenDangerCount()
    },
    goPatrol() {
      this.$router.push({ path: '/app/inspection/index?active=patrol' })
    },
    goMaintenance() {
      this.$router.push({ path: '/app/inspection/index?active=maintenance' })
    },
    goHiddenDanger() {
      this.$router.push({ path: '/app/inspection/index?active=hiddenDanger' })
    },
    getPatrolCount() {
      patrolTaskCount().then(res => {
        this.statistics.patrolCount = res.data
      })
    },
    getMaintenanceCount() {
      maintenanceTaskCount().then(res => {
        this.statistics.maintenanceCount = res.data
      })
    },
    getHiddenDangerCount() {
      hiddenDangersCount().then(res => {
        this.statistics.hiddenDangersCount = res.data
      })
    },
    logout() {
      this.$store.dispatch('user/logout').then((response) => {
        if (response === 'wx') {
          this.$router.push('/login')
        } else {
          this.$router.push('/login') // 为了重新实例化vue-router对象 避免bug
        }
      })
    },
    openPwdUpdate() {
      this.$router.push('/app/me/pwdUpdate')
    },
    goBack() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    },
    onClickLeft() {
      Toast('返回')
    },
    onClickRight() {
      Toast('按钮')
    }
  }
}
</script>

<style scoped>

  .me-card {
    width: 100%;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: center;
    background-image: url("../../../assets/images/new/mebg.png");
    height: 180px;
    background-color: transparent !important;
    color: #ffffff !important;
    z-index: 1 !important;
  }

</style>
