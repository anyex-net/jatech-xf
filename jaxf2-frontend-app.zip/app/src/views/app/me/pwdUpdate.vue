<template>
  <div class="body-me">
    <common-head :isBack="true" :title="'密码修改'"/>
    <div class="content">
      <div class="cards-navbar">
        <van-form>
          <van-field
            label="旧密码"
            v-model="temp.oldPassword"
            placeholder="请输入旧密码"
            type="password"
            input-align="right"
            autocomplete=""
          />
          <van-field
            label="新密码"
            v-model="temp.newPassword"
            type="password"
            placeholder="请输入新密码"
            input-align="right"
            autocomplete=""
          />
          <van-field
            label="确认密码"
            v-model="temp.newPassword1"
            type="password"
            placeholder="请重复确认密码"
            input-align="right"
            autocomplete=""
          />

        </van-form>
        <van-row>
          <van-col span="22" offset="1">
            <van-button style="margin-top:20px;background-color: #1989fa" class="button"
                        @click="updatePassword">修改密码
            </van-button>
          </van-col>
        </van-row>
      </div>
    </div>
  </div>
</template>

<script>
  import {updatePwd} from "@/api/sys/user";
  import commonHead from "@/views/app/common/head";
  import store from "@/store";
  import {Dialog} from "vant";

  export default {
    components: {
      commonHead
    },
    mounted() {

    },
    created() {

    },
    data() {
      return {
        temp: {
          oldPassword: null,
          newPassword: null,
          newPassword1: null,
        }
      }
    },
    methods: {
      close() {
        this.$emit("close")
      },
      updatePassword() {
        Dialog.confirm({
          message: "是否修改?",
        }).then(() => {
          if (this.temp.oldPassword === null || this.temp.oldPassword === "") {
            this.$toast("旧密码不能为空");
            return;
          }
          if (this.temp.newPassword === null || this.temp.newPassword === "") {
            this.$toast("新密码不能为空");
            return;
          }
          if (this.temp.newPassword1 === null || this.temp.newPassword1 === "") {
            this.$toast("重复新密码不能为空");
            return;
          }
          store.commit('showLoading')
          updatePwd(this.temp).then(response => {
            if (response.success) {
              store.commit('hideLoading')
              this.$store.dispatch('user/logout').then(() => {
                location.reload() // 为了重新实例化vue-router对象 避免bug
              })
            }
          }).catch(err => {
            store.commit('hideLoading')
          })
        }).catch(() => {
          store.commit('hideLoading')
          // on cancel
        });
      }
    }
  }
</script>



