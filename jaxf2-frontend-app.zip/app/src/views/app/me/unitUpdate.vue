<template>
  <div>
    <common-head :is-back="true" :title="title" />
    <!--    <common-head :is-back="true" :title="title" />-->
    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-form label-width="140px" @submit="onSubmit">
        <van-field
          v-model="temp.name"
          :rules="[{ required: true, message: '请填写名称' }]"
          clearable
          label="名称"
          name="name"
          placeholder="名称"
          required
        />

        <van-field
          :rules="[{ required: true, message: '请选择所属区域' }]"
          :value="formTemp.areaName"
          clickable
          label="所属区域"
          name="areaName"
          placeholder="选择所属区域"
          readonly
          required
          @click="areaClick"
        />
        <van-popup v-model="formTemp.areaActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.areaActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.areaActionSheet.show = false"
            @confirm="onAreaConfirm"
          >
            <template #title>
              <form action="/">
                <van-search
                  v-model="formTemp.searchAreaValue"
                  name="searchValue"
                  placeholder="请输入搜索关键词"
                  shape="round"
                  @blur="onAreaSearch"
                />
              </form>
            </template>
          </van-picker>
        </van-popup>
        <van-field
          v-if="unitType === 1"
          v-model="temp.juridicalName"
          :rules="[{ required: true, message: '请填写法人姓名' }]"
          clearable
          label="法人姓名"
          name="administratorPhone"
          placeholder="法人姓名"
          required
        />
        <van-field
          v-if="unitType === 1"
          v-model="temp.juridicalPhone"
          :rules="[{ required: true, message: '请填写法人电话' }]"
          clearable
          label="法人电话"
          name="administratorPhone"
          placeholder="法人电话"
          required
        />
        <van-field
          v-if="unitType === 1"
          v-model="temp.juridicalCard"
          :rules="[{ required: true, message: '请填写法人身份证' }]"
          clearable
          label="法人身份证"
          name="administratorPhone"
          placeholder="法人身份证"
          required
        />
        <van-field
          v-if="unitType === 2"
          :rules="[{ required: true, message: '请选择单位类别' }]"
          :value="formTemp.unitCategoryName"
          clickable
          label="单位类别"
          name="unitCategoryName"
          placeholder="选择单位类别"
          readonly
          required
          @click="formTemp.unitCategoryActionSheet.show = true"
        />
        <van-popup v-if="unitType === 2" v-model="formTemp.unitCategoryActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.unitCategoryActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.unitCategoryActionSheet.show = false"
            @confirm="onUnitCategoryConfirm"
          />
        </van-popup>

        <van-field
          v-if="unitType === 2"
          :rules="[{ required: true, message: '请选择场所类型' }]"
          :value="formTemp.placeTypeName"
          clickable
          label="场所类型"
          name="placeTypeName"
          placeholder="选择场所类型"
          readonly
          required
          @click="formTemp.placeTypeActionSheet.show = true"
        />
        <van-popup v-if="unitType === 2" v-model="formTemp.placeTypeActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.placeTypeActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.placeTypeActionSheet.show = false"
            @confirm="onPlaceTypeConfirm"
          />
        </van-popup>

        <van-field
          v-if="unitType === 2"
          v-model="temp.unifiedCode"
          :rules="[{ required: true, message: '请填写社会信用统一代码' }]"
          clearable
          label="社会信用统一代码"
          name="unifiedCode"
          placeholder="社会信用统一代码"
          required
        />

        <van-field
          v-if="unitType === 2"
          :rules="[{ required: true, message: '请选单位类型' }]"
          :value="formTemp.unitTypeName"
          clickable
          label="单位类型"
          name="unitTypeName"
          placeholder="选择单位类型"
          readonly
          required
          @click="formTemp.unitTypeActionSheet.show = true"
        />
        <van-popup v-if="unitType === 2" v-model="formTemp.unitTypeActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.unitTypeActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.unitTypeActionSheet.show = false"
            @confirm="onUnitTypeConfirm"
          />
        </van-popup>

        <van-field
          v-if="unitType === 2"
          v-model="temp.industryClassification"
          :rules="[{ required: true, message: '请填写国民经济行业分类' }]"
          clearable
          label="国民经济行业分类"
          name="industryClassification"
          placeholder="国民经济行业分类"
          required
        />

        <van-field
          v-if="unitType === 2"
          v-model="temp.personLiableName"
          :rules="[{ required: true, message: '请填写消防安全责任人姓名' }]"
          clearable
          label="消防安全责任人姓名"
          name="personLiableName"
          placeholder="消防安全责任人姓名"
          required
        />

        <van-field
          v-if="unitType === 2"
          v-model="temp.personLiablePhone"
          :rules="[{ required: true, message: '请填写消防安全责任人电话' }]"
          clearable
          label="消防安全责任人电话"
          name="personLiablePhone"
          placeholder="消防安全责任人电话"
          required
        />

        <van-field
          v-if="unitType === 2"
          v-model="temp.administratorName"
          :rules="[{ required: true, message: '请填写消防安全管理人姓名' }]"
          clearable
          label="消防安全管理人姓名"
          name="administratorName"
          placeholder="消防安全管理人姓名"
          required
        />

        <van-field
          v-if="unitType === 2"
          v-model="temp.administratorPhone"
          :rules="[{ required: true, message: '请填写消防安全管理人电话' }]"
          clearable
          label="消防安全管理人电话"
          name="administratorPhone"
          placeholder="消防安全管理人电话"
          required
        />

        <van-field
          v-if="unitType === 4"
          v-model="temp.juridicalName"
          :rules="[{ required: true, message: '请填写联系人名称' }]"
          clearable
          label="联系人姓名"
          name="juridicalName"
          placeholder="联系人姓名"
          required
        />
        <van-field
          v-if="unitType === 4"
          v-model="temp.juridicalPhone"
          :rules="[{ required: true, message: '请填写联系人电话' }]"
          clearable
          label="联系人电话"
          name="juridicalPhone"
          placeholder="联系人电话"
          required
        />
        <base-map-search
          ref="mapSearch"
          input-align="left"
          :is-edit="true"
          :is-hide="false"
          :latitude="temp.lat"
          :longitude="temp.lng"
          :value="temp.address"
          @updateLocation="updateLocation"
        />

        <van-field
          v-model="temp.lng"
          :rules="[{ required: true, message: '请填写经度' }]"
          clearable
          label="经度"
          name="lng"
          placeholder="经度"
          required
        />

        <van-field
          v-model="temp.lat"
          :rules="[{ required: true, message: '请填写纬度' }]"
          clearable
          label="纬度"
          name="lat"
          placeholder="纬度"
          required
        />

        <van-field label="推送通道" name="channelIdList">
          <template #input>
            <van-checkbox-group v-model="formTemp.channelIdList" direction="horizontal">
              <van-checkbox
                v-for="(item,index) in formTemp.checkboxGroup.notice"
                :key="index"
                :name="item.id"
                icon-size="12px"
                shape="square"
              >{{ item.name }}
              </van-checkbox>
            </van-checkbox-group>
          </template>
        </van-field>

        <div class="bottom" />
        <div class="bar-footer">
          <van-button block native-type="submit" round type="info">更新</van-button>
        </div>
      </van-form>
    </div>
  </div>
</template>

<script>
import commonHead from '@/views/app/common/head'
import { getUnitDetail, getUnitList, onlineUnitAdd, unitEdit, unitList } from '@/api/sys/unit'
import { Toast } from 'vant'
import { getAreaInfoById, getAreaListByName } from '@/api/sys/area'
import { unitCategoryList } from '@/api/sys/unitCategory'
import { unitTypeList } from '@/api/sys/unitType'
import { getNoticeChannel } from '@/api/common'
import BaseMapSearch from '@/components/Map/baseMapSearch'

export default {
  name: 'Index',
  components: { commonHead, BaseMapSearch },
  data() {
    return {
      id: null,
      isEdit: false,
      isLimit: true,
      title: null,
      unitType: null,
      titleMap: {
        edit: '编辑单位',
        add: '添加单位'
      },
      temp: {
        name: null,
        parentId: null,
        areaId: null,
        unitCategory: null,
        placeType: null,
        unifiedCode: null,
        unitType: null,
        industryClassification: null,
        personLiableName: null,
        personLiablePhone: null,
        administratorName: null,
        administratorPhone: null,
        address: '',
        lng: null,
        lat: null,
        operateUnitId: null,
        examUnitId: '',
        channelIdList: null,
        status: null
      },
      formTemp: {
        areaName: '',
        parentName: '',
        unitCategoryName: '',
        placeTypeName: '',
        unitTypeName: '',
        operateUnitName: '',
        examUnitName: '',
        channelIdList: [],
        searchUnitValue: '',
        unitActionSheet: {
          show: false,
          actions: []
        },
        searchAreaValue: '',
        areaActionSheet: {
          show: false,
          actions: []
        },
        unitCategoryActionSheet: {
          show: false,
          actions: []
        },
        placeTypeActionSheet: {
          show: false,
          actions: [
            { id: '01', name: '沿街商铺' },
            { id: '02', name: '政府单位' },
            { id: '03', name: '公共娱乐场所' },
            { id: '04', name: '商超市场' },
            { id: '05', name: '宾馆饭店' },
            { id: '06', name: '医院' },
            { id: '07', name: '公共高层建筑' },
            { id: '08', name: '工业企业' },
            { id: '09', name: '客运车站' },
            { id: '10', name: '养老院' },
            { id: '11', name: '学校' },
            { id: '12', name: '弱势群体' },
            { id: '13', name: '住宅小区' },
            { id: '14', name: '10人以上出租房' }
          ]
        },
        unitTypeActionSheet: {
          show: false,
          actions: []
        },
        operateUnitActionSheet: {
          show: false,
          actions: []
        },
        examUnitActionSheet: {
          show: false,
          actions: []
        },
        checkboxGroup: {
          notice: []
        }
      }
    }
  },
  created() {
    this.onInitData()
  },
  methods: {
    updateLocation(lng, lat, address) {
      this.temp.lng = lng
      this.temp.lat = lat
      this.temp.address = address
    },
    onInitData() {
      this.$route.query.id ? this.id = this.$route.query.id : this.id = null
      this.isEdit = this.$route.query.operationType === 'edit'
      this.isLimit = !(this.$route.query.limit === 'edit-1')
      this.isEdit ? this.title = this.titleMap.edit : this.title = this.titleMap.add
      this.getUnitCategoryList()
      this.getUnitTypeList()
      this.onGetNoticeChannel()
      if (this.isEdit) {
        this.onLoad()
      } else {
        this.temp.status = 1
      }
    },
    onLoad() {
      getUnitDetail(this.id).then(res => {
        if (res.success) {
          this.temp = res.data
          this.$refs.mapSearch.updateAddress(this.temp.address, this.temp.lng, this.temp.lat)
          if (this.temp.isOperate) this.unitType = 1
          else if (this.temp.isOnline) this.unitType = 2
          else if (this.temp.isExam) this.unitType = 3
          else if (this.temp.isImplement) this.unitType = 4
          else if (this.temp.isMonitor) this.unitType = 5
          this.onEditDataHandle(res.data)
        }
      })
    },

    onSubmit(values) {
      if (this.isEdit) {
        this.onUpdate(values)
      } else {
        this.onAdd(values)
      }
    },
    onAdd(values) {
      this.onAddDataHandle(values)
      Toast.loading({
        duration: 0, // 持续展示 toast
        forbidClick: true,
        message: '添加中...'
      })
      onlineUnitAdd(this.temp).then((res) => {
        if (res.success) {
          Toast.clear()
          Toast.success('添加成功')
          const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
          const path = routeArray[routeArray.length - 1]
          this.$router.push(path)
        } else {
          Toast(res.message)
        }
      }).catch((err) => {
        Toast(err + '')
      })
    },
    onAddDataHandle(values) {
      this.temp.channelIdList = values.channelIdList
    },

    onUpdate(values) {
      this.onAddDataHandle(values)
      Toast.loading({
        duration: 0, // 持续展示 toast
        forbidClick: true,
        message: '更新中...'
      })
      unitEdit(this.temp).then((res) => {
        if (res.success) {
          Toast.clear()
          Toast.success('更新成功')
          const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
          const path = routeArray[routeArray.length - 1]
          this.$router.push(path)
        } else {
          Toast(res.message)
        }
      }).catch((err) => {
        Toast(err + '')
      })
    },
    onEditDataHandle(values) {
      if (values.areaId) {
        this.onAreaInfoHandle(values.areaId)
      }

      if (values.placeType) {
        const placeTypeActions = this.formTemp.placeTypeActionSheet.actions
        this.formTemp.placeTypeName = placeTypeActions.find(res => res.id === values.placeType).name
      }

      if (values.unitCategory) {
        const unitCategoryActions = this.formTemp.unitCategoryActionSheet.actions
        this.formTemp.unitCategoryName = unitCategoryActions.find(res => res.id === values.unitCategory).name
      }

      if (values.unitType) {
        const unitTypeActions = this.formTemp.unitTypeActionSheet.actions
        this.formTemp.unitTypeName = unitTypeActions.find(res => res.id === values.unitType).name
      }
      if (values.channelIdList) {
        this.formTemp.channelIdList = values.channelIdList
      }
    },
    onAreaInfoHandle(value) {
      getAreaInfoById(value).then(res => {
        if (res.success) {
          this.formTemp.areaName = res.data.name
        }
      })
    },
    unitClick() {
      this.formTemp.unitActionSheet.show = true
      this.formTemp.searchUnitValue = ''
      this.formTemp.unitActionSheet.actions = []
    },
    onUnitConfirm(value) {
      if (!value) {
        Toast.fail('请选择')
        return
      }
      this.temp.parentId = value.id
      this.formTemp.unitName = value.name
      this.formTemp.unitActionSheet.show = false
    },
    onUnitSearch(val) {
      getUnitList({ name: val.target._value }).then(res => {
        if (res.success) {
          this.formTemp.unitActionSheet.actions = res.data.map(item => {
            return { id: item.id, name: item.name }
          })
        }
      })
    },
    areaClick() {
      this.formTemp.areaActionSheet.show = true
      this.formTemp.searchAreaValue = ''
      this.formTemp.areaActionSheet.actions = []
    },
    onAreaConfirm(value) {
      if (!value) {
        Toast.fail('请选择')
        return
      }
      this.temp.areaId = value.id
      this.formTemp.areaName = value.name
      this.formTemp.areaActionSheet.show = false
    },
    onAreaSearch(val) {
      if (!val.target._value) {
        return
      }
      getAreaListByName(val.target._value).then(res => {
        if (res.success) {
          this.formTemp.areaActionSheet.actions = res.data.map(item => {
            return { id: item.id, name: item.name }
          })
        }
      })
    },
    getUnitCategoryList() {
      unitCategoryList().then(res => {
        if (res.success) {
          this.formTemp.unitCategoryActionSheet.actions = res.data
        }
      })
    },
    onUnitCategoryConfirm(value) {
      if (!value) {
        Toast.fail('请选择')
        return
      }
      this.temp.unitCategory = value.id
      this.formTemp.unitCategoryName = value.name
      this.formTemp.unitCategoryActionSheet.show = false
    },
    onPlaceTypeConfirm(value) {
      if (!value) {
        Toast.fail('请选择')
        return
      }
      this.temp.placeType = value.id
      this.formTemp.placeTypeName = value.name
      this.formTemp.placeTypeActionSheet.show = false
    },
    getUnitTypeList() {
      unitTypeList().then(response => {
        if (response.success) {
          this.formTemp.unitTypeActionSheet.actions = response.data
        }
      })
    },
    onUnitTypeConfirm(value) {
      if (!value) {
        Toast.fail('请选择')
        return
      }
      this.temp.unitType = value.id
      this.formTemp.unitTypeName = value.name
      this.formTemp.unitTypeActionSheet.show = false
    },
    onGetNoticeChannel() {
      getNoticeChannel().then(res => {
        if (res.success) {
          this.formTemp.checkboxGroup.notice = res.data
        }
      })
    },
    getOperateUnitList() {
      unitList({ isOperate: true }).then(response => {
        if (response.success) {
          this.formTemp.operateUnitActionSheet.actions = response.data
        }
      })
    },
    onOperateUnitConfirm(value) {
      if (!value) {
        Toast.fail('请选择')
        return
      }
      this.temp.operateUnitId = value.id
      this.formTemp.operateUnitName = value.name
      this.formTemp.operateUnitActionSheet.show = false
    },
    getExamUnitList() {
      unitList({ isExam: true }).then(response => {
        if (response.success) {
          this.formTemp.examUnitActionSheet.actions = response.data
        }
      })
    },
    onExamUnitConfirm(value) {
      if (!value) {
        Toast.fail('请选择')
        return
      }
      this.temp.examUnitId = value.id
      this.formTemp.examUnitName = value.name
      this.formTemp.examUnitActionSheet.show = false
    }
  }
}
</script>

<style scoped>

</style>
