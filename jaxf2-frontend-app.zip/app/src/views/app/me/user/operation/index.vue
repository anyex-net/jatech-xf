<template>
  <div>
    <common-head :is-back="true" :title="title" />
    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-form @submit="onSubmit">
        <van-field
          v-model="temp.account"
          :rules="[{ required: true, message: '请填写账号' }]"
          clearable
          label="账号"
          name="account"
          placeholder="账号"
          required
          @blur="accountConfirm"
        />
        <van-field
          v-model="temp.name"
          :rules="[{ required: true, message: '请填写姓名' }]"
          clearable
          label="姓名"
          name="name"
          placeholder="姓名"
          required
        />

        <van-field label="推送通道" name="channelIdList">
          <template #input>
            <van-checkbox-group v-model="formTemp.channelIdList" direction="horizontal">
              <van-checkbox
                v-for="(item,index) in formTemp.checkboxGroup.notice"
                :key="index"
                :name="item.id"
                icon-size="12px"
                shape="square"
              >{{ item.name }}
              </van-checkbox>
            </van-checkbox-group>
          </template>
        </van-field>

        <van-field
          v-model="temp.phone"
          clearable
          label="手机"
          name="phone"
          placeholder="手机"
          type="tel"
        />

        <van-field
          v-model="temp.email"
          clearable
          label="邮箱"
          name="email"
          placeholder="邮箱"
          type="email"
        />

        <van-field
          :value="temp.birthday"
          clickable
          label="生日"
          name="birthday"
          placeholder="生日"
          readonly
          @click="formTemp.date.birthdayShowPicker = true"
        />
        <van-popup v-model="formTemp.date.birthdayShowPicker" position="bottom">
          <van-datetime-picker
            v-model="formTemp.date.value"
            :min-date="formTemp.date.minDate"
            type="date"
            @cancel="formTemp.date.birthdayShowPicker = false"
            @confirm="onBirthdayConfirm"
          />
        </van-popup>

        <van-field label="性别" name="sex">
          <template #input>
            <van-radio-group v-model="temp.sex" direction="horizontal">
              <van-radio :name="1" icon-size="12px" shape="square">男</van-radio>
              <van-radio :name="2" icon-size="12px" shape="square">女</van-radio>
              <van-radio :name="3" icon-size="12px" shape="square">未知</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <van-field label="用户头像" name="avatarList">
          <template #input>
            <van-uploader v-model="formTemp.avatarList" :after-read="afterRead" :max-count="1" multiple />
          </template>
        </van-field>

        <van-field label="事件推送级别" name="sendList">
          <template #input>
            <van-checkbox-group v-model="formTemp.sendList" direction="horizontal">
              <van-checkbox
                v-for="(item,index) in formTemp.checkboxGroup.send"
                :key="index"
                :name="item.id"
                icon-size="12px"
                shape="square"
              >{{ item.label }}
              </van-checkbox>
            </van-checkbox-group>
          </template>
        </van-field>

        <van-field label="火警推送级别" name="fireSendList">
          <template #input>
            <van-checkbox-group v-model="formTemp.fireSendList" direction="horizontal">
              <van-checkbox
                v-for="(item,index) in formTemp.checkboxGroup.fireSend"
                :key="index"
                :name="item.id"
                icon-size="12px"
                shape="square"
              >{{ item.label }}
              </van-checkbox>
            </van-checkbox-group>
          </template>
        </van-field>
        <div class="bottom" />
        <div class="bar-footer">
          <van-button v-if="isEdit" block native-type="submit" round type="info">更新</van-button>
          <van-button v-else block native-type="submit" round type="info">提交</van-button>
        </div>
      </van-form>
    </div>
  </div>
</template>

<script>
import commonHead from '@/views/app/common/head'
import { sysUserAdd, sysUserDetail, sysUserEdit } from '@/api/system/userManage'
import { getOnlineUnitDetail, getUnitList } from '@/api/sys/unit'
import { getNoticeChannel } from '@/api/common'
import { Toast } from 'vant'
import { sysFileGetFileList, sysFileInfoUpload } from '@/api/system/fileManage'

export default {
  name: 'Index',
  components: { commonHead },
  data() {
    return {
      id: null,
      isEdit: false,
      title: null,
      titleMap: {
        edit: '编辑用户信息',
        add: '添加用户信息'
      },
      temp: {
        account: null,
        avatar: null,
        birthday: null,
        email: null,
        firstFireSend: null,
        firstSend: null,
        name: null,
        phone: null,
        secondFireSend: null,
        secondSend: null,
        sex: null,
        thirdFireSend: null,
        thirdSend: null,
        unitId: null,
        unitName: null,
        unitType: null,
        unitTypeName: '联网单位'
      },
      formTemp: {
        channelIdList: [],
        sendList: [],
        fireSendList: [],
        unitTypeActionSheet: {
          show: false,
          actions: [{ id: 1, name: '运营单位' }, { id: 2, name: '联网单位' }, { id: 3, name: '维保单位' }]
        },
        unitActionSheet: {
          show: false,
          actions: []
        },
        searchUnitValue: '',
        checkboxGroup: {
          notice: [],
          send: [{ id: 1, label: '一级' }, { id: 2, label: '二级' }, { id: 3, label: '三级' }],
          fireSend: [{ id: 1, label: '一级' }, { id: 2, label: '二级' }, { id: 3, label: '三级' }]
        },
        avatarList: [],
        date: {
          minDate: new Date(1890, 0, 1),
          birthdayShowPicker: false,
          value: null
        }
      }
    }
  },
  created() {
    this.onInitData()
    if (this.$route.query.unitId) {
      this.temp.unitId = this.$route.query.unitId
    }
  },
  methods: {
    accountConfirm() {
      const myreg = /^[1][3,4,5,7,8][0-9]{9}$/
      if (this.temp.account.toString().length === 11 && myreg.test(this.temp.account)) {
        this.temp.phone = this.temp.account
      }
    },
    onInitData() {
      this.$route.query.id ? this.id = this.$route.query.id : this.id = null
      this.isEdit = this.$route.query.operationType === 'edit'
      this.isEdit ? this.title = this.titleMap.edit : this.title = this.titleMap.add
      this.onGetNoticeChannel()
      if (this.isEdit) {
        this.onLoad()
      } else {
        this.formTemp.date.value = new Date()
        this.temp.birthday = this.formatDate(this.formTemp.date.value)
        this.formTemp.sendList.push(1)
      }
    },
    onSubmit(values) {
      if (this.isEdit) {
        this.onUpdate(values)
      } else {
        this.onAdd(values)
      }
    },

    onUpdate(values) {
      this.onAddDataHandle(values)
      Toast.loading({
        duration: 0, // 持续展示 toast
        forbidClick: true,
        message: '更新中...'
      })
      sysUserEdit(this.temp).then(res => {
        if (res.success) {
          Toast.clear()
          Toast.success('更新成功')
          this.onBack()
        } else {
          Toast(res.message)
        }
      }).catch((err) => {
        Toast(err + '')
      })
    },
    onBack() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    },
    onLoad() {
      sysUserDetail({ id: this.id }).then(res => {
        if (res.success) {
          this.temp = res.data
          this.onEditDataHandle(res.data)
        }
      })
    },
    onEditDataHandle(values) {
      if (values.birthday) {
        this.formTemp.date.value = this.reverseFormatDate(values.birthday)
      }
      if (values.grantChannelIdList) {
        this.formTemp.channelIdList = values.grantChannelIdList
      }
      if (values.avatar) {
        this.onFileDataHandle(values.avatar)
      }
      const sendList = this.formTemp.sendList
      values.firstSend ? sendList.push(1) : (sendList.indexOf(1) !== -1 ? sendList.splice(sendList.indexOf(1), 1) : null)
      values.secondSend ? sendList.push(2) : (sendList.indexOf(2) !== -1 ? sendList.splice(sendList.indexOf(2), 1) : null)
      values.thirdSend ? sendList.push(3) : (sendList.indexOf(3) !== -1 ? sendList.splice(sendList.indexOf(3), 1) : null)

      const fireSendList = this.formTemp.fireSendList
      values.firstFireSend ? fireSendList.push(1) : (fireSendList.indexOf(1) !== -1 ? fireSendList.splice(fireSendList.indexOf(1), 1) : null)
      values.secondFireSend ? fireSendList.push(2) : (fireSendList.indexOf(2) !== -1 ? fireSendList.splice(fireSendList.indexOf(2), 1) : null)
      values.thirdFireSend ? fireSendList.push(3) : (fireSendList.indexOf(3) !== -1 ? fireSendList.splice(fireSendList.indexOf(3), 1) : null)

      const actions = this.formTemp.unitTypeActionSheet.actions
      // eslint-disable-next-line no-return-assign
      this.temp.unitTypeName = actions.find(item => item.id = values.unitType).name

      this.onUnitInfoHandle(values.unitId)
    },
    reverseFormatDate(date) {
      const dateList = date.split('-')
      const year = parseInt(dateList[0])
      const month = parseInt(dateList[1])
      const day = parseInt(dateList[2])
      return new Date(year, month - 1, day)
    },
    onUnitInfoHandle(value) {
      getOnlineUnitDetail(value).then(res => {
        if (res.success) {
          this.temp.unitName = res.data.name
        }
      })
    },
    onFileDataHandle(value) {
      const fileList = this.formTemp.avatarList
      sysFileGetFileList({ 'fileIds': value }).then(res => {
        if (res.success) {
          res.data.forEach(item => {
            fileList.push({
              url: item.filePath,
              fileId: item.id
            })
          })
        }
      })
    },

    onAdd(values) {
      this.onAddDataHandle(values)
      Toast.loading({
        duration: 0, // 持续展示 toast
        forbidClick: true,
        message: '添加中...'
      })
      sysUserAdd(this.temp).then(res => {
        if (res.success) {
          Toast.clear()
          Toast.success('添加成功')
          this.onBack()
        } else {
          Toast(res.message)
        }
      }).catch((err) => {
        Toast(err + '')
      })
    },
    onAddDataHandle(values) {
      this.temp.grantChannelIdList = this.formTemp.channelIdList

      const sendList = values.sendList
      sendList.includes(1) ? this.temp.firstSend = true : this.temp.firstSend = false
      sendList.includes(2) ? this.temp.secondSend = true : this.temp.secondSend = false
      sendList.includes(3) ? this.temp.thirdSend = true : this.temp.thirdSend = false

      const fireSend = values.fireSendList
      fireSend.includes(1) ? this.temp.firstFireSend = true : this.temp.firstFireSend = false
      fireSend.includes(2) ? this.temp.secondFireSend = true : this.temp.secondFireSend = false
      fireSend.includes(3) ? this.temp.thirdFireSend = true : this.temp.thirdFireSend = false

      const avatarList = values.avatarList
      if (avatarList.length > 0) {
        this.temp.avatar = values.avatarList[0].fileId
      }
    },
    onUnitTypeSelect(item) {
      // 默认情况下点击选项时不会自动收起
      // 可以通过 close-on-click-action 属性开启自动收起
      this.formTemp.unitTypeActionSheet.show = false
      this.temp.unitType = item.id
      this.temp.unitTypeName = item.name
    },
    unitClick() {
      this.formTemp.unitActionSheet.show = true
      this.formTemp.searchUnitValue = ''
      this.formTemp.unitActionSheet.actions = []
    },
    onUnitConfirm(value) {
      if (!value) {
        Toast.fail('请先选择单位')
        return
      }
      this.temp.unitId = value.id
      this.temp.unitName = value.name
      this.formTemp.unitActionSheet.show = false
    },
    onUnitSearch(val) {
      getUnitList({ name: val.target._value }).then(res => {
        if (res.success) {
          this.formTemp.unitActionSheet.actions = res.data.map(item => {
            return { id: item.id, name: item.name }
          })
        }
      })
    },
    onGetNoticeChannel() {
      getNoticeChannel().then(res => {
        if (res.success) {
          this.formTemp.checkboxGroup.notice = res.data
        }
      })
    },
    onBirthdayConfirm(time) {
      this.temp.birthday = this.formatDate(time)
      this.formTemp.date.birthdayShowPicker = false
    },
    formatDate(date) {
      const year = `${date.getFullYear()}`
      let month = `${date.getMonth() + 1}`
      let day = `${date.getDate()}`
      // eslint-disable-next-line no-return-assign
      return `${year}-${month.length > 1 ? month : month = '0' + month}-${day.length > 1 ? day : day = '0' + day}`
    },
    afterRead(file) {
      file.status = 'uploading'
      file.message = '上传中...'
      const content = file.file
      const data = new FormData()
      data.append('file', content)
      sysFileInfoUpload(data).then((response) => {
        if (response.success) {
          file.fileId = response.data
          file.status = 'success'
          file.message = ''
        } else {
          file.status = 'failed'
          file.message = '上传失败'
        }
      }).catch((err) => {
        Toast(err + '')
      })
    }
  }
}
</script>

<style scoped>

</style>
