<template>
  <div>
    <common-head :is-back="true" title="用户详情"/>
    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-cell title="联网单位" :value="temp.unitName"/>
      <van-cell title="账号" :value="temp.account"/>
      <van-cell title="姓名" :value="temp.name"/>
      <van-cell title="昵称" :value="temp.nickName"/>
      <van-cell title="邮箱" :value="temp.email"/>
      <van-cell title="电话" :value="temp.phone"/>
      <!--      <van-cell title="状态">-->
      <!--        &lt;!&ndash; 使用 right-icon 插槽来自定义右侧图标 &ndash;&gt;-->
      <!--        <template #right-icon>-->
      <!--          <van-button v-if="temp.status" plain hairline type="primary" size="mini">启用</van-button>-->
      <!--          <van-button v-else plain hairline type="warning" size="mini">停用</van-button>-->
      <!--        </template>-->
      <!--      </van-cell>-->
      <van-cell title="授权设备数" :value="temp.deviceNum"/>
    </div>
  </div>
</template>

<script>
  import commonHead from '@/views/app/common/head'
  import {Toast} from 'vant'
  import {sysUserDetail} from '@/api/system/userManage'
  import {getOnlineUnitDetail} from '@/api/sys/unit'

  export default {
    name: 'Index',
    components: {commonHead}, data() {
      return {
        id: null,
        temp: {
          account: null,
          deviceNum: 0,
          email: null,
          id: null,
          name: null,
          nickName: null,
          phone: null,
          sex: 3,
          status: 0,
          tel: null,
          unitId: null,
          unitName: null,
          unitType: 4
        }
      }
    },
    created() {
      this.onInitData()
    },
    methods: {
      onInitData() {
        if (this.$route.query.id) {
          this.id = this.$route.query.id
          this.onLoad()
        } else {
          // Notify({ type: 'primary', message: '用户id为null！' });
          Toast.fail('用户id为null！')
        }
      },
      onLoad() {
        sysUserDetail({id: this.id}).then(res => {
          if (res.success) {
            this.temp = res.data
            this.onUnitInfoHandle(res.data.unitId)
          }
        })
      },
      onUnitInfoHandle(value) {
        getOnlineUnitDetail(value).then(res => {
          if (res.success) {
            this.temp.unitName = res.data.name
          }
        })
      }
    }
  }
</script>

<style scoped>

</style>
