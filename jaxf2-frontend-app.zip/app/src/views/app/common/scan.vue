<template>
  <div @click="showScanPopup">
    <slot name="icon">
      <img src="@/assets/images/saoyisao.png" :height="height" :width="width" alt="@/assets/images/saoyisao.png">
    </slot>
  </div>
</template>

<script>
import { getSignature } from '@/api/sys/wx'
import wx from 'weixin-js-sdk'
import store from '@/store'

export default {
  name: 'Scan',
  props: {
    width: {
      type: String,
      default: '21'
    },
    height: {
      type: String,
      default: '21'
    }
  },
  data() {
    return {
      application: store.getters.user.application
    }
  },
  created() {
    delete window.scanConfirm
    window.scanConfirm = this.scanConfirm
    if (window.AndroidWebView) {
      window.AndroidWebView.setBarCodeCB('scanConfirm')
    }
  },
  beforeDestroy() {
  },
  methods: {
    /**
     *
     * @param code
     * @param type
     * $emit scanData 回调函授
     * @returns
     */
    scanConfirm(code, type) {
      this.showScan = false
      if (code === null || code === '' || typeof code === 'undefined') {
        this.$toast.success('请使用正确的二维码或者NFC!')
        return
      }
      const scanData = {
        code: code,
        type: type
      }
      // alert('scanData: '+ scanData.code+" type: "+scanData.type)
      this.$emit('scanData', scanData)
    },
    showScanPopup() {
      if (this.application === 'app' && window.AndroidWebView) {
        window.AndroidWebView.startScan()
      }
      if (this.application === 'wx') {
        const url = this.getSignUrl()
        getSignature({ url: url }).then(response => {
          if (response.success) {
            // 生成签名
            // jsapi_ticket 后台获取
            // noncestr 随机字符串
            // timestamp 当前时间戳
            // url 当前url，不算hash值
            // 按照以上顺序以键值对的形式连接起来（所有属性值均为原始值），在通过sha1加密形成签名。
            wx.config({
              debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
              appId: response.data.appId, // 必填，公众号的唯一标识
              timestamp: response.data.timestamp, // 必填，生成签名的时间戳
              nonceStr: response.data.nonceStr, // 必填，生成签名的随机串
              signature: response.data.signature, // 必填，签名
              jsApiList: ['scanQRCode'] // 必填，需要使用的JS接口列表
            })
            wx.ready((res) => {
              // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
              this.isWxConfig = true // 放开扫码按钮限制
              wx.scanQRCode({
                needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
                scanType: ['qrCode', 'barCode'], // 可以指定扫二维码还是一维码，默认二者都有
                success: (res) => {
                  const result = res.resultStr // 当needResult 为 1 时，扫码返回的结果
                  this.scanConfirm(result, 'wx')
                },
                fail: (res) => {
                  alert(JSON.stringify(res))
                },
                complete: (res) => {
                  // alert('完成' + JSON.stringify(res))
                }
              })
            })
            wx.error((res) => {
              alert('失败' + JSON.stringify(res))
              // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查    看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
            })
          }
        })
      }
    },
    getSignUrl() {
      let signLink = ''
      const ua = navigator.userAgent.toLowerCase()
      if (/iphone|ipad|ipod/.test(ua)) {
        signLink = localStorage.getItem('firstUrl')
        if (!signLink) signLink = location.href
      } else {
        signLink = location.href
      }
      return signLink
    }
  }
}
</script>

<style scoped>

</style>
