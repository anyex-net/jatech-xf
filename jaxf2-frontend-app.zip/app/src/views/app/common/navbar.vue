<template>
  <div>
    <van-tabbar fixed v-model="active" class="bottom-tab" route v-if="isLogin && isShow" @change="onChange">
      <router-link class="tab-item" to="/index">
        <van-tabbar-item>
          <img class="tabImg"
               :src="$route.path.indexOf('/index') == 0 ? require('@/assets/images/activeshouye.png') : require('@/assets/images/shouye.png')">
          <div :class="$route.path.indexOf('/index') == 0 ? 'tabFont-active': 'tabFont'">首页</div>
        </van-tabbar-item>
      </router-link>


      <van-tabbar-item v-for="(item,index1) in menuList" :key="item.id" @click="goItemPath(item, index1)"
                       class="tab-item">
        <img class="tabImg"
             :src="$route.path.indexOf(item.path) >= 0  ? require('@/assets/images/active'+ item.meta.icon + '.png') : require('@/assets/images/'+ item.meta.icon  + '.png')">
        <div :class="$route.path.indexOf(item.path) >= 0  ? 'tabFont-active': 'tabFont'">{{item.meta.title}}</div>
      </van-tabbar-item>

      <router-link class="tab-item" to="/me">
        <van-tabbar-item>
          <img class="tabImg"
               :src="$route.path.indexOf('/me') == 0  ? require('@/assets/images/activeme.png') : require('@/assets/images/me.png')">
          <div :class="$route.path.indexOf('/me') == 0 ? 'tabFont-active': 'tabFont'">我的</div>
        </van-tabbar-item>
      </router-link>
    </van-tabbar>
  </div>
</template>

<script>
  import store from "@/store";

  export default {
    data() {
      return {
        active: 0,
      };
    },
    created() {

    },
    mounted() {

    },
    computed: {
      menuList() {
        return store.getters.menus;
      },
    },
    methods: {
      goItemPath(item, index1) {
        if (item.path === '/app/warn/index') {
          this.$router.push({path: '/app/sys/unit/index', query: {index: index1}});
        } else {
          this.$router.push({path: item.path, query: {index: index1}});
        }
      },
      onChange(index) {
        // this.$emit("ok", index);
        this.active = index
      },
    },
    props: {
      isLogin: {
        required: true,
        type: Boolean
      },
      isShow: {
        required: false,
        type: Boolean
      },
      user: {
        required: false,
        type: Object
      }
    },
  };
</script>

<style>

  .tab-item {
    display: flex;
    flex: 1;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    height: 100%;
    width: 25%;
  }

  .tabImg {
    width: 24px;
    height: 24px;
  }

  .tabFont {
    font-size: 14px;
    color: #353535;
    padding-top: 7px;
  }

  .tabFont-active {
    font-size: 14px;
    color: #1477FF;
    padding-top: 7px;
  }
</style>
