<template>
  <div class="popover" :style="defaultStyle">
    <div :style="headerStyle">
      <slot name="header"></slot>
    </div>
    <slot name="content"></slot>
    <slot name="footer"></slot>
  </div>
</template>

<script>
  export default {
    name: "custom-card",
    computed: {
      defaultStyle() {
        let returnStyle = "";
        if (this.$attrs.shadow === '') {
          returnStyle += "box-shadow: 0 2px 12px 0 rgb(0 0 0 / 15%);"
        }
        if (this.$attrs.border === '') {
          returnStyle += "border:1px solid #ccc;"
        }
        return returnStyle
      },
      headerStyle() {
        if (this.$attrs.headerBorder === "") {
          return "border-bottom:3px solid #ececec;"
        }
      }
    }
  }
</script>

<style scoped>
  .popover {
    background: #fff;
    padding: 10px;
  }
</style>
