<template>
  <div>
    <video
      v-if="url != null && url !== ''"
      id="myvideo"
      style="width: 100%"
      class="video-js vjs-default-skin"
      controls
      preload="auto"
      :height="videoHeight"
    >
      <source :src="url" type="application/x-mpegURL">
    </video>
    <div v-else style="text-align: center;width: 100%">
      没有视频
    </div>
  </div>
</template>
<script>
import videojs from 'video.js'
import 'videojs-contrib-hls'

export default {
  name: 'Video1',
  components: {},
  directives: {},
  filters: {},
  props: {
    url: String,
    default: null,
    videoHeight: {
      type: String,
      default: '600px'
    }
  },
  data() {
    return {
      player: null
    }
  },
  beforeDestroy() {
    if (this.player) {
      this.player.dispose()
    }
  },
  mounted() {
    this.getVideo()
  },
  created() {
  },
  methods: {
    getVideo() {
      if (this.url !== null && this.url !== '') {
        this.$nextTick(() => {
          this.player = videojs(
            'myvideo',
            {
              bigPlayButton: false,
              textTrackDisplay: false,
              posterImage: true,
              errorDisplay: false,
              controlBar: true
            },
            function() {
              this.play()
            }
          )
        })
      }
    }
  }
}
</script>
