<template>
  <div>
    <div class="home-nav">
      <van-sticky>
        <van-nav-bar :border="false">
          <template #title>
            <span class="van-nav-bar__content">{{ title }}</span>
          </template>
          <template v-if="backSwitch" #left>
            <img src="@/assets/images/chehui.png" alt="" style="width: 20px" @click="goBack">
          </template>
          <template v-if="scanSwitch" #right>
            <img src="@/assets/images/saoyisao.png" alt="" style="width: 20px" @click="goScan">
          </template>
        </van-nav-bar>
      </van-sticky>
    </div>
  </div>
</template>

<script>
import TaskList from '@/views/app/inspection/index'

export default {
  name: 'Index',
  components: {
    TaskList
  },
  props: {
    title: {
      title: String,
      default: '标题'
    },
    backSwitch: {
      switch: Boolean,
      default: true
    },
    scanSwitch: {
      switch: Boolean,
      default: false
    },
    goBackMethod: {
      type: Function,
      default: null
    }
  },
  data() {
    return {
      scanData: {}
    }
  },
  computed: {},
  created() {
    if (window.AndroidWebView) {
      window.AndroidWebView.setBarCodeCB('receiveBarCode')
    }
    window.receiveBarCode = this.receiveBarCode
    window.receiveBarcode = this.receiveBarcode
  },
  methods: {
    goBack() {
      if (this.goBackMethod) {
        this.goBackMethod()
      } else {
        const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
        const path = routeArray[routeArray.length - 1]
        this.$router.push(path)
      }
    },
    /**
       * 扫一扫回调方法 @scan=""
       */
    goScan() {
      this.scanData = {}
      // 安卓方法
      if (window.AndroidWebView) {
        window.AndroidWebView.setBarCodeCB('receiveBarCode')
        window.AndroidWebView.startScan()
      }
      this.$emit('scan', this.scanData)
    },
    receiveBarCode(code, t) {
      // if (typeof (t) != 'undefined' && (t === 'rfid' || t === 'backbtn')) {
      //
      // } else {
      //   this.$toast.success('请用RFID扫码');
      //   return;
      // }
      if (code === null || code === '') {
        this.$toast.success('站点码不能为空')
        return
      }
      this.scanData.code = code
      this.scanData.type = t
    },
    receiveBarcode(code, t) {
      this.receiveBarCode(code, t)
    }
  }
}
</script>

