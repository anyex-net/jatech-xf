<template>
  <div class="home-nav">
    <div class="top-head" :style="'background:' + backgroundColor" />
    <van-nav-bar
      :border="false"
      class="navBar navBar-fixed transparent"
      fixed
      :style="'background:' + backgroundColor"
    >
      <template #title>
        <!--        自定义-->
        <slot v-if="customTitle" name="title" />
        <span v-else class="title">{{ title }}</span>
      </template>
      <template v-if="isBack === true || isClose === true || showUser === true || customLeft === true" #left>
        <!--        自定义-->
        <slot v-if="customLeft" name="left" />
        <span
          v-if="showUser === true"
          class="bdname"
          style="color: #ffffff;font-size: 15px"
        >{{ user.name }}</span>
        <img
          v-if="(isBack === true || isClose === true) && toIndex === false"
          ref="backRef"
          style="width: 16px"
          alt=""
          :src="backImg"
          :style="backImgStyle"
          width="20"
          @click="goBack"
        >
        <div v-if="isBack === true && toIndex === true" style="display: flex;align-items: center" @click="goBack">
          <img ref="backRef" style="width: 16px" :src="backImg" alt="">
          <span style="color: #ffffff;font-size: 14px;position:relative;left:3px">首页</span>
        </div>
      </template>
      <template #right>
        <div v-if="scan" style="margin-left: 1.2rem;">
          <scan width="21" @scanData="doScanData" />
        </div>
        <van-popover
          v-if="isMore && filterActions.length>0"
          v-model:show="showPopover"
          placement="bottom-end"
          :actions="filterActions"
          @select="onSelect"
        >
          <template #reference>
            <img src="@/assets/images/gengduo.png" @click="showPopover=!showPopover">
          </template>
        </van-popover>
        <van-icon
          v-if="isAdd1"
          color="white"
          name="plus"
          size="20"
          @click="goAdd()"
        />
        <van-icon
          v-if="isAdd && hasBtnPermission(type + ':device:add')"
          color="white"
          name="plus"
          size="20"
          @click="goDeviceAdd()"
        />
        <img
          v-if="isSearch === true"
          alt=""
          src="@/assets/images/solve-select.png"
          style="margin-left: 15px"
          width="20"
          @click="search()"
        >
        <!--        自定义-->
        <slot v-if="customRight" name="right" />
      </template>
    </van-nav-bar>
  </div>
</template>

<script>
import store from '@/store'
import { hasBtnPermission } from '@/utils/permission'
import Scan from '@/views/app/common/scan'

export default {
  name: 'CommonHead',
  components: {
    Scan
  },
  data() {
    return {
      user: store.getters.user,
      application: store.getters.user.application,
      menuOptions: [],
      noticeOptions: [],
      showPopover: false,
      isWxConfig: false,
      code: null
    }
  },
  created() {
  },
  beforeDestroy() {

  },
  props: {
    filterActions: {
      type: Array,
      default: () => []
    },
    edit: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: ''
      // required: true,
    },
    isBack: {
      type: Boolean,
      default: false
    },
    backImg: {
      type: String,
      default: require('@/assets/images/new/back.png')
    },
    backImgStyle: {
      type: String,
      default: ''
    },
    isClose: {
      type: Boolean,
      default: false
    },
    backgroundColor: {
      type: String,
      default: '#1989FA'
    },
    isMore: {
      type: Boolean,
      default: false
    },
    isDown: {
      type: Boolean,
      default: false
    },
    isSearch: {
      type: Boolean,
      default: false
    },
    scan: {
      type: Boolean,
      default: false
    },
    toIndex: {
      type: Boolean,
      default: false
    },
    showUser: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      required: false
    },
    isAdd1: {
      type: Boolean,
      default: false
    },
    isAdd: {
      type: Boolean,
      default: false
    },
    customLeft: {
      type: Boolean,
      default: false
    },
    customRight: {
      type: Boolean,
      default: false
    },
    customTitle: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    doScanData(value) {
      this.$emit('scanData', value)
    },
    onSelect(item) {
      this.$emit('onSelect', item)
    },
    hasBtnPermission(value) {
      if (value != null) {
        return hasBtnPermission(value)
      } else {
        return false
      }
    },
    goAdd() {
      this.$emit('goAdd')
    },
    goDeviceAdd() {
      this.$router.push({ path: '/app/warn/common/deviceAdd', query: { type: this.type }})
    },
    getSignUrl() {
      let signLink = ''
      const ua = navigator.userAgent.toLowerCase()
      if (/iphone|ipad|ipod/.test(ua)) {
        signLink = localStorage.getItem('firstUrl')
        if (!signLink) signLink = location.href
      } else {
        signLink = location.href
      }
      return signLink
    },
    goBack() {
      if (this.isBack === true) {
        if (this.toIndex === true) {
          if (this.$parent.unitId) {
            this.$router.push({ path: '/index', query: { unitId: this.$parent.unitId }})
          } else {
            this.$router.push({ path: '/index' })
          }
        } else {
          const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
          const path = routeArray[routeArray.length - 1]
          this.$router.push(path)
        }
      } else if (this.isClose === true) {
        this.$emit('close')
      }
    },
    search() {
      this.$emit('searchShow')
    },
    download() {
      this.$emit('download')
    }

  }
}

</script>

<style lang="less">

  .navBar .van-nav-bar__left:active {
    opacity: 1
  }

  .navBar .van-nav-bar__right:active {
    opacity: 1;

  }

  .van-popover__action {
    width: 138px !important;
  }
</style>
