<!--
* @Author:Daisy
* @Date: 2021/5/30
* @Desc: 选择器（field + picker）
-->
<template>
  <div class="my-select">
    <van-field style="background-color: transparent !important;" :required="required"
               :class="isSelectWhite===true ? 'text selectWhite' : 'text'"
               v-model="value"
               v-bind="$attrs" :input-align="inputAlign" :readonly="true"
               clickable :is-link="isLink"
               name="picker"
               :rules="rules"
               @focus="openPicker()"/>
    <selector
      v-if="!readonly"
      v-bind="$attrs"
      v-on="$listeners"
      :search-label="sLabel"
      :search-value="sValue"
      :isBottom="isBottom"
      :show-picker.sync="showPicker"
      @onShow="onShow"
    />
  </div>
</template>
<script>
  import selector from '@/components/selector/index';

  export default {
    name: 'mySelect',
    components: {
      selector
    },
    props: {
      //下拉选项保存值
      sValue: {
        type: String,
        default: 'id'
      },
      isBottom: {
        type: Boolean,
        default: false,
      },
      isSelectWhite: {
        type: Boolean,
        default: false,
      },
      isLink: {
        type: Boolean,
        default: true,
      },
      inputAlign: {
        type: String,
        default: 'id'
      },
      required: {
        type: Boolean,
        default: false,
      },
      rules: {
        type: Array,
        required: false
      },
      //下拉展示的字段，可以是单个属性，也可以是多个属性拼接
      // 单属性 label='name'|| 多属性 :label="['key', 'name']"
      sLabel: {
        type: [String, Array],
        default: 'value'
      },
      readonly: {
        type: Boolean,
        default: false,
      }
    },
    data() {
      return {
        showPicker: false,
        value: '', //field绑定值
        showOptions: [],
        searchText: ''
      };
    },
    created() {
    },
    methods: {
      /**
       * 获取展示字段
       * @param item
       * @returns {string|*}
       */
      getShowData(item) {
        if (item) {
          if (typeof this.sLabel == 'string') {
            return item[this.sLabel];
          } else {
            let str = '';
            this.sLabel.forEach(i => {
              str = str.concat(item[i] + ' ');
            });
            return str;
          }
        }
      },
      /**
       * 确认 更新field展示值为当前选项
       * @param value
       */
      onShow(value) {
        this.value = this.getShowData(value);
      },
      openPicker() {
        this.showPicker = true
      }
    }
  };
</script>

<style scoped>
  .close-popup {
    position: absolute;
    right: 0.28rem;
    top: 0.3rem;
  }

  .selectWhite >>> .van-field__value .van-field__body .van-field__control {
    color: white;
  }

  .my-select >>> .van-cell::after {
    border-bottom: none;
  }
</style>
