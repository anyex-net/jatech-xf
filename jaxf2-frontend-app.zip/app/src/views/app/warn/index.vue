<template>
  <div>
    <transition :name="transitionName">
      <router-view ref="we"/>
    </transition>
    <van-tabbar v-if="isShowWarn" class="bottom-tab" v-model="active"
                route
                @change="onChange">
      <van-tabbar-item v-for="(item,index1) in menuList" :key="item.id"
                       class="tab-item" @click="goItemPath(item,index1)">
        <img class="tabImg"
             :src="$route.path.indexOf(item.path) >= 0  ? require('@/assets/images/'+ item.meta.icon + '2.png') : require('@/assets/images/'+ item.meta.icon  + '1.png')">
        <div :class="$route.path.indexOf(item.path) >= 0  ? 'tabFont-active': 'tabFont'">{{item.meta.title}}</div>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>
<script>
  import store from "@/store";

  export default {
    components: {},
    data: () => {
      return {
        active: 0,
        index: 0,
        index1: 0,
        menus: store.getters.menus,
        menuList: [],
        transitionName: '',
        unitId: null,
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId
      }
    },
    computed: {
      isShowWarn() {
        if (this.$route.path === '/app/warn/index' || this.$route.query.index) {
          this.init()
          return true
        } else return false
      }
    },
    watch: {//使用watch 监听$router的变化
      $route(to, from) {
        //如果to索引大于from索引,判断为前进状态,反之则为后退状态
        if (to.meta.index > -1) {
          if (to.meta.index > from.meta.index) {
            //设置动画名称
            this.transitionName = 'slide-left';
          } else if (to.meta.index < from.meta.index) {
            this.transitionName = 'slide-right';
          } else {
            this.transitionName = "";
          }
        } else {
          this.transitionName = "";
        }
      }
    },
    methods: {
      goItemPath(item, index1) {
        this.$router.push({path: item.path, query: {index1: index1, index: this.index, unitId: this.unitId}})
      },
      init() {
        if (this.$route.query.index) {
          this.index = this.$route.query.index;
          this.menuList = this.menus[this.index].children
          if (this.$route.query.index1) {
            this.index1 = this.$route.query.index1;
          }
          this.$router.push({
            path: this.menuList[this.index1].path,
            query: {index: this.index, index1: this.index1, unitId: this.unitId}
          })
        }
      },
      onChange(index) {
        // this.$emit("ok", index);
        this.active = index
      },
    },
  };
</script>
<style scoped>
  .bottom-tab {
    width: 100%;
    height: 75px !important;
    position: fixed;
    left: 0px;
    bottom: 0px;
    display: flex;
    z-index: 999;
    border-top: 1px solid #e7e7e7;
    height: calc(75px + constant(safe-area-inset-bottom));
    height: calc(75px + env(safe-area-inset-bottom));
  }


  .slide-right-enter-active,
  .slide-right-leave-active,
  .slide-left-enter-active,
  .slide-left-leave-active {
    height: 100%;
    width: 100%;
    will-change: transform;
    transition: all 500ms;
    position: absolute;
    backface-visibility: hidden;
    perspective: 1000;
  }

  .slide-right-enter, .slide-right-enter-active {
    animation: bounce-left-in 500ms;
  }

  .slide-right-leave-active {
    animation: bounce-left-out 500ms;
  }

  .slide-left-enter, .slide-left-enter-active {
    animation: bounce-right-in 500ms;
  }

  .slide-left-leave-active {
    animation: bounce-right-out 500ms;
  }

  @keyframes bounce-right-in {
    0% {
      transform: translate3d(100%, 0, 0);
    }
    100% {
      transform: translate3d(0px, 0, 0);
    }
  }

  @keyframes bounce-right-out {
    0% {
      transform: translate3d(0, 0, 0);
    }
    100% {
      transform: translate3d(-100%, 0, 0);
    }
  }

  @keyframes bounce-left-in {
    0% {
      transform: translate3d(-100%, 0, 0);
    }
    100% {
      transform: translate3d(0px, 0, 0);
    }
  }

  @keyframes bounce-left-out {
    0% {
      transform: translate3d(0, 0, 0);
    }
    100% {
      transform: translate3d(100%, 0, 0);
    }
  }

  .tabFont {
    font-size: 14px;
    color: #666666;
    padding-top: 7px;
  }

  .tabFont-active {
    font-size: 14px;
    color: #1989FA;
    padding-top: 7px;
  }
</style>
