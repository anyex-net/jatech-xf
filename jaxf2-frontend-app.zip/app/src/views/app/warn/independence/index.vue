<template>
  <div>
    <!--<transition :name="transitionName">
      <router-view class="Router"/>
    </transition>-->
    <common-head :type="type" :background-color="'#1989FA'" :toIndex="true" :isBack="true" :title="title"/>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div style="background: #ffffff;" class="dls">
          <van-swipe width="90" class="my-swipe1" v-if="menuList.length>0" ref="swiper" :loop="false"
                     :show-indicators="false"
                     indicator-color="white">
            <!--<van-swipe-item @click="swipeOnClick($event, 0, null)" :data-index="0" :key="0">
              <div style="display: flex;align-items: center;justify-content: center;height: 60px">
                <van-badge v-if="warnCount !== 0" color="#FF585C" :content="warnCount" position="bottom-right">
                  <div :class="active === 0 ? 'swipe-item-background-active' : 'swipe-item-background'">
                    <van-image width="40"
                               :src="active === 0? require('@/assets/images/activedlsAll.png') : require('@/assets/images/dlsAll.png')"/>
                  </div>
                </van-badge>
                <div v-if="warnCount === 0"
                     :class="active === 0 ? 'swipe-item-background-active' : 'swipe-item-background'">
                  <van-image width="40"
                             :src="active === 0? require('@/assets/images/activedlsAll.png') : require('@/assets/images/dlsAll.png')"/>
                </div>
              </div>
              <span :class="active === 0 ? 'swipe-font-active' : 'swipe-font'">全部</span>
            </van-swipe-item>-->
            <van-swipe-item @click="swipeOnClick($event, index+1, item)" :data-index="index+1"
                            :key="index+1"
                            v-for="(item, index) in menuList">
              <div style="display: flex;align-items: center;justify-content: center;height: 60px">
                <van-badge v-if="item.warnCount !== 0" color="#FF585C" :content="item.warnCount"
                           position="bottom-right">
                  <div :class="active === index + 1 ? 'swipe-item-background-active' : 'swipe-item-background'">
                    <van-image width="40"
                               :src="active === index + 1 ? require('@/assets/images/active'+item.meta.icon+'1.png') : require('@/assets/images/'+item.meta.icon+'.png')"/>
                  </div>
                </van-badge>
                <div v-if="item.warnCount === 0"
                     :class="active === index + 1 ? 'swipe-item-background-active' : 'swipe-item-background'">
                  <van-image width="40"
                             :src="active === index + 1 ? require('@/assets/images/active'+item.meta.icon+'1.png') : require('@/assets/images/'+item.meta.icon+'.png')"/>
                </div>
              </div>
              <span :class="active === index + 1 ? 'swipe-font-active' : 'swipe-font'">{{item.meta.title}}</span>
            </van-swipe-item>
          </van-swipe>
          <van-grid :border="false" :column-num="3">
            <van-grid-item @click="goDeviceList(deviceStateObject.all)">
              <div class="tj-title">设备总数/个</div>
              <div class="tj-value">{{sumCount}}</div>
            </van-grid-item>
            <van-grid-item @click="goDeviceList(deviceStateObject.offline)">
              <div class="tj-title">失联总数/个</div>
              <div class="tj-value">{{offlineCount}}</div>
            </van-grid-item>
            <van-grid-item @click="goDeviceList(deviceStateObject.warn)">
              <div class="tj-title">报警总数/个</div>
              <div class="tj-value">{{warnCount}}</div>
            </van-grid-item>
          </van-grid>
        </div>
        <common-warn-card ref="commonWarnCardRef" :unitId="unitId" :type="type"/>
        <div v-if="this.$parent.isShowWarn" class="nav-bottom"/>
      </div>
    </div>
  </div>
</template>
<script>

  import constant from '@/api/common/constant.js'
  import {deviceCount, getDeviceState, getDeviceType} from "@/api/common/common.js";
  import store from "@/store";
  import commonHead from "@/views/app/common/head";
  import commonWarnCard from "@/views/app/warn/common/warnCard";
  import {warnCount} from "../../../../api/common/common";

  export default {
    components: {commonHead, commonWarnCard},
    data() {
      return {
        sumCount: 0,
        offlineCount: 0,
        deviceTypeOptions: constant.deviceTypeOptions,
        deviceStateObject: constant.deviceStateObject,
        type: '',
        warnCount: 0,
        showPopover: false,
        index: 0,
        index1: 0,
        menuList: [],
        transitionName: '',
        active: 1,
        title: '',
        unitId: null,
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      this.init();
    },
    mounted() {

    },
    computed: {},
    methods: {
      swipeOnClick(e, index, item) {
        this.active = index;
        this.type = item.name;
        this.getDeviceCount(this.type, unitId);
        this.$refs.commonWarnCardRef.refresh(this.type)
      },
      init() {
        if (this.$route.query.index) {
          this.title = '独立式'
          this.index = this.$route.query.index;
          if (this.$route.query.index1) {
            this.index1 = this.$route.query.index1;
            this.menuList = store.getters.menus[this.index].children[this.index1].children
            this.menuList.forEach(item => {
              if (item.warnPath) {
                warnCount(item.warnPath, {unitId: this.unitId}).then((response) => {
                  if (response.success) {
                    item.warnCount = response.data;
                  }
                }).catch((err) => {
                  this.$toast(err + "2");
                });
              }
            })
            if (this.menuList.length > 0) {
              this.type = this.menuList[0].name;
            }
            this.getDeviceCount(this.type, this.unitId);
          }
        } else if (this.$route.query.type) {
          let object = this.deviceTypeOptions.find(item => item.key === this.$route.query.type);
          if (object) this.title = object.value;
          this.type = this.$route.query.type;
          this.getDeviceCount(this.type, this.unitId);
        }
      },
      goDeviceList(state) {
        this.$router.push({
          path: "/app/warn/common/deviceList",
          query: {type: this.type, state: state, unitId: this.unitId}
        });
      },
      getDeviceType(type) {
        return getDeviceType(type);
      },
      getDeviceState(item) {
        return getDeviceState(item);
      },
      getDeviceCount(type, unitId) {
        this.sumCount = 0;
        this.warnCount = 0;
        this.offlineCount = 0;
        deviceCount({
          types: type,
          unitId: unitId
        }).then((response) => {
          if (response.success) {
            this.sumCount = response.data.sumCount;
            this.warnCount = response.data.warnCount;
            this.offlineCount = response.data.offlineCount;
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
    }
    ,
  }
  ;
</script>

<style scoped>

  .my-swipe1 >>> .van-swipe {
    height: 120px;
    width: 100%;
    background-color: #ffffff;
  }

  .my-swipe1 >>> .van-swipe__track {
    height: 90px;
    width: 100%;
    margin-top: 10px;
    background-color: #ffffff;
  }

  .my-swipe1 >>> .van-swipe-item {
    color: #9B9B9B;
    font-size: 12px;
    line-height: 25px;
    text-align: center;
    background-color: #ffffff;
    padding: 5px;
  }

  .dls >>> .van-badge--fixed {
    position: absolute;
    top: 0;
    right: 0;
    -webkit-transform: translate(50%, -50%);
    transform: translate(30%, 20%);
    -webkit-transform-origin: 100%;
    transform-origin: 100%;
  }

  .swipe-item-background {
    border-radius: 50%;
    width: 50px;
    height: 50px;
    background: #F4F7FE;
    display: flex;
    align-items: center;
    justify-content: center
  }

  .swipe-item-background-active {
    border-radius: 50%;
    width: 50px;
    height: 50px;
    background: #1989FA;
    display: flex;
    align-items: center;
    justify-content: center
  }

  .swipe-font-active {
    color: #1989FA;
  }

  .swipe-font {
    color: #9B9B9B;
  }

  .swipe-item-width {
    width: 25% !important;
  }

</style>
