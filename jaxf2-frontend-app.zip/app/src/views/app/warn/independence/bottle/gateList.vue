<template>
  <div>
    <common-head @onSelect="onSelect" :customTitle="true"
                 @searchShow="showList=!showList"
                 :isMore="true"
                 :isBack="true" :filterActions="filterActions">
      <template #title>
        <span style="color: #ffffff;font-weight: bolder">网关列表({{ deviceCount}})</span>
      </template>
    </common-head>

    <div v-show="showList === false" class="cards-navbar" style="background: #F4F4F4;">
      <div class="card search">
        <my-select
          ref="unitRef"
          label="联网单位："
          placeholder="点击选择联网单位"
          filterable
          s-label="name"
          s-value="id"
          :isBottom="true"
          input-align="right"
          :options="unitOptions"
          @confirm="(value)=>{this.listQuery.unitId = value}"
        />
        <van-field input-align="right" v-model="listQuery.name" label="网关名称：" placeholder="请输入名称"/>
        <van-field input-align="right" v-model="listQuery.deviceId" label="网关编号：" placeholder="请输入网关编号"/>
        <div class="btn-wrapper">
          <van-row type="flex" justify="space-between">
            <van-col span="11">
              <van-button class="orange button" @click="reset">
                重置
              </van-button>
            </van-col>
            <van-col span="11">
              <van-button class="blue button" @click="search">搜索
              </van-button>
            </van-col>
          </van-row>
        </div>
      </div>
    </div>

    <div v-show="showList === true" class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="white-circle">
          <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
            <van-list v-model="loading" :finished="finished"
                      :immediate-check="false"
                      finished-text="没有更多了"
                      v-on:load="onLoad"
                      ref="deviceList"
            >
              <div v-for="(item, index) in deviceList" :key="index">
                <van-swipe-cell>
                  <div class="item">
                    <div class="item-top">
                      <span>{{item.unitName}}</span>
                      <span>{{item.name}}</span>
                    </div>
                    <div class="item-bottom">
                      <span>{{item.deviceId}}</span>
                      <span v-if="!item.isConnect" style="color:#F6383A">未连接</span>
                      <span v-if="item.isConnect">已连接</span>
                    </div>
                  </div>
                  <template #right>
                    <van-button
                      style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                      square
                      text="轮询" @click="lunxun(item)"/>
                    <van-button v-if="hasBtnPermission('bottle:gate:edit')"
                                style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                                square
                                text="编辑" @click="editDevice(item)"/>
                    <van-button v-if="hasBtnPermission('bottle:gate:del')"
                                style="height: 100%" square text="删除" type="danger" @click="gateDelete1(item)"
                                class="delete-button"/>
                  </template>
                </van-swipe-cell>
                <div style="height: 4px;background: #F4F4F4;"/>
              </div>
            </van-list>
          </van-pull-refresh>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import constant from "@/api/common/constant.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from '@/views/app/common/my-select/index';
  import waterConstant from "@/api/water/constant.js"
  import {gateDelete, gatePage} from "@/api/bottle";
  import {hasBtnPermission} from "@/utils/permission";
  import store from "@/store";
  import {getSelectorList} from "../../../../../api/sys/unit";
  import {gateLunxun} from "../../../../../api/bottle";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        deviceList: [],
        loading: false,
        deviceCount: 0,
        filterActions: [{
          text: '搜索网关',
          icon: 'search',
          code: 'search'
        }],
        actions: [
          {
            text: '添加网关',
            icon: 'edit',
            permission: 'bottle:device:add',
            code: 'add',
            path: "/app/warn/bottle/gateForm"
          },
        ],
        showList: true,
        finished: false,
        isLoading: false,
        listQuery: {
          pageNo: 1,
          pageSize: 10,
          deviceId: null,
          name: null,
          imei: null,
          unitId: null,
          xksId: null,
        },
        typeOptions: constant.deviceTypeOptions,
        deviceStateOptions: constant.deviceStateOptions,
        constant: constant,
        unitOptions: [],
        waterConstant: waterConstant,
        unitId: null,
      };
    },
    created() {
      if (this.$route.query.type) {
        this.listQuery.types = this.$route.query.type;
      }
      if (this.$route.query.deviceType) {
        this.listQuery.deviceType = this.$route.query.deviceType;
      }
      if (this.$route.query.state) {
        this.listQuery.states = this.$route.query.state;
      }
      if (this.$route.query.xksId) {
        this.listQuery.xksId = this.$route.query.xksId;
      }
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
        this.listQuery.unitId = this.$route.query.unitId;
      }
      this.loading = true;
      this.gatePage();
      this.getUnitList()
      this.actions.forEach(item => {
        if (item => this.hasBtnPermission(item.permission))
          this.filterActions.push(item)
      })
    },
    mounted() {

    },
    computed: {},
    methods: {
      onSelect(item) {
        if (item.code === 'search') {
          this.showList = false
        } else {
          this.$router.push({path: item.path, query: {unitId: this.unitId}})
        }
      },
      gateDelete1(item) {
        this.$dialog
          .confirm({
            message: "是否删除",
          }).then(() => {
          store.commit('showLoading')
          gateDelete([item.id])
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.search();
              } else {
                this.$toast(response.message);
              }
            }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      lunxun(item) {
        store.commit('showLoading')
        gateLunxun({gateId: item.id}).then(response => {
          store.commit('hideLoading')
          if (response.success) {
            this.$toast("轮询成功");
          }
        }).catch((err) => {
          store.commit('hideLoading')
          this.$toast(err + "");
        });
      },
      editDevice(item) {
        this.$router.push("/app/warn/bottle/gateForm?id=" + item.id + "&unitId" + this.unitId)
      },
      hasBtnPermission(value) {
        if (value != null)
          return hasBtnPermission(value)
        else {
          return false;
        }
      },
      getUnitList() {
        getSelectorList({isOnline: 1}).then(response => {
          if (response.success) {
            this.unitOptions = response.data;
            if (this.listQuery.unitId) {
              this.temp.unitId = this.unitId
              if (this.unitOptions.find(item => item.id === this.listQuery.unitId))
                this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.listQuery.unitId).name
            }
          }
        })
      },
      reset() {
        this.listQuery = {
          pageNo: 1,
          pageSize: 10,
          deviceId: null,
          imei: null,
          name: null,
          unitId: this.unitId
        }
        this.$refs.unitRef.value = null;
      },
      search() {
        this.showList = true
        this.deviceList = [];
        this.listQuery.pageNo = 1;
        this.finished = false;
        this.loading = true;
        this.gatePage()
      },
      gatePage() {
        gatePage(this.listQuery).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.loading = false;
            this.deviceCount = response.data.totalRows
            this.deviceList = this.deviceList.concat(response.data.rows);
            // 如果加载完毕，显示没有更多了
            if (response.data.rows.length < this.listQuery.pageSize) {
              this.finished = true;
            }
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
      onLoad() {
        this.listQuery.pageNo++;
        this.gatePage();
      },
      onRefresh() {
        this.deviceList = [];
        this.listQuery.pageNo = 1;
        this.loading = true;
        this.isLoading = true;
        this.finished = false;
        this.gatePage();
      },
    },
  };
</script>
<style lang="less" scoped>

  .van-pull-refresh {
    position: relative;
    transition: all 0.5s;
  }

  .van-pull-refresh.active {
    margin-top: 20px;
    transition: all 0.5s;
  }

  .van-swipe {
    width: 100% !important;
    padding: 10px 10px 10px 10px;
    line-height: 30px;
    font-size: 14px;
  }

  .swipeActive {
    background-color: #1989fa;
    color: #fff;
    border-radius: 5px;
  }

  .cards-swipe {
    position: fixed;
    width: 100%;
    overflow-y: scroll;
    top: 174px;
    top: calc(174px + constant(safe-area-inset-top));
    top: calc(174px + env(safe-area-inset-top));
    bottom: 0px;
    bottom: calc(0px + constant(safe-area-inset-bottom));
    bottom: calc(0px + env(safe-area-inset-bottom));
  }
</style>
