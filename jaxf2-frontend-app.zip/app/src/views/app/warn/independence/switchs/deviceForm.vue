<template>
  <div>
    <common-head :isBack="true" :customTitle="true" :customRight="true" background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px">
      <template #title>
        <span style="color: black;font-weight: bolder">{{isEdit?'编辑设备' : '添加设备'}}</span>
      </template>
      <template #right>
        <van-button @click="save" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card">
          <div class="form switch-form">
            <van-form ref="formRef">
              <my-select
                ref="unitRef"
                :required="true"
                label="联网单位："
                placeholder="点击选择联网单位"
                :rules="rules.unitId"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :isBottom="true"
                :options="unitOptions"
                @confirm="changeUnit"
              />
              <my-select
                ref="gateRef"
                :rules="rules.gateId"
                :required="true"
                label="设备网关："
                :isBottom="true"
                placeholder="选择设备网关"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="gateOptions"
                @confirm="(value)=>{this.temp.gateId = value}"
              />
              <van-field v-model="temp.name"
                         :rules="rules.name"
                         required
                         input-align="right"
                         label="设备名称："
                         placeholder="请输入设备名称"
              />
              <van-field v-model="temp.address"
                         :rules="rules.address"
                         required
                         input-align="right"
                         type="number"
                         label="设备地址："
                         placeholder="请输入设备地址码"
              />
              <van-field v-model="temp.position"
                         :rules="rules.position"
                         required
                         input-align="right"
                         label="设备位置："
                         placeholder="请输入设备位置"
              />
              <my-select
                ref="userRef"
                label="安装人员："
                placeholder="点击选择安装人员"
                filterable
                s-label="name"
                s-value="id"
                :isBottom="true"
                input-align="right"
                :options="userOptions"
                @confirm="(value)=>{this.temp.installUserId = value}"
              />
              <common-date-select label="安装时间：" placeholder="请选择安装时间"
                                  @update="(value)=>{this.temp.installDate = value}"
                                  :value="temp.installDate"/>
            </van-form>

          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import constant from "@/api/elec/constant";
  import BaseMapSearch from "@/components/Map/baseMapSearch";
  import {sysUserSelector} from "@/api/system/userManage.js";
  import commonConstant from "@/api/common/constant.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import store from "@/store";
  import CommonUploadImage from "@/components/Upload/CommonUploadImage";
  import CommonDateSelect from "@/components/selector/CommonDateSelect";
  import {deviceAdd, deviceDetail, deviceUpdate, gateList} from "@/api/switchs";
  import {getSelectorList} from "../../../../../api/sys/unit";

  export default {
    components: {BaseMapSearch, commonHead, mySelect, CommonUploadImage, CommonDateSelect},
    data() {
      return {
        type: commonConstant.deviceTypeObject.switchs,
        showPicker1: false,
        factory: false,
        install: false,
        platform: false,
        isEdit: false,
        showSelectPlatform: false,
        showSelectUnit: false,
        show: false,
        loading: false,
        platformOptions: [],
        providerOptions: [],
        unitId: null,
        modelOptions: [],
        unitOptions: [],
        DeviceName: "",
        constant: constant,
        userOptions: [],
        gateOptions: [],
        deviceTypeObject: commonConstant.deviceTypeObject,
        temp: {
          gateId: null,
          name: null,
          installDate: null,
          installUserId: null,
          address: null,
          id: null,
          unitId: null,
          unitName: null,
          position: null,
        },
        rules: {
          gateId: [{required: true, message: '', trigger: "onBlur/onChange"}],
          unitId: [{required: true, message: '', trigger: "onBlur/onChange"}],
          name: [{required: true, message: '', trigger: "onBlur/onChange"}],
          address: [{required: true, message: '', trigger: "onBlur/onChange"}],
          position: [{required: true, message: '', trigger: "onBlur/onChange"}],
        },
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      if (this.$route.query.id) {
        this.id = this.$route.query.id
        this.init(this.id);
      } else {
        this.temp.unitId = this.unitId
        this.getGateList(this.unitId);
        this.getUserList(this.unitId);
      }
      getSelectorList({isOnline: 1}).then((response) => {
        this.unitOptions = response.data;
        this.temp.unitId = this.unitId
        if (this.unitOptions.find(item => item.id === this.temp.unitId)) {
          this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.temp.unitId).name
        }
      });
    },
    methods: {
      getUserList(unitId) {
        sysUserSelector({unitId: unitId}).then((response) => {
          this.userOptions = response.data;
        });
      },
      init(id) {
        this.isEdit = true;
        deviceDetail(id).then(response => {
          if (response.success) {
            this.temp = response.data
            this.$refs.gateRef.value = response.data.gateName;
            this.gateOptions = [];
            this.getGateList(this.temp.unitId);
            this.$refs.unitRef.value = response.data.unitName
            this.getUserList(this.temp.unitId);
            this.$refs.userRef.value = this.temp.installUserName
          }
        })
      },
      changeUnit(value) {
        this.temp.unitId = value
        this.temp.gateId = null;
        this.$refs.gateRef.value = null;
        this.gateOptions = [];
        this.getGateList(value);
        this.$refs.userRef.value = null;
        this.temp.installUserId = null;
        this.getUserList(this.temp.unitId)
      },
      getGateList(value) {
        gateList({unitId: value}).then(response => {
          if (response.success) {
            this.gateOptions = response.data
          }
        })
      },
      toScan(val) {
        this.temp.imei = val;
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      save() {
        this.$refs.formRef.validate().then(() => {
          this.loading = true;
          store.commit('showLoading')
          if (!this.isEdit) {
            deviceAdd(this.temp)
              .then((response) => {
                if (response.success) {
                  store.commit('hideLoading')
                  this.loading = false;
                  this.$toast("保存成功");
                  setTimeout(this.goBack(), 500);
                } else {
                  this.loading = false;
                  this.$toast(response.message);
                }
              })
              .catch((err) => {
                store.commit('hideLoading')
                this.loading = false;
                this.$toast(err + "");
              });
          } else {
            deviceUpdate(this.temp)
              .then((response) => {
                if (response.success) {
                  store.commit('hideLoading')
                  this.loading = false;
                  this.$toast("保存成功");
                  setTimeout(this.goBack(), 500);
                } else {
                  this.loading = false;
                  this.$toast(response.message);
                }
              })
              .catch((err) => {
                store.commit('hideLoading')
                this.loading = false;
                this.$toast(err + "");
              });
          }
        })
      }

    },
  };
</script>

<style scoped>

  .switch-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

</style>
