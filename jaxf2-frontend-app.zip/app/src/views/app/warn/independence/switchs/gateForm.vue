<template>
  <div>
    <common-head :isBack="true" :customTitle="true" :customRight="true" background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px">
      <template #title>
        <span style="color: black;font-weight: bolder">{{isEdit?'编辑网关' : '添加网关'}}</span>
      </template>
      <template #right>
        <van-button @click="save" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card">
          <div class="form bottle-form">
            <van-form ref="formRef">
              <my-select
                ref="unitRef"
                :required="true"
                :isBottom="true"
                label="联网单位："
                :rules="rules.unitId"
                placeholder="点击选择联网单位"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="unitOptions"
                @confirm="(value)=>{this.temp.unitId = value}"
              />
              <my-select
                ref="platformRef"
                :rules="rules.platform"
                :isBottom="true"
                v-if="!isEdit"
                label="接入平台："
                :required="true"
                placeholder="点击选择接入平台"
                filterable
                s-label="name"
                s-value="code"
                input-align="right"
                :options="platformOptions"
                @confirm="(value)=>{this.temp.platform = value;this.modelOptions=[]; this.$refs.modelRef.value= null;this.getModel(this.temp.platform, this.temp.provider, this.type)}"
              />
              <my-select
                ref="providerRef"
                label="厂　　家："
                v-if="!isEdit"
                :rules="rules.provider"
                :isBottom="true"
                :required="true"
                placeholder="点击选择厂家"
                filterable
                s-label="name"
                s-value="code"
                input-align="right"
                :options="providerOptions"
                @confirm="(value)=>{this.temp.provider = value;this.modelOptions=[];this.$refs.modelRef.value= null; this.getModel(this.temp.platform, this.temp.provider, this.type)}"
              />
              <my-select
                ref="modelRef"
                v-if="!isEdit"
                label="型　　号："
                :rules="rules.model"
                :isBottom="true"
                placeholder="点击选择型号"
                :required="true"
                filterable
                s-label="value"
                s-value="value"
                input-align="right"
                :options="modelOptions"
                @confirm="(value)=>{this.temp.model = value}"
              />
              <van-field
                v-model="temp.deviceId"
                :rules="rules.deviceId"
                required
                label="网关编号："
                input-align="right"
                placeholder="请输入网关编号"
              />
              <van-field
                v-model="temp.name"
                :rules="rules.name"
                required
                label="网关名称："
                input-align="right"
                placeholder="请输入网关名称"
              />
              <van-field
                v-model="temp.address"
                required
                :isHide="true"
                :isBottom="true"
                input-align="right"
                label="安装地址"
                placeholder="请输入安装地址"
              />
              <base-map-search
                :isHide="true"
                ref="mapSearch"
                :isEdit="isEdit"
                :value="temp.address"
                :rules="rules.address"
                :longitude="temp.lng"
                :latitude="temp.lat"
                @updateLocation="updateLocation"
              />
              <van-field
                v-model="temp.lng"
                input-align="right"
                required
                label="经　　度："
                placeholder="请输入经度"
              />
              <van-field
                v-model="temp.lat"
                input-align="right"
                required
                label="纬　　度："
                placeholder="请输入纬度"
              />
              <common-upload-image ref="installPicRef" label="安装图片："/>
            </van-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import constant from "@/api/elec/constant";
  import BaseMapSearch from "@/components/Map/baseMapSearch";
  import {getPlatform, getProvider} from "@/api/common/index";
  import {sysUserSelector} from "@/api/system/userManage.js";
  import commonConstant from "@/api/common/constant.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import {getModel} from "@/api/common";
  import store from "@/store";
  import CommonUploadImage from "@/components/Upload/CommonUploadImage";
  import CommonDateSelect from "@/components/selector/CommonDateSelect";
  import {gateAdd, gateDetail, gateUpdate} from "@/api/switchs/index";
  import {getSelectorList} from "../../../../../api/sys/unit";

  export default {
    components: {BaseMapSearch, commonHead, mySelect, CommonUploadImage, CommonDateSelect},
    data() {
      return {
        type: commonConstant.deviceTypeObject.switchs,
        showPicker1: false,
        factory: false,
        install: false,
        platform: false,
        showSelectPlatform: false,
        showSelectUnit: false,
        show: false,
        loading: false,
        isEdit: false,
        platformOptions: [],
        providerOptions: [],
        modelOptions: [],
        unitOptions: [],
        DeviceName: "",
        constant: constant,
        userOptions: [],
        deviceTypeObject: commonConstant.deviceTypeObject,
        temp: {
          deviceId: null,
          installPic: null,
          platform: null,
          platformName: null,
          provider: null,
          providerName: null,
          name: null,
          address: null,
          id: null,
          unitId: null,
          unitName: null,
          model: null,
          lng: null,
          lat: null,
        },
        rules: {
          deviceId: [{required: true, message: '', trigger: "onBlur/onChange"}],
          position: [{required: true, message: '', trigger: "onBlur/onChange"}],
          platform: [{required: true, message: '', trigger: "onBlur/onChange"}],
          provider: [{required: true, message: '', trigger: "onBlur/onChange"}],
          model: [{required: true, message: '', trigger: "onBlur/onChange"}],
          name: [{required: true, message: '', trigger: "onBlur/onChange"}]
        },
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      if (this.$route.query.id) {
        this.id = this.$route.query.id
        this.init(this.id);
      }
      getPlatform().then((response) => {
        this.platformOptions = response.data;
      });
      getProvider({deviceType: this.type}).then((response) => {
        this.providerOptions = response.data;
      });
      sysUserSelector().then((response) => {
        this.userOptions = response.data;
      });
      getSelectorList({isOnline: 1}).then((response) => {
        this.unitOptions = response.data;
        this.temp.unitId = this.unitId
        if (this.unitOptions.find(item => item.id === this.temp.unitId)) {
          this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.temp.unitId).name
        }
      });
    },
    methods: {
      init(id) {
        this.isEdit = true;
        gateDetail(id).then(response => {
          if (response.success) {
            this.temp = response.data
            if (this.temp.address && this.temp.lng && this.temp.lat) {
              this.$refs.mapSearch.updateAddress(this.temp.address, this.temp.lng, this.temp.lat)
            }
            this.$refs.installPicRef.setFileList(this.temp.installPic)
            this.$refs.unitRef.value = response.data.unitName
          }
        })
      },
      toScan(val) {
        this.temp.imei = val;
      },
      getModel(platform, provider, type) {
        getModel({platform: platform, provider: provider, type: type}).then(response => {
          if (response.success) {
            response.data.forEach(item => {
              this.modelOptions.push({value: item})
            })
          }
        })
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      updateLocation(lng, lat, address) {
        this.temp.lng = lng;
        this.temp.lat = lat;
        this.temp.address = address;
      },
      formatDate(date) {
        return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
      },
      onConfirm(date) {
        this.show = false;
        this.temp.installDate = this.formatDate(date);
      },
      save() {
        this.$refs.formRef.validate().then(() => {
          this.loading = true;
          store.commit('showLoading')
          this.temp.installPic = '';
          this.$refs.installPicRef.fileList.forEach(item => {
            this.temp.installPic = this.temp.installPic + item.fileId + ","
          })
          if (!this.isEdit) {
            gateAdd(this.temp)
              .then((response) => {
                if (response.success) {
                  store.commit('hideLoading')
                  this.loading = false;
                  this.$toast("保存成功");
                  setTimeout(this.goBack(), 500);
                } else {
                  this.loading = false;
                  this.$toast(response.message);
                }
              })
              .catch((err) => {
                store.commit('hideLoading')
                this.loading = false;
                this.$toast(err + "");
              });
          } else {
            gateUpdate(this.temp)
              .then((response) => {
                if (response.success) {
                  store.commit('hideLoading')
                  this.loading = false;
                  this.$toast("保存成功");
                  setTimeout(this.goBack(), 500);
                } else {
                  this.loading = false;
                  this.$toast(response.message);
                }
              })
              .catch((err) => {
                store.commit('hideLoading')
                this.loading = false;
                this.$toast(err + "");
              });
          }
        }).catch(err => {

        })
      },
    },
  };
</script>

<style scoped>

  .bottle-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

</style>
