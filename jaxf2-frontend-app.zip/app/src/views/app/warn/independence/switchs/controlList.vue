<template>
  <div>
    <common-head :customTitle="true" :isBack="true">
      <template #title>
        <span style="color: #ffffff;font-weight: bolder">控制列表({{ deviceCount}})</span>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="white-circle">
          <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
            <van-list v-model="loading" :finished="finished"
                      :immediate-check="false"
                      finished-text="没有更多了"
                      v-on:load="onLoad"
                      ref="controlList"
            >
              <div v-for="(item, index) in controlList" :key="index">
                <van-swipe-cell>
                  <div class="item">
                    <div class="item-top">
                      <span>{{item.name}}</span>
                      <span>{{item.value}}</span>
                    </div>
                  </div>
                  <template #right>
                    <van-button v-if="hasBtnPermission('switch:deviceControl:control')"
                                style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                                square
                                text="执行" @click="control(item)"/>
                  </template>
                </van-swipe-cell>
                <div style="height: 4px;background: #F4F4F4;"/>
              </div>
            </van-list>
          </van-pull-refresh>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import commonHead from "@/views/app/common/head";
  import mySelect from '@/views/app/common/my-select/index';
  import {hasBtnPermission} from "@/utils/permission";
  import {controlSwitchDeviceControl, switchDeviceControlPage} from "../../../../../api/switchs/deviceControl";
  import store from "../../../../../store";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        controlList: [],
        loading: false,
        deviceCount: 0,
        showList: true,
        finished: false,
        isLoading: false,
        listQuery: {
          pageNo: 1,
          pageSize: 10,
          deviceId: null,
        },
      };
    },
    created() {
      if (this.$route.query.id) {
        this.listQuery.deviceId = this.$route.query.id;
      }
      this.loading = true;
      this.controlPage()
    },
    mounted() {

    },
    computed: {},
    methods: {
      control(item) {
        this.$dialog
          .confirm({
            message: "是否执行" + item.name,
          }).then(() => {
          store.commit('showLoading')
          controlSwitchDeviceControl({id: item.id})
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.controlList = [];
                this.controlPage();
              } else {
                this.$toast(response.message);
              }
            }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "3");
          });
        }).catch(() => {
          // on cancel
        });
      },
      hasBtnPermission(value) {
        if (value != null)
          return hasBtnPermission(value)
        else {
          return false;
        }
      },
      controlPage() {
        switchDeviceControlPage(this.listQuery).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.loading = false;
            this.deviceCount = response.data.totalRows
            this.controlList = this.controlList.concat(response.data.rows);
            // 如果加载完毕，显示没有更多了
            if (response.data.rows.length < this.listQuery.pageSize) {
              this.finished = true;
            }
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
      onLoad() {
        this.listQuery.pageNo++;
        this.controlPage();
      },
      onRefresh() {
        this.controlList = [];
        this.listQuery.pageNo = 1;
        this.loading = true;
        this.isLoading = true;
        this.finished = false;
        this.controlPage();
      },
    },
  };
</script>
<style lang="less" scoped>

  .van-pull-refresh {
    position: relative;
    transition: all 0.5s;
  }

  .van-pull-refresh.active {
    margin-top: 20px;
    transition: all 0.5s;
  }

  .van-swipe {
    width: 100% !important;
    padding: 10px 10px 10px 10px;
    line-height: 30px;
    font-size: 14px;
  }

  .swipeActive {
    background-color: #1989fa;
    color: #fff;
    border-radius: 5px;
  }

  .cards-swipe {
    position: fixed;
    width: 100%;
    overflow-y: scroll;
    top: 174px;
    top: calc(174px + constant(safe-area-inset-top));
    top: calc(174px + env(safe-area-inset-top));
    bottom: 0px;
    bottom: calc(0px + constant(safe-area-inset-bottom));
    bottom: calc(0px + env(safe-area-inset-bottom));
  }
</style>
