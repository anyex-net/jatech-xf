<template>
  <div>
    <common-head :customTitle="true" :isBack="true">
      <template #title>
        <span style="color: #ffffff;font-weight: bolder">监控视频</span>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <v-video style="width: 100%;height:100%" :id="id" :appVideoUrl="appVideoUrl"/>
      </div>
    </div>
  </div>
</template>
<script>

  import commonHead from "@/views/app/common/head";
  import vVideo from '@/components/Video/index'

  export default {
    name: "video1",
    components: {commonHead, vVideo},
    directives: {},
    filters: {},
    data() {
      return {
        id: this.$route.query.id,
        appVideoUrl: this.$route.query.appVideoUrl
      }
    },
    beforeDestroy() {

    },
    mounted() {

    },
    created() {
    },
    methods: {}
  }
</script>
