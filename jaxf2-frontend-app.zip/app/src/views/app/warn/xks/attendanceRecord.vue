<template>
  <div>
    <common-head :customTitle="true" :isBack="true">
      <template #title>
        <span style="color: #ffffff;font-weight: bolder">排班签到记录</span>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="white-circle">
          <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
            <van-list v-model="loading" :finished="finished"
                      :immediate-check="false"
                      finished-text="没有更多了"
                      v-on:load="onLoad"
                      ref="list"
            >
              <div v-for="(item, index) in list" :key="index">
                <van-row style="height:90px">
                  <van-col span="6" align="center">
                    <van-image round width="40" :src="require('@/assets/images/new/userImage.png')"/>
                    <br><span style="color: #393943;font-size: 14px;font-weight: bold">{{item.userName}}</span>
                  </van-col>
                  <van-col span="9" align="left" :offset="2"
                           style="font-size: 14px;height:100%;color: #5A5A5A;display: flex;flex-direction: column;justify-content: center;">
                    <van-row style="height: 20px" v-if="item.scheduleStartTime != null">
                      上班　{{format(item.scheduleStartTime)}}
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceStartTime != null">
                      {{format(item.attendanceStartTime)}}<span
                      style="margin-left: 5px">已签到</span>
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceStartTime == null">未签到</van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #3ABB5D;color: #3ABB5D"
                      v-if="item.attendanceStartTime != null && item.scheduleStartTime != null && item.attendanceStartTime <= item.scheduleStartTime">
                      正常
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #F1C345;color: #F1C345"
                      v-if="item.attendanceStartTime != null && item.scheduleStartTime != null && item.attendanceStartTime > item.scheduleStartTime">
                      迟到
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content: center;color: #FF5C50;border-radius: 9px;box-sizing: border-box;border: 1px solid #FF5C50;"
                      v-if="item.attendanceStartTime == null && item.scheduleStartTime != null && getNowTime() > item.scheduleStartTime">
                      缺卡
                    </van-row>
                  </van-col>
                  <van-col span="7" align="left" class="col"
                           style="font-size: 14px;height:100%;display: flex;flex-direction: column;justify-content: center;">
                    <van-row style="height: 20px" v-if="item.scheduleEndTime != null">
                      下班　{{format(item.scheduleEndTime)}}
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceEndTime != null">
                      {{format(item.attendanceEndTime)}}<span style="margin-left: 5px"> 已签退</span>
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceEndTime == null">未签退
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #3ABB5D;color: #3ABB5D"
                      v-if="item.attendanceEndTime != null && item.scheduleEndTime != null && item.attendanceEndTime >= item.scheduleEndTime">
                      正常
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #F1C345;color: #F1C345"
                      v-if="item.attendanceEndTime != null && item.scheduleEndTime != null && item.attendanceEndTime < item.scheduleEndTime">
                      早退
                    </van-row>
                  </van-col>
                </van-row>
                <div style="height: 4px;background: #F4F4F4;"/>
              </div>
            </van-list>
          </van-pull-refresh>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import commonHead from "@/views/app/common/head";
  import mySelect from '@/views/app/common/my-select/index';
  import {hasBtnPermission} from "@/utils/permission";
  import {getAttendanceAndSchedulePage} from "../../../../api/xks";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        list: [],
        loading: false,
        deviceCount: 0,
        showList: true,
        finished: false,
        isLoading: false,
        listQuery: {
          pageNo: 1,
          pageSize: 10,
          xksId: null,
        },
      };
    },
    created() {
      if (this.$route.query.xksId) {
        this.listQuery.xksId = this.$route.query.xksId;
      }
      this.loading = true;
      this.getAttendanceAndSchedulePage()
    },
    mounted() {

    },
    computed: {},
    methods: {
      format(date) {
        return date.substring(11, 16)
      },
      hasBtnPermission(value) {
        if (value != null)
          return hasBtnPermission(value)
        else {
          return false;
        }
      },
      getAttendanceAndSchedulePage() {
        this.finished = false;
        this.loading = true;
        getAttendanceAndSchedulePage(this.listQuery).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.loading = false;
            this.deviceCount = response.data.totalRows
            this.list = this.list.concat(response.data.rows);
            // 如果加载完毕，显示没有更多了
            if (response.data.rows.length < this.listQuery.pageSize) {
              this.finished = true;
            }
          }
        }).catch((err) => {
          this.$toast(err + "");
          this.loading = false;
        });
      },
      onLoad() {
        this.listQuery.pageNo++;
        this.controlPage();
      },
      onRefresh() {
        this.list = [];
        this.listQuery.pageNo = 1;
        this.loading = true;
        this.isLoading = true;
        this.finished = false;
        this.controlPage();
      },
    },
  };
</script>
<style lang="less" scoped>

  .van-pull-refresh {
    position: relative;
    transition: all 0.5s;
  }

  .van-pull-refresh.active {
    margin-top: 20px;
    transition: all 0.5s;
  }

  .van-swipe {
    width: 100% !important;
    padding: 10px 10px 10px 10px;
    line-height: 30px;
    font-size: 14px;
  }

  .swipeActive {
    background-color: #1989fa;
    color: #fff;
    border-radius: 5px;
  }

  .cards-swipe {
    position: fixed;
    width: 100%;
    overflow-y: scroll;
    top: 174px;
    top: calc(174px + constant(safe-area-inset-top));
    top: calc(174px + env(safe-area-inset-top));
    bottom: 0px;
    bottom: calc(0px + constant(safe-area-inset-bottom));
    bottom: calc(0px + env(safe-area-inset-bottom));
  }
</style>
