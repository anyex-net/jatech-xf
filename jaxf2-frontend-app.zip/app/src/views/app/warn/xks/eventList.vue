<template>
  <div>
    <common-head @searchShow="showList=!showList" :isMore="true" :filterActions="filterActions" :customTitle="true"
                 :isBack="true" @onSelect="onSelect">
      <template #title>
        <span style="color: #ffffff;font-weight: bolder">事件列表({{ eventCount}})</span>
      </template>
    </common-head>

    <div v-show="showList === false" class="cards-navbar" style="background: #F4F4F4;">
      <div class="card search">
        <my-select
          ref="handleStateRef"
          label="事件状态"
          placeholder="点击选择事件状态"
          filterable
          s-label="value"
          s-value="key"
          input-align="right"
          :isBottom="true"
          :options="constant.handleStateOptions"
          @confirm="(value)=>{this.eventListQuery.state = value}"
        />
        <my-select
          ref="eventTypeRef"
          label="事件类型"
          placeholder="点击选择事件类型"
          filterable
          s-label="value"
          s-value="key"
          input-align="right"
          :isBottom="true"
          :options="constant.xksDeviceStateOptions"
          @confirm="(value)=>{this.listQuery.deviceStates = value}"
        />
        <van-field input-align="right" v-model="listQuery.deviceCode" label="设备编码：" placeholder="请输入设备编码"/>
        <van-field readonly clickable input-align="right" label="开始时间"
                   :value="this.listQuery.eventTimeStart"
                   placeholder="请选择开始时间" @click="showEventTimeStart = true"/>
        <van-popup v-model="showEventTimeStart" position="bottom">
          <van-datetime-picker type="datetime" v-model="eventTimeCurrentStart"
                               @cancel="() => {this.showEventTimeStart = false;}"
                               @confirm="eventStartConfirm"/>
        </van-popup>
        <van-field readonly clickable input-align="right" label="结束时间"
                   :value="this.listQuery.eventTimeEnd"
                   placeholder="请选择结束时间" @click="showEventTimeEnd = true"/>
        <van-popup v-model="showEventTimeEnd" position="bottom">
          <van-datetime-picker type="datetime" v-model="eventTimeCurrentEnd"
                               @cancel="() => {this.showEventTimeEnd = false;}"
                               @confirm="eventEndConfirm"/>
        </van-popup>
        <div class="btn-wrapper">
          <van-row type="flex" justify="space-between">
            <van-col span="11">
              <van-button class="orange button" @click="resetEventQuery">
                重置
              </van-button>
            </van-col>
            <van-col span="11">
              <van-button class="blue button" @click="onRefresh">搜索
              </van-button>
            </van-col>
          </van-row>
        </div>
      </div>
    </div>

    <div v-show="showList === true" class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="white-circle">
          <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
            <van-list v-model="loading" :finished="finished"
                      :immediate-check="false"
                      finished-text="没有更多了"
                      v-on:load="onLoad"
                      ref="eventList"
            >
              <div v-for="(item, index) in eventList" :key="index">
                <van-swipe-cell>
                  <div class="item">
                    <div class="item-top">
                      <span
                        class="name">{{item.deviceCode}}({{item.deviceName == null ? '没有编码表' : item.deviceName}})</span>
                      <span>{{item.address}}</span>
                    </div>
                    <div class="item-bottom">
                      <span class="name">{{item.eventDesc}}</span>
                      <span>{{item.eventTime}}</span>
                    </div>
                    <div class="item-bottom">
                      <span class="name">{{getState(item)}}</span>
                      <span class="status">{{item.processTime}}</span>
                    </div>
                  </div>
                  <template #right>
                    <van-button @click="handleEventDetail(item)"
                                style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                                square
                                text="进程"/>
                    <van-button v-if="isHandleEvent(item) === true"
                                @click="goEventHandle(item)"
                                style="height: 100%" square text="处理" type="danger"
                                class="delete-button"/>
                  </template>
                </van-swipe-cell>
                <div style="height: 4px;background: #F4F4F4;"/>
              </div>
            </van-list>
          </van-pull-refresh>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import commonHead from "@/views/app/common/head";
  import mySelect from '@/views/app/common/my-select/index';
  import {hasBtnPermission} from "@/utils/permission";
  import {getEventPage} from "../../../../api/xks";
  import constant from "../../../../api/common/constant";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        eventList: [],
        loading: false,
        deviceCount: 0,
        finished: false,
        isLoading: false,
        listQuery: {
          deviceCode: null,
          pageNo: 1,
          pageSize: 10,
          deviceStates: null,
          state: null,
          eventTimeStart: null,
          eventTimeEnd: null,
          xksId: null,
          transmissionId: null
        },
        eventCount: 0,
        showList: true,
        filterActions: [{
          text: '查询',
          icon: 'search',
          code: 'search'
        }],
        constant: constant,
        showEventTimeStart: false,
        showEventTimeEnd: false,
        eventTimeCurrentStart: new Date(),
        eventTimeCurrentEnd: new Date(),
      };
    },
    created() {
      if (this.$route.query.xksId) {
        this.listQuery.xksId = this.$route.query.xksId;
      }
      if (this.$route.query.transmissionId) {
        this.listQuery.transmissionId = this.$route.query.transmissionId;
      }
      this.loading = true;
      this.getEventList()
    },
    mounted() {

    },
    computed: {},
    methods: {
      resetEventQuery() {
        this.listQuery = {
          deviceCode: null,
          pageNo: 1,
          pageSize: 10,
          deviceStates: null,
          state: null,
          eventTimeStart: null,
          eventTimeEnd: null,
          xksId: this.$route.query.xksId,
          transmissionId: this.$route.query.transmissionId
        }
        this.$refs.handleStateRef.value = null;
        this.$refs.eventTypeRef.value = null;
        this.eventTimeCurrentStart = new Date();
        this.eventTimeCurrentEnd = new Date();
      },
      eventStartConfirm(date) {
        let year = date.getFullYear();
        let month = date.getMonth() + 1
        month = month < 10 ? "0" + month : month;
        let day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        let hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        let second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
        let currentTime = year + "-" + month + "-" + day + "  " + hour + ":" + minute + ":" + second;
        this.listQuery.eventTimeStart = currentTime;
        this.eventTimeCurrentStart = new Date(currentTime);
        this.showEventTimeStart = false;
      },
      eventEndConfirm(date) {
        let year = date.getFullYear();
        let month = date.getMonth() + 1
        month = month < 10 ? "0" + month : month;
        let day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        let hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        let second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
        let currentTime = year + "-" + month + "-" + day + "  " + hour + ":" + minute + ":" + second;
        this.listQuery.eventTimeEnd = currentTime;
        this.eventTimeCurrentEnd = new Date(currentTime);
        this.showEventTimeEnd = false;
      },
      onSelect(item) {
        if (item.code === 'search') {
          this.showList = false
        }
      },
      isHandleEvent(item) {
        let type = constant.handleStateOptions.find((item1) => item1.key === item.state).type;
        if (type <= 3 && hasBtnPermission(constant.deviceTypeObject.xks + ":event:handle")) {
          return true;
        } else {
          return false;
        }
      },
      handleEventDetail(item) {
        this.$router.push({
          path: "/app/warn/common/eventDetail",
          query: {id: item.id, type: constant.deviceTypeObject.xks, title: item.eventDesc}
        });
      },
      goEventHandle(item) {
        this.$router.push({
          path: "/app/warn/common/eventHandle",
          query: {type: constant.deviceTypeObject.xks, eventId: item.id},
        });
      },
      getState(item) {
        let state = constant.handleStateOptions.find((item1) => item1.key === item.state).value;
        return state;
      },
      hasBtnPermission(value) {
        if (value != null)
          return hasBtnPermission(value)
        else {
          return false;
        }
      },
      getEventList() {
        getEventPage(this.listQuery).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.loading = false;
            this.eventCount = response.data.totalRows
            this.eventList = this.eventList.concat(response.data.rows);
            // 如果加载完毕，显示没有更多了
            if (response.data.rows.length < this.listQuery.pageSize) {
              this.finished = true;
            }
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
      onLoad() {
        this.listQuery.pageNo++;
        this.getEventList();
      },
      onRefresh() {
        this.eventList = [];
        this.listQuery.pageNo = 1;
        this.loading = true;
        this.isLoading = true;
        this.finished = false;
        this.getEventList();
        this.showList = true
      },
    },
  };
</script>
<style lang="less" scoped>

  .van-pull-refresh {
    position: relative;
    transition: all 0.5s;
  }

  .van-pull-refresh.active {
    margin-top: 20px;
    transition: all 0.5s;
  }

  .van-swipe {
    width: 100% !important;
    padding: 10px 10px 10px 10px;
    line-height: 30px;
    font-size: 14px;
  }

  .swipeActive {
    background-color: #1989fa;
    color: #fff;
    border-radius: 5px;
  }

  .cards-swipe {
    position: fixed;
    width: 100%;
    overflow-y: scroll;
    top: 174px;
    top: calc(174px + constant(safe-area-inset-top));
    top: calc(174px + env(safe-area-inset-top));
    bottom: 0px;
    bottom: calc(0px + constant(safe-area-inset-bottom));
    bottom: calc(0px + env(safe-area-inset-bottom));
  }
</style>
