<template>
  <div>
    <common-head :isBack="true" :customTitle="true" :customRight="true" background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px">
      <template #title>
        <span style="color: black;font-weight: bolder">添加消控室</span>
      </template>
      <template #right>
        <van-button @click="add" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card">
          <div class="form xks-form">
            <van-form ref="formRef">
              <my-select
                ref="unitRef"
                :required="true"
                :isBottom="true"
                label="联网单位："
                :rules="rules.unitId"
                placeholder="点击选择联网单位"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="unitOptions"
                @confirm="(value)=>{this.temp.unitId = value}"
              />
              <van-field
                v-model="temp.name"
                required
                :rules="rules.name"
                label="名　　称："
                input-align="right"
                placeholder="请输入消控室名称"
              />
              <van-field
                v-model="temp.phone"
                required
                :rules="rules.phone"
                label="联系电话："
                input-align="right"
                placeholder="请输入联系人电话"
              />
              <van-field
                :rules="rules.address"
                v-model="temp.address"
                required
                :isHide="true"
                :isBottom="true"
                input-align="right"
                label="安装地址"
                placeholder="请输入安装地址"
              />
              <base-map-search
                ref="mapSearch"
                :isHide="true"
                :rules="rules.address"
                :value="temp.address"
                :longitude="temp.lng"
                :latitude="temp.lat"
                @updateLocation="updateLocation"
              />
              <van-field
                v-model="temp.lng"
                :rules="rules.lng"
                input-align="right"
                required
                label="经　　度："
                placeholder="请输入经度"
              />
              <van-field
                v-model="temp.lat"
                :rules="rules.lat"
                input-align="right"
                required
                label="纬　　度："
                placeholder="请输入纬度"
              />
              <my-select
                ref="statusRef"
                :required="true"
                label="状　　态："
                :rules="rules.status"
                placeholder="点击选择状态"
                filterable
                :isBottom="true"
                s-label="name"
                s-value="id"
                input-align="right"
                :options="statusOptions"
                @confirm="(value)=>{this.temp.status = value}"
              />
              <my-select
                ref="videoTypeRef"
                label="视频类型："
                placeholder="点击选择视频类型"
                filterable
                s-label="name"
                :isBottom="true"
                s-value="id"
                input-align="right"
                :options="videoTypeOptions"
                @confirm="(value)=>{this.temp.videoType = value}"
              />
              <van-field
                v-model="temp.pcVideoUrl"
                input-align="right"
                label="PC端视频地址："
                label-width="3.3rem"
                placeholder="请输入PC端视频地址"
              />
              <van-field
                v-model="temp.appVideoUrl"
                input-align="right"
                label-width="3.3rem"
                label="移动端视频地址："
                placeholder="请输入移动端视频地址"
              />
              <van-field input-align="right" label="排　　班：" name="isSchedule">
                <template #input>
                  <van-switch size="23" :active-value="1" :inactive-value="0"
                              v-model="temp.isSchedule"/>
                </template>
              </van-field>
              <van-field input-align="right" label="电话推送：" name="isPhonePush">
                <template #input>
                  <van-switch size="23" :active-value="1" :inactive-value="0"
                              v-model="temp.isPhonePush"/>
                </template>
              </van-field>
              <van-field input-align="right" label="值守推送：" name="isSchedulePush">
                <template #input>
                  <van-switch size="23" :active-value="1" :inactive-value="0"
                              v-model="temp.isSchedulePush"/>
                </template>
              </van-field>
            </van-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import BaseMapSearch from "@/components/Map/baseMapSearch";
  import {addXks} from "@/api/xks/base";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import store from "@/store";
  import {getSelectorList} from "../../../../api/sys/unit";

  export default {
    components: {BaseMapSearch, commonHead, mySelect},
    data() {
      return {
        show: false,
        loading: false,
        videoTypeOptions: [
          {id: 0, name: "萤石云"},
          {id: 1, name: "乐橙"},
        ],
        statusOptions: [
          {id: 0, name: "正常"},
          {id: 1, name: "维保"},
          {id: 2, name: "在修"},
        ],
        unitOptions: [],
        temp: {
          unitId: null,
          name: null,
          phone: null,
          address: null,
          lat: null,
          lng: null,
          pcVideoUrl: null,
          videoType: null,
          appVideoUrl: null,
          status: null,
          isSchedule: 1,
          isSchedulePush: 1,
          isPhonePush: 1,
        },
        rules: {
          phone: [{required: true, message: '', trigger: "onBlur/onChange"}],
          status: [{required: true, message: '', trigger: "onBlur/onChange"}],
          unitId: [{required: true, message: '', trigger: "onBlur/onChange"}],
          name: [{required: true, message: '', trigger: "onBlur/onChange"}],
          address: [{required: true, message: '', trigger: "onBlur/onChange"}],
          lng: [{required: true, message: '', trigger: "onBlur/onChange"}],
          lat: [{required: true, message: '', trigger: "onBlur/onChange"}],
        },
        unitId: null,
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      getSelectorList({isOnline: 1}).then((response) => {
        this.unitOptions = response.data;
        this.temp.unitId = this.unitId
        if (this.unitOptions.find(item => item.id === this.temp.unitId)) {
          this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.temp.unitId).name
        }
      });
    },
    methods: {
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      updateLocation(lng, lat, address) {
        this.temp.lng = lng;
        this.temp.lat = lat;
        this.temp.address = address;
      },
      add() {
        this.$refs.formRef.validate().then(() => {
          this.loading = true;
          store.commit('showLoading')
          addXks(this.temp).then((response) => {
            if (response.success) {
              store.commit('hideLoading')
              this.loading = false;
              this.$toast("保存成功");
              setTimeout(this.goBack(), 500);
            } else {
              this.loading = false;
              this.$toast(response.message);
            }
          })
            .catch((err) => {
              store.commit('hideLoading')
              this.loading = false;
              this.$toast(err + "");
            });
        })
      },
    },
  };
</script>

<style scoped>

  .xks-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

</style>
