<template>
  <div>
    <common-head :isBack="true" :customTitle="true" :customRight="true" background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px">
      <template #title>
        <span style="color: black;font-weight: bolder">{{type===1?'编辑用传':'添加用传'}}</span>
      </template>
      <template #right>
        <van-button @click="save" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card">
          <div class="form transmission-form">
            <van-form ref="formRef">
              <my-select
                ref="unitRef"
                :required="true"
                label="联网单位："
                :isBottom="true"
                :placeholder="type===1?'':'点击选择联网单位'"
                filterable
                s-label="name"
                s-value="id"
                :rules="rules.unitId"
                input-align="right"
                :options="unitOptions"
                @confirm="changeUnit"/>
              <my-select
                ref="xksInfoRef"
                :required="true"
                label="所属消控室："
                :isBottom="true"
                :placeholder="type===1?'':'点击选择消控室'"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :rules="rules.xksId"
                :options="xksOptions"
                @confirm="(value)=>{this.temp.xksId = value}"
              />
              <my-select v-if="type===0"
                         ref="xksTransmissionDetailIdList"
                         :required="true"
                         label="接入消控室："
                         :isBottom="true"
                         :placeholder="type===1?'':'点击选择消控室'"
                         filterable
                         s-label="name"
                         s-value="id"
                         input-align="right"
                         :rules="rules.xksId1"
                         :options="xksOptions"
                         @confirm="(value)=>{
                this.temp.xksTransmissionDetailIdList = [];
                this.temp.xksTransmissionDetailIdList.push(value)
              }"
              />
              <van-field
                v-model="temp.name"
                :rules="rules.name"
                input-align="right"
                required
                label="用传名称："
                :placeholder="type===1?'':'请输入用传名称'"
              />
              <van-field
                v-model="temp.code"
                input-align="right"
                required
                type="number"
                label="用传编码："
                :placeholder="type===1?'':'请输入用传编码'"
                readonly
              />
              <my-select
                ref="providerIdRef"
                :required="true"
                label="厂　　家："
                :isBottom="true"
                :rules="rules.provider"
                :placeholder="type===1?'':'点击选择厂家'"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="providerOptions"
                @confirm="(value)=>{this.temp.providerId = value;this.temp.protocolId = null;
              this.temp.protocolValue = null;this.$refs.protocolIdRef.value = null;this.getProtocolList(value)}"
              />
              <my-select
                ref="protocolIdRef"
                :required="true"
                label="协　　议："
                :rules="rules.protocol"
                :isBottom="true"
                :placeholder="type===1?'':'点击选择协议'"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="protocolOptions"
                @confirm="(value)=>{this.temp.protocolId = value}"
              />
              <van-field
                v-model="temp.position"
                input-align="right"
                label="位　　置："
                :placeholder="type===1?'':'请输入位置'"
              />
              <my-select
                ref="userRef"
                label="安装人员："
                :placeholder="type===1?'':'点击选择安装人员'"
                filterable
                s-label="name"
                :isBottom="true"
                s-value="id"
                input-align="right"
                :options="userOptions"
                @confirm="(value)=>{this.temp.installUserId = value}"
              />
              <common-date-select label="到期时间：" :placeholder="type===1?'':'请选择到期时间'"
                                  @update="(value)=>{this.temp.expireDate = value}"
                                  :value="temp.expireDate"/>
              <common-upload-image ref="installPicRef" label="安装图片："/>
            </van-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import BaseMapSearch from "@/components/Map/baseMapSearch";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import store from "@/store";
  import {getXksInfo} from "@/api/xks";
  import {getProtocol, getProvider} from "@/api/common";
  import constant from "@/api/common/constant";
  import CommonUploadImage from "@/components/Upload/CommonUploadImage";
  import {
    addXksTransmissionDevice,
    updateXksTransmissionDevice,
    xksTransmissionDeviceDetail
  } from "@/api/xks/transmissionDevice";
  import {xksTransmissionGetCode} from "../../../../api/xks/transmissionDevice";
  import CommonDateSelect from "@/components/selector/CommonDateSelect";
  import {sysUserSelector} from "../../../../api/system/userManage";
  import {getSelectorList} from "../../../../api/sys/unit";

  export default {
    components: {BaseMapSearch, commonHead, mySelect, CommonDateSelect, CommonUploadImage},
    data() {
      return {
        show: false,
        loading: false,
        videoTypeOptions: [
          {id: 0, name: "萤石云"},
          {id: 1, name: "乐橙"},
        ],
        statusOptions: [
          {id: 0, name: "正常"},
          {id: 1, name: "维保"},
          {id: 2, name: "在修"},
        ],
        unitOptions: [],
        xksOptions: [],
        providerOptions: [],
        protocolOptions: [],
        userOptions: [],
        type: 0,
        temp: {
          id: null,
          unitId: null,
          name: null,
          code: null,
          xksId: null,
          xksTransmissionDetailIdList: null,
          providerId: null,
          protocolIdRef: null,
          address: null,
          position: null,
          installDate: null,
          expireDate: null,
          installUserId: null,
          installPic: '',
        },
        rules: {
          xksId: [{required: true, message: '', trigger: "onBlur/onChange"}],
          xksId1: [{required: true, message: '', trigger: "onBlur/onChange"}],
          unitId: [{required: true, message: '', trigger: "onBlur/onChange"}],
          name: [{required: true, message: '', trigger: "onBlur/onChange"}],
          provider: [{required: true, message: '', trigger: "onBlur/onChange"}],
          protocol: [{required: true, message: '', trigger: "onBlur/onChange"}],
        },
        id: null,
        index: null,
        index1: null,
        xksId: null,
        unitId: null,
        xksName: null,
      };
    },
    created() {
      this.init()
    },
    methods: {
      async init() {
        await this.getUnitList();
        await this.getProviderList();
        await sysUserSelector().then((response) => {
          this.userOptions = response.data;
        });
        if (this.$route.query.type) {
          this.type = parseInt(this.$route.query.type);
        }
        if (this.$route.query.id) {
          this.id = this.$route.query.id;
        }
        if (this.$route.query.xksName) {
          this.xksName = this.$route.query.xksName;
        }
        if (this.$route.query.index) {
          this.index = this.$route.query.index;
        }
        if (this.$route.query.index1) {
          this.index1 = this.$route.query.index1;
        }
        if (this.$route.query.unitId) {
          this.unitId = this.$route.query.unitId;
        }
        this.$nextTick(() => {
          if (this.type === 0) {
            if (this.unitOptions.find(item => item.id === this.unitId)) {
              this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.unitId).name
              this.changeUnit(this.unitId)
              this.$refs.xksInfoRef.value = this.xksName
            }
            xksTransmissionGetCode().then(response => {
              if (response.success) {
                this.temp.code = response.data
              }
            })
          } else if (this.type === 1) {
            this.getDetail(this.id);
          }
        })
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path)
      },
      getDetail(id) {
        xksTransmissionDeviceDetail(id).then(response => {
          if (response.success) {
            this.temp = response.data
            this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.temp.unitId).name
            this.xksOptions = [];
            this.$refs.installPicRef.setFileList(this.temp.installPic)
            this.$refs.providerIdRef.value = this.providerOptions.find(item => item.id === this.temp.providerId).name
            if (this.temp.installUserId) {
              this.$refs.userRef.value = this.userOptions.find(item => item.id === this.temp.installUserId).name
            }
            getXksInfo({unitId: this.temp.unitId}).then(response => {
              if (response.success) {
                this.xksOptions = response.data;
                this.$refs.xksInfoRef.value = this.xksOptions.find(item => item.id === this.temp.xksId).name
              }
            })
            getProtocol({providerId: this.temp.providerId}).then((response) => {
              if (response.success) {
                this.protocolOptions = response.data
                this.$refs.protocolIdRef.value = this.protocolOptions.find(item => item.id === this.temp.protocolId).name
              }
            })
          }
        })
      },
      async getUnitList() {
        await getSelectorList({isOnline: 1}).then((response) => {
          this.unitOptions = response.data;
        });
      },
      async getProviderList() {
        await getProvider({deviceType: constant.deviceTypeObject.xks}).then(response => {
          if (response.success) {
            this.providerOptions = response.data;
            this.getProtocolList();
          }
        })
      },
      getProtocolList(providerId) {
        this.protocolOptions = [];
        getProtocol({providerId: providerId}).then((response) => {
          if (response.success) {
            this.protocolOptions = response.data
          }
        })
      },
      changeUnit(value) {
        this.temp.unitId = value;
        this.$refs.xksInfoRef.value = null;
        this.$refs.xksTransmissionDetailIdList.value = null;
        this.temp.xksId = null;
        this.getXksList(value)
      },
      getXksList(unitId) {
        this.xksOptions = [];
        getXksInfo({unitId: unitId}).then(response => {
          if (response.success) {
            this.xksOptions = response.data;
          }
        })
      },
      updateLocation(lng, lat, address) {
        this.temp.lng = lng;
        this.temp.lat = lat;
        this.temp.address = address;
      },
      save() {
        this.$refs.formRef.validate().then(() => {
          this.temp.installPic = this.$refs.installPicRef.getFileIds();
          store.commit('showLoading')
          if (this.type === 1) {
            updateXksTransmissionDevice(this.temp).then((response) => {
              if (response.success) {
                store.commit('hideLoading')
                this.loading = false;
                this.$toast("保存成功");
                setTimeout(this.goBack(), 500);
              } else {
                this.loading = false;
                this.$toast(response.message);
              }
            }).catch((err) => {
              store.commit('hideLoading')
              this.loading = false;
              this.$toast(err + "");
            });
          } else {
            addXksTransmissionDevice(this.temp).then((response) => {
              if (response.success) {
                store.commit('hideLoading')
                this.loading = false;
                this.$toast("保存成功");
                setTimeout(this.goBack(), 500);
              } else {
                this.loading = false;
                this.$toast(response.message);
              }
            }).catch((err) => {
              store.commit('hideLoading')
              this.loading = false;
              this.$toast(err + "");
            });
          }
        }).catch(err => {

        })
      },
    },
  };
</script>

<style scoped>

  .transmission-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

</style>

