<template>
  <div>
    <div class="top-head" style="background:#1989fa"/>
    <van-nav-bar fixed style="height: 48px;" class="navBar navBar-fixed navBackground transparent" :border="false">
      <template #title>
        <my-select
          :isBottom="true"
          ref="xksInfoRef"
          class="title"
          filterable
          :isLink="false"
          s-label="text"
          s-value="id"
          :isSelectWhite="true"
          input-align="center"
          :options="option1"
          @confirm="change"
        />
      </template>
      <template #left>
        <div @click="goBack" style="display: flex;align-items: center">
          <img ref="backRef" style="width: 16px" src="@/assets/images/new/back.png" alt=""/>
          <span style="color: #ffffff;font-size: 14px;position:relative;left:3px"> 首页</span>
        </div>
      </template>
      <template #right>
        <van-popover @select="onSelect" placement="bottom-end" v-model:show="showPopover"
                     :actions="filterActions">
          <template #reference>
            <img src="@/assets/images/gengduo.png" @click="showPopover=!showPopover"/>
          </template>
        </van-popover>
      </template>
    </van-nav-bar>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="xksBackground">
          <van-grid :border="false" :column-num="4">
            <van-grid-item @click="goDeviceList(deviceStateObject.warn)">
              <van-badge v-if="warnCount !== 0" color="#FF585C" :content="warnCount" position="bottom-right">
                <div class="circle">
                  <van-image width="30" :src="require('@/assets/images/huojing.png')"/>
                </div>
              </van-badge>
              <div v-if="warnCount === 0" class="circle">
                <van-image width="30" :src="require('@/assets/images/huojing.png')"/>
              </div>
              <span class="font font-PingFang">报警</span>
            </van-grid-item>
            <van-grid-item @click="goDeviceList(deviceStateObject.abnormal)">
              <van-badge v-if="abnormalCount !== 0" color="#FF585C" :content="abnormalCount" position="bottom-right">
                <div class="circle">
                  <van-image width="30" :src="require('@/assets/images/gaojing.png')"/>
                </div>
              </van-badge>
              <div v-if="abnormalCount === 0" class="circle">
                <van-image width="30" :src="require('@/assets/images/gaojing.png')"/>
              </div>
              <span class="font font-PingFang">告警</span>
            </van-grid-item>
            <van-grid-item @click="goDeviceList(deviceStateObject.fault)">
              <van-badge v-if="faultCount !== 0" color="#FF585C" :content="faultCount" position="bottom-right">
                <div class="circle">
                  <van-image width="30" :src="require('@/assets/images/guzhang.png')"/>
                </div>
              </van-badge>
              <div v-if="faultCount === 0" class="circle">
                <van-image width="30" :src="require('@/assets/images/guzhang.png')"/>
              </div>
              <span class="font font-PingFang">故障</span>
            </van-grid-item>
            <van-grid-item @click="goDeviceList(deviceStateObject.shield)">
              <van-badge v-if="shieldCount !== 0" color="#FF585C" :content="shieldCount" position="bottom-right">
                <div class="circle">
                  <van-image width="30" :src="require('@/assets/images/pingbi.png')"/>
                </div>
              </van-badge>
              <div v-if="shieldCount === 0" class="circle">
                <van-image width="30" :src="require('@/assets/images/pingbi.png')"/>
              </div>
              <span class="font font-PingFang">屏蔽</span>
            </van-grid-item>
          </van-grid>
        </div>
        <div style="opacity:1 !important;margin-top:-120px" class="white-circle">
          <van-row>
            <van-col style="border-radius: 10px;" span="22" offset="1">
              <van-row style="height:10px" :border="false">
              </van-row>
              <van-row style="height:30px;display: flex;align-items: center;" :border="false">
                <van-col span="1" align="center">
                  <div class="before"></div>
                </van-col>
                <van-col span="12" align="left" class="col"><span class="title font-PingFang">消控室</span>
                </van-col>
              </van-row>
              <van-row>
                <van-grid style="height: 100%" :border="false" :column-num="2">
                  <van-grid-item @click="getAttendance()">
                    <div class="qiandao">
                      <span v-if="attendanceType===0" style="font-size: 16px;color:#ffffff;position:relative;top:-3px"
                            class="font-PingFang">值班签到</span>
                      <span v-if="attendanceType===1" style="font-size: 16px;color:#ffffff;position:relative;top:-3px"
                            class="font-PingFang">值班签退</span>
                    </div>
                  </van-grid-item>
                  <van-grid-item>
                    <div class="jksp" @click="goVideo()">
                      <span style="font-size: 16px;color:#ffffff;position:relative;top:-3px"
                            class="font-PingFang">监控视频</span>
                    </div>
                  </van-grid-item>
                </van-grid>
              </van-row>
            </van-col>
          </van-row>
        </div>
        <div class="white-circle">
          <van-row>
            <van-col style="border-radius: 10px;" span="22" offset="1">
              <van-row style="height:10px" :border="false">
              </van-row>
              <van-row style="height:30px;display: flex;align-items: center;" :border="false">
                <van-col span="1" align="center">
                  <div class="before"></div>
                </van-col>
                <van-col span="12" align="left" class="col"><span class="title font-PingFang">用传信息</span>
                </van-col>
                <van-col style="display: flex;align-items: center;justify-content:flex-end;" span="10"
                         align="right"
                         class="col">
                  <img :height="15" style="position: relative;left:-2px;"
                       :src="require('@/assets/images/new/add.png')">
                  <span v-if="hasBtnPermission('xks:transmissionInfo:add')" @click="handleAddTransmission()"
                        style="font-size:13px;color:#1989FA">新增</span>
                </van-col>
              </van-row>
              <div v-if="this.transmissionList.length>0">
                <van-swipe-cell v-for="(item, index) in transmissionList" :key="index">
                  <div class="item" style="padding-left: 5px">
                    <div class="item-top">
                      <span class="title">{{item.name}}</span>
                    </div>
                    <div class="item-bottom">
                      <span>编码:{{item.code}}</span>
                      <span v-if="item.isNetwork===0 || item.isNetwork===null" class="status"
                            style="text-align: right">联网状态:<span
                        class="font-red">异常</span></span>
                      <span v-if="item.isNetwork===1" class="status"
                            style="flex: 0.6;text-align: right">联网状态:正常</span>
                    </div>
                    <div class="item-bottom">
                      <span v-if="item.networkTime!= null" class="status">最后一次联网时间:　　{{item.networkTime}}</span>
                    </div>
                  </div>
                  <template #right>
                    <van-button
                      v-if="hasBtnPermission('xks:transmissionInfo:setIsPush') && item.isPush === true"
                      style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                      square
                      text="关闭推送" @click="handleSetIsPush(item.id, false)"/>
                    <van-button
                      v-if="hasBtnPermission('xks:transmissionInfo:setIsPush') && item.isPush === false"
                      style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                      square
                      text="开启推送" @click="handleSetIsPush(item.id, true)"/>
                    <van-button
                      style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                      square
                      text="事件" @click="goEventList(item.id)"/>
                    <van-button
                      v-if="hasBtnPermission('xks:transmissionInfo:control')"
                      style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                      square
                      text="控制" @click="handleControl(item)"/>
                    <van-button v-if="hasBtnPermission('xks:transmissionInfo:edit')"
                                @click="handleUpdateTransmission(item.id)"
                                style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                                square
                                text="编辑"/>
                    <van-button v-if="hasBtnPermission('xks:transmissionInfo:del')"
                                @click="deleteTransmission(item.id)"
                                style="height: 100%;" square text="删除" type="danger"
                                class="delete-button"/>
                  </template>
                </van-swipe-cell>
              </div>
              <div v-if="this.transmissionList.length===0">
                <div style="color: #969799;width:100%;height: 40px;line-height: 40px;text-align:center">没有更多了</div>
              </div>
            </van-col>
          </van-row>
        </div>
        <div class="white-circle">
          <van-row>
            <van-col style="border-radius: 10px;" span="22" offset="1">
              <van-row style="height:50px;display: flex;align-items: center;" :border="false">
                <van-col span="1" align="center">
                  <div class="before"></div>
                </van-col>
                <van-col span="12" align="left" class="col"><span class="title font-PingFang">维保单位信息</span>
                </van-col>
                <van-col span="11" v-if="examUnit == null" align="right" class="col">
                  <span style="font-size: 14px" class="font-PingFang">暂无维保单位</span>
                </van-col>
              </van-row>
              <van-row v-if="examUnit != null"
                       style="display: flex;height:90px;padding-bottom: 10px">
                <van-col span="16" offset="1">
                  <div style="font-size: 14px;" class="font-PingFang">
                    <div style="display: flex;align-items: center;font-weight: bold;height: 30px">
                      {{examUnit.name}}
                    </div>
                    <div style="display: flex;align-items:flex-end;height: 25px;"><span
                      style="color:#9B9B9B">联系人:</span>
                      <span style="color:#393943">{{examUnit.juridicalName}}</span>
                    </div>
                    <div style="display: flex;align-items: flex-end;height: 25px"><span
                      style="color:#9B9B9B">联系号码:</span><span style="color:#393943">{{examUnit.juridicalPhone}}</span>
                    </div>
                  </div>
                </van-col>
                <van-col span="7" style="position: relative">
                  <div @click="callPhone(examUnit.juridicalPhone)"
                       style="position:absolute;bottom:0px;display: flex;align-items: center;width: 100%;height: 32px;border-radius: 16px;opacity: 1;background: #FFFFFF;box-sizing: border-box;border: 1px solid #C2C2C2;">
                    <img style="padding-left: 10px" src="@/assets/images/phone.png" alt=""><span
                    style="padding-left: 10px">联系维保</span>
                  </div>
                </van-col>
              </van-row>
            </van-col>
          </van-row>
        </div>
        <van-row class="white-circle" style="padding-bottom: 10px;">
          <van-row>
            <van-col style="border-radius: 10px;" span="22" offset="1">
              <van-row style="height:10px" :border="false">
              </van-row>
              <van-row style="height:30px;display: flex;align-items: center;" :border="false">
                <van-col span="1" align="center">
                  <div class="before"></div>
                </van-col>
                <van-col span="12" align="left" class="col"><span class="title font-PingFang">今日排班</span>
                </van-col>
                <van-col v-if="this.scheduleList.length === 0" span="11" align="right" class="col">
                  <span style="font-size: 14px" class="font-PingFang">暂无排班</span>
                </van-col>
                <van-col v-if="this.scheduleList.length > 0" span="4" align="right" :offset="7"
                         @click="goAttendanceList()">
                  <span style="color:#979797; font-size: 14px">更多<span
                    style="position:relative;left:2px;">></span></span>
                </van-col>
              </van-row>
              <van-row v-if="this.scheduleList.length>0">
                <van-row v-for="(item,index) in scheduleList" :key="index" class="font-PingFang"
                         style="height:100px;display: flex;align-items: center;"
                         :border="false">
                  <van-col span="6" align="center">
                    <van-image round width="50" :src="require('@/assets/images/new/userImage.png')"/>
                    <br><span style="color: #393943;font-size: 14px;font-weight: bold">{{item.userName}}</span>
                  </van-col>
                  <van-col span="9" align="left" :offset="2"
                           style="font-size: 14px;height:100%;color: #5A5A5A;display: flex;flex-direction: column;justify-content: center;">
                    <van-row style="height: 20px" v-if="item.scheduleStartTime != null">
                      上班　{{format(item.scheduleStartTime)}}
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceStartTime != null">
                      {{format(item.attendanceStartTime)}}<span
                      style="margin-left: 5px">已签到</span>
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceStartTime == null">未签到</van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #3ABB5D;color: #3ABB5D"
                      v-if="item.attendanceStartTime != null && item.scheduleStartTime != null && item.attendanceStartTime <= item.scheduleStartTime">
                      正常
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #F1C345;color: #F1C345"
                      v-if="item.attendanceStartTime != null && item.scheduleStartTime != null && item.attendanceStartTime > item.scheduleStartTime">
                      迟到
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content: center;color: #FF5C50;border-radius: 9px;box-sizing: border-box;border: 1px solid #FF5C50;"
                      v-if="item.attendanceStartTime == null && item.scheduleStartTime != null && getNowTime() > item.scheduleStartTime">
                      缺卡
                    </van-row>
                  </van-col>
                  <van-col span="7" align="left" class="col"
                           style="font-size: 14px;height:100%;display: flex;flex-direction: column;justify-content: center;">
                    <van-row style="height: 20px" v-if="item.scheduleEndTime != null">
                      下班　{{format(item.scheduleEndTime)}}
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceEndTime != null">
                      {{format(item.attendanceEndTime)}}<span style="margin-left: 5px"> 已签退</span>
                    </van-row>
                    <van-row style="height: 20px" v-if="item.attendanceEndTime == null">未签退
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #3ABB5D;color: #3ABB5D"
                      v-if="item.attendanceEndTime != null && item.scheduleEndTime != null && item.attendanceEndTime >= item.scheduleEndTime">
                      正常
                    </van-row>
                    <van-row
                      style="width: 40px;height: 20px;display: flex;align-items: center;justify-content:center;border-radius: 9px;box-sizing: border-box;border: 1px solid #F1C345;color: #F1C345"
                      v-if="item.attendanceEndTime != null && item.scheduleEndTime != null && item.attendanceEndTime < item.scheduleEndTime">
                      早退
                    </van-row>
                  </van-col>
                </van-row>
              </van-row>
            </van-col>
          </van-row>
        </van-row>

        <common-warn-card ref="commonWarnCardRef" :unitId="unitId" :xksId="id" :type="this.type" :isShield="true"/>

        <div v-if="this.$parent.isShowWarn" class="nav-bottom"/>
      </div>
    </div>
  </div>
</template>

<script>
  import {getAttendance, getXksInfo} from "@/api/xks/index";
  import {deviceCount, getDeviceState} from "@/api/common/common.js";
  import constant from '@/api/common/constant.js'
  import commonWarnCard from "@/views/app/warn/common/warnCard";
  import {deleteXks, getExamUnit} from "@/api/xks";
  import {hasBtnPermission} from "@/utils/permission";
  import {deleteXksTransmissionDevice, xksTransmissionDeviceList} from "@/api/xks/transmissionDevice";
  import mySelect from "@/views/app/common/my-select/index"
  import store from "@/store";
  import {getAttendanceAndSchedulePage, getAttendanceType} from "../../../../api/xks";
  import {xksTransmissionSetIsPush} from "../../../../api/xks/transmissionDevice";

  export default {
    components: {commonWarnCard, mySelect},
    data() {
      return {
        active: 0,
        activeNavIndex: 0, // 底部导航激活下标
        warnCount: 0,
        abnormalCount: 0,
        faultCount: 0,
        shieldCount: 0,
        deviceList: [],
        scheduleList: [],
        userSchedule: null,
        attendanceType: 0,
        type: constant.deviceTypeObject.xks,
        activeName: constant.deviceStateObject.warn,
        deviceStateObject: constant.deviceStateObject,
        value1: 0,
        id: null,
        monitorDeviceId: null,
        appVideoUrl: null,
        unitId: null,
        option1: [
          // { text: "全部商品", value: 0 },
          // { text: "新款商品", value: 1 },
          // { text: "活动商品", value: 2 },
        ],
        signIn: "",
        examUnit: null,
        showPopover: false,
        index: null,
        index1: null,
        transmissionList: [],
        actions: [
          {text: '新增', icon: 'add-o', permission: 'xks:info:add'},
          {text: '编辑', icon: 'edit', permission: 'xks:info:edit'},
          {text: '删除', icon: 'delete', permission: 'xks:info:del'},
        ],
        filterActions: [],
      };
    },

    created() {
      if (this.$route.query.id) {
        this.id = this.$route.query.id;
      }
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      if (this.$route.query.index) {
        this.index = this.$route.query.index;
      }
      if (this.$route.query.index1) {
        this.index1 = this.$route.query.index1;
      }
      this.filterActions = this.actions.filter(item => this.hasBtnPermission(item.permission));
      this.init();
    },
    computed: {},
    methods: {
      goEventList(id) {
        this.$router.push({path: '/app/warn/xks/eventList', query: {xksId: this.id, transmissionId: id}});
      },
      goAttendanceList() {
        this.$router.push({path: '/app/warn/xks/attendanceRecord', query: {xksId: this.id}});
      },
      format(date) {
        return date.substring(11, 16)
      },
      callPhone(phone) {
        window.location.href = "tel://" + phone;
      },
      getNowTime() {
        const HH = new Date().getHours() < 10 ? '0' + new Date().getHours() : new Date().getHours()
        const mm = new Date().getMinutes() < 10 ? '0' + new Date().getMinutes() : new Date().getMinutes()
        const ss = new Date().getSeconds() < 10 ? '0' + new Date().getSeconds() : new Date().getSeconds()
        return HH + ':' + mm + ':' + ss
      },
      handleControl(item) {
        this.$router.push("/app/warn/xks/controlList?id=" + item.id)
      },
      handleUpdateTransmission(value) {
        this.$router.push({
          path: "/app/warn/xks/transmissionEdit",
          query: {type: 1, xksId: this.xksId, id: value, index: this.index, index1: this.index1}
        })
      },
      handleAddTransmission() {
        if (this.xksId) {
          this.$router.push({
            path: "/app/warn/xks/transmissionEdit",
            query: {
              type: 0,
              xksId: this.xksId,
              unitId: this.unitId,
              xksName: this.$refs.xksInfoRef.value,
              index: this.index,
              index1: this.index1
            }
          })
        } else {
          this.$toast("请先选择消控室")
        }
      },
      deleteTransmission(value) {
        this.$dialog.confirm({
          message: "是否删除",
        }).then(() => {
          store.commit('showLoading')
          deleteXksTransmissionDevice([value])
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.getXksTransmissionDeviceList(this.id)
              } else {
                this.$toast(response.message);
              }
            })
            .catch((err) => {
              store.commit('hideLoading')
              this.$toast(err + "");
            });
        }).catch(() => {
          // on cancel
        });
      },
      onSelect(item) {
        if (item.text === '新增') {
          this.$router.push({path: "/app/warn/xks/add", query: {unitId: this.unitId}})
        } else if (item.text === '编辑') {
          if (this.id != null) {
            this.$router.push({path: "/app/warn/xks/edit", query: {id: this.id, unitId: this.unitId}});
          } else {
            this.$toast("请先选择消控室");
          }
        } else if (item.text === '删除') {
          if (this.id != null) {
            this.$dialog.confirm({
              message: "是否删除",
            }).then(() => {
              store.commit('showLoading')
              deleteXks([this.id])
                .then((response) => {
                  store.commit('hideLoading')
                  if (response.success) {
                    this.$toast("删除成功");
                    this.option1 = [];
                    this.id = null;
                    this.init();
                  } else {
                    this.$toast(response.message);
                  }
                })
                .catch((err) => {
                  store.commit('hideLoading')
                  this.$toast(err + "");
                });
            }).catch(() => {
              // on cancel
            });
          } else {
            this.$toast("请先选择消控室");
          }
        } else if (item.text === '用传') {

        }
      },
      getXksTransmissionDeviceList(xksId) {
        this.transmissionList = [];
        xksTransmissionDeviceList({xksId: xksId}, 'list').then(response => {
          if (response.success) {
            this.transmissionList = response.data
          }
        })
      },
      handleSetIsPush(id, isPush) {
        let content = '';
        if (isPush === true) content = '确定要开启推送'
        if (isPush === false) content = '确定要关闭推送'
        this.$dialog.confirm({
          message: content,
        }).then(() => {
          store.commit('showLoading')
          xksTransmissionSetIsPush({id: id, isPush: isPush}).then((response) => {
            if (response.success) {
              store.commit('hideLoading')
              this.$toast('操作成功');
              this.getXksTransmissionDeviceList(this.id);
            }
          }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      getExamUnit(id) {
        getExamUnit({id: id}).then(response => {
          if (response.success) {
            this.examUnit = response.data
          }
        })
      }
      ,
      async init() {
        this.$nextTick(() => {
          this.$refs.xksInfoRef.value = null;
        })
        await this.getXksInfo();
        if (this.id !== null) {
          this.change(this.id)
        }
      }
      ,
      getDeviceType(type) {
        if (type === null) return '';
        else return type;
      }
      ,
      getDeviceState(item) {
        return getDeviceState(item);
      }
      ,
      toVideo() {
        //this.$router.push("/app/warn/shipin/index");
      }
      ,
      hasBtnPermission(value) {
        if (value != null)
          return hasBtnPermission(value)
        else {
          return false;
        }
      }
      ,
      goXksAdd() {

      }
      ,
      goBack() {
        this.$router.push({path: "/index", query: {unitId: this.unitId}});
      }
      ,
      goDeviceList(state) {
        this.$router.push({
          path: "/app/warn/common/deviceList",
          query: {type: this.type, state: state, xksId: this.id, unitId: this.unitId}
        });
      }
      ,
      getCount() {
        deviceCount({xksId: this.id, types: this.type,}).then((response) => {
          if (response.success) {
            this.warnCount = response.data.warnCount;
            this.abnormalCount = response.data.abnormalCount;
            this.faultCount = response.data.faultCount;
            this.shieldCount = response.data.shieldCount;
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      }
      ,
      async getXksInfo() {
        await getXksInfo({unitId: this.unitId}).then((response) => {
          if (response.success) {
            for (let i = 0; i < response.data.length; i++) {
              this.option1.push({
                text: response.data[i].name,
                value: i,
                id: response.data[i].id,
                monitorDeviceId: response.data[i].monitorDeviceId,
                appVideoUrl: response.data[i].appVideoUrl,
              });
            }
            if (response.data.length > 0) {
              if (this.id === null) {
                this.id = response.data[0].id;
                this.unitId = response.data[0].unitId;
                this.monitorDeviceId = response.data[0].monitorDeviceId
                this.appVideoUrl = this.option1.find(item => item.id === this.id).appVideoUrl;
                if (this.$refs.xksInfoRef) {
                  this.$refs.xksInfoRef.value = response.data[0].name;
                  this.$router.replace({
                    path: "/app/warn/xks/index",
                    query: {id: this.id, index: this.index, index1: this.index1, unitId: this.unitId}
                  })
                }
              }
            }
          }
        })
          .catch((err) => {
            this.$toast(err + "");
          });
      }
      ,
      getAttendanceAndSchedulePage() {
        this.finished = false;
        this.loading = true;
        getAttendanceAndSchedulePage({
          xksId: this.id,
          pageNo: 1,
          pageSize: 3
        }).then((response) => {
          if (response.success) {
            this.scheduleList = response.data.rows;
          }
        }).catch((err) => {
          this.$toast(err + "");
          this.loading = false;
        });
      }
      ,
      getCurrentUserSchedule() {
        getAttendanceType({
          xksId: this.id,
        }).then((response) => {
          if (response.success) {
            this.attendanceType = response.data;
          }
        })
          .catch((err) => {
            this.$toast(err + "");
          });
      }
      ,
      goVideo() {
        this.$router.push({path: "/app/warn/shipin", query: {id: this.monitorDeviceId, appVideoUrl: this.appVideoUrl}});
      },
      getAttendance() {
        let type;
        let message;
        if (this.id === null) {
          this.$toast("请先选择消控室");
          return;
        }
        if (this.attendanceType === 0) {
          message = "是否签到"
          type = 0;
        } else if (this.attendanceType === 1) {
          type = 1;
          message = "是否签退"
        }
        this.$dialog.confirm({
          message: message,
        }).then(() => {
          getAttendance({
            xksId: this.id,
            type: type
          }).then((response) => {
            if (response.success) {
              if (type === 0) {
                this.$toast("签到成功");
              } else if (type === 1) {
                this.$toast("签退成功");
              }
              this.getAttendanceAndSchedulePage();
              this.getCurrentUserSchedule();
            }
          })
            .catch((err) => {
              this.$toast(err + "");
            });
        })
          .catch(() => {
            // on cancel
          });
      }
      ,
      change(data) {
        this.examUnit = null
        this.scheduleList = []
        this.deviceList = [];
        this.warnCount = 0;
        this.abnormalCount = 0;
        this.faultCount = 0;
        this.shieldCount = 0;
        if (this.id !== data) {
          this.$router.replace({
            path: "/app/warn/xks/index",
            query: {id: data, index: this.index, index1: this.index1, unitId: this.unitId}
          })
        }
        this.id = data;
        this.id = data;
        this.$refs.xksInfoRef.value = this.option1.find(item => item.id === this.id).text;
        this.monitorDeviceId = this.option1.find(item => item.id === this.id).monitorDeviceId;
        this.appVideoUrl = this.option1.find(item => item.id === this.id).appVideoUrl;
        this.getCount();
        this.getAttendanceAndSchedulePage();
        this.getCurrentUserSchedule();
        this.getExamUnit(this.id)
        this.getXksTransmissionDeviceList(this.id);
        this.$refs.commonWarnCardRef.refreshXks(this.type, this.id)
      }
    },
  }
  ;
</script>

<style scoped>
  .navbar .myselect .title >>> .van-cell {
    font-size: 0.45rem !important;
    color: #fff !important;
  }

  .xksBackground {
    width: 100%;
    height: 230px;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: center;
    background-image: url("../../../../assets/images/new/xksbg.png");
  }

  .xksBackground >>> .van-grid-item__content {
    background-color: transparent;
  }

  .xksBackground .circle {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center
  }

  .xksBackground .font {
    color: #ffffff;
    line-height: 35px;
    font-size: 16px;
  }

  .xksBackground .num {
    width: 20px;
    height: 20px;
    background: #FF585C;
    border-radius: 50%;
    color: #fff;
    text-align: center;
    position: absolute;
    line-height: 18px;
  }

  .white-circle .title {
    font-size: 16px;
    font-weight: bold;
    color: #3A3A44;
  }

  .qiandao {
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: center;
    background-image: url("../../../../assets/images/new/zbqd.png");
    width: 100%;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .jksp {
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: center;
    background-image: url("../../../../assets/images/new/jksp.png");
    width: 100%;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .xksBackground >>> .van-badge--fixed {
    position: absolute;
    top: 0;
    right: 0;
    -webkit-transform: translate(50%, -50%);
    transform: translate(30%, 250%);
    -webkit-transform-origin: 100%;
    transform-origin: 100%;
  }

  .xksBackground >>> .van-badge {
    display: inline-block;
    box-sizing: border-box;
    min-width: 16px;
    padding: 0 3px;
    color: #fff;
    font-weight: 500;
    font-size: 12px;
    font-family: -apple-system-font, Helvetica Neue, Arial, sans-serif;
    line-height: 1.2;
    text-align: center;
    background-color: #ee0a24;
    border: none;
    border-radius: 999px;
  }
</style>
