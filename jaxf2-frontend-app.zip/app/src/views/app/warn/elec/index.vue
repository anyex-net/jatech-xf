<template>
  <div>
    <common-head :toIndex="true" :type="type" :isBack="true" :title="'电气'"/>
    <div class="content elec">
      <div class="cards-navbar">
        <div style="padding: 15px">
          <div class="count">
            <van-row @click="goDeviceList(deviceStateObject.all)">
              <van-col span="1" offset="1" align="center">
                <div class="before"></div>
              </van-col>
              <van-col span="11"><span>设备总数</span></van-col>
              <van-col span="2" offset="7" style="
              background: #1989fa;
              color: #fff;
              text-align: center;
              border-radius: 5px;
            "><span>{{ sumCount }}</span></van-col>
            </van-row>
            <van-row @click="goDeviceList(deviceStateObject.offline)">
              <van-col span="1" offset="1" align="center">
                <div class="baojing"/>
              </van-col>
              <van-col span="11"><span>失联数</span></van-col>
              <van-col span="2" offset="7" style="
              background: #db5a52;
              color: #fff;
              text-align: center;
              border-radius: 5px;
            "><span>{{ offlineCount }}</span></van-col>
            </van-row>
            <van-row @click="goDeviceList(deviceStateObject.warn)">
              <van-col span="1" offset="1" align="center">
                <div class="baojing"/>
              </van-col>
              <van-col span="11"><span>报警数</span></van-col>
              <van-col span="2" offset="7"
                       style="background: #db5a52;color: #fff;text-align: center;border-radius: 5px;">
                <span>{{ warnCount }}</span>
              </van-col>
            </van-row>
          </div>
        </div>
        <common-warn-card :type="type"/>
        <div v-if="this.$parent.isShowWarn" class="nav-bottom"/>
      </div>
    </div>
  </div>
</template>
<script>
  import {deviceCount, getDeviceState, getDeviceType} from "@/api/common/common.js";
  import constant from "@/api/common/constant.js"
  import commonWarnCard from "@/views/app/warn/common/warnCard";
  import commonHead from "@/views/app/common/head";

  export default {
    components: {
      commonWarnCard,
      commonHead
    },
    data() {
      return {
        sumCount: 0,
        warnCount: 0,
        type: constant.deviceTypeObject.elec,
        offlineCount: 0,
        showPopover: false,
        deviceStateObject: constant.deviceStateObject,
        deviceList: [],
        unitId: null,
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      this.getDeviceCount({unitId: this.unitId});
    },
    computed: {},
    methods: {
      goDeviceList(state) {
        this.$router.push({
          path: "/app/warn/common/deviceList",
          query: {type: this.type, state: state, unitId: this.unitId}
        });
      },
      getDeviceState(item) {
        return getDeviceState(item);
      },
      getDeviceType(item) {
        return getDeviceType(item);
      },
      getDeviceCount() {
        deviceCount({
          types: this.type,
          unitId: this.unitId
        }).then((response) => {
          if (response.success) {
            this.sumCount = response.data.sumCount;
            this.warnCount = response.data.warnCount;
            this.offlineCount = response.data.offlineCount;
          }
        })
          .catch((err) => {
            this.$toast(err + "");
          });
      },
    },
  };
</script>
<style scoped>
  .elec >>> .van-badge--fixed {
    position: absolute;
    top: 0;
    right: 0;
    -webkit-transform: translate(50%, -50%);
    transform: translate(30%, 20%);
    -webkit-transform-origin: 100%;
    transform-origin: 100%;
  }

</style>
