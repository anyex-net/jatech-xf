<template>
  <div>
    <div class="white-circle">
      <van-row>
        <van-col style="border-radius: 10px;" span="22" offset="1">
          <van-row style="height:10px" :border="false">
          </van-row>
          <van-row style="height:30px;display: flex;align-items: center;" :border="false">
            <van-col span="1" align="center">
              <div class="before"></div>
            </van-col>
            <van-col span="12" align="left" class="col"><span style="font-size: 16px;font-weight: bold;color: #3A3A44;"
                                                              class="font-PingFang">设备列表</span>
            </van-col>
            <van-col span="4" align="right" :offset="7" @click="goDeviceList(active)">
              <span style="color:#979797; font-size: 12px">更多<span style="position:relative;left:2px;">></span></span>
            </van-col>
          </van-row>
          <van-row style="height:10px;"/>
        </van-col>
      </van-row>
      <div style="position:relative" class="font-PingFang">
        <van-tabs title-active-color="#1989FA"
                  color="#1989FA" v-model="active" @click="onClick">
          <van-tab :title="item.title" :name="item.name" :key="index" v-for="(item,index) in filterArray">
            <van-loading v-if="isLoading" color="#1989fa"
                         style="width: 100%;height:90px;display: flex;align-items: center;justify-content: center"
                         vertical>
              <span style="color:#1989fa">加载中...</span>
            </van-loading>
            <div v-if="isLoading === false && (deviceList == null || deviceList.length === 0)">
              <van-cell-group>
                <div class="noMore">没有更多了</div>
              </van-cell-group>
            </div>
            <div v-for="(item, index) in deviceList">
              <div style="height: 2px;background: #F4F4F4;"/>
              <div class="item" @click="goDeviceDetail(item)" :key="index">
                <div class="item-top">
                  <span class="title">{{getCode(item)}}</span>
                  <span v-if="getDeviceState(item) !== '在线'" class="status">{{getDeviceState(item)}}</span>
                  <span v-if="getDeviceState(item) === '在线'"
                        class="font-green">{{getDeviceState(item)}}</span>
                </div>
                <div class="item-bottom">
                  <span class="bdname">{{item.unitName}}</span>
                  <span class="bdname1">{{item.position}}</span>
                </div>
                <div class="item-bottom">
                  <span>{{getValue(item)}}</span>
                  <span>{{item.heartTime}}</span>
                </div>
              </div>
            </div>
          </van-tab>
        </van-tabs>
      </div>
    </div>
  </div>
</template>

<script>

  import {getDeviceState} from "@/api/common/common.js";
  import {devicePage} from "@/api/common/common";
  import constant from "@/api/common/constant";
  import waterConstant from "@/api/water/constant"

  export default {
    data() {
      return {
        isLoading: true,
        constant: constant,
        deviceList: [],
        active: 0,
        deviceStateObject: constant.deviceStateObject,
        filterArray: [],
        waterConstant: waterConstant,
        tabArray: [{
          title: '报警设备',
          name: constant.deviceStateObject.warn,
          type: 'xks,smoke,temp,gas,btn,elec,water,xfs,bottle'
        },
          {title: '故障设备', name: constant.deviceStateObject.fault, type: 'xks, smoke,temp,gas,btn,elec,xfs'},
          {
            title: '异常设备',
            name: constant.deviceStateObject.abnormal,
            type: 'xks,smoke,temp,gas,btn,elec,water,xfs,bottle,switchs'
          },
          {title: '屏蔽设备', name: constant.deviceStateObject.shield, type: 'xks'}]
      };
    },
    created() {
      this.tabArray.forEach(item => {
        if (item.type.split(',').indexOf(this.type) >= 0) {
          this.filterArray.push(item)
        }
      })
      this.active = constant.deviceStateObject.warn;
      this.getDeviceList(this.active, this.type, this.sensorTypes, this.xksId, this.unitId);

    },
    mounted() {

    },
    computed: {},
    methods: {
      refresh(type, sensorTypes) {
        this.filterArray = []
        this.tabArray.forEach(item => {
          if (item.type.split(',').indexOf(type) >= 0) {
            this.filterArray.push(item)
          }
        })
        this.getDeviceList(this.active, type, sensorTypes, this.xksId, this.unitId)
      },
      refreshXks(type, xksId) {
        this.filterArray = []
        this.tabArray.forEach(item => {
          if (item.type.split(',').indexOf(type) >= 0) {
            this.filterArray.push(item)
          }
        })
        this.getDeviceList(this.active, type, null, this.xksId, this.unitId)
      },
      onClick(active) {
        this.deviceList = [];
        this.isLoading = true;
        this.getDeviceList(active, this.type, this.sensorTypes, this.xksId, this.unitId);
      },
      goDeviceList(state) {
        this.$router.push({
          path: "/app/warn/common/deviceList",
          query: {state: state, type: this.type, xksId: this.xksId, unitId: this.unitId}
        });
      },
      goDeviceDetail(item) {
        if (item.type === this.constant.deviceTypeObject.water) {
          this.$router.push({path: "/app/warn/water/sensorDetail", query: {type: this.type, id: item.id}})
        } else {
          this.$router.push({path: "/app/warn/common/deviceDetail", query: {type: this.type, id: item.id}});
        }
      },
      getCode(item) {
        if (this.type === this.constant.deviceTypeObject.bottle) {
          return item.deviceId + '-' + item.address
        } else if (this.type === this.constant.deviceTypeObject.switchs) {
          return item.deviceId + '-' + item.address
        } else if (this.type === this.constant.deviceTypeObject.xks) {
          return item.transmissionCode + '-' + item.sysAddress + '-' + item.deviceCode
        } else {
          return item.imei
        }
      },
      getValue(item) {
        let name = '';
        if (item.name.length > 10) name = item.name.substring(0, 10) + '..'
        else name = item.name
        if (this.type === this.constant.deviceTypeObject.bottle) {
          if (item.pressure) return name + '(' + item.pressure + 'Mpa)'
          else return name
        } else if (this.type === this.constant.deviceTypeObject.switchs) {
          if (item.switchState === 1) return name + '(' + '断开' + ')'
          else return name + '(' + '闭合' + ')'
        } else if (this.type === this.constant.deviceTypeObject.xfs) {
          if (item.waterPressure) return name + '(' + item.waterPressure + ')' + 'Mpa'
          else return name
        } else if (this.type === this.constant.deviceTypeObject.gas) {
          if (item.gasVal) return name + '(' + item.gasVal + ')'
          else return name
        } else if (this.type === this.constant.deviceTypeObject.water) {
          let positionObject = this.waterConstant.positionOptions.find(item1 => item1.typeId === item.sensorType
            && item1.id === item.onPosition);
          if (positionObject) {
            if (item.sensorData)
              return positionObject.name + '：' + item.sensorData + positionObject.unit
            else return name + '：无';
          } else return name
        } else {
          return name;
        }
      },
      getDeviceState(item) {
        return getDeviceState(item);
      },
      getDeviceList(state, type, sensorTypes, xksId, unitId) {
        let deviceTypeObject = this.constant.deviceTypeOptions.find(item1 => item1.key === type);
        let typeName = '';
        if (deviceTypeObject) typeName = deviceTypeObject.value
        devicePage({
          pageNo: 1,
          pageSize: 3,
          sensorTypes: sensorTypes,
          xksId: xksId,
          state: state,
          states: state,
          unitId: unitId
        }, type).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.deviceList = response.data.rows;
            this.deviceList.forEach(item => {
              item.typeName = typeName
            })
          }
        }).catch((err) => {
          this.$toast(err + "1");
          this.isLoading = false;
        });
      },
    },
    props: {
      sensorTypes: {
        required: false,
        type: String
      },
      type: {
        required: true,
        type: String
      },
      unitId: {
        required: false,
        type: String
      },
      isShield: {
        type: Boolean,
        default: false,
      },
      xksId: {
        type: String,
        required: false,
      }
    },
  };
</script>

<style>

</style>
