<template>
  <div>
    <common-head
      :is-back="true"
      :custom-title="true"
      :custom-right="true"
      background-color="#FFFFFF"
      :back-img="require('@/assets/images/new/back1.png')"
      back-img-style="width: 8px;height: 16px"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">{{ title }}</span>
      </template>
      <template #right>
        <van-button
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF"
          @click="save"
        >保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card">
          <div class="form device-form">
            <van-form ref="formRef">
              <my-select
                ref="unitRef"
                :is-bottom="true"
                :required="true"
                label="联网单位"
                :rules="rules.unitId"
                placeholder="点击选择联网单位"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="unitOptions"
                @confirm="(value)=>{this.temp.unitId = value; }"
              />
              <my-select
                v-if="!isEdit"
                ref="platformRef"
                :rules="rules.platform"
                :is-bottom="true"
                label="接入平台"
                :required="true"
                placeholder="点击选择接入平台"
                filterable
                s-label="name"
                s-value="code"
                input-align="right"
                :options="platformOptions"
                @confirm="(value)=>{this.temp.platform = value;this.modelOptions=[]; this.$refs.modelRef.value= null;this.getModel(this.temp.platform, this.temp.provider, this.type)}"
              />
              <my-select
                v-if="!isEdit"
                ref="providerRef"
                :rules="rules.provider"
                label="厂　　家"
                :is-bottom="true"
                :required="true"
                placeholder="点击选择厂家"
                filterable
                s-label="name"
                s-value="code"
                input-align="right"
                :options="providerOptions"
                @confirm="(value)=>{this.temp.provider = value;this.modelOptions=[];this.$refs.modelRef.value= null; this.getModel(this.temp.platform, this.temp.provider, this.type)}"
              />
              <my-select
                v-if="!isEdit"
                ref="modelRef"
                :rules="rules.model"
                :is-bottom="true"
                label="型　　号"
                placeholder="点击选择型号"
                :required="true"
                filterable
                s-label="value"
                s-value="value"
                input-align="right"
                :options="modelOptions"
                @confirm="(value)=>{this.temp.model = value}"
              />
              <my-select
                v-if="!isEdit"
                ref="isRegisterRef"
                :rules="rules.isRegister"
                label="是否注册"
                :is-bottom="true"
                placeholder="点击选择是否注册"
                :required="true"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="isRegisterOptions"
                @confirm="(value)=>{this.temp.isRegister = value}"
              />
              <van-field
                v-if="this.temp.isRegister !== null && this.temp.isRegister === 0 && !isEdit"
                v-model="temp.deviceId"
                required
                :rules="rules.deviceId"
                label="设备ID"
                input-align="right"
                placeholder="请输入设备ID"
              />
              <my-select
                v-if="type === deviceTypeObject.water"
                ref="waterDeviceTypeRef"
                label="设备类型"
                :rules="rules.sensorType"
                :is-bottom="true"
                :required="true"
                placeholder="点击选择设备类型"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="sensorTypeOptions"
                @confirm="(value)=>{this.temp.sensorType = value}"
              />
              <van-field
                v-model="temp.name"
                :rules="rules.name"
                :is-bottom="true"
                required
                label="设备名称"
                input-align="right"
                placeholder="请输入设备名称"
              />
              <van-field
                v-if="!isEdit"
                v-model="temp.imei"
                :rules="rules.imei"
                :is-bottom="true"
                required
                label="imei　号"
                right-icon="scan"
                input-align="right"
                placeholder="扫码获取"
                @click-right-icon="scan"
              />
              <van-field
                v-model="temp.position"
                :rules="rules.position"
                required
                :is-bottom="true"
                input-align="right"
                label="位　　置"
                placeholder="请输入位置"
              />
              <van-field
                v-model="temp.address"
                :rules="rules.address"
                required
                :is-bottom="true"
                input-align="right"
                label="安装地址"
                placeholder="请输入安装地址"
              />
              <base-map-search
                ref="mapSearch"
                :is-edit="isEdit"
                :is-hide="true"
                :value="temp.address"
                :longitude="temp.lng"
                :latitude="temp.lat"
                @updateLocation="updateLocation"
              />
              <van-field
                v-model="temp.lng"
                :is-bottom="true"
                input-align="right"
                required
                label="经　　度"
                placeholder="请输入经度"
              />
              <van-field
                v-model="temp.lat"
                input-align="right"
                required
                label="纬　　度"
                placeholder="请输入纬度"
              />
              <van-field
                v-if="type === deviceTypeObject.water || type === deviceTypeObject.xfs"
                v-model="temp.minWarn"
                required
                :rules="rules.minWarn"
                input-align="right"
                label="最小预警"
                placeholder="请输入最小预警"
              />
              <van-field
                v-if="type === deviceTypeObject.water || type === deviceTypeObject.xfs"
                v-model="temp.maxWarn"
                :rules="rules.maxWarn"
                required
                input-align="right"
                label="最大预警"
                placeholder="请输入最大预警"
              />
              <van-field
                v-if="type === deviceTypeObject.water && temp.sensorType === 2"
                v-model="temp.floorSpace"
                :rules="rules.floorSpace"
                required
                input-align="right"
                label="底面　积"
                placeholder="请输入底面积"
              />
              <van-field
                v-if="type === deviceTypeObject.water && temp.sensorType === 2"
                v-model="temp.high"
                required
                input-align="right"
                label="总　　高:"
                placeholder="请输入总高"
              />
              <common-date-select
                :rules="rules.registerTime"
                required
                label="注册时间："
                placeholder="请选择注册时间"
                :value="temp.registerTime"
                @update="(value)=>{this.temp.registerTime = value}"
              />
              <van-field
                v-model="temp.allottedTime"
                :rules="rules.allottedTime"
                required
                input-align="right"
                type="number"
                label="到期年限："
                placeholder="请输入到期年限"
              />
              <common-upload-image ref="installPicRef" label="安装图片"/>
            </van-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import constant from '@/api/elec/constant'
  import BaseMapSearch from '@/components/Map/baseMapSearch'
  import {getPlatform, getProvider} from '@/api/common/index'
  import {sysUserSelector} from '@/api/system/userManage.js'
  import {deviceAdd} from '@/api/common/common.js'
  import waterConstant from '@/api/water/constant.js'
  import commonConstant from '@/api/common/constant.js'
  import commonHead from '@/views/app/common/head'
  import mySelect from '@/views/app/common/my-select/index'
  import {getModel} from '@/api/common'
  import store from '@/store'
  import CommonUploadImage from '@/components/Upload/CommonUploadImage'
  import CommonDateSelect from '@/components/selector/CommonDateSelect'
  import {deviceDetail, deviceEdit} from '../../../../api/common/common'
  import {getSignature} from '../../../../api/sys/wx'
  import wx from 'weixin-js-sdk'
  import {getSelectorList} from '../../../../api/sys/unit'

  export default {
    components: {BaseMapSearch, commonHead, mySelect, CommonUploadImage, CommonDateSelect},
    data() {
      return {
        type: '',
        showPicker1: false,
        factory: false,
        install: false,
        platform: false,
        showSelectPlatform: false,
        showSelectUnit: false,
        show: false,
        minDate: new Date('1995-07-01'),
        currentDate: new Date(),
        loading: false,
        platformOptions: [],
        providerOptions: [],
        modelOptions: [],
        unitOptions: [],
        DeviceName: '',
        constant: constant,
        userOptions: [],
        waterDeviceType: false,
        sensorTypeOptions: waterConstant.sensorTypeOptions,
        deviceTypeObject: commonConstant.deviceTypeObject,
        deviceTypeOptions: commonConstant.deviceTypeOptions,
        waterDeviceTypeOptions: waterConstant.deviceTypeOptions,
        isRegisterOptions: [{id: 1, name: '是'}, {id: 0, name: '否'}],
        title: '',
        isEdit: false,
        rules: {
          deviceId: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          sensorType: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          imei: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          address: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          registerTime: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          allottedTime: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          minWarn: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          maxWarn: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          position: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          isRegister: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          platform: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          provider: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          model: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          unitId: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          name: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          floorSpace: [{required: true, message: '', trigger: 'onBlur/onChange'}],
          high: [{required: true, message: '', trigger: 'onBlur/onChange'}]
        },
        id: null,
        application: store.getters.user.application,
        temp: {
          sensorType: null,
          high: null,
          floorSpace: null,
          registerTime: null,
          allottedTime: 2,
          allottedTimeUnit: 1,
          isRegister: null,
          deviceId: null,
          installPic: null,
          installUserId: null,
          installUserName: null,
          platform: null,
          platformName: null,
          provider: null,
          providerName: null,
          installDate: null,
          name: null,
          address: null,
          id: null,
          position: null,
          unitId: null,
          unitName: null,
          deviceType: null,
          model: null,
          imei: null,
          lng: null,
          lat: null,
          minWarn: null,
          maxWarn: null
        },
        unitId: null
      }
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId
      }
      this.type = this.$route.query.type
      const object = this.deviceTypeOptions.find(item => item.key === this.type)
      let operate = '添加'
      if (this.$route.query.id) {
        operate = '编辑'
        this.id = this.$route.query.id
        this.init(this.id)
      }
      if (object) this.title = operate + object.value + '设备'
      else {
        this.title = operate + '未知类型设备'
      }
      getPlatform().then((response) => {
        this.platformOptions = response.data
      })
      getProvider({deviceType: this.type}).then((response) => {
        this.providerOptions = response.data
      })
      getSelectorList({isOnline: 1}).then((response) => {
        this.unitOptions = response.data
        if (this.unitId) {
          this.temp.unitId = this.unitId
          if (this.unitOptions.find(item => item.id === this.temp.unitId)) {
            this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.temp.unitId).name
          }
        }
      })
      if (window.AndroidWebView) {
        window.AndroidWebView.setBarCodeCB('toScan')
      }
      window.toScan = this.toScan
    },
    beforeDestroy() {
      delete window.toScan
    },
    methods: {
      getUserList(unitId) {
        sysUserSelector({unitId: unitId}).then((response) => {
          this.userOptions = response.data
        })
      },
      init(id) {
        this.isEdit = true
        deviceDetail(this.type, id).then(response => {
          if (response.success) {
            this.temp = response.data
            if (this.temp.allottedTimeUnit == null) {
              this.temp.allottedTimeUnit = 1
            }
            if (this.temp.address && this.temp.lng && this.temp.lat) {
              this.$refs.mapSearch.updateAddress(this.temp.address, this.temp.lng, this.temp.lat)
            }
            this.$refs.installPicRef.setFileList(this.temp.installPic)
            this.$refs.unitRef.value = response.data.unitName
            // this.getUserList(this.temp.unitId);
            // this.$refs.userRef.value = this.temp.installUserName
          }
        })
      },
      getSignUrl() {
        let signLink = ''
        const ua = navigator.userAgent.toLowerCase()
        if (/iphone|ipad|ipod/.test(ua)) {
          signLink = localStorage.getItem('firstUrl')
          if (!signLink) signLink = location.href
        } else {
          signLink = location.href
        }
        return signLink
      },
      scan() {
        if (this.application === 'app' && window.AndroidWebView) {
          window.AndroidWebView.startScan()
        } else if (this.application === 'wx') {
          const url = this.getSignUrl()
          getSignature({url: url}).then(response => {
            if (response.success) {
              // 生成签名
              // jsapi_ticket 后台获取
              // noncestr 随机字符串
              // timestamp 当前时间戳
              // url 当前url，不算hash值
              // 按照以上顺序以键值对的形式连接起来（所有属性值均为原始值），在通过sha1加密形成签名。
              wx.config({
                debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                appId: response.data.appId, // 必填，公众号的唯一标识
                timestamp: response.data.timestamp, // 必填，生成签名的时间戳
                nonceStr: response.data.nonceStr, // 必填，生成签名的随机串
                signature: response.data.signature, // 必填，签名
                jsApiList: ['scanQRCode'] // 必填，需要使用的JS接口列表
              })
              wx.ready((res) => {
                // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
                this.isWxConfig = true // 放开扫码按钮限制
                wx.scanQRCode({
                  needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
                  scanType: ['qrCode', 'barCode'], // 可以指定扫二维码还是一维码，默认二者都有
                  success: (res) => {
                    alert("成功")
                    const result = res.resultStr // 当needResult 为 1 时，扫码返回的结果
                    this.toScan(result)
                  },
                  fail: (res) => {
                    this.$toast('调用扫码失败' + JSON.stringify(res))
                  },
                  complete: (res) => {

                  }
                })
              })
              wx.error((res) => {
                this.$toast('调用扫码失败' + JSON.stringify(res))
                // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查    看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
              })
            }
          })
        }
      },
      toScan(val) {
        this.temp.imei = val
      },
      getModel(platform, provider, type) {
        getModel({platform: platform, provider: provider, type: type}).then(response => {
          if (response.success) {
            response.data.forEach(item => {
              this.modelOptions.push({value: item})
            })
          }
        })
      },
      goBack() {
        const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
        const path = routeArray[routeArray.length - 1]
        this.$router.push(path)
      },
      updateLocation(lng, lat, address) {
        this.temp.lng = lng
        this.temp.lat = lat
        this.temp.address = address
      },
      formatDate(date) {
        return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`
      },
      onConfirm(date) {
        this.show = false
        this.temp.installDate = this.formatDate(date)
      },
      save() {
        this.$refs.formRef.validate().then(() => {
          this.loading = true
          store.commit('showLoading')
          this.temp.installPic = ''
          this.$refs.installPicRef.fileList.forEach(item => {
            this.temp.installPic = this.temp.installPic + item.fileId + ','
          })
          if (!this.isEdit) {
            deviceAdd(this.type, this.temp)
              .then((response) => {
                if (response.success) {
                  store.commit('hideLoading')
                  this.loading = false
                  this.$toast('保存成功')
                  setTimeout(this.goBack(), 500)
                } else {
                  this.loading = false
                  this.$toast(response.message)
                }
              })
              .catch((err) => {
                store.commit('hideLoading')
                this.loading = false
                this.$toast(err + '')
              })
          } else {
            deviceEdit(this.type, this.temp)
              .then((response) => {
                if (response.success) {
                  store.commit('hideLoading')
                  this.loading = false
                  this.$toast('保存成功')
                  setTimeout(this.goBack(), 500)
                } else {
                  this.loading = false
                  this.$toast(response.message)
                }
              })
              .catch((err) => {
                store.commit('hideLoading')
                this.loading = false
                this.$toast(err + '')
              })
          }
        }).catch(err => {

        })
      }
    }
  }
</script>

<style scoped>

  .device-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

</style>
