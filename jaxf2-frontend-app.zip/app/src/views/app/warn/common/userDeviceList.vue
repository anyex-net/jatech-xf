<template>
  <div>
    <common-head :isBack="true" title="人员设备列表" :isAdd1="true" @goAdd="goAdd"/>

    <div class="cards-navbar" style="background: #F4F4F4;">
      <div class="white-circle">
        <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
          <div v-for="(item, index) in userDeviceList" :key="index">
            <van-swipe-cell>
              <div class="item">
                <div class="item-top">
                  <span class="title">{{item.name}}({{item.phone}})</span>
                  <van-button @click="bind(item.userId)" plain hairline type="primary"
                              size="small"
                              v-if="item.id===null">
                    绑定
                  </van-button>
                  <van-button @click="unBind(item.userId)" plain hairline type="danger" size="small"
                              v-if="item.id!==null">
                    解绑
                  </van-button>
                </div>
              </div>
              <template #right>
                <van-button v-if="hasBtnPermission(type + ':device:del')"
                            style="height: 100%" square text="删除" type="danger"
                            @click="deleteUserDevice(item)"
                            class="delete-button"/>
              </template>
            </van-swipe-cell>
            <div style="height: 4px;background: #F4F4F4;"/>
          </div>
          <div v-if="userDeviceList.length === 0">
            <van-cell-group>
              <div class="noMore">没有更多了</div>
            </van-cell-group>
          </div>
        </van-pull-refresh>
      </div>
    </div>

  </div>
</template>
<script>
  import commonHead from "@/views/app/common/head";
  import mySelect from '@/views/app/common/my-select/index';
  import {hasBtnPermission} from "../../../../utils/permission";
  import store from "@/store";
  import {deleteUserDevice, userDeviceBind, userManagerPage} from "../../../../api/common";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        userDeviceList: [],
        loading: false,
        finished: false,
        isLoading: false,
        listQuery: {
          unitId: null,
          deviceId: null,
          pageNo: 1,
          pageSize: 10
        },
        type: null,
      };
    },
    created() {
      this.type = this.$route.query.type;
      this.listQuery.unitId = this.$route.query.unitId;
      this.listQuery.deviceId = this.$route.query.deviceId;
      this.getUserDevicePage();
    },
    mounted() {

    },
    computed: {},
    methods: {
      goAdd() {
        this.$router.push(
          {
            path: "/app/warn/common/userDeviceForm",
            query: {type: this.type, deviceId: this.listQuery.deviceId}
          }
        );
      },
      bind(userId) {
        this.$dialog
          .confirm({
            message: "是否绑定",
          }).then(() => {
          store.commit('showLoading')
          userDeviceBind(this.type, {userId: userId, deviceId: this.listQuery.deviceId, isBind: true})
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.onRefresh();
              } else {
                this.$toast(response.message);
              }
            }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      unBind(userId) {
        this.$dialog
          .confirm({
            message: "是否解绑",
          }).then(() => {
          store.commit('showLoading')
          userDeviceBind(this.type, {userId: userId, deviceId: this.listQuery.deviceId, isBind: false})
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.onRefresh();
              } else {
                this.$toast(response.message);
              }
            }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      deleteUserDevice(item) {
        this.$dialog
          .confirm({
            message: "是否删除",
          }).then(() => {
          store.commit('showLoading')
          deleteUserDevice(this.type, item)
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.onRefresh();
              } else {
                this.$toast(response.message);
              }
            }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      hasBtnPermission(value) {
        if (value != null) {
          value = value.replace('switchs', 'switch')
          return hasBtnPermission(value)
        } else {
          return false;
        }
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      reset() {

      },
      getUserDevicePage() {
        this.listQuery.states = this.listQuery.state
        userManagerPage(this.type, this.listQuery).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.userDeviceList = response.data;
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
      onRefresh() {
        this.userDeviceList = [];
        this.getUserDevicePage();
      },
    },
  };
</script>
<style lang="less" scoped>

  .van-pull-refresh {
    position: relative;
    transition: all 0.5s;
  }

  .van-pull-refresh.active {
    margin-top: 20px;
    transition: all 0.5s;
  }

  .van-swipe {
    width: 100% !important;
    padding: 10px 10px 10px 10px;
    line-height: 30px;
    font-size: 14px;
  }

  .swipeActive {
    background-color: #1989fa;
    color: #fff;
    border-radius: 5px;
  }

  .cards-swipe {
    position: fixed;
    width: 100%;
    overflow-y: scroll;
    top: 174px;
    top: calc(174px + constant(safe-area-inset-top));
    top: calc(174px + env(safe-area-inset-top));
    bottom: 0px;
    bottom: calc(0px + constant(safe-area-inset-bottom));
    bottom: calc(0px + env(safe-area-inset-bottom));
  }
</style>
