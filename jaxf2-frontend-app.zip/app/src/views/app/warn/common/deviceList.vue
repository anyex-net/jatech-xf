<template>
  <div>
    <common-head @searchShow="showList=!showList" :isBack="true"
                 :title="typeName + '设备列表('+ deviceCount+')'" :isMore="true" :filterActions="filterActions"
                 @onSelect="onSelect"/>

    <div v-show="showList === false" class="cards-navbar" style="background: #F4F4F4;">
      <div class="card search">
        <my-select
          ref="unitRef"
          label="联网单位："
          placeholder="点击选择联网单位"
          filterable
          s-label="name"
          s-value="id"
          :isBottom="true"
          input-align="right"
          :options="unitOptions"
          @confirm="(value)=>{this.listQuery.unitId = value}"
        />
        <my-select
          label="传感器类型："
          ref="sensorTypeRef"
          :isBottom="true"
          placeholder="点击选择传感器类型"
          v-if="constant.deviceTypeObject.water === type"
          filterable
          s-label="name"
          s-value="id"
          input-align="right"
          :options="sensorTypeOptions"
          @confirm="(value)=>{this.listQuery.sensorTypes = value}"
        />
        <my-select
          ref="deviceStateRef"
          label="设备状态："
          :isBottom="true"
          placeholder="点击选择设备状态"
          filterable
          s-label="label"
          s-value="value"
          input-align="right"
          :options="deviceStateOptions"
          @confirm="(value)=>{this.listQuery.state = value}"
        />
        <van-field input-align="right" v-model="listQuery.name" label="设备名称：" placeholder="请输入设备名称"/>
        <van-field input-align="right" v-if="type !== constant.deviceTypeObject.xks && type !== constant.deviceTypeObject.bottle
            && type !== constant.deviceTypeObject.switchs"
                   v-model="listQuery.imei" label="imei　号：" placeholder="请输入imei号"/>
        <van-field input-align="right" v-if="constant.deviceTypeObject.xks===type"
                   v-model="listQuery.deviceCode"
                   label="设备编码：" placeholder="请输入设备码"/>
        <van-field input-align="right"
                   v-if="type === constant.deviceTypeObject.bottle || type === constant.deviceTypeObject.switchs"
                   v-model="listQuery.deviceId" label="网关编号：" placeholder="请输入网关编号"/>
        <div class="btn-wrapper">
          <van-row type="flex" justify="space-between">
            <van-col span="11">
              <van-button class="orange button" @click="reset">
                重置
              </van-button>
            </van-col>
            <van-col span="11">
              <van-button class="blue button" @click="search">搜索
              </van-button>
            </van-col>
          </van-row>
        </div>
      </div>
    </div>

    <div v-show="showList === true" class="content font-PingFang">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="white-circle">
          <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
            <van-list v-model="loading" :finished="finished"
                      :immediate-check="false"
                      finished-text="没有更多了"
                      v-on:load="onLoad"
                      ref="deviceList"
            >
              <div v-for="(item, index) in deviceList" :key="index">
                <van-swipe-cell>
                  <div class="item" @click="goDeviceDetail(item)">
                    <div class="item-top">
                      <span class="title">{{getCode(item)}}</span>
                      <span v-if="getDeviceState(item) !== '在线'" class="status">{{getDeviceState(item)}}</span>
                      <span v-if="getDeviceState(item) === '在线'"
                            class="font-green">{{getDeviceState(item)}}</span>
                    </div>
                    <div class="item-bottom">
                      <span class="bdname">{{item.unitName}}</span>
                      <span class="bdname1">{{item.position}}</span>
                    </div>
                    <div class="item-bottom">
                      <span class="bdname">{{getValue(item)}}</span>
                      <span class="bdname1">{{item.heartTime}}</span>
                    </div>
                  </div>
                  <template #right>
                    <van-button
                      v-if="hasBtnPermission('switch:device:control') && type === constant.deviceTypeObject.switchs"
                      style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                      square
                      text="控制" @click="switchControl(item)"/>
                    <van-button
                      v-if="hasBtnPermission(type + ':device:edit') && type !== constant.deviceTypeObject.xks"
                      style="height: 100%;background-color: #1989fa !important;color:#ffffff"
                      square
                      text="编辑" @click="editDevice(item)"/>
                    <van-button
                      v-if="hasBtnPermission(type + ':device:del') && type !== constant.deviceTypeObject.xks"
                      style="height: 100%" square text="删除" type="danger"
                      @click="deleteDevice(item)"
                      class="delete-button"/>
                  </template>
                </van-swipe-cell>
                <div style="height: 4px;background: #F4F4F4;"/>
              </div>
            </van-list>
          </van-pull-refresh>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import {devicePage, getDeviceState, getDeviceType} from "@/api/common/common.js";
  import constant from "@/api/common/constant.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from '@/views/app/common/my-select/index';
  import {hasBtnPermission} from "../../../../utils/permission";
  import {deviceDel} from "../../../../api/common/common";
  import store from "@/store";
  import waterConstant from "@/api/water/constant"
  import {getSelectorList} from "../../../../api/sys/unit";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        deviceList: [],
        loading: false,
        typeName: '',
        deviceCount: 0,
        showList: true,
        finished: false,
        isLoading: false,
        unitId: null,
        listQuery: {
          deviceType: null,
          sensorTypes: null,
          deviceId: null,
          deviceCode: null,
          name: null,
          pageNo: 1,
          pageSize: 10,
          states: null,
          state: null,
          imei: null,
          unitId: null,
          xksId: null,
        },
        type: null,
        typeOptions: constant.deviceTypeOptions,
        deviceStateOptions: constant.deviceStateOptions,
        constant: constant,
        unitOptions: [],
        sensorTypeOptions: waterConstant.sensorTypeOptions1,
        waterConstant: waterConstant,
        filterActions: [{
          text: '查询设备',
          icon: 'search',
          code: 'search'
        }],
        unitId: null,
        actions: [
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'smoke',
            permission: 'smoke:device:add',
            path: "/app/warn/common/deviceForm?type=smoke"
          },
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'temp',
            permission: 'temp:device:add',
            path: "/app/warn/common/deviceForm?type=temp"
          },
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'gas',
            permission: 'gas:device:add',
            path: "/app/warn/common/deviceForm?type=gas"
          },
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'elec',
            permission: 'elec:device:add',
            path: "/app/warn/common/deviceForm?type=elec"
          },
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'btn',
            permission: 'btn:device:add',
            path: "/app/warn/common/deviceForm?type=btn"
          },
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'xfs',
            permission: 'xfs:device:add',
            path: "/app/warn/common/deviceForm?type=xfs"
          },
          {
            text: '网关管理',
            icon: 'edit',
            type: 'bottle',
            permission: 'bottle:gate:add',
            path: "/app/warn/bottle/gateList"
          },
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'bottle',
            permission: 'bottle:device:add',
            path: "/app/warn/bottle/deviceForm"
          },
          {
            text: '网关管理',
            icon: 'edit',
            type: 'switchs',
            permission: 'switch:gate:add',
            path: "/app/warn/switchs/gateList"
          },
          {
            text: '新增设备',
            icon: 'add-o',
            type: 'switchs',
            permission: 'switch:device:add',
            path: "/app/warn/switchs/deviceForm"
          },
          {
            text: '水主机管理',
            icon: 'edit',
            type: 'water',
            permission: 'water:device:add',
            path: "/app/warn/water/deviceList"
          },
          {
            text: '添加传感器',
            icon: 'edit',
            type: 'water',
            permission: 'water:deviceSensor:add',
            path: "/app/warn/water/sensorForm"
          }
        ],
      };
    },
    created() {
      if (this.$route.query.type) {
        this.type = this.$route.query.type;
        let deviceTypeObject = this.typeOptions.find(item1 => item1.key === this.type);
        if (deviceTypeObject) this.typeName = deviceTypeObject.value
        this.actions.forEach(item1 => {
          if (this.hasBtnPermission(item1.permission) && item1.type === this.$route.query.type) {
            this.filterActions.push(item1)
          }
        })
      }
      if (this.$route.query.sensorTypes) {
        this.listQuery.sensorTypes = this.$route.query.sensorTypes;
        this.$nextTick(() => {
          let sensorTypeObject = this.sensorTypeOptions.find(item => item.id === this.$route.query.sensorTypes)
          if (sensorTypeObject)
            this.$refs.sensorTypeRef.value = sensorTypeObject.name;
        })
      }
      if (this.$route.query.state) {
        this.listQuery.state = this.$route.query.state;
        this.$nextTick(() => {
          let deviceStateObject = this.deviceStateOptions.find(item => item.value === this.listQuery.state)
          if (deviceStateObject) this.$refs.deviceStateRef.value = deviceStateObject.label
        })
      }
      if (this.$route.query.xksId) {
        this.listQuery.xksId = this.$route.query.xksId;
      }
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
        this.listQuery.unitId = this.$route.query.unitId;
      }
      this.loading = true;
      this.getDevicePage();
      this.getUnitList()
    },
    mounted() {

    },
    computed: {},
    methods: {
      onSelect(item) {
        if (item.code === 'search') {
          this.showList = false
        } else {
          this.$router.push({path: item.path, query: {unitId: this.unitId}});
        }
      },
      switchControl(item) {
        this.$router.push("/app/warn/switchs/controlList?id=" + item.id)
      },
      editDevice(item) {
        if (this.type === this.constant.deviceTypeObject.switchs) {
          this.$router.push("/app/warn/switchs/deviceForm?type=" + this.type + "&id=" + item.id + "&unitId=" + this.unitId)
        } else if (this.type === this.constant.deviceTypeObject.bottle) {
          this.$router.push("/app/warn/bottle/deviceForm?type=" + this.type + "&id=" + item.id + "&unitId=" + this.unitId)
        } else if (this.type === this.constant.deviceTypeObject.water) {
          this.$router.push("/app/warn/water/sensorForm?type=" + this.type + "&id=" + item.id + "&unitId=" + this.unitId)
        } else this.$router.push("/app/warn/common/deviceForm?type=" + this.type + "&id=" + item.id + "&unitId=" + this.unitId)
      },
      deleteDevice(item) {
        this.$dialog
          .confirm({
            message: "是否删除",
          }).then(() => {
          store.commit('showLoading')
          deviceDel(this.type, [item.id])
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.search();
              } else {
                this.$toast(response.message);
              }
            }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      hasBtnPermission(value) {
        if (value != null) {
          value = value.replace('switchs', 'switch')
          return hasBtnPermission(value)
        } else {
          return false;
        }
      },
      getSensorType(item) {
        let item1 = this.waterConstant.sensorTypeOptions.find(item1 =>
          item1.id == item
        );
        if (item1) return item1.name;
      },
      getUnitList() {
        getSelectorList({isOnline: 1}).then(response => {
          if (response.success) {
            this.unitOptions = response.data;
            if (this.listQuery.unitId) {
              if (this.unitOptions.find(item => item.id === this.listQuery.unitId))
                this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.listQuery.unitId).name
            }
          }
        })
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      goDeviceDetail(item) {
        if (this.type === this.constant.deviceTypeObject.water) {
          this.$router.push({
            path: "/app/warn/water/sensorDetail",
            query: {type: this.type, id: item.id, activeName: 'info'}
          })
        } else this.$router.push({
          path: "/app/warn/common/deviceDetail",
          query: {type: this.type, id: item.id, activeName: 'info'}
        })
      },
      reset() {
        this.listQuery = {
          sensorTypes: null,
          deviceCode: null,
          position: null,
          deviceId: null,
          pageNo: 1,
          pageSize: 10,
          state: null,
          name: null,
          imei: null,
          unitId: this.unitId
        }
        this.$refs.deviceStateRef.value = null;
        if (this.$refs.sensorTypeRef)
          this.$refs.sensorTypeRef.value = null;
      },
      search() {
        this.showList = true
        this.deviceList = [];
        this.listQuery.pageNo = 1;
        this.finished = false;
        this.loading = true;
        this.getDevicePage()
      },
      getCode(item) {
        if (this.type === this.constant.deviceTypeObject.bottle) {
          return item.deviceId + '-' + item.address
        } else if (this.type === this.constant.deviceTypeObject.switchs) {
          return item.deviceId + '-' + item.address
        } else if (this.type === this.constant.deviceTypeObject.xks) {
          return item.transmissionCode + '-' + item.sysAddress + '-' + item.deviceCode
        } else {
          return item.imei
        }
      },
      getValue(item) {
        let name = '';
        if (item.name.length > 10) name = item.name.substring(0, 10) + '..'
        else name = item.name
        if (this.type === this.constant.deviceTypeObject.bottle) {
          if (item.pressure) return name + '(' + item.pressure + 'Mpa)'
          else return name
        } else if (this.type === this.constant.deviceTypeObject.switchs) {
          if (item.switchState === 1) return name + '(' + '断开' + ')'
          else return name + '(' + '闭合' + ')'
        } else if (this.type === this.constant.deviceTypeObject.xfs) {
          if (item.waterPressure) return name + '(' + item.waterPressure + ')' + 'Mpa'
          else return name
        } else if (this.type === this.constant.deviceTypeObject.gas) {
          if (item.gasVal) return name + '(' + item.gasVal + ')'
          else return name
        } else if (this.type === this.constant.deviceTypeObject.water) {
          let positionObject = this.waterConstant.positionOptions.find(item1 => item1.typeId === item.sensorType
            && item1.id === item.onPosition);
          console.log(positionObject)
          if (positionObject) {
            if (item.sensorData == null) return positionObject.name + '：无'
            else return positionObject.name + '：' + item.sensorData + positionObject.unit
          } else return name
        } else {
          return name;
        }
      },
      getDeviceState(item) {
        return getDeviceState(item);
      },
      getDeviceType(item) {
        return getDeviceType(item);
      },
      getDevicePage() {
        this.listQuery.states = this.listQuery.state
        devicePage(this.listQuery, this.type).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.loading = false;
            this.deviceCount = response.data.totalRows
            this.deviceList = this.deviceList.concat(response.data.rows);
            // 如果加载完毕，显示没有更多了
            if (response.data.rows.length < this.listQuery.pageSize) {
              this.finished = true;
            }
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
      onLoad() {
        this.listQuery.pageNo++;
        this.getDevicePage();
      },
      onRefresh() {
        this.deviceList = [];
        this.listQuery.pageNo = 1;
        this.loading = true;
        this.isLoading = true;
        this.finished = false;
        this.getDevicePage();
      },
    },
  };
</script>
<style lang="less" scoped>

  .van-pull-refresh {
    position: relative;
    transition: all 0.5s;
  }

  .van-pull-refresh.active {
    margin-top: 20px;
    transition: all 0.5s;
  }

  .van-swipe {
    width: 100% !important;
    padding: 10px 10px 10px 10px;
    line-height: 30px;
    font-size: 14px;
  }

  .swipeActive {
    background-color: #1989fa;
    color: #fff;
    border-radius: 5px;
  }

  .cards-swipe {
    position: fixed;
    width: 100%;
    overflow-y: scroll;
    top: 174px;
    top: calc(174px + constant(safe-area-inset-top));
    top: calc(174px + env(safe-area-inset-top));
    bottom: 0px;
    bottom: calc(0px + constant(safe-area-inset-bottom));
    bottom: calc(0px + env(safe-area-inset-bottom));
  }
</style>
