<template>
  <div>
    <common-head :isBack="true" :customTitle="true"
                 background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px"
                 :customRight="true">
      <template #title>
        <span style="color: black;font-weight: bolder">{{title+'事件进程'}}</span>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="white-circle">
          <van-steps inactive-color="#969799" active-color="#969799" direction="vertical" :active="0">
            <van-step v-for="(item,index) in list" :key="index">
              <div>{{item.processDate}} {{getDealUserName(item)}}{{getState(item.state)}}</div>
              <br>
              <div style="font-size: 12px">{{getDescription(item)}}
                <span @click="handleNoticeRecord(item)" style="color: #1989fa"
                      v-if="getStateType(item) === 1">推送明细</span>
              </div>
              <div v-if="item.filePaths != null">
                <br>
                <span style="margin-right: 10px" v-for="(item1,index1) in item.filePaths" :key="index1">
                <van-image @click="Preview_img(item.filePaths,index1)" width="50" height="70" :src="item1"/>
              </span>
              </div>
            </van-step>
          </van-steps>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import commonHead from "@/views/app/common/head";
  import {eventProcessPage} from "@/api/common/common";
  import constant from "@/api/common/constant";
  import {sysFileGetPath} from "@/api/sys/fileManage";
  import {ImagePreview} from "vant";
  import store from "../../../../store";

  export default {
    components: {commonHead},
    data() {
      return {
        list: [],
        type: null,
        id: null,
        title: '',
        stateOptions: constant.handleStateOptions,
        imageUrls: [],
        imageIndex: 0,
      };
    },
    created() {
      if (this.$route.query.type) {
        this.type = this.$route.query.type;
      }
      if (this.$route.query.id) {
        this.id = this.$route.query.id;
      }
      if (this.$route.query.title) {
        this.title = this.$route.query.title;
      }
      this.getEventProcess(this.type, this.id);
    },
    mounted() {

    },
    computed: {},
    methods: {
      handleNoticeRecord(item) {
        this.$router.push({
          "path": "/app/warn/common/noticeRecord",
          query: {title: this.title, id: item.id, type: this.type}
        })
      },
      getStateType(item1) {
        return this.stateOptions.find(item => item.key === item1.state).type;
      },
      Preview_img(list, index) {
        ImagePreview({
          images: list, //图片数组
          showIndex: true,
          loop: false,
          closeable: true,
          startPosition: index,
        });
      },
      getDescription(item) {
        let memo;
        if (item.memo === null) memo = this.stateOptions.find(item1 => item1.key === item.state).value;
        else memo = item.memo;
        return item.deviceName + "设备" + item.eventDesc + "," + memo;
      },
      getDealUserName(item) {
        if (item.processUserName === null) return "系统自动"
        else return item.processUserName + "处理"
      },
      getState(state) {
        return this.stateOptions.find(item => item.key === state).value;
      },
      getEventProcess(type, id) {
        store.commit('showLoading')
        eventProcessPage(type, {eventId: id}).then(response => {
          if (response.success) {
            store.commit('hideLoading')
            this.list = response.data;
            this.list.forEach(item => {
              if (item.fileId !== null) {
                sysFileGetPath({"fileIds": item.fileId}).then((response) => {
                  if (response.success) {
                    this.$set(item, "filePaths", response.data)
                  }
                });
              }
            })
          }
        }).catch(err => {
          store.commit('hideLoading')
        })
      }
    },
  };
</script>

<style lang="less" scoped>

</style>
