<template>
  <div>
    <common-head :isBack="true" :customTitle="true"
                 background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px"
                 :customRight="true">
      <template #title>
        <span style="color: black;font-weight: bolder">{{title+'推送明细'}}</span>
      </template>
    </common-head>

    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="white-circle">
          <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
            <van-list v-model="loading" :finished="finished"
                      :immediate-check="false"
                      finished-text="没有更多了"
                      v-on:load="onLoad"
                      ref="list"
            >
              <div v-for="(item, index) in list" :key="index">
                <div class="item">
                  <div class="item-top">
                    <span class="name">{{item.channelName}}</span>
                    <span class="safe">{{getCode(item.code)}}</span>
                  </div>
                  <div class="item-bottom">
                    <span>{{item.unitName}}</span>
                    <span>{{item.createTime}}</span>
                  </div>
                  <div class="item-bottom">
                    <span>{{item.userName}}({{item.phone}})</span>
                    <span>{{item.message}}</span>
                  </div>
                </div>
                <div style="height: 5px;background: #F4F4F4;"/>
              </div>
            </van-list>
          </van-pull-refresh>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import commonHead from "@/views/app/common/head";
  import mySelect from '@/views/app/common/my-select/index';
  import {noticeRecordPage} from "@/api/common/common";
  import constant from "@/api/common/constant";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        list: [],
        loading: false,
        showList: true,
        finished: false,
        isLoading: false,
        listQuery: {
          pageNo: 1,
          pageSize: 10,
          eventProcessId: null,
        },
        type: null,
        id: null,
        title: null,
        recordStateOptions: constant.recordStateOptions
      };
    },
    created() {
      if (this.$route.query.type) {
        this.type = this.$route.query.type;
      }
      if (this.$route.query.id) {
        this.id = this.$route.query.id;
        this.listQuery.eventProcessId = this.id;
      }
      if (this.$route.query.title) {
        this.title = this.$route.query.title;
      }
      this.getNoticeRecordPage()
    },
    mounted() {

    },
    computed: {},
    methods: {
      getCode(code) {
        return this.recordStateOptions.find(item => item.key === code).value
      },
      getNoticeRecordPage() {
        noticeRecordPage(this.type, this.listQuery).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.loading = false;
            this.list = this.list.concat(response.data.rows);
            // 如果加载完毕，显示没有更多了
            if (response.data.rows.length < this.listQuery.pageSize) {
              this.finished = true;
            }
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
      onLoad() {
        this.listQuery.pageNo++;
        this.getNoticeRecordPage();
      },
      onRefresh() {
        this.deviceList = [];
        this.listQuery.pageNo = 1;
        this.loading = true;
        this.isLoading = true;
        this.finished = false;
        this.getNoticeRecordPage();
      },
    },
  };
</script>
<style lang="less" scoped>

  .van-pull-refresh {
    position: relative;
    transition: all 0.5s;
  }

  .van-pull-refresh.active {
    margin-top: 20px;
    transition: all 0.5s;
  }

  .van-swipe {
    width: 100% !important;
    padding: 10px 10px 10px 10px;
    line-height: 30px;
    font-size: 14px;
  }

  .swipeActive {
    background-color: #1989fa;
    color: #fff;
    border-radius: 5px;
  }

  .cards-swipe {
    position: fixed;
    width: 100%;
    overflow-y: scroll;
    top: 174px;
    top: calc(174px + constant(safe-area-inset-top));
    top: calc(174px + env(safe-area-inset-top));
    bottom: 0px;
    bottom: calc(0px + constant(safe-area-inset-bottom));
    bottom: calc(0px + env(safe-area-inset-bottom));
  }
</style>
