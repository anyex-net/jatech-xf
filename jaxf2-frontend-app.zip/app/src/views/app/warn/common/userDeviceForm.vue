<template>
  <div>
    <common-head :isBack="true" :customTitle="true"
                 background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px"
                 :customRight="true">
      <template #title>
        <span style="color: black;font-weight: bolder">添加临时人员绑定</span>
      </template>
      <template #right>
        <van-button @click="submit" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">设置
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card device-handle-form">
          <van-field
            :border="false"
            v-model="temp.name"
            input-align="left"
            placeholder="请输入姓名"
            label="姓　名："
          />
          <van-field
            :border="false"
            v-model="temp.mobile"
            placeholder="请输入手机号"
            input-align="left"
            label="手机号："
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import {addUserDevice} from "@/api/common";
  import store from "@/store";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        type: '',
        loading: false,
        temp: {
          deviceId: null,
          name: null,
          mobile: null,
        },
      };
    },
    created() {
      this.type = this.$route.query.type;
      this.temp.deviceId = this.$route.query.deviceId;
    },
    mounted() {

    },
    computed: {},
    methods: {
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      submit() {
        if (this.temp.name == null || this.temp.name === '') {
          this.$toast("名称必填");
          return;
        }
        if (this.temp.mobile == null || this.temp.mobile === '') {
          this.$toast("手机号必填");
          return;
        }
        store.commit('showLoading')
        addUserDevice(this.type, this.temp).then((response) => {
          if (response.success) {
            this.$toast("设置成功");
            store.commit('hideLoading')
            setTimeout(this.goBack(), 500);
          } else {
            store.commit('hideLoading')
            this.$toast(response.message);
          }
        }).catch((err) => {
          store.commit('hideLoading')
          this.$toast(err + "");
        });
      },
    },
  };
</script>

<style scoped>
  .preview-cover {
    position: absolute;
    bottom: 0;
    box-sizing: border-box;
    width: 100%;
    padding: 4px;
    color: #fff;
    font-size: 12px;
    text-align: center;
    background: rgba(0, 0, 0, 0.3);
  }

  .device-handle-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

  .defaultButton {

    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: transparent;
    padding: 1px 10px;
    font-size: 14px;
    height: 24px;
    position: relative;
    top: -4px;
    color: #707070
  }

  .defaultButton_active {
    font-size: 14px;
    padding: 1px 10px;
    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: #1989FA;
    color: #FFFFFF;
    height: 24px;
    position: relative;
    top: -4px;
  }
</style>
