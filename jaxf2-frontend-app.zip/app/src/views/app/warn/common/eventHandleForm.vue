<template>
  <div>
    <div class="card event-handle-form">
      <div class="white-circle">
        <van-steps inactive-color="#969799" active-color="#969799" direction="vertical" :active="0">
          <van-step v-for="(item,index) in list" :key="index">
            <div>{{item.processDate}} {{getDealUserName(item)}}{{getState(item.state)}}</div>
            <br>
            <div style="font-size: 12px">{{getDescription(item)}}
              <span @click="handleNoticeRecord(item)" style="color: #1989fa"
                    v-if="getStateType(item) === 1">推送明细</span>
            </div>
            <div v-if="item.filePaths != null">
              <br>
              <span style="margin-right: 10px" v-for="(item1,index1) in item.filePaths" :key="index1">
                <van-image @click="Preview_img(item.filePaths,index1)" width="50" height="70" :src="item1"/>
              </span>
            </div>
          </van-step>
        </van-steps>
      </div>
    </div>
    <div v-if="eventObject.state <= 201" class="card event-handle-form">
      <van-field
        readonly
        :border="false"
        v-model="eventObject.unitName"
        input-align="left"
        label="联网单位："
      />
      <van-field
        :border="false"
        v-model="eventObject.deviceName"
        readonly
        input-align="left"
        label="设备名称："
      />
      <van-field
        :border="false"
        v-model="eventObject.eventDesc"
        readonly
        input-align="left"
        label="事件描述："
        placeholder="请输入事件描述"
      />
      <van-field
        :border="false"
        v-model="eventObject.position"
        readonly
        input-align="left"
        label="位　　置："
      />
      <van-field
        :border="false"
        v-model="eventObject.eventTime"
        readonly
        input-align="left"
        label="事件时间："
      />
      <van-field
        :border="false"
        v-model="eventObject.receiveTime"
        readonly
        input-align="left"
        label="接收时间："
      />
      <van-field :border="false" input-align="left" name="radio"
                 label="处理结果：">
        <template #input>
          <van-radio-group style="height: 30px" v-model="state" direction="horizontal">
            <van-radio name="201">
              <template #icon="props">
                <button type="button" :class="props.checked ? 'defaultButton_active' : 'defaultButton'">处理中
                </button>
              </template>
            </van-radio>
            <van-radio name="301">
              <template #icon="props">
                <button type="button" :class="props.checked ? 'defaultButton_active' : 'defaultButton'">确认
                </button>
              </template>
            </van-radio>
            <van-radio name="302">
              <template #icon="props">
                <button type="button" :class="props.checked ? 'defaultButton_active' : 'defaultButton'">误报
                </button>
              </template>
            </van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <van-field :border="false"
                 input-align="left" readonly
                 label="处理说明："/>
      <div style="padding: 0px 10px;">
        <van-field
          input-align="left"
          label=""
          :required="true"
          v-model="message"
          rows="2"
          type="textarea"
          placeholder="请输入处理说明"
          show-word-limit
          style="background-color: #FAFAFA;border-radius: 6px;"
        />
      </div>
      <van-uploader :preview-full-image="true" preview-size="1.8rem" :after-read="afterRead"
                    v-model="fileList">
        <template #preview-cover="{ file }">
          <div class="preview-cover van-ellipsis">{{ file.name }}</div>
        </template>
        <van-button
          style="width:60px;height: 60px;margin-left: 10px;float: left;margin-top:10px;margin-bottom: 10px"
          icon="plus"/>
      </van-uploader>
    </div>
  </div>
</template>

<script>
  import {sysFileInfo} from "@/api/detail/index";
  import constant from "@/api/common/constant.js"
  import {eventHandle} from "@/api/common/common.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import {eventDetail, eventProcessPage} from "../../../../api/common/common";
  import {ImagePreview} from "vant";
  import {sysFileGetPath} from "../../../../api/sys/fileManage";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        value: "",
        state: "",
        list: [],
        loading: false,
        eventObject: {state: null},
        message: "",
        fileId: "",
        fileList: [],
        handleOptions: constant.handleOptions,
        stateOptions: constant.handleStateOptions,
        imageUrls: [],
        imageIndex: 0,
      };
    },
    props: {
      type: {
        type: String,
        required: false,
      },
      eventId: {
        type: String,
        required: false,
      },
    },
    created() {
      this.init()
    },
    mounted() {

    },
    computed: {},
    methods: {
      init() {
        this.getEventDetail();
        this.getEventProcess(this.type, this.eventId)
      },
      getEventDetail() {
        eventDetail(this.type, this.eventId).then(response => {
          if (response.success) {
            this.eventObject = response.data
            if (this.eventObject.state <= 201) {
              this.$emit("setEventHandle", true);
            } else {
              this.$emit("setEventHandle", false);
            }
          }
        })
      },
      afterRead(file) {
        // 此时可以自行将文件上传至服务器
        file.status = 'uploading'
        file.message = '上传中...'
        let content = file.file;
        let data = new FormData();
        data.append('file', content);
        sysFileInfo(data)
          .then((response) => {
            if (response.success) {
              file.status = 'success'
              file.fileId = response.data;
            } else {
              file.status = 'failed'
              file.message = '上传失败'
              this.$toast(response.message);
            }
          }).catch((err) => {
          file.status = 'failed'
          file.message = '上传失败'
          this.$toast(err + "");
        });
      },
      handle() {
        let fileId = "";
        if (this.fileList.filter(item => item.status === 'uploading').length !== 0) {
          this.$toast("图片正在上传")
          return;
        }
        if (this.fileList != null) {
          this.fileList.forEach((item) => {
            if (item.status === 'success')
              fileId = fileId + item.fileId + ","
          })
        }
        this.loading = true;
        if (!this.state && this.state !== 0) {
          this.$toast("处理结果必选")
          return;
        }
        if (this.memo === null) {
          this.$toast("处理说明必填")
          return;
        }
        eventHandle(this.type, {
          fileId: fileId,
          id: this.eventObject.id,
          memo: this.message,
          state: this.state
        }).then((response) => {
          if (response.success) {
            this.loading = false;
            this.$toast("处理成功");
            this.init()
          } else {
            this.loading = false;
            this.$toast(response.message);
          }
        }).catch((err) => {
          this.loading = false;
          this.$toast(err + "");
        });
      },
      handleNoticeRecord(item) {
        this.$router.push({
          "path": "/app/warn/common/noticeRecord",
          query: {title: item.eventDesc, id: item.id, type: this.type}
        })
      },
      getStateType(item1) {
        return this.stateOptions.find(item => item.key === item1.state).type;
      },
      Preview_img(list, index) {
        ImagePreview({
          images: list, //图片数组
          showIndex: true,
          loop: false,
          closeable: true,
          startPosition: index,
        });
      },
      getDescription(item) {
        let memo;
        if (item.memo === null) memo = this.stateOptions.find(item1 => item1.key === item.state).value;
        else memo = item.memo;
        return item.deviceName + "设备" + item.eventDesc + "," + memo;
      },
      getDealUserName(item) {
        if (item.processUserName === null) return "系统自动"
        else return item.processUserName + "处理"
      },
      getState(state) {
        return this.stateOptions.find(item => item.key === state).value;
      },
      getEventProcess(type, id) {
        eventProcessPage(type, {eventId: id}).then(response => {
          if (response.success) {
            this.list = response.data;
            this.list.forEach(item => {
              if (item.fileId !== null) {
                sysFileGetPath({"fileIds": item.fileId}).then((response) => {
                  if (response.success) {
                    this.$set(item, "filePaths", response.data)
                  }
                });
              }
            })
          }
        })
      }
    },
  };
</script>

<style scoped>

  .preview-cover {
    position: absolute;
    bottom: 0;
    box-sizing: border-box;
    width: 100%;
    padding: 4px;
    color: #fff;
    font-size: 12px;
    text-align: center;
    background: rgba(0, 0, 0, 0.3);
  }

  .event-handle-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

  .defaultButton {

    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: transparent;
    padding: 1px 10px;
    font-size: 14px;
    height: 24px;
    position: relative;
    top: -4px;
    color: #707070
  }

  .defaultButton_active {
    font-size: 14px;
    padding: 1px 10px;
    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: #1989FA;
    color: #FFFFFF;
    height: 24px;
    position: relative;
    top: -4px;
  }
</style>
