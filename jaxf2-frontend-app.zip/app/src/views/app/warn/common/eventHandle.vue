<template>
  <div>
    <common-head :isBack="true" :customTitle="true"
                 background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px"
                 :customRight="true">
      <template #title>
        <span style="color: black;font-weight: bolder">事件处理</span>
      </template>
      <template #right>
        <van-button @click="handle" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">提交
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card event-handle-form">
          <van-field
            :border="false"
            readonly
            v-model="eventObject.unitName"
            input-align="left"
            label="联网单位："
          />
          <van-field
            :border="false"
            v-model="eventObject.deviceName"
            readonly
            input-align="left"
            label="设备名称："
          />
          <van-field
            :border="false"
            v-model="eventObject.eventDesc"
            readonly
            input-align="left"
            label="事件描述："
            placeholder="请输入事件描述"
          />
          <van-field
            :border="false"
            v-model="eventObject.position"
            readonly
            input-align="left"
            label="位　　置："
          />
          <van-field
            :border="false"
            v-model="eventObject.eventTime"
            readonly
            input-align="left"
            label="事件时间："
          />
          <van-field
            :border="false"
            v-model="eventObject.receiveTime"
            readonly
            input-align="left"
            label="接收时间："
          />
          <van-field :border="false" input-align="left" name="radio"
                     label="处理结果：">
            <template #input>
              <van-radio-group style="height: 30px" @change="changeState" v-model="state"
                               direction="horizontal">
                <van-radio name="201">
                  <template #icon="props">
                    <button type="button"
                            :class="props.checked ? 'defaultButton_active' : 'defaultButton'">处理中
                    </button>
                  </template>
                </van-radio>
                <van-radio name="301">
                  <template #icon="props">
                    <button type="button"
                            :class="props.checked ? 'defaultButton_active' : 'defaultButton'">误报
                    </button>
                  </template>
                </van-radio>
                <van-radio name="302">
                  <template #icon="props">
                    <button type="button"
                            :class="props.checked ? 'defaultButton_active' : 'defaultButton'">确认
                    </button>
                  </template>
                </van-radio>
              </van-radio-group>
            </template>
          </van-field>
          <my-select v-if="state === '301'"
                     label="误报原因"
                     :required="true"
                     placeholder="点击选择误报原因"
                     filterable
                     s-label="name"
                     s-value="id"
                     input-align="left"
                     :isBottom="true"
                     ref="eventProcessOptionRef"
                     :options="eventProcessFilterOptions"
                     @confirm="(value)=>{this.eventProcessOptionId = value}"
          />

          <my-select
            v-if="state === '302' &&
            ((this.type === this.deviceTypeObject.xks && eventObject.deviceState === 1) ||
            ((this.type === this.deviceTypeObject.smoke || this.type === this.deviceTypeObject.gas
             || this.type === this.deviceTypeObject.temp || this.type === this.deviceTypeObject.btn || this.type === this.deviceTypeObject.elec) && eventObject.eventType === 1))"
            label="确认级别"
            :required="true"
            placeholder="点击选择确认级别"
            filterable
            s-label="name"
            s-value="id"
            input-align="left"
            :isBottom="true"
            ref="eventProcessOptionRef"
            :options="eventProcessFilterOptions"
            @confirm="(value)=>{this.eventProcessOptionId = value}"
          />

          <van-field :border="false" readonly
                     input-align="left"
                     label="处理说明："/>
          <div style="padding: 0px 10px;">
            <van-field
              input-align="left"
              label=""
              v-model="message"
              rows="2"
              type="textarea"
              placeholder="请输入处理说明"
              show-word-limit
              style="background-color: #FAFAFA;border-radius: 6px;"
            />
          </div>
          <van-uploader :preview-full-image="true" preview-size="1.8rem" :after-read="afterRead"
                        v-model="fileList">
            <template #preview-cover="{ file }">
              <div class="preview-cover van-ellipsis">{{ file.name }}</div>
            </template>
            <van-button
              style="width:60px;height: 60px;margin-left: 10px;float: left;margin-top:10px;margin-bottom: 10px"
              icon="plus"/>
          </van-uploader>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {sysFileInfo} from "@/api/detail/index";
  import constant from "@/api/common/constant.js"
  import {eventHandle} from "@/api/common/common.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import {eventDetail} from "../../../../api/common/common";
  import {getEventProcessOptions} from "../../../../api/common";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        value: "",
        state: "",
        eventProcessOptionId: null,
        eventProcessOptions: [],
        eventProcessFilterOptions: [],
        loading: false,
        eventObject: {},
        message: "",
        fileId: "",
        fileList: [],
        handleOptions: constant.handleOptions,
        deviceTypeObject: constant.deviceTypeObject
      };
    },
    created() {
      if (this.$route.query.type)
        this.type = this.$route.query.type;
      if (this.$route.query.eventId)
        this.eventId = this.$route.query.eventId;
      this.getEventDetail();
      this.getEventProcessOptions();
    },
    mounted() {

    },
    computed: {
      path() {
        return this.$route.path;
      },
    },
    methods: {
      getEventProcessFilterOptions(type) {
        this.eventProcessFilterOptions = this.eventProcessOptions.filter(item => item.type === parseInt(type));
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      getEventProcessOptions() {
        getEventProcessOptions().then(response => {
          if (response.success) {
            this.eventProcessOptions = response.data;
          }
        })
      },
      getEventDetail() {
        eventDetail(this.type, this.eventId).then(response => {
          if (response.success) {
            this.eventObject = response.data
          }
        })
      },
      afterRead(file) {
        // 此时可以自行将文件上传至服务器
        file.status = 'uploading'
        file.message = '上传中...'
        let content = file.file;
        let data = new FormData();
        data.append('file', content);
        sysFileInfo(data)
          .then((response) => {
            if (response.success) {
              file.status = 'success'
              file.fileId = response.data;
            } else {
              file.status = 'failed'
              file.message = '上传失败'
              this.$toast(response.message);
            }
          }).catch((err) => {
          file.status = 'failed'
          file.message = '上传失败'
          this.$toast(err + "");
        });
      },
      changeState(value) {
        this.eventProcessOptionId = null;
        if (this.$refs.eventProcessOptionRef) {
          this.$refs.eventProcessOptionRef.value = null
        }
        this.getEventProcessFilterOptions(value);
      },
      handle() {
        let fileId = "";
        if (this.fileList.filter(item => item.status === 'uploading').length !== 0) {
          this.$toast("图片正在上传")
          return;
        }
        if (this.fileList != null) {
          this.fileList.forEach((item) => {
            if (item.status === 'success')
              fileId = fileId + item.fileId + ","
          })
        }
        this.loading = true;
        if (!this.state && this.state !== 0) {
          this.$toast("处理结果必选")
          return;
        }
        eventHandle(this.type, {
          fileId: fileId,
          id: this.eventObject.id,
          memo: this.message,
          state: this.state,
          eventProcessOptionId: this.eventProcessOptionId
        }).then((response) => {
          if (response.success) {
            this.loading = false;
            this.$toast("处理成功");
            setTimeout(this.goBack(), 500);
          } else {
            this.loading = false;
            this.$toast(response.message);
          }
        }).catch((err) => {
          this.loading = false;
          this.$toast(err + "");
        });
      },
    },
  };
</script>

<style scoped>

  .preview-cover {
    position: absolute;
    bottom: 0;
    box-sizing: border-box;
    width: 100%;
    padding: 4px;
    color: #fff;
    font-size: 12px;
    text-align: center;
    background: rgba(0, 0, 0, 0.3);
  }

  .event-handle-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

  .defaultButton {

    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: transparent;
    padding: 1px 10px;
    font-size: 14px;
    height: 24px;
    position: relative;
    top: -4px;
    color: #707070
  }

  .defaultButton_active {
    font-size: 14px;
    padding: 1px 10px;
    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: #1989FA;
    color: #FFFFFF;
    height: 24px;
    position: relative;
    top: -4px;
  }
</style>
