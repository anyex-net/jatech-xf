<template>
  <div>
    <common-head
      :is-back="true"
      :custom-title="true"
      :custom-right="true"
      background-color="#FFFFFF"
      :back-img="require('@/assets/images/new/back1.png')"
      back-img-style="width: 8px;height: 16px"
    >
      <template #title>
        <span style="color: black;font-weight: bolder">{{ isEdit?'编辑水主机' : '添加水主机' }}</span>
      </template>
      <template #right>
        <van-button
          size="small"
          style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF"
          @click="save"
        >保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card">
          <div class="form water-form">
            <van-form ref="formRef">
              <my-select
                ref="unitRef"
                :required="true"
                :is-bottom="true"
                label="联网单位："
                placeholder="点击选择联网单位"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :rules="rules.unitId"
                :options="unitOptions"
                @confirm="(value)=>{this.temp.unitId = value;}"
              />
              <my-select
                v-if="!isEdit"
                ref="platformRef"
                label="接入平台："
                :is-bottom="true"
                :required="true"
                placeholder="点击选择接入平台"
                filterable
                s-label="name"
                s-value="code"
                input-align="right"
                :options="platformOptions"
                :rules="rules.platform"
                @confirm="(value)=>{this.temp.platform = value;this.modelOptions=[]; this.$refs.modelRef.value= null;this.getModel(this.temp.platform, this.temp.provider, this.type)}"
              />
              <my-select
                v-if="!isEdit"
                ref="providerRef"
                :is-bottom="true"
                label="厂　　家："
                :required="true"
                placeholder="点击选择厂家"
                :rules="rules.provider"
                filterable
                s-label="name"
                s-value="code"
                input-align="right"
                :options="providerOptions"
                @confirm="(value)=>{this.temp.provider = value;this.modelOptions=[];this.$refs.modelRef.value= null; this.getModel(this.temp.platform, this.temp.provider, this.type)}"
              />
              <my-select
                v-if="!isEdit"
                ref="modelRef"
                :is-bottom="true"
                label="型　　号："
                placeholder="点击选择型号"
                :rules="rules.model"
                :required="true"
                filterable
                s-label="value"
                s-value="value"
                input-align="right"
                :options="modelOptions"
                @confirm="(value)=>{this.temp.model = value}"
              />
              <my-select
                v-if="!isEdit"
                ref="isRegisterRef"
                :is-bottom="true"
                label="是否注册："
                :rules="rules.isRegister"
                placeholder="点击选择是否注册"
                :required="true"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="isRegisterOptions"
                @confirm="(value)=>{this.temp.isRegister = value}"
              />
              <van-field
                v-if="this.temp.isRegister !== null && this.temp.isRegister === 0 && !isEdit"
                v-model="temp.deviceId"
                required
                label="设备ID："
                input-align="right"
                :rules="rules.deviceId"
                placeholder="请输入设备ID"
              />
              <my-select
                v-if="!isEdit"
                ref="waterDeviceTypeRef"
                :is-bottom="true"
                label="设备类型："
                :required="true"
                placeholder="点击选择设备类型"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :rules="rules.sensorType"
                :options="sensorTypeOptions"
                @confirm="(value)=>{this.temp.sensorType = value}"
              />
              <van-field
                v-model="temp.name"
                required
                label="设备名称："
                input-align="right"
                placeholder="请输入设备名称"
                :rules="rules.name"
              />
              <van-field
                v-model="temp.imei"
                required
                label="imei　号："
                right-icon="scan"
                input-align="right"
                placeholder="扫码获取"
                :rules="rules.imei"
                @click-right-icon="scan"
              />
              <van-field
                v-model="temp.position"
                required
                input-align="right"
                label="位　　置："
                placeholder="请输入位置"
                :rules="rules.position"
              />
              <van-field
                v-model="temp.address"
                :rules="rules.address"
                required
                :is-hide="true"
                :is-bottom="true"
                input-align="right"
                label="安装地址"
                placeholder="请输入安装地址"
              />
              <base-map-search
                ref="mapSearch"
                :is-hide="true"
                :is-edit="isEdit"
                :value="temp.address"
                :longitude="temp.lng"
                :latitude="temp.lat"
                @updateLocation="updateLocation"
              />
              <van-field
                v-model="temp.lng"
                input-align="right"
                required
                label="经　　度："
                placeholder="请输入经度"
              />
              <van-field
                v-model="temp.lat"
                input-align="right"
                required
                label="纬　　度："
                placeholder="请输入纬度"
              />
              <van-field
                v-if="!isEdit"
                v-model="temp.minWarn"
                required
                input-align="right"
                :rules="rules.minWarn"
                type="number"
                label="最小预警："
                placeholder="请输入最小预警"
              />
              <van-field
                v-if="!isEdit"
                v-model="temp.maxWarn"
                :rules="rules.maxWarn"
                required
                input-align="right"
                label="最大预警："
                type="number"
                placeholder="请输入最大预警"
              />
              <van-field
                v-if="temp.sensorType === 2 &&　!isEdit"
                v-model="temp.floorSpace"
                required
                input-align="right"
                label="底面　积："
                type="number"
                placeholder="请输入底面积"
              />
              <van-field
                v-if="temp.sensorType === 2　&&　!isEdit"
                v-model="temp.high"
                required
                input-align="right"
                :rules="rules.high"
                label="总　　高："
                type="number"
                placeholder="请输入总高"
              />
              <common-date-select
                :rules="rules.registerTime"
                required
                label="注册时间："
                placeholder="请选择注册时间"
                :value="temp.registerTime"
                @update="(value)=>{this.temp.registerTime = value}"
              />
              <van-field
                v-model="temp.allottedTime"
                :rules="rules.allottedTime"
                required
                input-align="right"
                type="number"
                label="到期年限："

                placeholder="请输入到期年限"
              />
              <common-upload-image ref="installPicRef" label="安装图片：" />
            </van-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import constant from '@/api/elec/constant'
import BaseMapSearch from '@/components/Map/baseMapSearch'
import { getPlatform, getProvider } from '@/api/common/index'
import { sysUserSelector } from '@/api/system/userManage.js'
import waterConstant from '@/api/water/constant.js'
import commonConstant from '@/api/common/constant.js'
import commonHead from '@/views/app/common/head'
import mySelect from '@/views/app/common/my-select/index'
import { getModel } from '@/api/common'
import store from '@/store'
import CommonUploadImage from '@/components/Upload/CommonUploadImage'
import CommonDateSelect from '@/components/selector/CommonDateSelect'
import { addWater, updateWater, waterDetail } from '@/api/water'
import { getSelectorList } from '../../../../api/sys/unit'

export default {
  components: { BaseMapSearch, commonHead, mySelect, CommonUploadImage, CommonDateSelect },
  data() {
    return {
      type: commonConstant.deviceTypeObject.water,
      showPicker1: false,
      factory: false,
      install: false,
      platform: false,
      showSelectPlatform: false,
      showSelectUnit: false,
      show: false,
      minDate: new Date('1995-07-01'),
      currentDate: new Date(),
      loading: false,
      platformOptions: [],
      id: null,
      providerOptions: [],
      modelOptions: [],
      unitOptions: [],
      isEdit: false,
      DeviceName: '',
      constant: constant,
      userOptions: [],
      waterDeviceType: false,
      sensorTypeOptions: waterConstant.sensorTypeOptions,
      deviceTypeObject: commonConstant.deviceTypeObject,
      waterDeviceTypeOptions: waterConstant.deviceTypeOptions,
      isRegisterOptions: [{ id: 1, name: '是' }, { id: 0, name: '否' }],
      rules: {
        deviceId: [{ required: true, message: '1', trigger: 'onBlur/onChange' }],
        sensorType: [{ required: true, message: '2', trigger: 'onBlur/onChange' }],
        imei: [{ required: true, message: '3', trigger: 'onBlur/onChange' }],
        address: [{ required: true, message: '4', trigger: 'onBlur/onChange' }],
        registerTime: [{ required: true, message: '5', trigger: 'onBlur/onChange' }],
        allottedTime: [{ required: true, message: '6', trigger: 'onBlur/onChange' }],
        minWarn: [{ required: true, message: '7', trigger: 'onBlur/onChange' }],
        maxWarn: [{ required: true, message: '8', trigger: 'onBlur/onChange' }],
        position: [{ required: true, message: '9', trigger: 'onBlur/onChange' }],
        isRegister: [{ required: true, message: '10', trigger: 'onBlur/onChange' }],
        platform: [{ required: true, message: '11', trigger: 'onBlur/onChange' }],
        provider: [{ required: true, message: '12', trigger: 'onBlur/onChange' }],
        model: [{ required: true, message: '13', trigger: 'onBlur/onChange' }],
        unitId: [{ required: true, message: '14', trigger: 'onBlur/onChange' }],
        name: [{ required: true, message: '15', trigger: 'onBlur/onChange' }]
      },
      temp: {
        sensorType: null,
        registerTime: null,
        allottedTime: 2,
        allottedTimeUnit: 1,
        high: null,
        floorSpace: null,
        isRegister: null,
        deviceId: null,
        installPic: null,
        installUserId: null,
        installUserName: null,
        platform: null,
        platformName: null,
        provider: null,
        providerName: null,
        installDate: null,
        name: null,
        address: null,
        id: null,
        position: null,
        unitId: null,
        unitName: null,
        deviceType: null,
        model: null,
        imei: null,
        lng: null,
        lat: null,
        minWarn: 0,
        maxWarn: 2
      },
      unitId: null
    }
  },
  created() {
    if (this.$route.query.unitId) {
      this.unitId = this.$route.query.unitId
    }
    if (this.$route.query.id) {
      this.id = this.$route.query.id
      this.init(this.id)
    }
    getPlatform().then((response) => {
      this.platformOptions = response.data
    })
    getProvider({ deviceType: this.deviceTypeObject.water }).then((response) => {
      this.providerOptions = response.data
    })
    getSelectorList({ isOnline: 1 }).then((response) => {
      this.unitOptions = response.data
      if (this.unitId) {
        this.temp.unitId = this.unitId
        if (this.unitOptions.find(item => item.id === this.temp.unitId)) {
          this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.temp.unitId).name
        }
      }
    })
    if (window.AndroidWebView) {
      window.AndroidWebView.setBarCodeCB('toScan')
      window.AndroidWebView.startScan()
    }
    window.toScan = this.toScan
  },
  beforeDestroy() {
    delete window.toScan
  },
  methods: {
    getUserList(unitId) {
      sysUserSelector({ unitId: unitId }).then((response) => {
        this.userOptions = response.data
      })
    },
    init(id) {
      this.isEdit = true
      waterDetail(id).then(response => {
        if (response.success) {
          this.temp = response.data
          if (this.temp.allottedTimeUnit == null) {
            this.temp.allottedTimeUnit = 1
          }
          if (this.temp.address && this.temp.lng && this.temp.lat) {
            this.$refs.mapSearch.updateAddress(this.temp.address, this.temp.lng, this.temp.lat)
          }
          this.$refs.installPicRef.setFileList(this.temp.installPic)
          this.$refs.unitRef.value = response.data.unitName
          // this.getUserList(this.temp.unitId);
          // this.$refs.userRef.value = this.temp.installUserName
        }
      })
    },
    scan() {
      if (window.AndroidWebView) {
        window.AndroidWebView.startScan()
      }
    },
    toScan(val) {
      this.temp.imei = val
    },
    getModel(platform, provider, type) {
      getModel({ platform: platform, provider: provider, type: type }).then(response => {
        if (response.success) {
          response.data.forEach(item => {
            this.modelOptions.push({ value: item })
          })
        }
      })
    },
    goBack() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    },
    updateLocation(lng, lat, address) {
      this.temp.lng = lng
      this.temp.lat = lat
      this.temp.address = address
    },
    formatDate(date) {
      return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`
    },
    onConfirm(date) {
      this.show = false
      this.temp.installDate = this.formatDate(date)
    },
    goBack() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    },
    save() {
      /* if (this.checkUnit() && this.checkImei() && this.checkPlat() && this.checkProvider() && this.checkModel() && this.checkDevice() && this.checkName() && this.checkPosition()) {*/
      this.$refs.formRef.validate().then(() => { // 验证通过
        this.loading = true
        store.commit('showLoading')
        this.temp.installPic = ''
        this.$refs.installPicRef.fileList.forEach(item => {
          this.temp.installPic = this.temp.installPic + item.fileId + ','
        })
        if (!this.isEdit) {
          addWater(this.temp)
            .then((response) => {
              if (response.success) {
                store.commit('hideLoading')
                this.loading = false
                this.$toast('保存成功')
                setTimeout(this.goBack(), 500)
              } else {
                this.loading = false
                this.$toast(response.message)
              }
            })
            .catch((err) => {
              store.commit('hideLoading')
              this.loading = false
              this.$toast(err + '')
            })
        } else {
          updateWater(this.temp)
            .then((response) => {
              if (response.success) {
                store.commit('hideLoading')
                this.loading = false
                this.$toast('保存成功')
                setTimeout(this.goBack(), 500)
              } else {
                this.loading = false
                this.$toast(response.message)
              }
            })
            .catch((err) => {
              store.commit('hideLoading')
              this.loading = false
              this.$toast(err + '')
            })
        }
      }).catch(err => {

      })
    }
  }
}
</script>

<style scoped>

  .water-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

</style>
