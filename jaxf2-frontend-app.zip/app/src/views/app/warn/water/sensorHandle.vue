<template>
  <div>
    <common-head :isBack="true" :customTitle="true"
                 background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px"
                 :customRight="true">
      <template #title>
        <span style="color: black;font-weight: bolder">设备处理</span>
      </template>
      <template #right>
        <van-button @click="handle" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">提交
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card device-handle-form">
          <van-field
            :border="false"
            readonly
            v-model="deviceDetail.unitName"
            input-align="left"
            label="联网单位："
          />
          <van-field
            :border="false"
            v-model="deviceDetail.name"
            readonly
            input-align="left"
            label="设备名称："
          />
          <van-field
            :border="false"
            v-model="deviceDetail.position"
            readonly
            input-align="left"
            label="位　　置："
          />
          <my-select
            label="设备状态"
            :required="true"
            placeholder="点击选择设备状态"
            filterable
            s-label="label"
            s-value="value"
            input-align="left"
            :isBottom="true"
            :options="deviceStateOptions"
            ref="deviceStateRef"
            @confirm="(value)=>{this.deviceDetail.deviceState = value; if(this.deviceDetail.state){this.deviceDetail.state}; this.deviceDetail.eventProcessOptionId = null;
                  if (this.$refs.eventProcessOptionRef) {
                    this.$refs.eventProcessOptionRef.value = null
                    } }"
          />

          <van-field :border="false" input-align="left" name="radio"
                     label="处理结果：" :required="true">
            <template #input>
              <van-radio-group @change="changeState" style="height: 30px" v-model="deviceDetail.state"
                               direction="horizontal">
                <van-radio name="201">
                  <template #icon="props">
                    <button type="button"
                            :class="props.checked ? 'defaultButton_active' : 'defaultButton'">处理中
                    </button>
                  </template>
                </van-radio>
                <van-radio name="301">
                  <template #icon="props">
                    <button type="button"
                            :class="props.checked ? 'defaultButton_active' : 'defaultButton'">误报
                    </button>
                  </template>
                </van-radio>
                <van-radio name="302">
                  <template #icon="props">
                    <button type="button"
                            :class="props.checked ? 'defaultButton_active' : 'defaultButton'">确认
                    </button>
                  </template>
                </van-radio>
              </van-radio-group>
            </template>
          </van-field>

          <my-select v-if="this.deviceDetail.state === '301'"
                     label="误报原因"
                     :required="true"
                     placeholder="点击选择误报原因"
                     filterable
                     s-label="name"
                     s-value="id"
                     input-align="left"
                     :isBottom="true"
                     ref="eventProcessOptionRef"
                     :options="eventProcessFilterOptions"
                     @confirm="(value)=>{this.deviceDetail.eventProcessOptionId = value}"
          />

          <van-field :border="false" readonly
                     input-align="left"
                     label="处理说明："/>
          <div style="padding: 0px 10px;">
            <van-field
              input-align="left"
              label=""
              v-model="deviceDetail.memo"
              rows="2"
              type="textarea"
              placeholder="请输入处理说明"
              show-word-limit
              style="background-color: #FAFAFA;border-radius: 6px;"
            />
          </div>

          <van-uploader :preview-image="true" :preview-full-image="true" preview-size="1.8rem"
                        :after-read="afterRead"
                        v-model="fileList">
            <template #preview-cover="{ file }">
              <div class="preview-cover van-ellipsis">{{ file.name }}</div>
            </template>
            <van-button
              style="width:60px;height: 60px;margin-left: 10px;float: left;margin-top:10px;margin-bottom: 10px"
              icon="plus"/>
          </van-uploader>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {sysFileInfo} from "@/api/detail/index";
  import constant from "@/api/common/constant.js"
  import {deviceDetail} from "@/api/common/common.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import {getEventProcessOptions} from "../../../../api/common";
  import {sensorHandle} from "../../../../api/water";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        type: '',
        deviceDetail: {eventProcessOptionId: null, state: null, deviceState: null},
        deviceStateOptions: [],
        eventProcessOptions: [],
        eventProcessFilterOptions: [],
        message: "",
        fileId: "",
        fileList: [],
        loading: false,
        handleOptions: constant.handleOptions,
      };
    },
    created() {
      this.type = this.$route.query.type;
      this.id = this.$route.query.id;
      this.getDeviceDetail();
      this.getEventProcessOptions();
    },
    mounted() {

    },
    computed: {},
    methods: {
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      getDeviceDetail() {
        deviceDetail(this.type, this.id)
          .then((response) => {
            if (response.success) {
              this.deviceDetail = response.data;
              this.getDeviceStateOptions(this.deviceDetail)
            }
          }).catch((err) => {
          this.$toast(err + "");
        });
      },
      getEventProcessOptions() {
        getEventProcessOptions().then(response => {
          if (response.success) {
            this.eventProcessOptions = response.data;
          }
        })
      },
      changeState(value) {
        this.deviceDetail.eventProcessOptionId = null;
        if (this.$refs.eventProcessOptionRef) {
          this.$refs.eventProcessOptionRef.value = null
        }
        this.getEventProcessFilterOptions(value);
      },
      getEventProcessFilterOptions(type) {
        this.eventProcessFilterOptions = this.eventProcessOptions.filter(item => item.type === parseInt(type));
      },
      getDeviceStateOptions(deviceDetail) {
        if (deviceDetail.isWarn && deviceDetail.isWarn === 1) {
          this.deviceStateOptions.push({label: "报警", value: "3"})
        }
        if (deviceDetail.isTest && deviceDetail.isTest === 1) {
          this.deviceStateOptions.push({label: "自检", value: "4"})
        }
        if (deviceDetail.isFault && deviceDetail.isFault === 1) {
          this.deviceStateOptions.push({label: "故障", value: "5"})
        }
        if (deviceDetail.isSensorFault && deviceDetail.isSensorFault === 1) {
          this.deviceStateOptions.push({label: "迷宫污染", value: "7"})
        }
        if (deviceDetail.isLowVol && deviceDetail.isLowVol === 1) {
          this.deviceStateOptions.push({label: "低电压", value: "6"})
        }
        if (deviceDetail.isOpen && deviceDetail.isOpen === 1) {
          this.deviceStateOptions.push({label: "拆除", value: "8"})
        }
        if (deviceDetail.isShield && deviceDetail.isShield === 1) {
          this.deviceStateOptions.push({label: "屏蔽", value: "9"})
        }
        if (deviceDetail.isOther && deviceDetail.isOther === 1) {
          this.deviceStateOptions.push({label: "其它", value: "11"})
        }
        if (deviceDetail.isAbnormal && deviceDetail.isAbnormal === 1) {
          this.deviceStateOptions.push({label: "异常", value: "10"})
        }
        this.deviceDetail.deviceState = this.deviceStateOptions[0].value
        this.$refs.deviceStateRef.value = this.deviceStateOptions[0].label
      },
      afterRead(file) {
        // 此时可以自行将文件上传至服务器
        file.status = 'uploading'
        file.message = '上传中...'
        let content = file.file;
        let data = new FormData();
        data.append('file', content);
        sysFileInfo(data).then((response) => {
          if (response.success) {
            file.status = 'success'
            file.fileId = response.data;
          } else {
            file.status = 'failed'
            file.message = '上传失败'
            this.$toast(response.message);
          }
        }).catch((err) => {
          file.status = 'failed'
          file.message = '上传失败'
          this.$toast(err + "");
        });
      },
      handle() {
        /*this.$refs.handleForm.validate().then(() => {*/
        let fileId = "";
        if (this.fileList.filter(item => item.status === 'uploading').length !== 0) {
          this.$toast("图片正在上传")
          return;
        }
        if (this.fileList != null) {
          this.fileList.forEach((item) => {
            if (item.status === 'success')
              fileId = fileId + item.fileId + ","
          })
        }
        let data = {};
        this.$set(data, 'fileId', fileId);
        this.$set(data, 'id', this.deviceDetail.id);
        this.$set(data, 'memo', this.deviceDetail.memo);
        if (this.deviceDetail.deviceState == null) {
          this.$toast("设备状态必选");
          return;
        }
        if (this.deviceDetail.state == null) {
          this.$toast("处理结果必选");
          return;
        }
        this.$set(data, 'deviceState', this.deviceDetail.deviceState);
        this.$set(data, 'state', this.deviceDetail.state);
        this.$set(data, 'eventProcessOptionId', this.deviceDetail.eventProcessOptionId);
        this.loading = true;
        sensorHandle(data).then((response) => {
          if (response.success) {
            this.loading = false;
            this.$toast("处理成功");
            setTimeout(this.goBack(), 500);
          } else {
            this.loading = false;
            this.$toast(response.message);
          }
        }).catch((err) => {
          this.loading = false;
          this.$toast(err + "");
        });
        // 验证通过
        /*}).catch(() => {
          //验证失败
        })*/
      },
    },
  };
</script>

<style scoped>
  .preview-cover {
    position: absolute;
    bottom: 0;
    box-sizing: border-box;
    width: 100%;
    padding: 4px;
    color: #fff;
    font-size: 12px;
    text-align: center;
    background: rgba(0, 0, 0, 0.3);
  }

  .device-handle-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

  .defaultButton {

    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: transparent;
    padding: 1px 10px;
    font-size: 14px;
    height: 24px;
    position: relative;
    top: -4px;
    color: #707070
  }

  .defaultButton_active {
    font-size: 14px;
    padding: 1px 10px;
    border: 1px solid #E3E3E3;
    border-radius: 10px;
    background-color: #1989FA;
    color: #FFFFFF;
    height: 24px;
    position: relative;
    top: -4px;
  }
</style>
