<template>
  <div>
    <common-head :isBack="true" :customTitle="true" background-color="#FFFFFF"
                 :isSearch="true && activeName==='event'"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px" @searchShow="showList=!showList">
      <template #title>
        <span style="color: black;font-weight: bolder">设备详情</span>
      </template>
      <template #right>
        <van-button v-if="activeName==='handle' && isEventHandle"
                    @click="handleEvent" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">处理
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <van-tabs title-inactive-color="#979797" title-active-color="#1989FA"
                color="#1989FA" class="fixed-tab detail-tab device-detail" v-model="activeName" @click="changeTab()">
        <van-tab name="info" title="基础信息">
          <div class="cards-tab" style="background: #F4F4F4">
            <div class="card">
              <van-cell-group class="item-group device-detail">
                <van-cell v-if="getDeviceState(deviceDetail) !== ''" class="bianhao" title="设备状态"
                          :value="getDeviceState(deviceDetail)"/>
                <van-cell v-if="getDeviceState(deviceDetail) === ''" title="设备状态" value="正常"/>
                <van-cell title="设备类型" :value="getDeviceType(deviceDetail)"/>
                <van-cell title="联网单位" :value="deviceDetail.unitName"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="接入平台："
                          :value="deviceDetail.platName"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="厂　　家："
                          :value="deviceDetail.providerName"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="型　　号："
                          :value="deviceDetail.model"/>
                <van-cell v-if="this.type === constant.deviceTypeObject.xks" title="消控　室："
                          :value="deviceDetail.xksName"/>
                <van-cell v-if="this.type === constant.deviceTypeObject.xks" title="用传主机："
                          :value="deviceDetail.transmissionName"/>
                <van-cell title="设备名称" :value="deviceDetail.name"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="imei　号："
                          :value="getDeviceCode(deviceDetail)"/>
                <van-cell v-if="this.type === constant.deviceTypeObject.xks" title="设备编码："
                          :value="getDeviceCode(deviceDetail)"/>
                <van-cell title="位　　置：" :value="deviceDetail.position"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="经　　度："
                          :value="deviceDetail.lng"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="纬　　度："
                          :value="deviceDetail.lat"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="安装人员："
                          :value="deviceDetail.installUserName"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="安装日期："
                          :value="deviceDetail.installDate"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="安装地址："
                          :value="deviceDetail.address"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="续费时间："
                          :value="deviceDetail.registerTime"/>
                <van-cell v-if="this.type !== constant.deviceTypeObject.xks" title="服务期限："
                          :value="deviceDetail.allottedTime"/>
              </van-cell-group>
            </div>
            <div class="bottom"
                 v-if="hasBtnPermission('water:device:setIsPush')"/>
          </div>
          <div class="bar-footer"
               v-if="hasBtnPermission('water:device:setIsPush')">
            <van-row style="width: 100%;flex-wrap:wrap;" type="flex" justify="space-between">
              <van-col style="display: flex" span="24">
                <van-button style="flex: 1"
                            v-if="hasBtnPermission('water:device:setIsPush') && deviceDetail.isPush === true"
                            class="button blue1"
                            @click="handleSetIsPush(deviceDetail.deviceId, false)">
                  关闭推送
                </van-button>
                <van-button style="flex: 1"
                            v-if="hasBtnPermission('water:device:setIsPush') && deviceDetail.isPush === false"
                            class=" button blue1"
                            @click="handleSetIsPush(deviceDetail.deviceId, true)">
                  开启推送
                </van-button>
              </van-col>
            </van-row>
          </div>
          <div class="bar-footer"
               v-if="!hasBtnPermission('water:deviceSensor:edit') && hasBtnPermission('water:deviceSensor:del')">
            <van-row type="flex" justify="space-between">
              <van-col span="24" v-if="hasBtnPermission('water:deviceSensor:del')">
                <van-button class="button danger" @click="del">
                  删除
                </van-button>
              </van-col>
            </van-row>
          </div>
          <div class="bar-footer"
               v-if="hasBtnPermission('water:deviceSensor:edit') && !hasBtnPermission('water:deviceSensor:del')">
            <van-row type="flex" justify="space-between">
              <van-col span="24">
                <van-button class="button blue1" @click="edit">
                  编辑
                </van-button>
              </van-col>
            </van-row>
          </div>
        </van-tab>
        <van-tab name="plane" title="设备定位">
          <div class="cards-tab" style="background: #F4F4F4">
            <div style="margin: 15px 16px 0px;font-size: 14px;color: rgb(151, 151, 151);">
              地图定位：
            </div>

            <div v-if="deviceDetail.lng !== null && activeName === 'plane'" class="card">
              <base-map-search
                ref="mapSearch"
                :isEdit="false"
                :isHide="true"
                :value="deviceDetail.address"
                :longitude="deviceDetail.lng"
                :latitude="deviceDetail.lat"
              />
            </div>
            <div v-else style="text-align: center">
              <div class="card" style="padding: 20px">
                没有地图定位
              </div>
            </div>

            <div style="margin: 15px 16px 0px;font-size: 14px;color: rgb(151, 151, 151);">
              平面图定位：
            </div>
            <div style="margin: 30px auto auto;height:300px;width:90%;">
              <div v-if="planeTemp !== null && planeTemp.filePath !== null"
                   style="z-index:0;position:relative;">
                <img style="width:100%;height:100%;" :src="planeTemp.filePath"/>
                <img :style="getPosition(item)" :key="index"
                     v-for="(item,index) in planeTemp.sysPlaneDeviceList"
                     width="24px" height="24px" draggable="false"
                     @click="showPopover=!showPopover"
                     :src="require('@/assets/smoke.png')" class="image">
              </div>
              <div v-else style="text-align: center">
                <div class="card" style="padding: 20px">
                  没有平面图
                </div>
              </div>
            </div>
          </div>
        </van-tab>
        <van-tab name="state" title="状态信息">
          <div class="cards-tab" 　style="background: #F4F4F4">
            <div class="card device-detail-status">
              <van-row style="padding: 10px;">
                <van-col class="title" span="7" :offset="1">是否报警：</van-col>
                <van-col :class="deviceDetail.isWarn ? 'font-red' : ''" align="right" span="14">
                  {{deviceDetail.lastWarnDate}}
                </van-col>
                <van-col :class="deviceDetail.isWarn ? 'font-red' : ''" align="right" span="2">
                  {{judge(deviceDetail.isWarn)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px">
                <van-col class="title" span="7" :offset="1">是否故障：</van-col>
                <van-col :class="deviceDetail.isFault ? 'font-red' : ''" align="right" span="14">
                  {{deviceDetail.lastFaultDate}}
                </van-col>
                <van-col :class="deviceDetail.isFault ? 'font-red' : ''" align="right" span="2">
                  {{judge(deviceDetail.isFault)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px" v-if="this.type !== constant.deviceTypeObject.water">
                <van-col class="title" span="7" :offset="1">是否测试报警：</van-col>
                <van-col :class="deviceDetail.isTest ? 'font-red' : ''" align="right" span="14">
                  {{deviceDetail.lastTestDate}}
                </van-col>
                <van-col :class="deviceDetail.isTest ? 'font-red' : ''" align="right" span="2">
                  {{judge(deviceDetail.isTest)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px"
                       v-if="this.type !== constant.deviceTypeObject.btn &&this.type !== constant.deviceTypeObject.water &&this.type !== constant.deviceTypeObject.xks">
                <van-col class="title" span="7" :offset="1">是否迷宫污染：</van-col>
                <van-col :class="deviceDetail.isSensorFault ? 'font-red' : ''" align="right" span="14">
                  {{deviceDetail.lastSensorDate}}
                </van-col>
                <van-col :class="deviceDetail.isSensorFault ? 'font-red' : ''" align="right" span="2">
                  {{judge(deviceDetail.isSensorFault)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px" v-if="this.type !== constant.deviceTypeObject.xks">
                <van-col class="title" span="7" :offset="1">是否离线：</van-col>
                <van-col
                  :class="deviceDetail.isOnline === null || deviceDetail.isOnline === 0  ? 'font-red':''"
                  align="right" span="14">{{deviceDetail.lastOfflineDate}}
                </van-col>
                <van-col
                  :class="deviceDetail.isOnline === null || deviceDetail.isOnline === 0  ? 'font-red':''"
                  align="right" span="2">
                  {{judge1(deviceDetail.isOnline)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px"
                       v-if="this.type !== constant.deviceTypeObject.btn &&this.type !== constant.deviceTypeObject.water &&this.type !== constant.deviceTypeObject.xks">
                <van-col class="title" span="7" :offset="1">是否拆除：</van-col>
                <van-col :class="deviceDetail.isOpen ? 'font-red':''" align="right" span="14">
                  {{deviceDetail.lastOpenDate}}
                </van-col>
                <van-col :class="deviceDetail.isOpen ? 'font-red':''" align="right" span="2">
                  {{judge(deviceDetail.isOpen)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px" v-if="this.type !== constant.deviceTypeObject.xks">
                <van-col class="title" span="7" :offset="1">是否低电压：</van-col>
                <van-col :class="deviceDetail.isLowVol ? 'font-red':''" align="right" span="14">
                  {{deviceDetail.lastVolDate}}
                </van-col>
                <van-col :class="deviceDetail.isLowVol ? 'font-red':''" align="right" span="2">
                  {{judge(deviceDetail.isLowVol)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px" v-if="this.type === constant.deviceTypeObject.xks">
                <van-col class="title" span="7" :offset="1">是否屏蔽：</van-col>
                <van-col :class="deviceDetail.isShield ? 'font-red':''" align="right" span="14">
                  {{deviceDetail.lastShieldDate}}
                </van-col>
                <van-col :class="deviceDetail.isShield ? 'font-red':''" align="right" span="2">
                  {{judge(deviceDetail.isShield)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px" v-if="this.type === constant.deviceTypeObject.xks">
                <van-col class="title" span="7" :offset="1">是否其它：</van-col>
                <van-col :class="deviceDetail.isOther ? 'font-red':''" align="right" span="14">
                  {{deviceDetail.lastOtherDate}}
                </van-col>
                <van-col :class="deviceDetail.isOther ? 'font-red':''" align="right" span="2">
                  {{judge(deviceDetail.isOther)}}
                </van-col>
              </van-row>
              <van-row style="padding: 10px" v-if="this.type === constant.deviceTypeObject.water">
                <van-col class="title" span="7" :offset="1">是否异常：</van-col>
                <van-col :class="deviceDetail.isAbnormal ? 'font-red':''" align="right" span="14">
                  {{deviceDetail.lastAbnormalDate}}
                </van-col>
                <van-col :class="deviceDetail.isAbnormal ? 'font-red':''" align="right" span="2">
                  {{judge(deviceDetail.isAbnormal)}}
                </van-col>
              </van-row>
            </div>
            <div class="bottom" v-if="hasBtnPermission(type + ':device:handle')"/>
          </div>
          <div class="bar-footer" v-if="isHandle && hasBtnPermission(type + ':device:handle')">
            <van-row type="flex" justify="space-between">
              <van-col span="24">
                <van-button class="button blue1" @click="goDeviceHandle">
                  处理
                </van-button>
              </van-col>
            </van-row>
          </div>
        </van-tab>
        <van-tab name="monitor" title="监控视频">
          <div class="cards-tab" style="background: #F4F4F4">
            <div v-show="monitorDeviceId !== null"
                 style="height:calc(100% - 44px);width:100%;">
              <div style="height:44px;font-size: 14px;color: rgb(151, 151, 151);">
                <my-select
                  ref="monitorRef"
                  label="监控设备"
                  placeholder="点击选择监控设备"
                  filterable
                  s-label="monitorDeviceName"
                  s-value="id"
                  :isBottom="true"
                  input-align="right"
                  :options="deviceMonitorList"
                  @confirm="changeMonitor"
                />
              </div>
              <v-video v-if="videoRefresh === true" style="width: 100%;height:100%" :id="monitorDeviceId"/>
            </div>
            <div v-if="monitorDeviceId == null"
                 style="margin: 15px auto auto;height:300px;width:100%;text-align: center">
              <div class="card" style="padding: 20px">
                没有监控视频
              </div>
            </div>
          </div>
        </van-tab>
        <van-tab name="event" v-if="eventId == null" title="事件列表">
          <div class="cards-tab" 　style="background: #F4F4F4">
            <div v-show="showList === false">
              <div class="card search">
                <my-select
                  label="事件状态"
                  placeholder="点击选择事件状态"
                  filterable
                  s-label="value"
                  s-value="key"
                  input-align="right"
                  :isBottom="true"
                  :options="constant.handleStateOptions"
                  @confirm="(value)=>{this.eventListQuery.state = value}"
                />
                <van-field readonly clickable input-align="right" label="开始时间"
                           :value="this.eventListQuery.eventTimeStart"
                           placeholder="请选择开始时间" @click="showEventTimeStart = true"/>
                <van-popup v-model="showEventTimeStart" position="bottom">
                  <van-datetime-picker type="datetime" v-model="eventTimeCurrentStart"
                                       @cancel="() => {this.showEventTimeStart = false;}"
                                       @confirm="eventStartConfirm"/>
                </van-popup>
                <van-field readonly clickable input-align="right" label="结束时间"
                           :value="this.eventListQuery.eventTimeEnd"
                           placeholder="请选择结束时间" @click="showEventTimeEnd = true"/>
                <van-popup v-model="showEventTimeEnd" position="bottom">
                  <van-datetime-picker type="datetime" v-model="eventTimeCurrentEnd"
                                       @cancel="() => {this.showEventTimeEnd = false;}"
                                       @confirm="eventEndConfirm"/>
                </van-popup>
                <div class="btn-wrapper">
                  <van-row type="flex" justify="space-between">
                    <van-col span="11">
                      <van-button class="orange button" @click="resetEventQuery">
                        重置
                      </van-button>
                    </van-col>
                    <van-col span="11">
                      <van-button class="blue button" @click="onRefresh">搜索
                      </van-button>
                    </van-col>
                  </van-row>
                </div>
              </div>
            </div>
            <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
              <van-list v-model="loading" :finished="finished" :immediate-check="false"
                        finished-text="没有更多了"
                        v-on:load="onLoad" style="background: #F4F4F4">
                <div style="height: 2px;background: #F4F4F4;"/>
                <div class="white-circle">
                  <div v-for="(item, index) in eventList" :key="index">
                    <van-swipe-cell>
                      <div class="item">
                        <div class="item-bottom">
                          <span class="name">{{item.eventDesc}}</span>
                          <span>{{item.eventTime}}</span>
                        </div>
                        <div class="item-bottom">
                          <span class="name">{{getState(item)}}</span>
                          <span class="status">{{item.processTime}}</span>
                        </div>
                      </div>
                      <template #right>
                        <van-button @click="handleEventDetail(item)"
                                    style="height: 70px;background-color: #1989fa !important;color:#ffffff"
                                    square
                                    text="进程"/>
                        <van-button v-if="isHandleEvent(item) === true"
                                    @click="goEventHandle(item)"
                                    style="height: 70px" square text="处理" type="danger"
                                    class="delete-button"/>
                      </template>
                    </van-swipe-cell>
                    <div style="height: 5px;background: #F4F4F4;"/>
                  </div>
                </div>
              </van-list>
            </van-pull-refresh>
          </div>
        </van-tab>
        <van-tab name="handle" v-if="eventId != null" title="事件处理">
          <div class="cards-tab" style="background: #F4F4F4">
            <event-handle-form @setEventHandle="setEventHandle" ref="eventHandleRef" :type="type"
                               :event-id="eventId"/>
          </div>
        </van-tab>
      </van-tabs>
    </div>
  </div>
</template>
<script>
  import {deviceDetail, deviceMonitorList, eventPage, getDeviceState, getDeviceType,} from "@/api/common/common";
  import constant from "@/api/common/constant.js";
  import waterConstant from "@/api/water/constant.js";
  import {deleteSensor} from "@/api/water/index.js";
  import commonHead from "@/views/app/common/head";
  import {hasBtnPermission} from "@/utils/permission";
  import store from "@/store";
  import mySelect from '@/views/app/common/my-select/index';
  import {getPlaneByDevice} from "@/api/sys/planeDevice";
  import BaseMapSearch from "@/components/Map/baseMapSearch";
  import vVideo from "@/components/Video";
  import eventHandleForm from "../common/eventHandleForm";
  import {setIsPush} from "../../../../api/common/common";

  export default {
    components: {commonHead, mySelect, BaseMapSearch, vVideo, eventHandleForm},
    data() {
      return {
        waterConstant: waterConstant,
        deviceDetail: {},
        activeName: 'info',
        isLoading: false,
        eventList: [],
        constant: constant,
        planeTemp: {
          sysPlaneDeviceList: [],
          filePath: null
        },
        loading: false,
        finished: false,
        type: "",
        id: "",
        showPopover: false,
        actions: [],
        showList: true,
        minDate: new Date("1995-07-01"),
        showEventTimeStart: false,
        showEventTimeEnd: false,
        eventTimeCurrentStart: new Date(),
        eventTimeCurrentEnd: new Date(),
        isHandle: false,
        monitorUrl: null,
        eventId: null,
        isEventHandle: false,
        monitorQuery: {
          deviceType: '',
          deviceId: ''
        },
        eventListQuery: {
          pageNo: 1,
          pageSize: 10,
          deviceId: null,
          id: null,
          sensorId: null,
          state: null,
          eventTimeStart: null,
          eventTimeEnd: null
        },
        deviceMonitorList: [],
        videoRefresh: true,
        monitorDeviceId: null,
      };
    },
    created() {
      if (this.$route.query.type) {
        this.type = this.$route.query.type;
      }
      if (this.$route.query.id) {
        this.id = this.$route.query.id;
      }

      if (this.$route.query.activeName) {
        this.activeName = this.$route.query.activeName
      }

      if (this.$route.query.eventID) {
        this.eventId = this.$route.query.eventID
      }
      this.eventListQuery.sensorId = this.id;
      this.getDeviceDetail();
      this.getPlaneByDevice();
      this.loading = true
      this.getEventPage();
    },
    mounted() {

    },
    computed: {},
    methods: {
      changeMonitor(value) {
        let item = this.deviceMonitorList.find(item => item.id === value);
        this.$refs.monitorRef.value = item.monitorDeviceName
        this.videoRefresh = false
        this.$nextTick(() => {
          this.monitorDeviceId = item.monitorDeviceId
          this.videoRefresh = true
        })
      },
      getDeviceMonitorList(deviceId) {
        deviceMonitorList(this.type, {deviceId: deviceId}).then(response => {
          if (response.success)
            this.deviceMonitorList = response.data
        })
      },
      handleSetIsPush(id, isPush) {
        let content = '';
        if (isPush === true) content = '确定要开启推送'
        if (isPush === false) content = '确定要关闭推送'
        this.$dialog.confirm({
          message: content,
        }).then(() => {
          store.commit('showLoading')
          setIsPush('water', {id: id, isPush: isPush}).then(response => {
            if (response.success) {
              store.commit('hideLoading')
              this.$toast('操作成功');
              this.getDeviceDetail();
            }
          }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      setEventHandle(value) {
        this.isEventHandle = value;
      },
      handleEvent() {
        this.$refs.eventHandleRef.handle();
      },
      changeTab() {
        console.log(this.activeName)
        if (this.activeName === 'info') {
          this.getDeviceDetail();
        }
        if (this.activeName === 'event') {
          this.onRefresh()
        }
        if (this.activeName === 'monitor') {
          this.videoRefresh = false
          if (this.deviceMonitorList.length > 0) {
            this.$nextTick(() => {
              if (this.$refs.monitorRef) {
                this.$refs.monitorRef.value = this.deviceMonitorList[0].monitorDeviceName
              }
              this.monitorDeviceId = this.deviceMonitorList[0].monitorDeviceId
              this.videoRefresh = true
            })
          }
        }
      },
      getPosition(item) {
        return "z-device:999;position:absolute;top:" + item.positionTop / 5 + "%;left:" + item.positionLeft / 5 + "%"
      },
      getPlaneByDevice() {
        getPlaneByDevice({type: this.type, deviceId: this.id}).then(response => {
          if (response.success) {
            this.planeTemp = response.data;
          }
        })
      },
      eventStartConfirm(date) {
        let year = date.getFullYear();
        let month = date.getMonth() + 1
        month = month < 10 ? "0" + month : month;
        let day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        let hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        let second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
        let currentTime = year + "-" + month + "-" + day + "  " + hour + ":" + minute + ":" + second;
        this.eventListQuery.eventTimeStart = currentTime;
        this.eventTimeCurrentStart = new Date(currentTime);
        this.showEventTimeStart = false;
      },
      eventEndConfirm(date) {
        let year = date.getFullYear();
        let month = date.getMonth() + 1
        month = month < 10 ? "0" + month : month;
        let day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        let hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        let second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
        let currentTime = year + "-" + month + "-" + day + "  " + hour + ":" + minute + ":" + second;
        this.eventListQuery.eventTimeEnd = currentTime;
        this.eventTimeCurrentEnd = new Date(currentTime);
        this.showEventTimeEnd = false;
      },
      resetEventQuery() {
        this.eventListQuery = {
          pageNo: 1,
          pageSize: 10,
          deviceId: null,
          state: null,
          eventTimeStart: null,
          eventTimeEnd: null
        }
        this.eventTimeCurrentStart = new Date();
        this.eventTimeCurrentEnd = new Date();
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path)
      },
      hasBtnPermission(value) {
        if (value != null)
          return hasBtnPermission(value)
        else {
          return false;
        }
      },
      deleteSensor(id) {
        this.$dialog
          .confirm({
            message: "是否删除",
          }).then(() => {
          store.commit('showLoading')
          deleteSensor([id])
            .then((response) => {
              store.commit('hideLoading')
              if (response.success) {
                this.getDeviceDetail();
              } else {
                this.$toast(response.message);
              }
            }).catch((err) => {
            store.commit('hideLoading')
            this.$toast(err + "");
          });
        }).catch(() => {
          // on cancel
        });
      },
      addSensor() {
        this.$router.push(
          {path: "/app/warn/water/sensorAdd", query: {type: this.type, id: this.id}}
        );
      },
      editSensor(id) {
        if (!this.hasBtnPermission(this.type + ":deviceSensor:edit")) {
          this.$toast("没有权限编辑传感器");
          return;
        }
        if (this.hasBtnPermission(this.type + ":deviceSensor:edit")) {
          this.$router.push(
            {path: "/app/warn/water/sensorEdit", query: {type: this.type, id: id}}
          );
        }
      },
      onSelect(action) {
        if (action.text === '设备编辑') {
          this.edit();
        } else if (action.text === '设备删除') {
          this.del();
        } else if (action.text === '传感器新增') {
          if (this.type === this.constant.deviceTypeObject.water && this.deviceDetail.deviceType === this.waterConstant.deviceTypeObject.sensor) {
            this.addSensor();
          } else {
            this.$toast("只支持水主机");
          }
        }
      },
      judge1(key) {
        if (key == null) return '是';
        const str = ["是", "否"];
        //if (key === 0) this.isHandle = true;
        return str[key];
      },
      judge(key) {
        if (key == null) return '否';
        const str = ["否", "是"];
        if (key === 1) this.isHandle = true;
        return str[key];
      },
      getState(item) {
        let state = constant.handleStateOptions.find((item1) => item1.key === item.state).value;
        return state;
      },
      getSensorType(item) {
        let item1 = waterConstant.positionOptions.find(item1 =>
          item1.typeId === item.sensorType && item1.id === item.onPosition
        );
        if (item1) return item1.name;
      },
      getSensorValue(item) {
        if (item.sensorData === null) return '';
        else return (
          item.sensorData +
          waterConstant.positionOptions.find(
            (item1) =>
              item1.typeId === item.sensorType && item1.id === item.onPosition
          ).unit
        );
      },
      getDeviceType(item) {
        if (this.type === constant.deviceTypeObject.xks)
          return item.deviceTypeName;
        else if (this.type === constant.deviceTypeObject.water) {
          let value = "";
          waterConstant.deviceTypeOptions.forEach((item1) => {
            if (item1.id === item.deviceType) {
              value = item1.name;
            }
          });
          if (value === "") return getDeviceType(this.type);
          else return value;
        } else return getDeviceType(this.type);
      },
      getDeviceCode(item) {
        if (this.type === constant.deviceTypeObject.xks) return item.deviceCode;
        else return item.imei;
      },
      getDeviceState(item) {
        return getDeviceState(item);
      },
      isHandleEvent(item) {
        let type = constant.handleStateOptions.find((item1) => item1.key === item.state).type;
        if (type !== 3 && hasBtnPermission(this.type + ":event:handle")) {
          return true;
        } else {
          return false;
        }
      },
      handleEventDetail(item) {
        this.$router.push({
          path: "/app/warn/common/eventDetail",
          query: {id: item.id, type: this.type, title: item.eventDesc}
        });
      },
      goEventHandle(item) {
        this.$router.push({
          path: "/app/warn/common/eventHandle",
          query: {type: this.type, eventObject: item},
        });
      },
      goDeviceHandle() {
        this.$router.push(
          {
            path: "/app/warn/water/sensorHandle",
            query: {type: this.type, id: this.deviceDetail.id}
          }
        );
      },
      getDeviceDetail() {
        deviceDetail(this.type, this.id)
          .then((response) => {
            if (response.success) {
              this.deviceDetail = response.data;
              if (this.activeName === 'plane') {
                this.$refs.mapSearch.updateAddress(response.data.address, response.data.lng, response.data.lat)
              }
              this.getDeviceMonitorList(this.deviceDetail.deviceId);
            }
          })
          .catch((err) => {
            this.$toast(err + "");
          });
      },
      getEventPage() {
        eventPage(this.type, this.eventListQuery).then((response) => {
          if (response.success) {
            this.isLoading = false;
            this.eventList = this.eventList.concat(response.data.rows);
            this.loading = false;
            if (response.data.rows.length < this.eventListQuery.pageSize) {
              this.finished = true;
            }
          }
        }).catch((err) => {
          this.$toast(err + "");
        });
      },
      onLoad() {
        this.eventListQuery.pageNo++;
        this.getEventPage();
      },
      onRefresh() {
        this.eventListQuery.pageNo = 1;
        this.finished = false;
        this.eventList = [];
        this.loading = true;
        this.getEventPage();
      },
      edit() {
        this.$router.push({path: "/app/warn/water/sensorForm", query: {id: this.id}});
      },
      del() {
        this.$dialog
          .confirm({
            message: "是否删除",
          })
          .then(() => {
            store.commit('showLoading')
            deleteSensor([this.id])
              .then((response) => {
                store.commit('hideLoading')
                if (response.success) {
                  setTimeout(this.goBack(), 500);
                } else {
                  this.$toast(response.message);
                }
              }).catch((err) => {
              store.commit('hideLoading')
              this.$toast(err + "");
            });
          })
          .catch(() => {
            // on cancel
          });
      },
      getVideo() {
        this.$nextTick(() => {
          try {
            videojs('video', {
              bigPlayButton: false,
              textTrackDisplay: false,
              posterImage: true,
              errorDisplay: false,
              controlBar: true,
            }, function () {
              this.play()
            })
          } catch (error) {
            console.log(error)
          }

        })
      },
    },
  };
</script>
<style scoped>

  .detail-tab >>> .van-tab {
    font-size: 12px
  }

  .device-detail >>> .van-cell__title {
    color: #979797;
    font-size: 14px;
    line-height: 24px;
  }

  .device-detail >>> .van-cell__value {
    color: #333333;
    font-size: 14px;
    line-height: 24px;
  }

  .device-detail-status >>> .van-row {
    height: 40px;
    width: 100%;
    display: flex;
    align-items: center;
    font-size: 13px;
  }

  .device-detail-status .title {
    color: #979797
  }
</style>
