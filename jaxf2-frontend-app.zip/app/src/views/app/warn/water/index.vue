<template>
  <div>
    <common-head @onSelect="onSelect" :toIndex="true" :type="type"
                 :isBack="true"
                 :title="'水系统'"/>
    <div class="content water">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div style="background: #ffffff;">
          <van-grid :border="false" :column-num="4">
            <van-grid-item @click="swipeOnClick(null, 0)">
              <van-badge v-if="allWarnCount !== 0" color="#FF585C" :content="allWarnCount" position="bottom-right">
                <div :class="active === 0 ? 'swipe-item-background-active' : 'swipe-item-background'">
                  <van-image width="30"
                             :src="active === 0 ? require('@/assets/images/activewaterAll1.png') : require('@/assets/images/waterAll.png')"/>
                </div>
              </van-badge>
              <div v-if="allWarnCount === 0"
                   :class="active === 0 ? 'swipe-item-background-active' : 'swipe-item-background'">
                <van-image width="30"
                           :src="active === 0 ? require('@/assets/images/activewaterAll1.png') : require('@/assets/images/waterAll.png')"/>
              </div>
              <span :class="active === 0 ? 'swipe-font-active' : 'swipe-font'">全部</span>
            </van-grid-item>
            <van-grid-item @click="swipeOnClick('2', 1)">
              <van-badge v-if="levelWarnCount !== 0" color="#FF585C" :content="levelWarnCount" position="bottom-right">
                <div :class="active === 1 ? 'swipe-item-background-active' : 'swipe-item-background'">
                  <van-image width="30"
                             :src="active === 1 ? require('@/assets/images/activeshuiwei1.png') : require('@/assets/images/shuiwei.png')"/>
                </div>
              </van-badge>
              <div v-if="levelWarnCount === 0"
                   :class="active === 1 ? 'swipe-item-background-active' : 'swipe-item-background'">
                <van-image width="30"
                           :src="active === 1 ? require('@/assets/images/activeshuiwei1.png') : require('@/assets/images/shuiwei.png')"/>
              </div>
              <span :class="active === 1 ? 'swipe-font-active' : 'swipe-font'">水位</span>
            </van-grid-item>
            <van-grid-item @click="swipeOnClick('3,4', 2)">
              <van-badge v-if="pressureWarnCount !== 0" color="#FF585C" :content="pressureWarnCount"
                         position="bottom-right">
                <div :class="active === 2 ? 'swipe-item-background-active' : 'swipe-item-background'">
                  <van-image width="30"
                             :src="active === 2 ? require('@/assets/images/activeshuiya1.png') : require('@/assets/images/shuiya.png')"/>
                </div>
              </van-badge>
              <div v-if="pressureWarnCount === 0"
                   :class="active === 2 ? 'swipe-item-background-active' : 'swipe-item-background'">
                <van-image width="30"
                           :src="active === 2 ? require('@/assets/images/activeshuiya1.png') : require('@/assets/images/shuiya.png')"/>
              </div>
              <span :class="active === 2 ? 'swipe-font-active' : 'swipe-font'">水压</span>
            </van-grid-item>
            <van-grid-item @click="swipeOnClick('1', 3)">
              <van-badge v-if="streamWarnCount !== 0" color="#FF585C" :content="streamWarnCount"
                         position="bottom-right">
                <div :class="active === 3 ? 'swipe-item-background-active' : 'swipe-item-background'">
                  <van-image width="30"
                             :src="active === 3 ? require('@/assets/images/activeshuiliu1.png') : require('@/assets/images/shuiliu.png')"/>
                </div>
              </van-badge>
              <div v-if="streamWarnCount === 0"
                   :class="active === 3 ? 'swipe-item-background-active' : 'swipe-item-background'">
                <van-image width="30"
                           :src="active === 3 ? require('@/assets/images/activeshuiliu1.png') : require('@/assets/images/shuiliu.png')"/>
              </div>
              <span :class="active === 3 ? 'swipe-font-active' : 'swipe-font'">水流</span>
            </van-grid-item>
          </van-grid>
          <van-grid :border="false" :column-num="3" style="margin-top: -20px">
            <van-grid-item @click="goDeviceList(deviceStateObject.all)">
              <div class="tj-title">设备总数/个</div>
              <div class="tj-value">{{sumCount}}</div>
            </van-grid-item>
            <van-grid-item @click="goDeviceList(deviceStateObject.offline)">
              <div class="tj-title">失联总数/个</div>
              <div class="tj-value">{{offlineCount}}</div>
            </van-grid-item>
            <van-grid-item @click="goDeviceList(deviceStateObject.warn)">
              <div class="tj-title">报警总数/个</div>
              <div class="tj-value">{{warnCount}}</div>
            </van-grid-item>
          </van-grid>
        </div>
        <common-warn-card :unitId="unitId" ref="warnCardRef" :sensorTypes="sensorTypes" :type="type"/>
        <div v-if="this.$parent.isShowWarn" class="nav-bottom"/>
      </div>
    </div>
  </div>
</template>

<script>
  import {getDeviceCount} from "@/api/water/index";
  import {getDeviceState} from "@/api/common/common.js";
  import constant from "@/api/water/constant.js"
  import commonConstant from "@/api/common/constant.js"
  import commonWarnCard from "@/views/app/warn/common/warnCard";
  import commonHead from "@/views/app/common/head";

  export default {
    components: {
      commonWarnCard, commonHead
    },

    data() {
      return {
        // active: 2,
        // activeNavIndex: 0,
        sumCount: 0,
        offlineCount: 0,
        warnCount: 0,
        filterActions: [],
        type: commonConstant.deviceTypeObject.water,
        pressureWarnCount: 0,
        levelWarnCount: 0,
        streamWarnCount: 0,
        allWarnCount: 0,
        showPopover: false,
        active: 0,
        deviceStateObject: commonConstant.deviceStateObject,
        deviceList: [],
        actions: [
          {text: '水主机管理', icon: 'edit', permission: 'water:device:add', path: "/app/warn/water/deviceList"},
          {text: '新增传感器', icon: 'add-o', permission: 'water:deviceSensor:form', path: "/app/warn/water/sensorForm"},
        ],
        sensorTypes: null,
        unitId: null,
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      getDeviceCount({unitId: this.unitId})
        .then((response) => {
          if (response.success) {
            this.pressureWarnCount = response.data.pressureWarnCount;
            this.streamWarnCount = response.data.streamWarnCount;
            this.levelWarnCount = response.data.levelWarnCount;
            this.allWarnCount = response.data.pressureWarnCount + response.data.streamWarnCount + response.data.levelWarnCount;
          }
        })
        .catch((err) => {
          this.$toast(err + "");
        });
      this.getDeviceCount(this.sensorTypes, this.unitId)
      this.actions.forEach(item => {
        if (item => this.hasBtnPermission(item.permission))
          this.filterActions.push(item)
      })
    },
    computed: {
      path() {
        return this.$route.path;
      },
    },
    methods: {
      swipeOnClick(deviceType, index) {
        this.sensorTypes = deviceType;
        this.active = index;
        if (index == 0) {
          this.getDeviceCount(deviceType, this.unitId);
        } else {
          this.getDeviceCount(deviceType, this.unitId);
        }
        this.$refs.warnCardRef.refresh(this.type, this.sensorTypes)
      },
      onSelect(item) {
        this.$router.push({path: item.path})
      },
      goDeviceList(state, deviceType) {
        this.$router.push({
          path: "/app/warn/common/deviceList",
          query: {
            type: this.type,
            state: state,
            deviceType: deviceType,
            sensorTypes: this.sensorTypes,
            unitId: this.unitId
          }
        });
      },
      getDeviceState(item) {
        return getDeviceState(item);
      },
      getDeviceType(deviceType) {
        let value = '';
        constant.deviceTypeOptions.forEach(item => {
          if (item.id === deviceType) {
            value = item.name;
          }
        });
        return value;
      },
      getDeviceCount(sensorTypes, unitId) {
        getDeviceCount({sensorTypes: sensorTypes, unitId: unitId})
          .then((response) => {
            if (response.success) {
              this.sumCount = response.data.sumCount;
              this.offlineCount = response.data.offlineCount;
              this.warnCount = response.data.pressureWarnCount + response.data.streamWarnCount + response.data.levelWarnCount;
            }
          })
          .catch((err) => {
            this.$toast(err + "");
          });
      },
    },
  };
</script>
<style scoped>
  .swipe-item-background {
    border-radius: 50%;
    width: 50px;
    height: 50px;
    background: #F4F7FE;
    display: flex;
    align-items: center;
    justify-content: center
  }

  .swipe-item-background-active {
    border-radius: 50%;
    width: 50px;
    height: 50px;
    background: #1989FA;
    display: flex;
    align-items: center;
    justify-content: center
  }

  .swipe-font {
    color: #9B9B9B;
    line-height: 35px;
  }

  .swipe-font-active {
    color: #1989FA;
    line-height: 35px;
  }

  .water >>> .van-badge--fixed {
    position: absolute;
    top: 0;
    right: 0;
    -webkit-transform: translate(50%, -50%);
    transform: translate(30%, 20%);
    -webkit-transform-origin: 100%;
    transform-origin: 100%;
  }

</style>
