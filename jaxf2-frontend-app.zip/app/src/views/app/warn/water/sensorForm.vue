<template>
  <div>
    <common-head :isBack="true" :customTitle="true" :customRight="true" background-color="#FFFFFF"
                 :back-img="require('@/assets/images/new/back1.png')"
                 back-img-style="width: 8px;height: 16px">
      <template #title>
        <span style="color: black;font-weight: bolder">{{isEdit?'编辑传感器' : '新增传感器'}}</span>
      </template>
      <template #right>
        <van-button @click="save" size="small" style="border-radius: 6px;font-size: 12px;padding: 12px 15px;
                          height: 18px;background-color: #1989FA!important;color: #FFFFFF">保存
        </van-button>
      </template>
    </common-head>
    <div class="content">
      <div class="cards-navbar" style="background: #F4F4F4;">
        <div class="card">
          <div class="form water-form">
            <van-form ref="formRef">
              <my-select
                ref="unitRef"
                :required="true"
                label="联网单位："
                :isBottom="true"
                placeholder="点击选择联网单位"
                filterable
                s-label="name"
                s-value="id"
                :rules="rules.unit"
                input-align="right"
                :options="unitOptions"
                @confirm="changeUnit"
              />
              <my-select
                ref="deviceRef"
                :isBottom="true"
                :required="true"
                :rules="rules.device"
                label="水主　机："
                placeholder="点击选择水主机"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :options="deviceOptions"
                @confirm="(value)=>{this.temp.deviceId = value}"
              />
              <van-field v-model="temp.name"
                         required
                         input-align="right"
                         label="传感器名称："
                         :rules="rules.name"
                         placeholder="请输入传感器名称"
              />
              <my-select
                label="传感器类型："
                ref="sensorTypeRef"
                :isBottom="true"
                :required="true"
                placeholder="点击选择传感器类型"
                filterable
                s-label="name"
                s-value="id"
                :rules="rules.sensorType"
                input-align="right"
                :options="sensorTypeOptions"
                @confirm="(value)=>{
              this.temp.sensorType = value;
              this.temp.onPosition = null;
              this.$refs.positionRef.value = null;
              this.positionOptions = this.waterConstant.positionOptions.filter(item => item.typeId === this.temp.sensorType);
            }"
              />
              <my-select
                label="接入位置："
                :required="true"
                ref="positionRef"
                :isBottom="true"
                placeholder="点击选择接入位置"
                filterable
                s-label="name"
                s-value="id"
                input-align="right"
                :rules="rules.onPosition"
                :options="positionOptions"
                @confirm="(value)=>{this.temp.onPosition = value}"
              />
              <van-field
                v-model="temp.position"
                required
                :rules="rules.position"
                input-align="right"
                label="设备位置："
                placeholder="请输入位置"
              />
              <van-field v-if="temp.sensorType === 2"
                         v-model="temp.floorSpace"
                         :rules="rules.floorSpace"
                         required
                         input-align="right"
                         label="底面　积："
                         placeholder="请输入底面积"
              />
              <van-field v-if="temp.sensorType === 2"
                         v-model="temp.high"
                         :rules="rules.high"
                         required
                         input-align="right"
                         label="高　　　："
                         placeholder="请输入高"
              />
              <van-field
                v-model="temp.minWarn"
                :rules="rules.minWarn"
                required
                input-align="right"
                label="最小预警："
                placeholder="请输入最小预警"
              />
              <van-field
                v-model="temp.maxWarn"
                required
                :rules="rules.maxWarn"
                input-align="right"
                label="最大预警："
                placeholder="请输入最大预警"
              />
            </van-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import waterConstant from "@/api/water/constant.js";
  import commonHead from "@/views/app/common/head";
  import mySelect from "@/views/app/common/my-select/index"
  import commonConstant from "@/api/common/constant";
  import {getDeviceList} from "@/api/water/index";
  import {addSensor, updateSensor, waterSensorDetail} from "../../../../api/water";
  import {getSelectorList} from "../../../../api/sys/unit";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        type: commonConstant.deviceTypeObject.water,
        sensorTypeOptions: waterConstant.sensorTypeOptions,
        waterConstant: waterConstant,
        positionOptions: [],
        loading: false,
        unitOptions: [],
        isEdit: false,
        deviceOptions: [],
        rules: {
          device: [{required: true, message: '', trigger: "onBlur/onChange"}],
          sensorType: [{required: true, message: '', trigger: "onBlur/onChange"}],
          minWarn: [{required: true, message: '', trigger: "onBlur/onChange"}],
          maxWarn: [{required: true, message: '', trigger: "onBlur/onChange"}],
          position: [{required: true, message: '', trigger: "onBlur/onChange"}],
          onPosition: [{required: true, message: '', trigger: "onBlur/onChange"}],
          unit: [{required: true, message: '', trigger: "onBlur/onChange"}],
          name: [{required: true, message: '', trigger: "onBlur/onChange"}]
        },
        temp: {
          name: null,
          sensorType: null,
          onPosition: null,
          onPositionName: null,
          sensorTypeName: null,
          floorSpace: null,
          position: null,
          high: null,
          minWarn: null,
          maxWarn: null,
          deviceId: null,
        },
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      if (this.$route.query.id) {
        this.id = this.$route.query.id
        this.init(this.id);
      }
      getSelectorList({isOnline: 1}).then((response) => {
        this.unitOptions = response.data;
        if (this.unitId) {
          this.temp.unitId = this.unitId
          if (this.unitOptions.find(item => item.id === this.temp.unitId)) {
            this.$refs.unitRef.value = this.unitOptions.find(item => item.id === this.temp.unitId).name
          }
        }
      });
    },
    methods: {
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      init(id) {
        this.isEdit = true;
        waterSensorDetail(id).then(response => {
          if (response.success) {
            this.temp = response.data
            this.$refs.unitRef.value = response.data.unitName
            this.$refs.deviceRef.value = response.data.deviceName
            this.$refs.sensorTypeRef.value = response.data.deviceName
            this.$refs.positionRef.value = response.data.deviceName
            getDeviceList({unitId: response.data.unitId}).then(response => {
              if (response.success) {
                response.data.forEach(item => {
                  this.deviceOptions.push({id: item.id, name: item.name + "(" + item.imei + ")"})
                })
              }
            })
          }
        })
      },
      changeUnit(value) {
        this.temp.unitId = value;
        this.temp.deviceId = null;
        this.$refs.deviceRef.value = null;
        this.deviceOptions = [];
        getDeviceList({unitId: value}).then(response => {
          if (response.success) {
            response.data.forEach(item => {
              this.deviceOptions.push({id: item.id, name: item.name + "(" + item.imei + ")"})
            })
          }
        })
      },
      goBack() {
        let routeArray = JSON.parse(sessionStorage.getItem("lasterRouter"));
        let path = routeArray[routeArray.length - 1]
        this.$router.push(path);
      },
      save() {
        this.$refs.formRef.validate().then(() => {
          this.loading = true;
          if (!this.isEdit) {
            addSensor(this.temp)
              .then((response) => {
                if (response.success) {
                  store.commit('hideLoading')
                  this.loading = false;
                  this.$toast("保存成功");
                  setTimeout(this.goBack(), 500);
                } else {
                  this.loading = false;
                  this.$toast(response.message);
                }
              })
              .catch((err) => {
                store.commit('hideLoading')
                this.loading = false;
                this.$toast(err + "");
              });
          } else {
            updateSensor(this.temp)
              .then((response) => {
                if (response.success) {
                  this.loading = false;
                  this.$toast("保存成功");
                  setTimeout(this.goBack(), 500);
                } else {
                  this.loading = false;
                  this.$toast(response.message);
                }
              })
              .catch((err) => {
                this.loading = false;
                this.$toast(err + "");
              });

          }
        }).catch(err => {

        })
      },
    },
  };
</script>

<style scoped>
  .water-form >>> .van-field__label {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    flex: none;
    box-sizing: border-box;
    width: 6.2em;
    margin-right: 12px;
    color: #979797;
    text-align: left;
    word-wrap: break-word;
  }

</style>
