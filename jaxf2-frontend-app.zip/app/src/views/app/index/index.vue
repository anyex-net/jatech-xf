<template>
  <div>
    <common-head :customTitle="true" :isMore="true" :filterActions="filterActions"
                 @onSelect="onSelect">
      <template #title>
        <my-select
          :isLink="false"
          :isSelectWhite="true"
          :options="unitList"
          :readonly="mySelectReadonly"
          @confirm="onClickItem"
          filterable
          input-align="center"
          ref="unitRef"
          s-label="name"
          s-value="id"
        />
      </template>

    </common-head>
    <div class="content" style="background: #ffffff;">
      <div class="cards-navbar">
        <div class="index-background"/>
        <div class="swipe-wrapper" style="margin-top: -240px;z-index: 22">
          <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
            <van-swipe-item
            ><img src="@/assets/images/banner1.png" alt=""
            /></van-swipe-item>
            <van-swipe-item
            ><img src="@/assets/images/banner1.png" alt=""
            /></van-swipe-item>
            <van-swipe-item
            ><img src="@/assets/images/banner1.png" alt=""
            /></van-swipe-item>
          </van-swipe>
        </div>
        <van-grid style="margin-top: 20px;z-index:1" class="childrenMenu" :border="false" :column-num="4">
          <van-grid-item @click="goItemPath(item.path)" :key="item.id"
                         v-for="(item, index) in childrenMenuList">
            <!-- <div
               style="border-radius:50%;width: 50px;height: 50px;background: #F4F7FE;display: flex;align-items: center;justify-content: center">
               <van-image width="40" :src="require('@/assets/images/'+item.meta.icon+'.png')"/>
             </div>
             <span class="font-PingFang" style="line-height: 25px;color:#45444A">{{item.meta.title}}</span>
             <div class="num font-PingFang" v-if="item.warnCount && item.warnCount !== 0 && item.warnCount !== ''">
               {{item.warnCount}}
             </div>-->
            <van-badge color="#FF585C" :content="item.warnCount ===0 ?'' : item.warnCount"
                       position="bottom-right">
              <div
                style="border-radius:50%;width: 45px;height: 45px;background: #F4F7FE;display: flex;align-items: center;justify-content: center">
                <van-image v-if="item.meta.icon != '' && item.meta.icon != null && item.meta.icon" width="30" :src="require('@/assets/images/'+item.meta.icon+'.png')"/>
                <van-image v-else width="30" :src="require('@/assets/images/xuncha.png')"/>
              </div>
            </van-badge>
            <span class="font-PingFang"
                  style="line-height: 35px;color:#45444A;font-size:14px">{{item.meta.title}}</span>
          </van-grid-item>
        </van-grid>
        <!--<div class="daichuli">
          <van-cell-group>
            <van-cell class="title title5" title="待处理事项"/>
          </van-cell-group>

          <common-warn-card :types="types"/>
        </div>-->
        <!--<div class="img-wrapper">
          <img src="@/assets/images/news.png" alt=""/>
        </div>-->
        <div class="nav-bottom"/>
      </div>
    </div>
  </div>
</template>

<script>
  import commonHead from "@/views/app/common/head";
  import {warnCount} from "../../../api/common/common";
  import mySelect from "@/views/app/common/my-select/index";
  import {getSelectorList} from "../../../api/sys/unit";
  import {hasBtnPermission} from "../../../utils/permission";
  import store from "../../../store";

  export default {
    components: {commonHead, mySelect},
    data() {
      return {
        childrenMenuList: [],
        menus: this.$store.getters.menus,
        types: '',
        mySelectReadonly: false,
        unitList: [],
        unitId: null,
        filterActions: [],
        actions: [
          {
            text: '单位管理',
            path: '/app/sys/unit/index',
            permission: 'sys:unit:index'
          }
        ]
      };
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId;
      }
      this.init()
      this.actions.forEach(item1 => {
        if (this.hasBtnPermission(item1.permission))
          this.filterActions.push(item1)
      })
    },
    mounted() {

    },
    computed: {
      unitName() {
        return this.$store.getters.user.unitName;
      },
    },
    methods: {
      onSelect(item) {
        this.$router.push({path: item.path})
      },
      hasBtnPermission(value) {
        if (value != null) {
          value = value.replace('switchs', 'switch')
          return hasBtnPermission(value)
        } else {
          return false;
        }
      },
      goItemPath(path) {
        this.$router.push({path: path, query: {unitId: this.unitId}});
      },
      getUnitList() {
        store.commit('showLoading')
        getSelectorList({isOnline: true}).then(response => {
          if (response.success) {
            this.unitList = response.data
            if (this.unitList.length > 0) {
              if (this.unitId == null) {
                this.onClickItem(this.unitList[0].id)
                this.$refs.unitRef.value = this.unitList[0].name
              } else {
                if (this.unitList.find(item => item.id === this.unitId)) {
                  this.onClickItem(this.unitId)
                  if (this.unitList.find(item => item.id === this.unitId)) {
                    this.$refs.unitRef.value = this.unitList.find(item => item.id === this.unitId).name;
                  }
                } else {
                  this.onClickItem(this.unitList[0].id)
                  this.$refs.unitRef.value = this.unitList[0].name
                }
              }
            }
            store.commit('hideLoading')
          }
        }).catch(err => {
          store.commit('hideLoading')
        })
      },
      onClickItem(val) {
        if (this.unitId !== val) {
          this.$router.replace({
            query: {
              unitId: val,
            }
          })
        }
        this.unitId = val;
        this.childrenMenuList.forEach((item, index) => {
            this.getWarnCount(item, index, val)
          }
        )
      },
      init() {
        this.unitList = []
        this.childrenMenuList = [];
        this.childrenMenuList = this.getChildrenMenu(this.childrenMenuList, this.menus, 0);
        this.getUnitList();
      },
      getWarnCount(item, index, unitId) {
        if (item.warnPath) {
          warnCount(item.warnPath, {unitId: unitId}).then((response) => {
            if (response.success) {
              item.warnCount = response.data
              this.$set(this.childrenMenuList, index, item)
            }
          }).catch((err) => {
            item.warnCount = 0;
          });
        }
      },
      getChildrenMenu(childrenMenuList, menus, index) {
        menus.forEach(item => {
          if (item.children.length !== 0)
            this.getChildrenMenu(childrenMenuList, item.children, index + 1)
          else if (index !== 0) {
            this.types = this.types + item.name + ","
            childrenMenuList.push(item);
          }
        });
        return childrenMenuList;
      },
    },
  };
</script>

<style lang="less">
  @import "../../../styles/home";
</style>

<style scoped>

  .childrenMenu >>> .van-grid-item__text {
    font-size: 14px;
    color: #353535;
    line-height: 25px;
  }

  .childrenMenu >>> .van-grid-item__content {
    background-color: transparent;
  }

  .index-background {
    width: 100%;
    height: 240px;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: center;
    background-image: url("../../../assets/images/new/indexBackground.png");
    z-index: 20;
  }

  .childrenMenu >>> .van-badge--fixed {
    position: absolute;
    top: 0;
    right: 0;
    -webkit-transform: translate(60%, -50%);
    transform: translate(40%, 0%);
    -webkit-transform-origin: 100%;
    transform-origin: 100%;
  }
</style>

