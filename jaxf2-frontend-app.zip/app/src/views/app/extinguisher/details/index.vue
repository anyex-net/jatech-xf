<template>
  <div style="background-color: #F4F4F4;">
    <common-head
      :is-back="true"
      :scan="true"
      title="灭火器管理"
      @scanData="getScanData"
    />
    <div class="content">
      <div style="margin: 12px;position: static !important;">
        <div class="cards-navbar">
          <van-field
            v-model="extinguisherData.query.address"
            input-align="right"
            clearable
            label="设备地址:"
            placeholder="请输入设备地址"
          />
          <van-field
            v-model="extinguisherData.query.building"
            input-align="right"
            clearable
            label="幢:"
            placeholder="请输入幢"
          />
          <van-field
            v-model="extinguisherData.query.storey"
            input-align="right"
            clearable
            label="层:"
            placeholder="请输入层"
          />
          <van-field
            v-model="extinguisherData.query.position"
            input-align="right"
            clearable
            label="安装位置:"
            placeholder="请输入安装位置"
          />
          <van-cell title="设备型号:" is-link :value="selectQuery.typeName" @click="extinguisherTypeChoice" />
          <van-cell title="设备状态:" is-link :value="selectQuery.stateName" @click="extinguisherStateShow = true" />
          <van-row type="flex" justify="space-around">
            <van-button style="width: 90px;height: 30px" type="default" color="#4CDA64" @click="selectList">查询
            </van-button>
            <van-button style="width: 90px;height: 30px" type="default" color="#F14949" @click="resetQuery">清除
            </van-button>
            <van-button style="width: 90px;height: 30px" type="default" color="#208DD0" @click="doAdd">新增</van-button>
          </van-row>
        </div>
      </div>
      <div id="exhibition">
        <van-list
          v-model="extinguisherData.loading"
          :finished="extinguisherData.finished"
          :finished-text="extinguisherData.message"
          @load="onExtinguisherLoad"
        >
          <template v-for="item in extinguisherData.list">
            <van-swipe-cell>
              <div id="contentData" @click="doDetails(item)">
                <span class="title">{{ item.name }}</span>
                <van-divider />
                <div style="display: flex;flex-direction: column;">
                  <span class="item">安装位置：
                    <span>{{ item.position }}</span>
                  </span>
                  <span class="item">类型：
                    <span>{{ item.typeName }}</span>
                  </span>
                  <span class="item">状态：
                    <span v-if="item.state === -1" style="color: #fc1313">报废</span>
                    <span v-if="item.state === 0" style="color: #0055ff">备用</span>
                    <span v-if="item.state === 1" style="color: #01ff01">正常</span>
                    <span v-if="item.state === 2" style="color: #fc1313">瓶体即将过期</span>
                    <span v-if="item.state === 3" style="color: #fc1313">灭火剂即将过期</span>
                  </span>
                  <span class="item">报废时间：
                    <span>{{ item.scrapDate }}</span>
                  </span>
                </div>
              </div>
              <template #right>
                <van-button style="height: 100%" square type="info" text="编辑" @click="doEdit(item)" />
              </template>
            </van-swipe-cell>
          </template>
        </van-list>
      </div>
    </div>
    <div class="addLevitationBall" @click="doAdd">
      <van-icon name="plus" color="#FFFFFF" size="25" />
    </div>
    <van-action-sheet
      v-model="extinguisherTypeShow"
      cancel-text="取消"
      close-on-click-action
      :actions="extinguisherTypeActions"
      @select="onExtinguisherTypeSelect"
    />
    <van-action-sheet
      v-model="extinguisherStateShow"
      cancel-text="取消"
      close-on-click-action
      :actions="extinguisherStateActions"
      @select="onExtinguisherStateSelect"
    />
  </div>
</template>

<script>
import commonHead from '@/views/app/common/head'
import { extinguisherPage } from '@/api/newExam/extinguisher'
import { extinguisherType_List } from '@/api/newExam/extinguisherType'
import { getInfoByCodeAndUnitId } from '@/api/newExam/point'

export default {
  name: 'Index',
  components: { commonHead },
  data() {
    return {
      extinguisherData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: this.$route.query.unitId,
          position: null,
          address: null,
          typeId: null,
          state: null,
          building: null,
          storey: null,
          pageNo: 1,
          pageSize: 10
        }
      },
      selectQuery: {
        typeName: null,
        stateName: null
      },
      extinguisherTypeShow: false,
      extinguisherTypeActions: [],
      extinguisherStateShow: false,
      extinguisherStateActions: [
        { id: -1, name: '报废' },
        { id: 0, name: '备用' },
        { id: 1, name: '正常' },
        { id: 2, name: '瓶体即将过期' },
        { id: 3, name: '灭火剂即将过期' }
      ],
      states: this.$route.query.states
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  created() {
    this.init()
  },
  methods: {
    /**
     * 初始化
     */
    init() {
      if (this.states === '3') {
        this.extinguisherData.query.state = 3
        this.selectQuery.stateName = '灭火剂快到期'
      }
      if (this.states === '2') {
        this.extinguisherData.query.state = 2
        this.selectQuery.stateName = '瓶体快到期'
      }
      if (this.states === '0') {
        this.extinguisherData.query.state = 0
        this.selectQuery.stateName = '备用'
      }
      this.getList()
    },
    /**
     * 清除
     */
    resetQuery() {
      this.extinguisherData.list = []
      this.extinguisherData.query = {
        position: null,
        address: null,
        typeId: null,
        state: null,
        pageNo: 1,
        pageSize: 10
      }
      this.selectQuery = {
        typeName: null,
        stateName: null
      }
      this.getList()
    },
    /**
     *查询
     */
    selectList() {
      this.extinguisherData.list = []
      this.getList()
    },
    /**
     * 查询灭火器类型选择
     */
    onExtinguisherTypeSelect(val) {
      this.selectQuery.typeName = val.name
      this.extinguisherData.query.typeId = val.id
    },
    /**
     * 获取灭火器类型表
     */
    extinguisherTypeChoice() {
      this.extinguisherTypeActions = []
      extinguisherType_List().then(res => {
        if (res.success) {
          this.extinguisherTypeActions = res.data
          this.extinguisherTypeShow = true
        } else {
          this.$message({
            message: res.message,
            type: 'danger'
          })
        }
      })
    },
    /**
     * 查询状态选择
     */
    onExtinguisherStateSelect(val) {
      this.selectQuery.stateName = val.name
      this.extinguisherData.query.state = val.id
    },
    /**
     * 获取列表数据
     */
    getList() {
      extinguisherPage(this.extinguisherData.query).then(res => {
        this.extinguisherData.list = this.extinguisherData.list.concat(res.data.rows)
        // 加载状态结束
        this.extinguisherData.loading = false
        this.extinguisherData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.extinguisherData.list.length >= res.data.totalRows) {
          this.extinguisherData.finished = true
        }
      }).catch(err => {
        console.log(err)
      })
    },
    /**
     * 列表加载
     */
    onExtinguisherLoad() {
      this.extinguisherData.query.pageNo++
      this.getList()
    },
    /**
     * 详情
     */
    doDetails(val) {
      this.$router.push({
        path: '/app/extinguisher/operation/index',
        query: {
          extinguisherId: val.id,
          operationType: 'details'
        }
      })
    },
    /**
     * 新增
     */
    doAdd() {
      this.$router.push({
        path: '/app/extinguisher/operation/index',
        query: {
          operationType: 'add'
        }
      })
    },
    /**
     * 编辑
     */
    doEdit(val) {
      this.$router.push({
        path: '/app/extinguisher/operation/index',
        query: {
          extinguisherId: val.id,
          operationType: 'edit'
        }
      })
    },
    /**
     * 扫一扫回调函数
     */
    getScanData(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      getInfoByCodeAndUnitId({ code: val.code, unitId: this.userInfo.unitId }).then(res => {
        this.doDetails(res.data.id)
      })
    }
  }
}
</script>

<style scoped>
.content{
  height: 100vh;
}

.cards-navbar {
  background-color: #FFFFFF !important;
  position: static !important;
  height: auto !important;
  overflow-y: auto !important;
  padding-bottom: 12px;
}

#exhibition {
  margin: 15px 10px;
  font-family: PingFang SC Bold;
  height: calc(100vh - 400px);
  overflow: scroll;
}

#contentData{
  background-color: #FFFFFF;
  padding: 15px 16px 8px 16px;
  margin-top: 12px;
}

#contentData .van-divider{
  margin: 11px 0 !important;
}

#contentData .title{
  font-family: PingFang SC Bold;
  font-size: 14px;
  font-weight: normal;
  line-height: 14px;
  letter-spacing: 0em;
  color: #3A3A44;
}

#contentData .item{
  font-family: PingFangSC-Regular;
  font-size: 12px;
  font-weight: normal;
  line-height: 12px;
  letter-spacing: 0em;
  color: #979797;
  padding: 0 0 10px 0;
}
.addLevitationBall{
  width: 56px;
  height: 56px;
  background: linear-gradient(130deg, #41A5FF 6%, #1477FF 91%);
  box-shadow: 0 2px 24px 0 rgba(20, 119, 255, 0.12);
  position: absolute;
  top:266px;
  right: 0;
  border-radius: 30px;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}
</style>
