<template>
  <div style="background-color: #F4F4F4;height: 100vh">
    <common-head
      :is-back="true"
      :scan="true"
      title="灭火器管理"
      @scanData="getScanData"
    />
    <div class="content">
      <div id="info" class="cards-navbar">
        <van-row type="flex" justify="space-around">
          <van-col span="6">
            <div @click="onClickActive(1)">
              <span>{{ extinguisherInfo.sum }}</span>
              <van-icon name="arrow" />
            </div>
            <span class="span_font">总数</span>
          </van-col>
          <van-col span="6">
            <div @click="onClickActive(2)">
              <span>{{ extinguisherInfo.fireExtinguishingAgent }}</span>
              <van-icon name="arrow" />
            </div>
            <span class="span_font">需维护</span>
          </van-col>
          <van-col span="6">
            <div @click="onClickActive(3)">
              <span>{{ extinguisherInfo.bottle }}</span>
              <van-icon name="arrow" />
            </div>
            <span class="span_font">即将报废</span>
          </van-col>
          <van-col span="6">
            <div @click="onClickActive(4)">
              <span>{{ extinguisherInfo.spare }}</span>
              <van-icon name="arrow" />
            </div>
            <span class="span_font">备用数量</span>
          </van-col>
        </van-row>
      </div>
      <div id="infoContent">
        <div id="exhibition">
          <van-loading
            v-if="false"
            color="#1989fa"
            style="width: 100%;height:90px;display: flex;align-items: center;justify-content: center"
            vertical
          >
            <span style="color:#1989fa">加载中...</span>
          </van-loading>
          <van-list
            v-model="extinguisherData.loading"
            :finished="extinguisherData.finished"
            :finished-text="extinguisherData.message"
            @load="onExtinguisherLoad"
          >
            <template v-for="item in extinguisherData.list">
              <div id="contentData" @click="doDetails(item)">
                <span class="title">{{ item.name }}</span>
                <van-divider />
                <div style="display: flex;flex-direction: column;">
                  <span class="item">安装位置：{{ item.address }}</span>
                  <span class="item">类型：{{ item.typeName }}</span>
                  <span class="item">状态：
                    <span v-if="item.state === -1" style="color: #fc1313">报废</span>
                    <span v-if="item.state === 0" style="color: #0055ff">备用</span>
                    <span v-if="item.state === 1" style="color: #01ff01">正常</span>
                    <span v-if="item.state === 2" style="color: #fc1313">瓶体即将过期</span>
                    <span v-if="item.state === 3" style="color: #fc1313">灭火剂即将过期</span>
                  </span>
                  <span class="item">报废时间：{{ item.scrapDate }}</span>
                </div>
              </div>
              <van-divider />
            </template>
          </van-list>
        </div>
      </div>
    </div>
    <div class="addLevitationBall" @click="doAdd">
      <van-icon name="plus" color="#FFFFFF" size="25" />
    </div>
  </div>
</template>

<script>
import commonHead from '@/views/app/common/head'
import { extinguisherPage, getStatistics, extinguisherList } from '@/api/newExam/extinguisher'

export default {
  name: 'Index',
  components: { commonHead },
  data() {
    return {
      tabsShow: false,
      extinguisherInfo: {
        bottle: 0,
        fill: 0,
        fireExtinguishingAgent: 0,
        normal: 0,
        spare: 0,
        sum: 0
      },
      extinguisherData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          unitId: this.$route.query.unitId,
          pageNo: 1,
          pageSize: 10
        }
      }
    }
  },
  computed: {
    userInfo() {
      return this.$store.getters.user
    }
  },
  created() {
    this.init()
  },
  methods: {
    /**
     * 新增
     */
    doAdd() {
      this.$router.push({
        path: '/app/extinguisher/operation/index',
        query: {
          operationType: 'add'
        }
      })
    },
    /**
     * 初始化
     */
    init() {
      this.getStatisticsInfo()
      this.getList()
    },
    /**
     * 获取列表数据
     */
    getList() {
      extinguisherPage(this.extinguisherData.query).then(res => {
        this.extinguisherData.list = this.extinguisherData.list.concat(res.data.rows)
        // 加载状态结束
        this.extinguisherData.loading = false
        this.extinguisherData.total = res.data.totalRows
        // 数据全部加载完成
        if (this.extinguisherData.list.length >= res.data.totalRows) {
          this.extinguisherData.finished = true
        }
      })
    },
    /**
     * 列表加载
     */
    onExtinguisherLoad() {
      this.extinguisherData.query.pageNo++
      this.getList()
    },
    /**
     * 详情
     */
    doDetails(val) {
      this.$router.push({
        path: '/app/extinguisher/operation/index',
        query: {
          extinguisherId: val.id,
          operationType: 'details'
        }
      })
    },
    /**
     * 灭火器统计信息
     */
    getStatisticsInfo() {
      this.extinguisherInfo = {
        bottle: 0,
        fill: 0,
        fireExtinguishingAgent: 0,
        normal: 0,
        spare: 0,
        sum: 0
      }
      getStatistics({ unitId: this.$route.query.unitId }).then(res => {
        this.extinguisherInfo = res.data
      })
    },
    /**
     * 扫一扫回调函数
     */
    getScanData(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      extinguisherList({ code: val.code, unitId: this.userInfo.unitId }).then(res => {
        if (res.data.length === 1) {
          this.$router.push({
            path: '/app/extinguisher/operation/index',
            query: {
              extinguisherId: res.data[0].id,
              operationType: 'details'
            }
          })
        } else {
          this.$toast({
            type: 'danger',
            message: '扫描正确的二维码！'
          })
        }
      })
    },
    /**
     * 切换活动
     * @param val
     */
    onClickActive(val) {
      let states
      if (val === 2) {
        states = '3'
      }
      if (val === 3) {
        states = '2'
      }
      if (val === 4) {
        states = '0'
      }
      this.$router.push({
        path: '/app/extinguisher/details/index',
        query: {
          states: states,
          unitId: this.$route.query.unitId
        }
      })
    }
  }
}
</script>

<style scoped>
.cards-navbar {
  background-color: #F4F4F4 !important;
  position: static !important;
}

#info {
  background: linear-gradient(180deg, #1989FA 0%, rgba(25, 137, 250, 0.00) 100%);
  height: 158px;
  color: #FFFFFF;
}

#info .van-row {
  padding: 31px 0 22px 0
}

#info .van-row .van-col {
  display: flex;
  flex-direction: column;
  align-items: center;
}

#info .van-row .van-col div {
  display: flex;
  align-items: center;
  justify-content: center;
}

#info .van-row .van-col span {
  font-family: PingFang SC Bold;
  font-size: 12px;
}

#info .van-row .van-col div span {
  font-family: PingFang SC Bold;
  font-size: 22px;
  font-weight: bolder;
}

#info .van-row .van-col div .van-icon {
  font-size: 18px;
  line-height: 22px;
  /*font-weight: bolder;*/
}

.span_font {
  font-family: PingFang SC Bold;
}

#infoContent {
  margin-top: -64px;
  z-index: 999;
  height: calc(100vh - 158px);
  overflow: scroll;
}

#exhibition {
  background-color: #FFFFFF;
  margin: 15px 10px;
  font-family: PingFang SC Bold;
}

#exhibition .infoCard {
  margin-bottom: 8px;
}

#exhibition .van-divider{
  margin: 0px !important;
}

#contentData{
  padding: 15px 16px 8px 16px;
}

#contentData .van-divider{
  margin: 11px 0 !important;
}

#contentData .title{
  font-family: PingFang SC Bold;
  font-size: 14px;
  font-weight: normal;
  line-height: 14px;
  letter-spacing: 0em;
  color: #3A3A44;
}

#contentData .item{
  font-family: PingFangSC-Regular;
  font-size: 12px;
  font-weight: normal;
  line-height: 12px;
  letter-spacing: 0em;
  color: #979797;
  padding: 0 0 10px 0;
}
.addLevitationBall{
  width: 56px;
  height: 56px;
  background: linear-gradient(130deg, #41A5FF 6%, #1477FF 91%);
  box-shadow: 0 2px 24px 0 rgba(20, 119, 255, 0.12);
  position: absolute;
  top:266px;
  right: 0;
  border-radius: 30px;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}
</style>
