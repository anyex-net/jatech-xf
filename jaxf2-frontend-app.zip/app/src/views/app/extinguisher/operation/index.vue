<template>
  <div style="background-color: #F4F4F4;">
    <common-head
      :is-back="true"
      :scan="false"
      :title="title"
    />
    <div class="content">
      <van-form v-if="operationType !== 'details' && operationType !== 'showDetails'" ref="tempForm" style="background-color: #FFFFFF" @submit="onSubmit">
        <my-select
          ref="unitRef"
          name="unitId"
          label="联网单位"
          placeholder="点击选择联网单位"
          filterable
          s-label="name"
          s-value="id"
          :is-bottom="true"
          input-align="right"
          :options="unitOptions"
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '点击选择联网单位' }]"
          @confirm="onUnitConfirm"
        />
        <van-field
          v-model="temp.name"
          name="name"
          label="名称"
          placeholder="名称"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写名称' }]"
        />
        <van-field
          v-model="temp.code"
          :readonly="readonly"
          required
          placeholder="请填写二维码"
          input-align="right"
          label="二维码:"
          name="code"
          :rules="[{ validator: asyncVerifyCode, message: '请输入二维码已存在' },{ required: true, message: '请填写二维码' }]"
        >
          <template #right-icon>
            <scan width="12" @scanData="setCode">
              <template #icon>
                <van-icon name="scan" style="font-size: 16px;line-height: inherit;" />
              </template>
            </scan>
          </template>
        </van-field>
        <van-field
          v-model="temp.factoryName"
          name="factoryName"
          label="厂商"
          placeholder="厂商"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写厂商' }]"
        />
        <my-select
          ref="typeRef"
          name="typeId"
          label="灭火器类型"
          placeholder="点击选择灭火器类型"
          filterable
          s-label="name"
          s-value="id"
          :is-bottom="true"
          input-align="right"
          :options="typeOptions"
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请点击选择灭火器类型' }]"
          @confirm="(value)=>{this.temp.typeId = value}"
        />
        <my-select
          ref="stateRef"
          name="state"
          label="状态"
          placeholder="点击选择状态"
          filterable
          s-label="name"
          s-value="id"
          :is-bottom="true"
          input-align="right"
          :options="stateOptions"
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请点击选择状态' }]"
          @confirm="(value)=>{this.temp.state = value}"
        />
        <van-field
          required
          readonly
          clickable
          name="useDate"
          :value="temp.useDate"
          input-align="right"
          label="使用时间"
          placeholder="点击选择使用时间"
          right-icon="arrow"
          :rules="[{ required: true, message: '请选择使用时间' }]"
          @click="onDateClick('useDate')"
        />
        <van-field
          required
          readonly
          clickable
          name="fillDate"
          :value="temp.fillDate"
          input-align="right"
          label="上次填充时间"
          placeholder="点击选择上次填充时间"
          right-icon="arrow"
          :rules="[{ required: true, message: '请选择上次填充时间' }]"
          @click="onDateClick('fillDate')"
        />
        <van-field
          v-model="temp.intervalMonth"
          name="intervalMonth"
          label="间隔填充年份"
          placeholder="间隔填充年份"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写间隔填充年份' }]"
        />
        <van-field
          required
          readonly
          clickable
          name="factoryDate"
          :value="temp.factoryDate"
          input-align="right"
          label="出厂时间"
          placeholder="点击选择出厂时间"
          right-icon="arrow"
          :rules="[{ required: true, message: '请选择出厂时间' }]"
          @click="onDateClick('factoryDate')"
        />
        <van-field
          v-model="temp.life"
          name="life"
          label="使用年限"
          placeholder="使用年限"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写使用年限' }]"
        />
        <van-field
          v-if="operationType === 'details' || operationType === 'showDetails'"
          v-model="temp.scrapDate"
          name="scrapDate"
          label="报废时间"
          placeholder="报废时间"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写报废时间' }]"
        />
        <van-field
          v-model="temp.building"
          name="building"
          label="幢"
          placeholder="幢"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写幢' }]"
        />
        <van-field
          v-model="temp.storey"
          name="storey"
          label="层"
          placeholder="层"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写层' }]"
        />
        <van-field
          v-model="temp.position"
          name="position"
          label="安装位置"
          placeholder="安装位置"
          input-align="right"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写安装位置' }]"
        />
        <base-map-search
          ref="mapSearch"
          name="address"
          input-align="right"
          label="设备地址"
          :is-edit="readonly"
          :latitude="temp.lng"
          :longitude="temp.lng"
          :value="temp.address"
          :rules="[{ required: true, message: '请填写设备地址' }]"
          @updateLocation="updateLocation"
        />
        <van-field
          v-model="temp.lng"
          placeholder="请填写经度"
          input-align="right"
          label="经度:"
          name="lng"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写经度' }]"
        />
        <van-field
          v-model="temp.lng"
          placeholder="请填写纬度"
          input-align="right"
          label="纬度:"
          name="lat"
          clearable
          required
          :readonly="readonly"
          :rules="[{ required: true, message: '请填写纬度' }]"
        />
        <div v-if="operationType !== 'details' && operationType !== 'showDetails'" class="bar-footer">
          <van-button round block type="info" native-type="submit">提交</van-button>
        </div>
      </van-form>
      <div v-if="operationType === 'details' || operationType === 'showDetails'">
        <div style="padding: 24px 15px 24px 15px;background-color: #FFFFFF">
          <van-row>
            <van-col span="8" class="detailsLayout-right">
              <span style="margin-bottom: 20px">设备名称：</span>
              <span style="margin-bottom: 20px">设备编码：</span>
              <span style="margin-bottom: 20px">设备型号：</span>
              <span style="margin-bottom: 20px">设备状态：</span>
              <span style="margin-bottom: 20px">设备厂家：</span>
              <span style="margin-bottom: 20px">生产时间：</span>
              <span style="margin-bottom: 20px">下次维护时间：</span>
              <span>预计报废时间：</span>
            </van-col>
            <van-col span="16" class="detailsLayout-left">
              <span style="margin-bottom: 20px">{{ temp.name }}</span>
              <span style="margin-bottom: 20px">{{ temp.code }}</span>
              <span style="margin-bottom: 20px">{{ temp.typeName }}</span>
              <span style="margin-bottom: 20px">
                <span v-if="temp.state === -1">报废</span>
                <span v-if="temp.state === 0">备用</span>
                <span v-if="temp.state === 1">正常</span>
                <span v-if="temp.state === 2">瓶体即将过期</span>
                <span v-if="temp.state === 3">灭火剂即将过期</span>
              </span>
              <span style="margin-bottom: 20px">{{ temp.factoryName }}</span>
              <span style="margin-bottom: 20px">{{ toParseTime(temp.factoryDate, '{y}年{m}月{d}日') }}</span>
              <span style="margin-bottom: 20px">{{ toParseTime(temp.nextFillDate, '{y}年{m}月{d}日') }}</span>
              <span>{{ toParseTime(temp.scrapDate, '{y}年{m}月{d}日') }}</span>
            </van-col>
          </van-row>
        </div>
        <van-divider style="margin: 0 !important;" />
        <div style="margin-bottom: 12px;padding: 24px 15px 24px 15px;background-color: #FFFFFF">
          <van-row>
            <van-col span="8" class="detailsLayout-right">
              <span style="margin-bottom: 20px">单位名称：</span>
              <span style="margin-bottom: 20px">位置：</span>
              <span style="margin-bottom: 20px">幢：</span>
              <span>层：</span>
            </van-col>
            <van-col span="16" class="detailsLayout-left">
              <span style="margin-bottom: 20px">{{ temp.unitName }}</span>
              <span style="margin-bottom: 20px">{{ temp.address }}</span>
              <span style="margin-bottom: 20px">{{ temp.building }}</span>
              <span>{{ temp.storey }}</span>
            </van-col>
          </van-row>
        </div>
        <div v-if="operationType !== 'showDetails'" style="background-color: #FFFFFF">
          <div
            style="padding: 11px 0 15px 13px;color: #3A3A44;font-family: PingFang SC Bold;font-size: 18px;font-weight: normal;line-height: 18px;"
          >
            <span>历史巡查记录</span>
          </div>
          <van-divider style="margin: 0 !important;" />
          <van-list
            v-model="inspectionData.loading"
            :finished="inspectionData.finished"
            :finished-text="inspectionData.message"
            @load="onInspectionLoad"
          >
            <template v-for="item in inspectionData.list">
              <div style="padding: 22px 0 20px 16px" @click="goFillingDetails(item)">
                <van-row type="flex" justify="space-between" style="margin-bottom: 12px">
                  <van-col span="8">
                    <span
                      style="font-family: PingFangSC-Regular;font-size: 12px;font-weight: normal;line-height: 12px;color: #979797;padding-bottom: 14px"
                    >
                      操作内容：
                      <span v-if="item.extinguisherState === '1'" style="font-size: 16px;line-height: 16px;">更换</span>
                      <span v-if="item.extinguisherState === '2'" style="font-size: 16px;line-height: 16px;">报废</span>
                    </span>
                  </van-col>
                  <van-col span="10">
                    <span
                      style="font-family: PingFangSC-Regular;font-size: 12px;font-weight: normal;line-height: 12px;color: #979797;padding-bottom: 14px"
                    >
                      操作人员：<span style="font-size: 16px;line-height: 16px;">
                        {{ item.checkUserName }}
                      </span>
                    </span>
                  </van-col>
                </van-row>
                <van-row>
                  <span
                    style="font-family: PingFangSC-Regular;font-size: 16px;font-weight: normal;line-height: 16px;color: #979797;"
                  >
                    {{ item.checkTime }}
                  </span>
                </van-row>
              </div>
            </template>
          </van-list>
        </div>
      </div>
      <div class="nav-bottom" />
      <van-popup v-model="showDatePicker" position="bottom">
        <van-datetime-picker
          type="date"
          @confirm="onDateConfirm"
          @cancel="showDatePicker = false"
        />
      </van-popup>
    </div>
  </div>
</template>

<script>

import commonHead from '@/views/app/common/head'
import BaseMapSearch from '@/components/Map/baseMapSearch'
import mySelect from '@/views/app/common/my-select/index'
import { parseTime } from '@/utils'
import { getSelectorList } from '@/api/sys/unit'
import { extinguisherType_List } from '@/api/newExam/extinguisherType'
import { extinguisherAdd, extinguisherDetail, extinguisherUpdate, verifyCode } from '@/api/newExam/extinguisher'
import store from '@/store'
import { Toast } from 'vant'
import { getInfoByCodeAndUnitId } from '@/api/newExam/point'
import { taskLogPage } from '@/api/newExam/taskLog'
import Scan from '@/views/app/common/scan'

export default {
  name: 'Index',
  components: { commonHead, BaseMapSearch, mySelect, Scan },
  data() {
    return {
      title: '',
      readonly: false,
      extinguisherId: this.$route.query.extinguisherId,
      operationType: this.$route.query.operationType,
      temp: {
        address: null,
        code: null,
        factoryDate: null,
        factoryName: null,
        fillDate: null,
        id: null,
        intervalMonth: null,
        lat: null,
        life: null,
        lng: null,
        name: null,
        nextFillDate: null,
        position: null,
        scrapDate: null,
        state: null,
        states: null,
        typeId: null,
        typeName: null,
        unitId: null,
        unitName: null,
        useDate: null,
        building: null,
        storey: null
      },
      showDatePicker: false,
      dateType: '',
      stateOptions: [
        { id: -1, name: '报废' },
        { id: 0, name: '备用' },
        { id: 1, name: '正常' },
        { id: 2, name: '瓶体快到期' },
        { id: 3, name: '灭火剂快到期' }
      ],
      unitOptions: [],
      typeOptions: [],
      personLiableName: null,
      inspectionData: {
        finished: false,
        message: '没有更多了！',
        loading: true,
        total: 0,
        list: [],
        query: {
          type: 1,
          deviceId: null,
          unitId: null,
          checkStatus: 1,
          pageNo: 1,
          pageSize: 10
        }
      }
    }
  },
  created() {
    this.init()
  },
  methods: {
    setCode(val) {
      const index = val.code.lastIndexOf('/')
      val.code = val.code.substring(index + 1, val.code.length)
      this.temp.code = val.code
    },
    /**
     * 已检查点位详情
     */
    goFillingDetails(val) {
      this.$router.push({
        path: '/app/new/inspection/filling/details/index',
        query: {
          taskLogId: val.id
        }
      })
    },
    /**
     * 获取点位ID
     */
    getDeviceId() {
      getInfoByCodeAndUnitId({ code: this.temp.code, unitId: this.temp.unitId }).then(res => {
        if (res.data) {
          this.inspectionData.query.deviceId = res.data.id
          this.getInspectionList()
        } else {
          this.inspectionData.loading = false
          this.inspectionData.finished = true
        }
      })
    },
    /**
     * 获取巡查列表
     */
    getInspectionList() {
      taskLogPage(this.inspectionData.query).then(res => {
        this.inspectionData.list = this.inspectionData.list.concat(res.data.rows)
        this.inspectionData.sum = res.data.totalRows
        // 结束
        this.inspectionData.loading = false
        // 数据全部加载完成
        if (this.inspectionData.list.length >= res.data.totalRows) {
          this.inspectionData.finished = true
        }
      })
    },
    /**
     * 获取巡查列表更多
     */
    onInspectionLoad() {
      this.inspectionData.query.pageNo++
      this.getInspectionList()
    },
    /**
     * 时间格式化
     */
    toParseTime(time, format) {
      return parseTime(time, format)
    },
    /**
     * 异步校验code
     */
    asyncVerifyCode(val) {
      if (this.temp.unitId) {
        return new Promise((resolve) => {
          Toast.loading('验证中...')
          verifyCode({ code: val }).then(res => {
            Toast.clear()
            resolve(!res.data)
          })
        })
      } else {
        this.temp.code = null
        this.$toast({
          type: 'danger',
          message: '请选择联网单位！'
        })
      }
    },
    /**
     * 时间选择器点击事件
     */
    onDateClick(type) {
      if (!this.readonly) {
        this.showDatePicker = true
        this.dateType = type
      }
    },
    /**
     * 时间选择器点击事件
     */
    onDateConfirm(time) {
      const dateTime = parseTime(time)
      switch (this.dateType) {
        case 'useDate':
          this.temp.useDate = dateTime
          break
        case 'fillDate':
          this.temp.fillDate = dateTime
          break
        case 'factoryDate':
          this.temp.factoryDate = dateTime
          break
      }
      this.showDatePicker = false
    },
    getUnitDetails() {

    },
    /**
     * 获取灭火器标签详情
     */
    getExtinguisherDetail() {
      extinguisherDetail(this.extinguisherId).then(response => {
        this.temp = response.data
        if (this.operationType === 'details') {
          this.getDeviceId()
        }
        if (this.operationType === 'edit') {
          this.$refs.stateRef.value = this.stateOptions.find(item => item.id === this.temp.state).name
          this.$refs.unitRef.value = this.temp.unitName
          this.$refs.typeRef.value = this.temp.typeName
          this.$nextTick(() => {
            this.$refs.mapSearch.updateAddress(this.temp.address, this.temp.lng, this.temp.lat)
          })
        }
      })
    },
    /**
     * 获取单位列表
     */
    getUnitList() {
      this.unitOptions = []
      getSelectorList({ isOnline: 1 }).then((response) => {
        this.unitOptions = response.data
      })
    },
    /**
     * 选择单位列表事件
     */
    onUnitConfirm(value) {
      this.temp.unitId = value
      this.getTypeList(value)
    },
    /**
     * 获取灭火器类型列表
     */
    getTypeList(value) {
      this.typeOptions = []
      if (value) {
        extinguisherType_List(value).then(response => {
          this.typeOptions = response.data
        })
      } else {
        this.$toast({
          type: 'danger',
          message: '请选择联网单位！'
        })
      }
    },
    /**
     * 初始化
     */
    async init() {
      if (this.operationType === 'add') {
        await this.getUnitList()
        this.title = '添加灭火器'
        this.readonly = false
      }
      if (this.operationType === 'edit') {
        await this.getUnitList()
        this.title = '编辑灭火器'
        await this.getExtinguisherDetail()
        this.readonly = false
      }
      if (this.operationType === 'details' || this.operationType === 'showDetails') {
        this.title = '灭火器详情'
        await this.getExtinguisherDetail()
        this.readonly = true
      }
    },
    /**
     * 更新地图位置
     * @param lng
     * @param lat
     * @param address
     */
    updateLocation(lng, lat, address) {
      this.$nextTick(() => {
        this.temp.lng = lng
        this.temp.lat = lat
        this.temp.address = address
      })
    },
    /**
     * 提交事件
     */
    onSubmit() {
      this.$refs.tempForm.validate().then(() => {
        store.commit('showLoading')
        if (this.operationType === 'add') {
          extinguisherAdd(this.temp).then(res => {
            if (res.success) {
              this.$toast({
                type: 'success',
                message: '保存成功！'
              })
              const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
              const path = routeArray[routeArray.length - 1]
              this.$router.push(path)
            }
            store.commit('hideLoading')
          })
        }
        if (this.operationType === 'edit') {
          extinguisherUpdate(this.temp).then(res => {
            if (res.success) {
              this.$toast({
                type: 'success',
                message: '保存成功！'
              })
              const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
              const path = routeArray[routeArray.length - 1]
              this.$router.push(path)
            }
            store.commit('hideLoading')
          })
        }
      })
    }
  }
}
</script>

<style scoped>
.content {
  padding-top: 60px;
  padding-left: 10px;
  padding-right: 10px;
}

.detailsLayout-left {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.detailsLayout-left span {
  color: #333333;
  font-family: PingFangSC-Regular;
  font-size: 18px;
  line-height: 18px;
}

.detailsLayout-right {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.detailsLayout-right span {
  color: #979797;
  font-family: PingFangSC-Regular;
  font-size: 14px;
  line-height: 18px;
}
</style>
