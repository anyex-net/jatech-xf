<template>
  <div style="width: 100%">
    <common-head :is-back="true" :custom-right="true" title="金安消防栓蓝牙助手">
      <template #right>
        <div style="display: flex;align-items: center">
          <van-icon size="20" name="plus" color="#FFFFFF" @click="connect"/>
        </div>
      </template>
    </common-head>
    <div class="info-label">
      <van-tabs  display:flex v-model="active">
        <van-tab title="消防栓信息">
          <van-row type="flex">
            <van-field label="IMEI" value="2345672345" readonly />
            <van-field label="QCCID" value="2345672345" readonly />
            <van-field label="信号强度" value="2345672345" readonly />
            <van-field label="水压" value="2345672345" readonly />
            <van-field label="电量" value="2345672345" readonly />
            <van-field label="用水量" value="2345672345" readonly />
            <van-field label="水位线" value="2345672345" readonly />
            <van-field label="温度" value="2345672345" readonly />
            <van-field label="角度" value="2345672345" readonly />
            <van-field label="角度2" value="2345672345" readonly />
            <van-field label="水流速" value="2345672345" readonly />
            <van-field label="软件版本" value="2345672345" readonly />
            <van-field label="时间" value="2345672345" readonly />
            <van-field label="偏差值" value="2345672345" readonly />
          </van-row>
          <van-row>
            <van-col span="12">
              <van-checkbox class="WarningCheckBos" v-model="isPressureWarning" checked-color="#ee0a24" shape="square"  disabled>水压报警</van-checkbox>
            </van-col>
            <van-col span="12">
              <van-checkbox class="WarningCheckBos"  v-model="isLowPressure" checked-color="#ee0a24"  shape="square"  disabled>水压过低</van-checkbox>
            </van-col>
            <van-col span="12">
              <van-checkbox class="WarningCheckBos" v-model="isHighPressure" checked-color="#ee0a24" shape="square"  disabled>水压过高</van-checkbox>
            </van-col>
            <van-col span="12">
              <van-checkbox class="WarningCheckBos"  v-model="isOpen" checked-color="#ee0a24"  shape="square"  disabled>阀门打开</van-checkbox>
            </van-col>
            <van-col span="12">
              <van-checkbox class="WarningCheckBos" v-model="isIncline" checked-color="#ee0a24" shape="square"  disabled>倾斜</van-checkbox>
            </van-col>
            <van-col span="12">
              <van-checkbox class="WarningCheckBos"  v-model="isLowPower" checked-color="#ee0a24"  shape="square"  disabled>低电压</van-checkbox>
            </van-col>
            <van-col span="12">
              <van-checkbox class="WarningCheckBos" v-model="isDismantle" checked-color="#ee0a24" shape="square"  disabled>防拆</van-checkbox>
            </van-col>
          </van-row>
        </van-tab>
        <van-tab title="收发数据">

        </van-tab>
        <van-tab title="消防栓配置">
          <van-form @submit="onXfsSubmit">
            <van-field name="switch" label="报警开关">
              <template #input>
                <van-switch v-model="submitList.isWarning" size="20" />
              </template>
            </van-field>
            <van-field
              readonly
              clickable
              name="datetimePicker"
              :value="submitList.time"
              label="定时时间"
              placeholder="点击选择时间"
              @click="showPicker = true"
            />
            <van-popup v-model="showPicker" position="bottom">
              <van-datetime-picker
                type="time"
                @confirm="onConfirmTime"
                @cancel="showPicker = false"
              />
            </van-popup>
            <van-field
              v-model="submitList.waterPressUpLimit"
              name="水压报警上限值"
              label="水压报警上限值"
              placeholder="水压报警上限值"
            />
            <van-field
              v-model="submitList.waterPressDownLimit"
              name="水压报警下限值"
              label="水压报警下限值"
              placeholder="水压报警下限值"
            />
            <van-field
              v-model="submitList.batteryWarning"
              name="电量报警值"
              label="电量报警值"
              placeholder="电量报警值"
            />
            <van-field
              v-model="submitList.waterPressUpLimit"
              name="水压报警上限值"
              label="水压报警上限值"
              placeholder="水压报警上限值"
            />
            <van-field
              v-model="submitList.angle"
              name="角度允许偏差"
              label="角度允许偏差"
              placeholder="角度允许偏差"
            />
            <van-field
              v-model="submitList.circulateTime"
              name="循环时间"
              label="循环时间"
              placeholder="循环时间"
            />
            <van-field
              v-model="submitList.isFlow"
              name="水流速阀开判断"
              label="水流速阀开判断"
              placeholder="水流速阀开判断"
            />
            <van-field
              v-model="submitList.flowLevel"
              name="水流系数"
              label="水流系数"
              placeholder="水流系数"
            />
            <van-field
              v-model="submitList.waterLevel"
              name="水位报警"
              label="水位报警"
              placeholder="水位报警"
            />
            <van-field
              v-model="submitList.valve"
              name="阀关闭阈值"
              label="阀关闭阈值"
              placeholder="阀关闭阈值"
            />
            <van-field
              v-model="submitList.reportTimes"
              name="单日上报次数"
              label="单日上报次数"
              placeholder="单日上报次数"
            />
            <van-field
              v-model="submitList.valveWarning"
              name="阀报警超时"
              label="阀报警超时"
              placeholder="阀报警超时"
            />
            <div style="margin: 16px;">
              <van-button round block type="info" native-type="submit">提交</van-button>
            </div>
          </van-form>
        </van-tab>
        <van-tab title="选项配置">
          <van-form @submit="onOptionSubmit">
            <van-row>
              <van-col span="12">
                <van-field name="switch" label="imsi">
                  <template #input>
                    <van-switch v-model="optionList.imsi" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="电量">
                  <template #input>
                    <van-switch v-model="optionList.battery" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="角度">
                  <template #input>
                    <van-switch v-model="optionList.angle" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="报警开关">
                  <template #input>
                    <van-switch v-model="optionList.isWarning" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="imei">
                  <template #input>
                    <van-switch v-model="optionList.imei" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="用水量">
                  <template #input>
                    <van-switch v-model="optionList.water" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="水流速">
                  <template #input>
                    <van-switch v-model="optionList.waterSpeed" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="定时时间">
                  <template #input>
                    <van-switch v-model="optionList.timeSet" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="QCCID">
                  <template #input>
                    <van-switch v-model="optionList.QCCID" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="水位线">
                  <template #input>
                    <van-switch v-model="optionList.waterLevel" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="软件版本">
                  <template #input>
                    <van-switch v-model="optionList.version" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="循环时间">
                  <template #input>
                    <van-switch v-model="optionList.circulateTime" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="信号强度">
                  <template #input>
                    <van-switch v-model="optionList.sign" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="温度">
                  <template #input>
                    <van-switch v-model="optionList.temp" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="时间">
                  <template #input>
                    <van-switch v-model="optionList.nowTime" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="水压报警值">
                  <template #input>
                    <van-switch v-model="optionList.pressureWarning" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="水压">
                  <template #input>
                    <van-switch v-model="optionList.waterPressure" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="基准角度">
                  <template #input>
                    <van-switch v-model="optionList.baseAngle" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="水位报警">
                  <template #input>
                    <van-switch v-model="optionList.levelWarning" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="报警标志">
                  <template #input>
                    <van-switch v-model="optionList.warningSign" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="上报上限">
                  <template #input>
                    <van-switch v-model="optionList.reportLimt" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="水流系数">
                  <template #input>
                    <van-switch v-model="optionList.flowLevel" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="电量报警">
                  <template #input>
                    <van-switch v-model="optionList.batteryWarning" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="流速阀开阈值">
                  <template #input>
                    <van-switch v-model="optionList.flowValveOpen" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="阀关闭阈值">
                  <template #input>
                    <van-switch v-model="optionList.flowValveClose" size="20" />
                  </template>
                </van-field>
              </van-col>
              <van-col span="12">
                <van-field name="switch" label="阀报警超时">
                  <template #input>
                    <van-switch v-model="optionList.flowWarning" size="20" />
                  </template>
                </van-field>
              </van-col>
            </van-row>
            <div style="margin: 16px;">
              <van-button round block type="info" native-type="submit">确认</van-button>
            </div>
          </van-form>
        </van-tab>
      </van-tabs>
    </div>


  </div>

</template>


<script>
import store from '@/store'
import { getSignature } from '../../../api/sys/wx'
import commonHead from '@/views/app/common/head'
import wx from 'jweixin-1.6.0'

export default {
  name: 'blueToothIndex',
  components: {commonHead},
  data() {
    return {
      user: store.getters.user,
      application: store.getters.user.application,
      menuOptions: [],
      noticeOptions: [],
      showScan: false,
      showPopover: false,
      isWxConfig: false,
      isPressureWarning:true,
      isLowPressure:true,
      isHighPressure:true,
      isOpen:true,
      isIncline:true,
      isLowPower:true,
      isDismantle:true,
      active:0,
      code: null,
      showPicker:false,
      submitList:{
        isWarning:true,
        waterPressUpLimit:null,
        waterPressDownLimit:null,
        batteryWarning:null,
        time:null,
        angle:null,
        circulateTime:null,
        isFlow:null,
        flowLevel:null,
        waterLevel:null,
        valve:null,
        reportTimes:null,
        valveWarning:null
      },
      optionList:{
        imsi:true,
        battery:true,
        angle:true,
        isWarning:true,
        imei:true,
        water:true,
        waterSpeed:true,
        timeSet:true,
        QCCID:true,
        waterLevel:true,
        version:true,
        circulateTime:true,
        sign:true,
        temp:true,
        nowTime:true,
        pressureWarning:true,
        waterPressure:true,
        baseAngle:true,
        levelWarning:true,
        warningSign:true,
        reportLimt:true,
        flowLevel:true,
        batteryWarning:true,
        flowValveOpen:true,
        flowValveClose:true,
        flowWarning:true,
      },
    }
  },
  created() {
    window.scanConfirm = this.scanConfirm;
    this.showScanPopup();
  },
  beforeDestroy() {

  },
  props: {
  },
  methods: {
    showScanPopup() {
      console.log(this.getSignUrl(),"this.getSignUrl()")
      console.log(this.application,"application")
      alert(this.application)
      if (this.application === 'app' && window.AndroidWebView) {
        window.AndroidWebView.setBarCodeCB('scanConfirm')
        window.AndroidWebView.startScan()
      } else if (this.application === 'wx'||this.application === 'app') {

        const url = this.getSignUrl()
        getSignature({ url: url }).then(response => {
          if (response.success) {
            alert("response.data.signature:"+response.data.signature)
            alert("url:"+url)
            console.log(response.data.signature)
            // 生成签名
            // jsapi_ticket 后台获取
            // noncestr 随机字符串
            // timestamp 当前时间戳
            // url 当前url，不算hash值
            // 按照以上顺序以键值对的形式连接起来（所有属性值均为原始值），在通过sha1加密形成签名。
            wx.config({
              debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
              appId: response.data.appId, // 必填，公众号的唯一标识
              timestamp: response.data.timestamp, // 必填，生成签名的时间戳
              nonceStr: response.data.nonceStr, // 必填，生成签名的随机串
              signature: response.data.signature, // 必填，签名
              jsApiList: ['startSearchBeacons'] // 必填，需要使用的JS接口列表
            })
            wx.checkJsApi({
              jsApiList: ['startSearchBeacons'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
              success: function (res) {
                // 以键值对的形式返回，可用的api值true，不可用为false
                // 如：{"checkResult":{"chooseImage":true},"errMsg":"checkJsApi:ok"}
                console.log('检查', res)
              }
            })
            wx.ready((res) => {
              wx.startSearchBeacons({
                ticket:"",
                complete:function(argv){
                  //回调函数
                  console.log(argv,"回调")
                }
              });
              // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
              // wx.startBluetoothDevicesDiscovery({
              //   services: [],
              //   complete: function(res) {
              //     setTimeout(function() {
              //       wx.getBluetoothDevices({
              //         complete: function(res) {
              //           console.log(res)
              //         }
              //       });
              //       wx.stopBluetoothDevicesDiscovery({
              //         success: function(res) {},
              //       })
              //     }, 4000)
              //   }
              // })
            })
            wx.error((res) => {
              alert('失败' + JSON.stringify(res))
              // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查    看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
            })
          }
        })
      }
    },
    getSignUrl() {
      let signLink = ''
      const ua = navigator.userAgent.toLowerCase()
      if (/iphone|ipad|ipod/.test(ua)) {
        signLink = localStorage.getItem('firstUrl')
        if (!signLink) signLink = location.href
      } else {
        signLink = location.href
      }
      return signLink
    },
    onXfsSubmit(values){
      console.log('submit', values);
    },
    onOptionSubmit(values){
      console.log('submit', values);
    },
    onConfirmTime(time) {
      this.submitList.time = time;
      this.showPicker = false;
    },
    connect(){
      alert("进行蓝牙连接")
    }
  }
}

</script>
<style scoped>
.info-label{
  /*display: fixed;*/
  position: absolute;
  top: 6%;
  width: 100%;
}
.WarningCheckBos /deep/ .van-checkbox__icon--disabled .van-icon{
  background-color: red;
}
.WarningCheckBos /deep/.van-checkbox__label--disabled{
  color: black;
}
</style>
