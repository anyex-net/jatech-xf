<template>
  <div>
    <common-head :is-back="true" :custom-right="true" title="用户列表">
      <template v-if="hasBtnPermission('sys:user:add')" #right>
        <div style="display: flex;align-items: center">
          <van-icon size="20" name="plus" color="#FFFFFF" @click="onAdd"/>
        </div>
      </template>
    </common-head>
    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-search v-model="searchValue" placeholder="请输入人员名称" show-action @search="onSearch">
        <template #action>
          <div @click="onSearch(searchValue)">搜索</div>
        </template>
      </van-search>
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <van-swipe-cell v-for="(item,index) in list" :key="index">
            <van-cell :title="item.name" :value="item.phone" is-link @click="onDetails(item.id)"/>
            <template v-if="hasBtnPermission('sys:user:delete') || hasBtnPermission('sys:user:edit')" #right>
              <van-button
                v-if="hasBtnPermission('sys:user:delete')"
                square
                type="danger"
                text="删除"
                @click="onDelete(index, item.id)"
              />
              <van-button
                v-if="hasBtnPermission('sys:user:edit')"
                square
                type="info"
                text="编辑"
                @click="onEdit(item.id)"
              />
              <!--              sys:user:grantRole-->
              <van-button
                v-if="hasBtnPermission('sys:user:grantRole')"
                square
                color="#7232dd"
                text="角色授权"
                @click="onRole(item.id)"
              />
            </template>
          </van-swipe-cell>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script>
  import commonHead from '@/views/app/common/head'
  import {getUserPage, sysUserDelete} from '@/api/system/userManage'
  import {Toast} from 'vant'
  import {hasBtnPermission} from '../../../../utils/permission'

  export default {
    name: 'Index',
    components: {commonHead},
    data() {
      return {
        list: [],
        loading: false,
        finished: false,
        refreshing: false,
        searchValue: null,
        query: {
          unitId: null,
          pageNo: 0,
          pageSize: 10
        },
        unitId: null
      }
    },
    created() {
      if (this.$route.query.unitId) {
        this.unitId = this.$route.query.unitId
        this.query.unitId = this.$route.query.unitId
      }
    },
    methods: {
      hasBtnPermission(value) {
        if (value != null) {
          return hasBtnPermission(value)
        } else {
          return false
        }
      },
      onLoad() {
        this.query.pageNo++
        this.getUserPageData()
      },
      getUserPageData() {
        if (this.refreshing) {
          this.list = []
          this.refreshing = false
        }
        getUserPage(this.query).then(res => {
          this.list = this.list.concat(res.data.rows)
          this.loading = false
          if (this.list.length >= res.data.totalRows) {
            this.finished = true
          }
        })
      },
      onSearch(val) {
        this.query.name = val
        this.onRefresh()
      },
      onRefresh() {
        // 清空列表数据
        this.list = []
        this.query.pageNo = 0
        this.finished = false
        // 重新加载数据
        // 将 loading 设置为 true，表示处于加载状态
        this.loading = true
        this.onLoad()
      },
      onDelete(index, id) {
        this.$dialog
          .confirm({
            message: '是否确认删除!'
          }).then(() => {
          sysUserDelete({id: id}).then(res => {
            if (res.success) {
              // Notify({ type: 'primary', message: '删除成功' });
              Toast.success('删除成功')
              // this.list.splice(index, 1)
              this.onRefresh()
            } else {
              Toast(res.message)
            }
          }).catch((err) => {
            Toast(err + '')
          })
        }).catch(() => {
        })
      },
      onDetails(id) {
        this.$router.push({
          path: '/app/sys/user/details/index',
          query: {
            id: id
          }
        })
      },
      onEdit(id) {
        this.$router.push({
          path: '/app/sys/user/operation/index',
          query: {
            id: id,
            operationType: 'edit',
            unitId: this.unitId
          }
        })
      },
      onAdd() {
        this.$router.push({
          path: '/app/sys/user/operation/index',
          query: {
            operationType: 'add',
            unitId: this.unitId
          }
        })
      },
      onRole(id) {
        this.$router.push({
          path: '/app/sys/user/role/index',
          query: {
            id: id
          }
        })
      }
    }
  }
</script>
