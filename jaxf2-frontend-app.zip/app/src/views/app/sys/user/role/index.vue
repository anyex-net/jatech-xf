<template>
  <div>
    <common-head :is-back="true" title="角色授权" />
    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-form @submit="onSubmit">
        <van-checkbox-group v-model="checkedRoleList">
          <van-cell-group>
            <van-cell
              v-for="(item, index) in roleList"
              :key="item.id"
              clickable
              :title="item.name"
              @click="toggle(index)"
            >
              <template #right-icon>
                <van-checkbox ref="checkboxes" :name="item.id" />
              </template>
            </van-cell>
          </van-cell-group>
        </van-checkbox-group>
        <div class="bottom" />
        <div class="bar-footer">
          <van-button block native-type="submit" round type="info">提交</van-button>
        </div>
      </van-form>
    </div>
  </div>
</template>

<script>
import commonHead from '@/views/app/common/head'
import { sysUserGrantRole, sysUserOwnRole } from '@/api/system/userManage'
import { sysRoleDropDown } from '@/api/system/roleManage'
import { Toast } from 'vant'

export default {
  name: 'Index',
  components: { commonHead },
  data() {
    return {
      checkedRoleList: [],
      roleList: [],
      userId: null
    }
  },
  created() {
    this.initData()
  },
  methods: {
    initData() {
      this.$route.query.id ? this.userId = this.$route.query.id : this.userId = null
      this.handleRole()
    },
    onSubmit() {
      this.onSysUserGrantRole()
    },
    toggle(index) {
      this.$refs.checkboxes[index].toggle()
    },
    handleRole() {
      sysRoleDropDown().then(res => {
        if (res.success) {
          this.roleList = res.data
        }
      })
      sysUserOwnRole({ 'id': this.userId }).then(res => {
        if (res.success) {
          this.checkedRoleList = []
          this.checkedRoleList = res.data
        }
      }).catch((err) => {
        Toast(err + '')
      })
    },
    onSysUserGrantRole() {
      sysUserGrantRole({ 'grantRoleIdList': this.checkedRoleList, 'id': this.userId }).then((response) => {
        if (response.success) {
          Toast.success('授权成功')
          this.onBack()
        }
      }).catch((err) => {
        Toast(err + '')
      })
    },
    onBack() {
      const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
      const path = routeArray[routeArray.length - 1]
      this.$router.push(path)
    }
  }
}
</script>

<style scoped>

</style>
