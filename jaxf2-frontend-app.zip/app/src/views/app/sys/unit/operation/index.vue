<template>
  <div>
    <common-head :is-back="true" :title="title"/>
    <common-head :is-back="true" :title="title"/>
    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-form label-width="140px" @submit="onSubmit">

        <van-field
          v-model="temp.name"
          :rules="[{ required: true, message: '请填写单位名称' }]"
          clearable
          label="单位名称"
          name="name"
          placeholder="单位名称"
          required
        />

        <!-- <van-field
           :value="formTemp.unitName"
           clickable
           label="父级单位"
           name="unitName"
           placeholder="选择父级单位"
           readonly
           @click="unitClick"
         />
         <van-popup v-model="formTemp.unitActionSheet.show" position="bottom" round>
           <van-picker
             :columns="formTemp.unitActionSheet.actions"
             show-toolbar
             value-key="name"
             @cancel="formTemp.unitActionSheet.show = false"
             @confirm="onUnitConfirm"
           >
             <template #title>
               <form action="/">
                 <van-search
                   v-model="formTemp.searchUnitValue"
                   name="searchValue"
                   placeholder="请输入搜索关键词"
                   shape="round"
                   @blur="onUnitSearch"
                 />
               </form>
             </template>
           </van-picker>
         </van-popup>-->

        <van-field
          v-model="formTemp.areaName"
          :rules="[{ required: true, message: '请选择所属区域' }]"
          is-link
          readonly
          label="所属区域"
          placeholder="请选所属区域"
          required
          name="areaName"
          @click="onAreaClick"
        />

        <!--        <van-field-->
        <!--          :rules="[{ required: true, message: '请选择所属区域' }]"-->
        <!--          :value="formTemp.areaName"-->
        <!--          clickable-->
        <!--          label="所属区域"-->
        <!--          name="areaName"-->
        <!--          placeholder="选择所属区域"-->
        <!--          readonly-->
        <!--          required-->
        <!--          @click="areaClick"-->
        <!--        />-->
        <!--        <van-popup v-model="formTemp.areaActionSheet.show" position="bottom" round>-->
        <!--          <van-picker-->
        <!--            :columns="formTemp.areaActionSheet.actions"-->
        <!--            show-toolbar-->
        <!--            value-key="name"-->
        <!--            @cancel="formTemp.areaActionSheet.show = false"-->
        <!--            @confirm="onAreaConfirm"-->
        <!--          >-->
        <!--            <template #title>-->
        <!--              <form action="/">-->
        <!--                <van-search-->
        <!--                  v-model="formTemp.searchAreaValue"-->
        <!--                  name="searchValue"-->
        <!--                  placeholder="请输入搜索关键词"-->
        <!--                  shape="round"-->
        <!--                  @blur="onAreaSearch"-->
        <!--                />-->
        <!--              </form>-->
        <!--            </template>-->
        <!--          </van-picker>-->
        <!--        </van-popup>-->

        <van-field
          :rules="[{ required: true, message: '请选择单位类别' }]"
          :value="formTemp.unitCategoryName"
          clickable
          label="单位类别"
          name="unitCategoryName"
          placeholder="选择单位类别"
          readonly
          required
          @click="formTemp.unitCategoryActionSheet.show = true"
        />
        <van-popup v-model="formTemp.unitCategoryActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.unitCategoryActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.unitCategoryActionSheet.show = false"
            @confirm="onUnitCategoryConfirm"
          />
        </van-popup>

        <van-field
          :rules="[{ required: true, message: '请选择场所类型' }]"
          :value="formTemp.placeTypeName"
          clickable
          label="场所类型"
          name="placeTypeName"
          placeholder="选择场所类型"
          readonly
          required
          @click="formTemp.placeTypeActionSheet.show = true"
        />
        <van-popup v-model="formTemp.placeTypeActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.placeTypeActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.placeTypeActionSheet.show = false"
            @confirm="onPlaceTypeConfirm"
          />
        </van-popup>

        <van-field
          v-model="temp.unifiedCode"
          :rules="[{ required: true, message: '请填写社会信用统一代码' }]"
          clearable
          label="社会信用统一代码"
          name="unifiedCode"
          placeholder="社会信用统一代码"
          required
        />

        <van-field
          :rules="[{ required: true, message: '请选单位类型' }]"
          :value="formTemp.unitTypeName"
          clickable
          label="单位类型"
          name="unitTypeName"
          placeholder="选择单位类型"
          readonly
          required
          @click="formTemp.unitTypeActionSheet.show = true"
        />
        <van-popup v-model="formTemp.unitTypeActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.unitTypeActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.unitTypeActionSheet.show = false"
            @confirm="onUnitTypeConfirm"
          />
        </van-popup>

        <van-field
          v-model="temp.industryClassification"
          :rules="[{ required: true, message: '请填写国民经济行业分类' }]"
          clearable
          label="国民经济行业分类"
          name="industryClassification"
          placeholder="国民经济行业分类"
          required
        />

        <van-field
          v-model="temp.personLiableName"
          :rules="[{ required: true, message: '请填写消防安全责任人姓名' }]"
          clearable
          label="消防安全责任人姓名"
          name="personLiableName"
          placeholder="消防安全责任人姓名"
          required
        />

        <van-field
          v-model="temp.personLiablePhone"
          :rules="[{ required: true, message: '请填写消防安全责任人电话' }]"
          clearable
          label="消防安全责任人电话"
          name="personLiablePhone"
          placeholder="消防安全责任人电话"
          required
        />

        <van-field
          v-model="temp.administratorName"
          :rules="[{ required: true, message: '请填写消防安全管理人姓名' }]"
          clearable
          label="消防安全管理人姓名"
          name="administratorName"
          placeholder="消防安全管理人姓名"
          required
        />

        <van-field
          v-model="temp.administratorPhone"
          :rules="[{ required: true, message: '请填写消防安全管理人电话' }]"
          clearable
          label="消防安全管理人电话"
          name="administratorPhone"
          placeholder="消防安全管理人电话"
          required
        />

        <base-map-search
          ref="mapSearch"
          :is-edit="true"
          :is-hide="false"
          :latitude="temp.lat"
          :longitude="temp.lng"
          :value="temp.address"
          @updateLocation="updateLocation"
        />

        <van-field
          v-model="temp.lng"
          :rules="[{ required: true, message: '请填写经度' }]"
          clearable
          label="经度"
          name="lng"
          placeholder="经度"
          required
        />

        <van-field
          v-model="temp.lat"
          :rules="[{ required: true, message: '请填写纬度' }]"
          clearable
          label="纬度"
          name="lat"
          placeholder="纬度"
          required
        />

        <van-field
          v-if="isLimit"
          :rules="[{ required: true, message: '请选运营单位' }]"
          :value="formTemp.operateUnitName"
          clickable
          label="运营单位"
          name="operateUnitName"
          placeholder="选择运营单位"
          readonly
          required
          @click="formTemp.operateUnitActionSheet.show = true"
        />
        <van-popup v-model="formTemp.operateUnitActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.operateUnitActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.operateUnitActionSheet.show = false"
            @confirm="onOperateUnitConfirm"
          />
        </van-popup>

        <van-field
          v-if="isLimit"
          :value="formTemp.examUnitName"
          clickable
          label="维保单位"
          name="examUnitName"
          placeholder="选择维保单位"
          readonly
          @click="formTemp.examUnitActionSheet.show = true"
        />
        <van-popup v-model="formTemp.examUnitActionSheet.show" position="bottom" round>
          <van-picker
            :columns="formTemp.examUnitActionSheet.actions"
            show-toolbar
            value-key="name"
            @cancel="formTemp.examUnitActionSheet.show = false"
            @confirm="onExamUnitConfirm"
          />
        </van-popup>

        <van-field label="推送通道" name="channelIdList">
          <template #input>
            <van-checkbox-group v-model="formTemp.channelIdList" direction="horizontal">
              <van-checkbox
                v-for="(item,index) in formTemp.checkboxGroup.notice"
                :key="index"
                :name="item.id"
                icon-size="12px"
                shape="square"
              >{{ item.name }}
              </van-checkbox>
            </van-checkbox-group>
          </template>
        </van-field>

        <van-field label="启用" name="switch">
          <template #input>
            <van-switch v-model="temp.status" :active-value="1" :inactive-value="0" size="20"/>
          </template>
        </van-field>

        <div class="bottom"/>
        <div class="bar-footer">
          <van-button v-if="isEdit" block native-type="submit" round type="info">更新</van-button>
          <van-button v-else block native-type="submit" round type="info">提交</van-button>
        </div>
      </van-form>

      <van-popup v-model="formTemp.areaActionSheet.show" round position="bottom">
        <van-cascader
          v-model="formTemp.areaId"
          title="请选择所属区域"
          :options="formTemp.areaActionSheet.actions"
          :field-names="{text: 'name', value: 'id', children: 'children'}"
          @close="formTemp.areaActionSheet.show = false"
          @change="onAreaChange"
        />
        <div class="bottom"/>
        <div class="bar-footer">
          <van-button block round type="info" @click="onAreaFinish">确定</van-button>
        </div>
      </van-popup>
    </div>
  </div>
</template>

<script>
  import commonHead from '@/views/app/common/head'
  import {
    getExamUnitList,
    getOnlineUnitDetail,
    getOperateUnitList,
    getUnitList,
    onlineUnitAdd,
    onlineUnitUpdate
  } from '@/api/sys/unit'
  import {Toast} from 'vant'
  import {getAreaInfoById, getAreaListByName, getAreaTree} from '@/api/sys/area'
  import {unitCategoryList} from '@/api/sys/unitCategory'
  import {unitTypeList} from '@/api/sys/unitType'
  import {getNoticeChannel} from '@/api/common'
  import BaseMapSearch from '@/components/Map/baseMapSearch'

  export default {
    name: 'Index',
    components: {commonHead, BaseMapSearch},
    data() {
      return {
        id: null,
        isEdit: false,
        isLimit: true,
        title: null,
        titleMap: {
          edit: '编辑联网单位',
          add: '添加联网单位'
        },
        temp: {
          name: null,
          parentId: null,
          areaId: null,
          unitCategory: null,
          placeType: null,
          unifiedCode: null,
          unitType: null,
          industryClassification: null,
          personLiableName: null,
          personLiablePhone: null,
          administratorName: null,
          administratorPhone: null,
          address: '',
          lng: null,
          lat: null,
          operateUnitId: null,
          examUnitId: '',
          channelIdList: null,
          status: null
        },
        formTemp: {
          areaId: null,
          areaName: '',
          parentName: '',
          unitCategoryName: '',
          placeTypeName: '',
          unitTypeName: '',
          operateUnitName: '',
          examUnitName: '',
          channelIdList: [],
          searchUnitValue: '',
          unitActionSheet: {
            show: false,
            actions: []
          },
          searchAreaValue: '',
          areaActionSheet: {
            show: false,
            actions: []
          },
          unitCategoryActionSheet: {
            show: false,
            actions: []
          },
          placeTypeActionSheet: {
            show: false,
            actions: [
              {id: '01', name: '沿街商铺'},
              {id: '02', name: '政府单位'},
              {id: '03', name: '公共娱乐场所'},
              {id: '04', name: '商超市场'},
              {id: '05', name: '宾馆饭店'},
              {id: '06', name: '医院'},
              {id: '07', name: '公共高层建筑'},
              {id: '08', name: '规下企业'},
              {id: '09', name: '客运车站'},
              {id: '10', name: '养老院'},
              {id: '11', name: '学校'},
              {id: '12', name: '弱势群体'},
              {id: '13', name: '住宅小区'},
              {id: '14', name: '10人以上出租房'},
              {id: '15', name: '规上企业'}
            ]
          },
          unitTypeActionSheet: {
            show: false,
            actions: []
          },
          operateUnitActionSheet: {
            show: false,
            actions: []
          },
          examUnitActionSheet: {
            show: false,
            actions: []
          },
          checkboxGroup: {
            notice: []
          }
        }
      }
    },
    created() {
      this.onInitData()
    },
    methods: {
      onAreaClick() {
        this.formTemp.areaActionSheet.show = true
        if (this.isEdit) {
          this.formTemp.areaId = null
        }
        this.getAreaTreeList('', '', 0)
      },
      onAreaFinish() {
        this.formTemp.areaActionSheet.show = false
        const arr = this.formTemp.areaName.split('/')
        this.formTemp.areaName = arr.reverse()[0]
      },
      onAreaChange({value, selectedOptions, tabIndex}) {
        this.formTemp.areaName = selectedOptions.map((option) => option.name).join('/')
        this.temp.areaId = value
        this.getAreaTreeList(value, selectedOptions, '')
      },
      getAreaTreeList(value, selectedOptions, tabIndex) {
        const queryParam = {
          name: null,
          areaId: null,
          isUnit: null
        }
        if (tabIndex !== 0) {
          queryParam.areaId = value
        }
        getAreaTree(queryParam).then(res => {
          res.data.map(item => {
            item.children = []
            return item
          })
          if (tabIndex === 0) {
            this.formTemp.areaActionSheet.actions = res.data
          } else {
            const item = selectedOptions.find(item => item.id === value)
            if (!item.leaf) {
              item.children = res.data
            }
          }
        }).catch(err => {
          console.log(err)
        })
      },

      updateLocation(lng, lat, address) {
        this.temp.lng = lng
        this.temp.lat = lat
        this.temp.address = address
      },
      async onInitData() {
        this.$route.query.id ? this.id = this.$route.query.id : this.id = null
        this.isEdit = this.$route.query.operationType === 'edit'
        this.isLimit = !(this.$route.query.limit === 'edit-1')
        this.isEdit ? this.title = this.titleMap.edit : this.title = this.titleMap.add
        await this.getUnitCategoryList()
        await this.getUnitTypeList()
        await this.onGetNoticeChannel()
        await this.getOperateUnitList()
        await this.getExamUnitList()
        if (this.isEdit) {
          this.onLoad()
        } else {
          this.temp.status = 1
        }
      },
      onLoad() {
        getOnlineUnitDetail(this.id).then(res => {
          if (res.success) {
            this.temp = res.data
            this.$refs.mapSearch.updateAddress(this.temp.address, this.temp.lng, this.temp.lat)
            this.onEditDataHandle(res.data)
          }
        })
      },

      onSubmit(values) {
        if (this.isEdit) {
          this.onUpdate(values)
        } else {
          this.onAdd(values)
        }
      },
      onAdd(values) {
        this.onAddDataHandle(values)
        Toast.loading({
          duration: 0, // 持续展示 toast
          forbidClick: true,
          message: '添加中...'
        })
        onlineUnitAdd(this.temp).then((res) => {
          if (res.success) {
            Toast.clear()
            Toast.success('添加成功')
            this.onBack()
          } else {
            Toast(res.message)
          }
        }).catch((err) => {
          Toast(err + '')
        })
      },
      onBack() {
        const routeArray = JSON.parse(sessionStorage.getItem('lasterRouter'))
        const path = routeArray[routeArray.length - 1]
        this.$router.push(path)
      },
      onAddDataHandle(values) {
        this.temp.channelIdList = values.channelIdList
      },

      onUpdate(values) {
        this.onAddDataHandle(values)
        Toast.loading({
          duration: 0, // 持续展示 toast
          forbidClick: true,
          message: '更新中...'
        })
        onlineUnitUpdate(this.temp).then((res) => {
          if (res.success) {
            Toast.clear()
            Toast.success('更新成功')
            this.onBack()
          } else {
            Toast(res.message)
          }
        }).catch((err) => {
          Toast(err + '')
        })
      },
      onEditDataHandle(values) {
        if (values.areaId) {
          this.onAreaInfoHandle(values.areaId)
        }

        if (values.placeType) {
          const placeTypeActions = this.formTemp.placeTypeActionSheet.actions
          if (placeTypeActions.find(res => res.id === values.placeType)) {
            this.formTemp.placeTypeName = placeTypeActions.find(res => res.id === values.placeType).name
          }
        }

        if (values.unitCategory) {
          const unitCategoryActions = this.formTemp.unitCategoryActionSheet.actions
          if (unitCategoryActions.find(res => res.id === values.unitCategory)) {
            this.formTemp.unitCategoryName = unitCategoryActions.find(res => res.id === values.unitCategory).name
          }
        }

        if (values.unitType) {
          const unitTypeActions = this.formTemp.unitTypeActionSheet.actions
          if (unitTypeActions.find(res => res.id === values.unitType)) {
            this.formTemp.unitTypeName = unitTypeActions.find(res => res.id === values.unitType).name
          } else {
            console.log("失败");
            console.log(unitTypeActions)
          }
        }

        if (values.operateUnitId) {
          const operateUnitActions = this.formTemp.operateUnitActionSheet.actions
          if (operateUnitActions.find(res => res.id === values.operateUnitId)) {
            this.formTemp.operateUnitName = operateUnitActions.find(res => res.id === values.operateUnitId).name
          }
        }

        if (values.examUnitId) {
          const examUnitActions = this.formTemp.examUnitActionSheet.actions
          if (examUnitActions.find(res => res.id === values.examUnitId)) {
            this.formTemp.examUnitName = examUnitActions.find(res => res.id === values.examUnitId).name
          }
        }
        if (values.parentId) {
          getOnlineUnitDetail(values.parentId).then(res => {
            if (res.success) {
              this.formTemp.parentName = res.data.name
            }
          })
        }
        if (values.channelIdList) {
          this.formTemp.channelIdList = values.channelIdList
        }
      },
      onAreaInfoHandle(value) {
        getAreaInfoById(value).then(res => {
          if (res.success) {
            this.formTemp.areaName = res.data.name
          }
        })
      },
      unitClick() {
        this.formTemp.unitActionSheet.show = true
        this.formTemp.searchUnitValue = ''
        this.formTemp.unitActionSheet.actions = []
      },
      onUnitConfirm(value) {
        if (!value) {
          Toast.fail('请选择')
          return
        }
        this.temp.parentId = value.id
        this.formTemp.unitName = value.name
        this.formTemp.unitActionSheet.show = false
      },
      onUnitSearch(val) {
        getUnitList({name: val.target._value}).then(res => {
          if (res.success) {
            this.formTemp.unitActionSheet.actions = res.data.map(item => {
              return {id: item.id, name: item.name}
            })
          }
        })
      },
      areaClick() {
        this.formTemp.areaActionSheet.show = true
        this.formTemp.searchAreaValue = ''
        this.formTemp.areaActionSheet.actions = []
      },
      onAreaConfirm(value) {
        if (!value) {
          Toast.fail('请选择')
          return
        }
        this.temp.areaId = value.id
        this.formTemp.areaName = value.name
        this.formTemp.areaActionSheet.show = false
      },
      onAreaSearch(val) {
        if (!val.target._value) {
          return
        }
        getAreaListByName(val.target._value).then(res => {
          if (res.success) {
            this.formTemp.areaActionSheet.actions = res.data.map(item => {
              return {id: item.id, name: item.name}
            })
          }
        })
      },
      async getUnitCategoryList() {
        await unitCategoryList().then(res => {
          if (res.success) {
            this.formTemp.unitCategoryActionSheet.actions = res.data
          }
        })
      },
      onUnitCategoryConfirm(value) {
        if (!value) {
          Toast.fail('请选择')
          return
        }
        this.temp.unitCategory = value.id
        this.formTemp.unitCategoryName = value.name
        this.formTemp.unitCategoryActionSheet.show = false
      },
      onPlaceTypeConfirm(value) {
        if (!value) {
          Toast.fail('请选择')
          return
        }
        this.temp.placeType = value.id
        this.formTemp.placeTypeName = value.name
        this.formTemp.placeTypeActionSheet.show = false
      },
      async getUnitTypeList() {
        await unitTypeList().then(response => {
          if (response.success) {
            this.formTemp.unitTypeActionSheet.actions = response.data
          }
        })
      },
      onUnitTypeConfirm(value) {
        if (!value) {
          Toast.fail('请选择')
          return
        }
        this.temp.unitType = value.id
        this.formTemp.unitTypeName = value.name
        this.formTemp.unitTypeActionSheet.show = false
      },
      async onGetNoticeChannel() {
        await getNoticeChannel().then(res => {
          if (res.success) {
            this.formTemp.checkboxGroup.notice = res.data
          }
        })
      },
      async getOperateUnitList() {
        await getOperateUnitList().then(response => {
          if (response.success) {
            this.formTemp.operateUnitActionSheet.actions = response.data
          }
        })
      },
      onOperateUnitConfirm(value) {
        if (!value) {
          Toast.fail('请选择')
          return
        }
        this.temp.operateUnitId = value.id
        this.formTemp.operateUnitName = value.name
        this.formTemp.operateUnitActionSheet.show = false
      },
      async getExamUnitList() {
        await getExamUnitList().then(response => {
          if (response.success) {
            this.formTemp.examUnitActionSheet.actions = response.data
          }
        })
      },
      onExamUnitConfirm(value) {
        if (!value) {
          Toast.fail('请选择')
          return
        }
        this.temp.examUnitId = value.id
        this.formTemp.examUnitName = value.name
        this.formTemp.examUnitActionSheet.show = false
      }
    }
  }
</script>

<style scoped>

</style>
