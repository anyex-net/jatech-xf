<template>
  <div>
    <common-head :is-back="true" title="单位详情"/>
    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-cell-group>
        <van-cell title="单位名称" :value="temp.name"/>
        <van-cell title="所属区域" :value="temp.areaName"/>
        <van-cell title="地址" :value="temp.address"/>
        <van-cell title="统一社会信用代码" :value="temp.unifiedCode"/>
        <van-cell title="安全责任人姓名" :value="temp.personLiableName"/>
        <van-cell title="安全责任人电话" :value="temp.personLiablePhone"/>
        <van-cell title="安全管理人姓名" :value="temp.administratorName"/>
        <van-cell title="安全管理人电话" :value="temp.administratorPhone"/>
        <van-cell title="状态">
          <!-- 使用 right-icon 插槽来自定义右侧图标 -->
          <template #right-icon>
            <van-button v-if="temp.status" plain hairline type="primary" size="mini">启用</van-button>
            <van-button v-else plain hairline type="warning" size="mini">停用</van-button>
          </template>
        </van-cell>
        <van-cell title="地图定位"/>
        <base-map-search
          ref="mapSearch"
          :is-edit="false"
          :is-hide="true"
          :value="temp.address"
          :longitude="temp.lng"
          :latitude="temp.lat"
        />
        <!--        style="padding: 10px 16px"-->
      </van-cell-group>
    </div>
  </div>
</template>

<script>
  import commonHead from '@/views/app/common/head'
  import {getOnlineUnitDetail} from '@/api/sys/unit'
  import {Toast} from 'vant'
  import BaseMapSearch from '@/components/Map/baseMapSearch'
  import {getAreaInfoById} from '@/api/sys/area'

  export default {
    name: 'Index',
    components: {commonHead, BaseMapSearch},
    data() {
      return {
        id: null,
        temp: {
          address: '',
          administratorName: null,
          administratorPhone: null,
          areaId: null,
          areaName: null,
          industryClassification: null,
          juridicalCard: null,
          juridicalName: null,
          juridicalPhone: null,
          lat: null,
          lng: null,
          name: '',
          personLiableName: null,
          personLiablePhone: null,
          placeType: null,
          status: 0,
          unifiedCode: null,
          unitCategory: null,
          unitType: null
        }
      }
    },
    created() {
      this.onInitData()
    },
    methods: {
      onInitData() {
        if (this.$route.query.id) {
          this.id = this.$route.query.id
          this.onLoad()
        } else {
          // Notify({type: 'primary', message: '联网单位id为null！'});
          Toast.fail('联网单位id为null！')
        }
      },
      onLoad() {
        getOnlineUnitDetail(this.id).then(res => {
          if (res.success) {
            this.temp = res.data
            this.onEditDataHandle(res.data)
          }
        })
      },
      onEditDataHandle(values) {
        if (values.areaId) {
          this.onAreaInfoHandle(values.areaId)
        }
      },
      onAreaInfoHandle(value) {
        getAreaInfoById(value).then(res => {
          if (res.success) {
            this.temp.areaName = res.data.name
          }
        })
      }
    }
  }
</script>

<style scoped>

</style>
