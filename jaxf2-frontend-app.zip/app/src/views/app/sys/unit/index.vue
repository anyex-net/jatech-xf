<template>
  <div>
    <common-head :is-back="true" :custom-right="true" title="联网单位列表">
      <template v-if="hasBtnPermission('sys:onlineUnit:add') && type === 1" #right>
        <div style="display: flex;align-items: center">
          <van-icon size="20" name="plus" color="#FFFFFF" @click="onAdd"/>
        </div>
      </template>
    </common-head>

    <div class="cards-navbar" style="background: #F4F4F4;">
      <van-search v-model="searchValue" placeholder="请输入搜索关键词" show-action @search="onSearch">
        <template #action>
          <div @click="onSearch(searchValue)">搜索</div>
        </template>
      </van-search>
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <van-swipe-cell v-for="(item,index) in list" :key="index">
            <van-cell class="pushtime" @click="onDetails(item.id)">
              <template #title>
                <span>{{item.name}}</span>
              </template>
              <van-button @click="handleSetProhibitPushTime(index, item.id)" plain hairline type="danger" size="small"
                          v-if="(item.prohibitPushTime == null || (item.prohibitPushTime != null && compareDate(new Date(), item.prohibitPushTime))) && hasBtnPermission('sys:onlineUnit:del') && type === 2">
                暂停推送
              </van-button>
              <van-button @click="cancelProhibitPush(index, item.id)" plain hairline type="primary" size="small"
                          v-if="item.prohibitPushTime != null && compareDate(item.prohibitPushTime, new Date()) && hasBtnPermission('sys:onlineUnit:del') && type === 2">
                恢复推送
              </van-button>
            </van-cell>
            <template #right>
              <van-button
                v-if="hasBtnPermission('sys:onlineUnit:del') && type === 1"
                square
                type="danger"
                text="删除"
                @click="onDelete(index, item.id)"
              />
              <van-button
                v-if="hasBtnPermission('sys:onlineUnit:edit') && type === 1"
                square
                type="info"
                text="编辑"
                @click="onEdit(item.id)"
              />
            </template>
          </van-swipe-cell>
        </van-list>
      </van-pull-refresh>
    </div>

    <van-dialog @confirm="setProhibitPushTime"
                v-model="isSetProhibitPush" title="请选择禁止推送时长"
                show-cancel-button>
      <div style="padding: 20px;">
        <van-radio-group v-model="cancelTemp.minute">
          <van-radio style="height: 40px" name="30">半小时</van-radio>
          <van-radio style="height: 40px" name="60">1小时</van-radio>
          <van-radio style="height: 40px" name="120">2小时</van-radio>
          <van-radio style="height: 40px" name="240">4小时</van-radio>
          <van-radio style="height: 40px" name="480">8小时</van-radio>
        </van-radio-group>
      </div>
    </van-dialog>
  </div>
</template>

<script>
  import commonHead from '@/views/app/common/head'
  import {getUnitPage, unit_Del} from '@/api/sys/unit'
  import {Toast} from 'vant'
  import {hasBtnPermission} from '@/utils/permission'
  import {onlineUnitCancelProhibitPush, onlineUnitSetProhibitPushTime} from "../../../../api/sys/unit";

  export default {
    name: 'Index',
    components: {commonHead},
    data() {
      return {
        list: [],
        loading: false,
        finished: false,
        refreshing: false,
        searchValue: null,
        index: null,
        type: 1,
        isSetProhibitPush: false,
        query: {
          pageNo: 0,
          pageSize: 10,
          isOnline: true,
          name: null
        },
        cancelTemp: {
          id: null,
          minute: null,
        },
      }
    },
    created() {
      if (this.$route.query.index) {
        this.index = this.$route.query.index
      }
      if (this.$route.query.type) {
        this.type = Number(this.$route.query.type)
      }
    },
    methods: {
      compareDate(date1, date2) {
        var oDate1 = new Date(date1);
        var oDate2 = new Date(date2);
        if (oDate1.getTime() > oDate2.getTime()) {
          return true; //第一个大
        } else {
          return false; //第二个大
        }
      },
      hasBtnPermission(value) {
        if (value != null) {
          return hasBtnPermission(value)
        } else {
          return false
        }
      },
      onLoad() {
        this.query.pageNo++
        this.getUnitPageData()
      },
      getUnitPageData() {
        if (this.refreshing) {
          this.list = []
          this.refreshing = false
        }
        getUnitPage(this.query).then(res => {
          this.list = this.list.concat(res.data.rows)
          this.loading = false
          if (this.list.length >= res.data.totalRows) {
            this.finished = true
          }
        })
      },
      onRefresh() {
        // 清空列表数据
        this.list = []
        this.query.pageNo = 0
        this.finished = false
        // 重新加载数据
        // 将 loading 设置为 true，表示处于加载状态
        this.loading = true
        this.onLoad()
      },
      handleSetProhibitPushTime(index, id) {
        this.cancelTemp.id = id;
        this.cancelTemp.minute = '30'
        this.isSetProhibitPush = true;
      },
      setProhibitPushTime() {
        this.$dialog
          .confirm({
            message: '是否确认禁止推送!'
          }).then(() => {
          onlineUnitSetProhibitPushTime(this.cancelTemp).then(res => {
            if (res.success) {
              // Notify({ type: 'primary', message: '删除成功' });
              Toast.success('操作成功')
              // this.list.splice(index, 1)
              this.onRefresh()
            } else {
              Toast(res.message)
            }
          }).catch((err) => {
            Toast(err + '')
          })
        }).catch(() => {
        })
      },
      cancelProhibitPush(index, id) {
        this.$dialog
          .confirm({
            message: '是否确认恢复推送!'
          }).then(() => {
          onlineUnitCancelProhibitPush({id: id}).then(res => {
            if (res.success) {
              // Notify({ type: 'primary', message: '删除成功' });
              Toast.success('恢复成功')
              // this.list.splice(index, 1)
              this.onRefresh()
            } else {
              Toast(res.message)
            }
          }).catch((err) => {
            Toast(err + '')
          })
        }).catch(() => {
        })
      },
      onDelete(index, id) {
        this.$dialog
          .confirm({
            message: '是否确认删除!'
          }).then(() => {
          unit_Del([id]).then(res => {
            if (res.success) {
              // Notify({ type: 'primary', message: '删除成功' });
              Toast.success('删除成功')
              // this.list.splice(index, 1)
              this.onRefresh()
            } else {
              Toast(res.message)
            }
          }).catch((err) => {
            Toast(err + '')
          })
        }).catch(() => {
        })
      },
      onDetails(id) {
        if (this.index) {
          this.$router.push({
            path: '/app/warn/index',
            query: {
              unitId: id,
              index: this.index
            }
          })
        }
      },
      onEdit(id) {
        this.$router.push({
          path: '/app/sys/unit/operation/index',
          query: {
            id: id,
            operationType: 'edit'
          }
        })
      },
      onAdd() {
        this.$router.push({
          path: '/app/sys/unit/operation/index',
          query: {
            operationType: 'add'
          }
        })
      },
      onSearch(val) {
        this.query.name = val
        this.onRefresh()
      }
    }
  }
</script>

<style scoped>
  .address-cell >>> .van-cell__title {
    min-width: 80%;
    text-align: left;
  }

  .pushtime >>> .van-cell__value {
    flex: 0.7
  }
</style>
