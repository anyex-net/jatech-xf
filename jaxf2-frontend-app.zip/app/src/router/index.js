import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    noCache: true                if set true, the page will no be cached(default is false)
    affix: true                  if set true, the tag will affix in the tags-view
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */

export const constantRoutes = [
  {
    meta: { index: -2 },
    path: '/flow/index',
    component: () => import('@/views/flow/index'),
    hidden: true
  }, {
    path: '/',
    redirect: '/index',
    meta: {
      showTab: true, // tab是否显示
      index: 0
    }
  },
  {
    path: '/index',
    component: () => import('@/views/app/index/index'),
    meta: {
      showTab: true, // tab是否显示
      index: 0
    }
  },
  {
    path: '/me',
    component: () => import('@/views/app/me/index'),
    meta: {
      showTab: true, // tab是否显示
      index: 0
    }
  },
  {
    path: '/app/me/unitUpdate',
    component: () => import('@/views/app/me/unitUpdate'),
    meta: { index: 3, keepAlive: false }
  },
  {
    meta: { index: -1 },
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/error-page/404'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('@/views/error-page/401'),
    hidden: true
  },
  {
    meta: { index: 6, keepAlive: false },
    path: '/app/warn/common/userDeviceForm',
    name: '/app/warn/common/userDeviceForm',
    component: () => import('@/views/app/warn/common/userDeviceForm')
  },
  {
    meta: { index: 5, keepAlive: false },
    path: '/app/warn/common/userDeviceList',
    name: '/app/warn/common/userDeviceList',
    component: () => import('@/views/app/warn/common/userDeviceList')
  },
  {
    meta: { index: 3, keepAlive: false },
    path: '/app/warn/common/deviceList',
    name: '/app/warn/common/deviceList',
    component: () => import('@/views/app/warn/common/deviceList')
  },
  {
    meta: { index: 4 },
    path: '/app/warn/index',
    name: '/app/warn/index',
    component: () => import('@/views/app/warn/index')
  },
  {
    meta: { index: 4 },
    path: '/app/warn/common/deviceDetail',
    name: '/app/warn/common/deviceDetail',
    component: () => import('@/views/app/warn/common/deviceDetail')
  },
  {
    meta: { index: 6 },
    path: '/app/warn/common/noticeRecord',
    name: '/app/warn/common/noticeRecord',
    component: () => import('@/views/app/warn/common/noticeRecord')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/common/eventDetail',
    name: '/app/warn/common/eventDetail',
    component: () => import('@/views/app/warn/common/eventDetail')
  },
  {
    meta: { index: 6 },
    path: '/app/warn/common/deviceForm',
    name: '/app/warn/common/deviceForm',
    component: () => import('@/views/app/warn/common/deviceForm')
  },
  {
    meta: { index: 6 },
    path: '/app/me/pwdUpdate',
    name: '/app/me/pwdUpdate',
    component: () => import('@/views/app/me/pwdUpdate')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/water/sensorForm',
    name: '/app/warn/water/sensorForm',
    component: () => import('@/views/app/warn/water/sensorForm')
  },
  {
    meta: { index: 4 },
    path: '/app/warn/water/sensorDetail',
    name: '/app/warn/water/sensorDetail',
    component: () => import('@/views/app/warn/water/sensorDetail')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/water/deviceList',
    name: '/app/warn/water/deviceList',
    component: () => import('@/views/app/warn/water/deviceList')
  },
  {
    meta: { index: 6 },
    path: '/app/warn/water/deviceForm',
    name: '/app/warn/water/deviceForm',
    component: () => import('@/views/app/warn/water/deviceForm')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/switchs/deviceForm',
    name: '/app/warn/switchs/deviceForm',
    component: () => import('@/views/app/warn/independence/switchs/deviceForm')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/switchs/controlList',
    name: '/app/warn/switchs/controlList',
    component: () => import('@/views/app/warn/independence/switchs/controlList')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/switchs/gateList',
    name: '/app/warn/switchs/gateList',
    component: () => import('@/views/app/warn/independence/switchs/gateList')
  },
  {
    meta: { index: 6 },
    path: '/app/warn/switchs/gateForm',
    name: '/app/warn/switchs/gateForm',
    component: () => import('@/views/app/warn/independence/switchs/gateForm')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/bottle/deviceForm',
    name: '/app/warn/bottle/deviceForm',
    component: () => import('@/views/app/warn/independence/bottle/deviceForm')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/bottle/gateList',
    name: '/app/warn/bottle/gateList',
    component: () => import('@/views/app/warn/independence/bottle/gateList')
  }, {
    meta: { index: 6 },
    path: '/app/warn/bottle/gateForm',
    name: '/app/warn/bottle/gateForm',
    component: () => import('@/views/app/warn/independence/bottle/gateForm')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/common/eventHandle',
    name: '/app/warn/common/eventHandle',
    component: () => import('@/views/app/warn/common/eventHandle')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/common/deviceHandle',
    name: '/app/warn/common/deviceHandle',
    component: () => import('@/views/app/warn/common/deviceHandle')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/water/sensorHandle',
    name: '/app/warn/water/sensorHandle',
    component: () => import('@/views/app/warn/water/sensorHandle')
  },
  {
    meta: { index: 2 },
    path: '/app/inspection/start/index',
    name: '/app/inspection/start/index',
    component: () => import('@/views/app/inspection/start/index')
  },
  {
    meta: { index: 3 },
    path: '/app/inspection/route/index',
    name: '/app/inspection/route/index',
    component: () => import('@/views/app/inspection/route/index')
  },
  {
    meta: { index: 4 },
    path: '/app/inspection/inspect/index',
    name: '/app/inspection/inspect/index',
    component: () => import('@/views/app/inspection/inspect/index')
  },
  {
    meta: { index: 5 },
    path: '/app/inspection/details/index',
    name: '/app/inspection/details/index',
    component: () => import('@/views/app/inspection/details/index')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/xks/add',
    name: '/app/warn/xks/add',
    component: () => import('@/views/app/warn/xks/add')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/shipin',
    name: '/app/warn/shipin',
    component: () => import('@/views/app/warn/shipin')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/xks/transmissionEdit',
    name: '/app/warn/xks/transmissionEdit',
    component: () => import('@/views/app/warn/xks/transmissionEdit')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/xks/eventList',
    name: '/app/warn/xks/eventList',
    component: () => import('@/views/app/warn/xks/eventList')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/xks/attendanceRecord',
    name: '/app/warn/xks/attendanceRecord',
    component: () => import('@/views/app/warn/xks/attendanceRecord')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/xks/controlList',
    name: '/app/warn/xks/controlList',
    component: () => import('@/views/app/warn/xks/controlList')
  },
  {
    meta: { index: 5 },
    path: '/app/warn/xks/edit',
    name: '/app/warn/xks/edit',
    component: () => import('@/views/app/warn/xks/edit')
  },
  {
    meta: { index: 5 },
    path: '/app/inspection/danger/index',
    name: '/app/inspection/danger/index',
    component: () => import('@/views/app/inspection/danger/index')
  },
  {
    meta: { index: 5 },
    path: '/app/inspection/danger/handle/index',
    name: '/app/inspection/danger/handle/index',
    component: () => import('@/views/app/inspection/danger/handle/index')
  },
  {
    meta: { index: 5 },
    path: '/app/inspection/filling/index',
    name: '/app/inspection/filling/index',
    component: () => import('@/views/app/inspection/filling/index')
  },
  {
    meta: { index: 5 },
    path: '/app/inspection/filling/details/index',
    name: '/app/inspection/filling/details/index',
    component: () => import('@/views/app/inspection/filling/details/index')
  },
  {
    meta: { index: 3 },
    path: '/app/inspection/point/add/index',
    name: '/app/inspection/point/add/index',
    component: () => import('@/views/app/inspection/point/add/index')
  },
  {
    meta: { index: 2 },
    path: '/app/inspection/point/index',
    name: '/app/inspection/point/index',
    component: () => import('@/views/app/inspection/point/index')
  },
  {
    meta: { index: 2 },
    path: '/app/inspection/maintenance/index',
    name: '/app/inspection/maintenance/index',
    component: () => import('@/views/app/inspection/maintenance/index')
  },
  {
    meta: { index: 2 },
    path: '/app/inspection/maintenance/index',
    name: '/app/inspection/maintenance/index',
    component: () => import('@/views/app/inspection/maintenance/index')
  },
  {
    meta: { index: 0 },
    path: '/app/sys/unit/index',
    name: '/app/sys/unit/index',
    component: () => import('@/views/app/sys/unit/index')
  }, {
    meta: { index: 3 },
    path: '/app/sys/unit/details/index',
    name: '/app/sys/unit/details/index',
    component: () => import('@/views/app/sys/unit/details/index')
  }, {
    meta: { index: 3 },
    path: '/app/sys/unit/operation/index',
    name: '/app/sys/unit/operation/index',
    component: () => import('@/views/app/sys/unit/operation/index')
  },
  {
    meta: { index: 2 },
    path: '/app/sys/user/index',
    name: '/app/sys/user/index',
    component: () => import('@/views/app/sys/user/index')
  }, {
    meta: { index: 3 },
    path: '/app/sys/user/details/index',
    name: '/app/sys/user/details/index',
    component: () => import('@/views/app/sys/user/details/index')
  }, {
    meta: { index: 3 },
    path: '/app/sys/user/operation/index',
    name: '/app/sys/user/operation/index',
    component: () => import('@/views/app/sys/user/operation/index')
  },
  {
    meta: { index: 2 },
    path: '/app/me/user/index',
    name: '/app/me/user/index',
    component: () => import('@/views/app/me/user/index')
  }, {
    meta: { index: 3 },
    path: '/app/me/user/details/index',
    name: '/app/me/user/details/index',
    component: () => import('@/views/app/me/user/details/index')
  }, {
    meta: { index: 3 },
    path: '/app/me/user/operation/index',
    name: '/app/me/user/operation/index',
    component: () => import('@/views/app/me/user/operation/index')
  },
  {
    meta: { index: 3 },
    path: '/app/sys/user/role/index',
    name: '/app/sys/user/role/index',
    component: () => import('@/views/app/sys/user/role/index')
  },
  // region 灭火器管理
  {
    meta: { index: 1 },
    path: '/app/extinguisher/index',
    name: '/app/extinguisher/index',
    component: () => import('@/views/app/extinguisher/index')
  },
  {
    meta: { index: 2 },
    path: '/app/extinguisher/details/index',
    name: '/app/extinguisher/details/index',
    component: () => import('@/views/app/extinguisher/details/index')
  },
  {
    meta: { index: 3 },
    path: '/app/extinguisher/operation/index',
    name: '/app/extinguisher/operation/index',
    component: () => import('@/views/app/extinguisher/operation/index')
  },
  // endregion
  // region 离线巡查
  {
    meta: {
      showTab: false, // tab是否显示
      index: 1
    },
    path: '/app/new/inspection/offline',
    name: '/app/new/inspection/offline',
    component: () => import('@/views/app/new/inspection/index')
  },
  {
    meta: {
      index: 2
    },
    path: '/app/new/inspection/offline/list',
    name: '/app/new/inspection/offline/list',
    component: () => import('@/views/app/new/inspection/offline/index')
  },
  // endregion
  // region 巡查维保
  {
    meta: { index: 2 },
    path: '/app/new/inspection/start/index',
    name: '/app/new/inspection/start/index',
    component: () => import('@/views/app/new/inspection/start/index')
  },
  {
    meta: { index: 4 },
    path: '/app/new/inspection/inspect/index',
    name: '/app/new/inspection/inspect/index',
    component: () => import('@/views/app/new/inspection/inspect/index')
  },
  {
    meta: { index: 5 },
    path: '/app/new/inspection/details/index',
    name: '/app/new/inspection/details/index',
    component: () => import('@/views/app/new/inspection/details/index')
  },
  {
    meta: { index: 5 },
    path: '/app/new/inspection/danger/index',
    name: '/app/new/inspection/danger/index',
    component: () => import('@/views/app/new/inspection/danger/index')
  },
  {
    meta: { index: 5 },
    path: '/app/new/inspection/danger/handle/index',
    name: '/app/new/inspection/danger/handle/index',
    component: () => import('@/views/app/new/inspection/danger/handle/index')
  },
  {
    meta: { index: 5 },
    path: '/app/new/inspection/filling/index',
    name: '/app/new/inspection/filling/index',
    component: () => import('@/views/app/new/inspection/filling/index')
  },
  {
    meta: { index: 5 },
    path: '/app/new/inspection/filling/details/index',
    name: '/app/new/inspection/filling/details/index',
    component: () => import('@/views/app/new/inspection/filling/details/index')
  },
  {
    meta: { index: 2 },
    path: '/app/new/inspection/point/index',
    name: '/app/new/inspection/point/index',
    component: () => import('@/views/app/new/inspection/point/index')
  },
  {
    meta: { index: 3 },
    path: '/app/new/inspection/point/add/index',
    name: '/app/new/inspection/point/add/index',
    component: () => import('@/views/app/new/inspection/point/add/index')
  },
  {
    meta: { index: 2 },
    path: '/app/new/inspection/maintenance/index',
    name: '/app/new/inspection/maintenance/index',
    component: () => import('@/views/app/new/inspection/maintenance/index')
  },
  {
    meta: { index: 3 },
    path: '/app/new/inspection/tabs/patrol/trajectory',
    name: '/app/new/inspection/tabs/patrol/trajectory',
    component: () => import('@/views/app/new/inspection/tabs/patrol/trajectory')
  }
  // endregion
]

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */

const createRouter = () => new Router({
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router

const originalPush = Router.prototype.push

Router.prototype.push = function push(to) {
  return originalPush.call(this, to).catch((err) => err)
}

