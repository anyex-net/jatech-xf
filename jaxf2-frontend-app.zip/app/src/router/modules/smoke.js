import Layout from '@/layout'

const smokeRouter = {
  path: '/smoke',
  component: Layout,
  redirect: '/smoke/list',
  name: 'smoke',
  meta: {
    title: '烟感',
    icon: 'table'
  },
  children: [
    {
      path: 'index',
      component: () => import('@/views/smoke/index'),
      name: '基本信息管理',
      meta: { title: '基本信息管理' }
    },
    {
      path: 'events',
      component: () => import('@/views/smoke/events'),
      name: '事件管理',
      meta: { title: '事件管理', noCache: true }
    },
  ]
}
export default smokeRouter
