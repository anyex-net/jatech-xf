import Layout from '@/layout'

const xksRouter = {
  path: '/xks',
  component: Layout,
  redirect: '/xks/list',
  name: 'xks',
  meta: {
    title: '消控室',
    icon: 'table'
  },
  children: [
    {
      path: 'list',
      component: () => import('@/views/xks/index'),
      name: '消控室管理',
      meta: { title: '消控室管理' }
    },
    {
      path: 'events',
      component: () => import('@/views/xks/events'),
      name: '事件管理',
      meta: { title: '事件管理', noCache: true }
    },
  ]
}
export default xksRouter
