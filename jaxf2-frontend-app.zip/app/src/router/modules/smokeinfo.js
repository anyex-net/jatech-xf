import Layout from '@/layout'

const smokeinfoRouter = {
  path: '/smoke',
  component: Layout,
  redirect: '/smokeinfo/list',
  name: 'smoke',
  meta: {
    title: '烟感',
    icon: 'table'
  },
  children: [
    {
      path: 'index',
      component: () => import('@/views/smokeinfo/index'),
      name: '烟感设备管理',
      meta: {title: '烟感设备管理'}
    },
    {
      path: 'events',
      component: () => import('@/views/smokeinfo/events'),
      name: '烟感事件管理',
      meta: {title: '烟感事件管理', noCache: true}
    },
    {
      path: 'noticeEvents',
      component: () => import('@/views/smokeinfo/noticeEvents'),
      name: '推送事件配置',
      meta: {title: '推送事件配置', noCache: true}
    },
    {
      path: 'userManage',
      component: () => import('@/views/smokeinfo/userManage'),
      name: '推送人员配置',
      meta: {title: '推送人员配置', noCache: true}
    }
  ]
}
export default smokeinfoRouter
