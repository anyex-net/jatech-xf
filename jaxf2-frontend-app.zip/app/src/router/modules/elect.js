import Layout from '@/layout'

const electRouter = {
  path: '/elect',
  component: Layout,
  redirect: '/elect/list',
  name: 'elect',
  meta: {
    title: '电气设备',
    icon: 'table'
  },
  children: [
    {
      path: 'list',
      component: () => import('@/views/xks/index'),
      name: 'electlist',
      meta: { title: '消控室管理' }
    },
    {
      path: 'events',
      component: () => import('@/views/xks/events'),
      name: '事件管理',
      meta: { title: '事件管理', noCache: true }
    },
  ]
}
export default electRouter
