<template>
  <div>
    <van-field :rules="rules" :required="required" input-align="right" :value="value" :label="label"
               :placeholder="placeholder"
               readonly right-icon="arrow" @click="showPicker = true"/>
    <van-popup v-model="showPicker" position="bottom">
      <van-datetime-picker v-model="currentDate" :formatter="formatter" type="datetime"
                           @cancel="cancel"
                           @confirm="confirm"/>
    </van-popup>
  </div>
</template>


<script>

  export default {
    name: 'CommonDateSelect',
    props: {
      label: {
        type: String,
        default: ''
      },
      required: {
        type: Boolean,
        default: false,
      },
      placeholder: {
        type: String,
        default: ''
      },
      value: {
        type: String,
        default: ''
      },
      rules: {
        type: Array,
        required: false
      },
    },
    data() {
      return {
        showPicker: false,
        currentDate: new Date(),
      }
    },
    mounted() {

    },
    methods: {
      formatter(type, value) {
        if (type === 'year') {
          return `${value}年`
        } else if (type === 'month') {
          return `${value}月`
        } else if (type === 'day') {
          return `${value}日`
        } else if (type === 'hour') {
          return `${value}时`
        } else if (type === 'minute') {
          return `${value}分`
        } else if (type === 'second') {
          return `${value}秒`
        }
        return value
      },
      confirm(date) {
        let year = date.getFullYear();
        let month = date.getMonth() + 1
        month = month < 10 ? "0" + month : month;
        let day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        let hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
        let minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
        let second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
        let currentTime = year + "-" + month + "-" + day + "  " + hour + ":" + minute + ":" + second;
        this.showPicker = false;
        this.$emit("update", currentTime);
        this.currentDate = new Date(currentTime)
      },
      cancel() {
        this.showPicker = false
        this.currentDate = new Date(this.value)
      }
    }
  }
</script>

<style lang="less" scoped>


</style>
