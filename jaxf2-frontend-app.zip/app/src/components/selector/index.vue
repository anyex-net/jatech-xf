<!--
* @Author:Daisy
* @Date: 2021/5/30
* @Desc: 模糊搜索/过滤
-->
<template>
  <div class="selector">
    <div>
      <van-popup :class="isBottom?'popupBottom1':'popupBottom'" v-model="showPicker" position="bottom"
                 :close-on-click-overlay="false" @click-overlay="close">
        <van-search v-if="remote || filterable" v-model="searchText" placeholder="搜索"
                    @input="onSearch"/>
        <van-picker show-toolbar :columns="showOptions"
                    @confirm="onConfirm" @cancel="close" @change="onChange">
          <template #option="item">
            <div style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;font-size: 13px">{{
              getShowData(item) }}
            </div>
          </template>
        </van-picker>
      </van-popup>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'selector',
    props: {
      //下拉选项保存值
      searchValue: {
        type: String,
        default: 'id'
      },
      isBottom: {
        type: Boolean,
        default: false,
      },
      //下拉展示的字段，可以是单个属性，也可以是多个属性拼接
      // 单属性 label='name'|| 多属性 :label="['key', 'name']"
      searchLabel: {
        type: [String, Array],
        default: 'value'
      },
      //弹出层是否展示
      showPicker: {
        type: Boolean,
        default: false
      },
      // 下拉列表
      options: {
        type: Array,
        default: () => []
      },
      //是否需要过滤
      filterable: {
        type: Boolean,
        default: false
      },
      //是否为远程搜索
      remote: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        searchText: '', //搜索参数
        currentChoose: null, //当前选中值
        showOptions: [] //展示的下拉列表
      };
    },
    watch: {
      //模糊搜索时需同步更新展示的下拉列表
      options(val) {
        if (this.remote) {
          this.showOptions = val;
        }
      },
      options: {
        handler(n, o) {
          this.showOptions = n //赋值给data
        },
        deep: true// 深度监听父组件传过来对象变化
      }
    },
    created() {
      this.$nextTick(() => {
        this.showOptions = this.options.slice(0);
      });
    },
    methods: {
      /**
       * 搜索时
       */
      onSearch() {
        if (this.remote) {
          this.$emit('search', this.searchText);
        } else if (this.filterable) {
          this.onFilter();
        }
      },
      /**
       * 过滤
       */
      onFilter() {
        if (this.searchText === '' || this.searchText === null) {
          this.showOptions = this.options.slice(0);
        } else {
          this.showOptions = this.options.filter(item => this.getShowData(item).indexOf(this.searchText) > -1);
        }
      },
      /**
       * 选择器展示值
       * @param item
       * @returns {string|*}
       */
      getShowData(item) {
        if (item) {
          if (typeof this.searchLabel == 'string') {
            return item[this.searchLabel] ? item[this.searchLabel] : item.id;
          } else {
            let str = '';
            this.searchLabel.forEach(i => {
              str = str.concat(item[i] + ' ');
            });
            return str;
          }
        }
      },
      /**
       * 确认回调
       * @param value
       */
      onConfirm(value) {
        if (value) {
          if (this.searchValue === 'item') {
            this.currentChoose = value;
          } else {
            if (value[this.searchValue] || value[this.searchValue] === 0) {
              this.currentChoose = value[this.searchValue];
            }
          }
          this.$emit('onShow', value);
          if (this.currentChoose || this.currentChoose === '0' || this.currentChoose === 0) {
            this.$emit('confirm', this.currentChoose);
          }
        }
        this.$emit('update:showPicker', false);
      },
      close() {
        this.$emit('update:showPicker', false);
        this.$emit('close');
      },
      onChange(picker, value, index) {
        if (value) {
          if (this.searchValue === 'item') {
            this.currentChoose = value;
          } else {
            this.currentChoose = value[this.searchValue];
          }
          this.$emit('change', this.currentChoose);
        }
      }
    }
  };
</script>

<style scoped>

  .close-popup {
    position: absolute;
    right: 0.28rem;
    top: 0.3rem;
  }

  .popupBottom {
    bottom: 60px;
    width: 100%;
    bottom: calc(60px + constant(safe-area-inset-bottom));
    bottom: calc(60px + env(safe-area-inset-bottom));
    z-index: 9999
  }

  .popupBottom1 {
    bottom: 0px;
    width: 100%;
    z-index: 9999
  }

</style>
