<template>
  <div>
    <easy-player alt="加载中" v-if="id != null || (appVideoUrl != null && appVideoUrl !== '')" ref="easyPlayer"
                 :live="true"
                 :stretch="false"
                 :decode-type="'soft'"
                 :easyStretch="false"
                 :video-url="url"/>
    <div v-if="id == null && (appVideoUrl == null || appVideoUrl==='')"
         style="text-align: center;width: 100%;height: 100%;display:flex;align-items:center;justify-content: center">
      没有视频
    </div>
  </div>
</template>
<script>
  import {getVideoUrl} from "../../api/monitor/index";
  import EasyPlayer from '@easydarwin/easyplayer'

  export default {
    name: 'Video1',
    components: {EasyPlayer},
    directives: {},
    filters: {},
    props: {
      id: String,
      default: null,
      videoHeight: {
        type: String,
        default: '600px'
      },
      appVideoUrl: {
        type: String,
        default: null,
      }
    },
    data() {
      return {
        player: null,
        reFresh: true,
        url: '',
        options: {},
        input: null,
      }
    },
    beforeDestroy() {
      if (this.$refs.easyPlayer) {
        this.$refs.easyPlayer.destroyPlayer()
      }
    },
    mounted() {

    },
    created() {
      if (this.appVideoUrl == null || this.appVideoUrl === '') {
        this.getVideoUrl();
      } else {
        setTimeout(() => {
          this.url = this.appVideoUrl
        }, 3000)
      }
    },
    watch: {},
    methods: {
      pause() {
        console.log("播放中断")
        alert("播放中断")
      },
      play() {
        console.log("开始播放")
        alert("开始播放")
      },
      error() {
        alert("播放发生异常");
      },
      getVideoUrl() {
        getVideoUrl({id: this.id}).then(response => {
          if (response.success) {
            setTimeout(() => {
              this.url = response.data;
            }, 3000)
          }
        })
      },
    }
  }
</script>

<style lang="less" scoped>


</style>
