<template>
  <div id="switch">
    <button type="button" class="defaultButton" :class="active ? 'defaultButton_active' : ''" @click="active = true">是</button>
    <button type="button" style="margin-left: 15px" class="defaultButton" :class="!active ? 'defaultButton_active' : ''" @click="active = false">否</button>
  </div>
</template>

<script>
export default {
  name: 'CustomSwitch',
  components: {},
  props: {
    value: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      active: this.value
    }
  },
  computed: {},
  // 侦听属性
  watch: {
    active(newVal, odlObj) {
      this.$emit('input', newVal)
    }
  },
  // 实例创建完成执行的钩子
  created() {},
  // 编译好的html挂载到页面完成后执行的事件钩子
  // 在整个实例中只执行一次
  mounted() {
    this.$emit('input', this.value)
  },
  methods: {}
}
</script>

<style scoped>
#switch{
    display: flex;
    flex-direction: row;
    align-content: center;
    justify-content: space-between;
    align-items: center;
}
.defaultButton{
    padding: 0 25px;
    height: 30px;
    border: 1px solid transparent;
    border-radius: 6px;
    background-color: #F6F6F6;
}
.defaultButton_active{
  padding: 0 25px;
  height: 30px;
  border: 1px solid transparent;
  border-radius: 6px;
  background-color: #1989FA;
  color: #FFFFFF;
}
</style>
