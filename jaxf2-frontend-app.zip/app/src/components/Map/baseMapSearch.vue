<template>
  <div>
    <div v-show="isShow" class="search-box">
      <!-- <el-input
        v-model="searchKey"
        type="search"
        id="search"
        placeholder="请输入详细地址" style="width:100%"></el-input> -->
      <van-field
        id="search"
        v-model="searchKey"
        required
        :rules="rules"
        :input-align="inputAlign"
        label="安装地址："
        placeholder="请输入详细地址"
        :error-message="errorsearchKey"
        @blur="checksearchKey()"
      />
      <!--<button @click="searchByHand">搜索</button>-->
      <div id="searchTip" class="tip-box"/>
    </div>
    <div class="amap-box">
      <el-amap
        :amap-manager="amapManager"
        :vid="'amap-vue'"
        :zoom="zoom"
        :plugin="plugin"
        :center="center"
        :events="events"
        :drag-enable="true"
        :show-indoor-map="false"
        :animate-enable="true"
      >
        <!-- 标记 -->
        <el-amap-marker
          v-for="(marker, index) in markers"
          :key="index"
          :position="marker"
        />
      </el-amap>
    </div>
  </div>
</template>
<script>
  import {AMapManager, lazyAMapApiLoaderInstance} from 'vue-amap'

  const amapManager = new AMapManager()

  export default {
    props: ['city', 'value', 'longitude', 'latitude', 'isEdit', 'rules', 'isHide', 'inputAlign'],
    data() {
      const self = this
      return {
        address: null,
        isShow: true,
        searchKey: '',
        amapManager,
        markers: [],
        errorsearchKey: '',
        searchOption: {
          city: this.city ? this.city : '全国',
          citylimit: true
        },
        center: [121.329402, 31.228667],
        zoom: 17,
        lng: 0,
        lat: 0,
        loaded: false,
        events: {
          init() {
            lazyAMapApiLoaderInstance.load().then(() => {
              self.initSearch()
            })
          },
          // 点击获取地址的数据
          click(e) {
            self.markers = []
            const {lng, lat} = e.lnglat
            self.lng = lng
            self.lat = lat
            self.center = [lng, lat]
            self.markers.push([lng, lat])
            // 这里通过高德 SDK 完成。
            const geocoder = new AMap.Geocoder({
              radius: 1000,
              extensions: 'all'
            })
            geocoder.getAddress([lng, lat], function (status, result) {
              if (status === 'complete' && result.info === 'OK') {
                if (result && result.regeocode) {
                  self.address = result.regeocode.formattedAddress
                  self.searchKey = result.regeocode.formattedAddress
                  self.$emit('updateLocation', lng, lat, self.searchKey)
                  self.$nextTick()
                }
              }
            })
          }
        },
        // 一些工具插件
        plugin: [
          {
            // 定位
            pName: 'Geolocation',
            showCircle: false,
            events: {
              init(o) {
                // o是高德地图定位插件实例
                o.getCurrentPosition((status, result) => {
                  if (result && result.position) {
                    if (self.isEdit) {
                      if (self.longitude && self.latitude) {
                        // 设置经度
                        self.lng = self.longitude
                        // 设置维度
                        self.lat = self.latitude
                        // 设置坐标
                        self.center = [self.longitude, self.latitude]
                        self.markers.push([self.longitude, self.latitude])
                      } else {
                        // 设置经度
                        self.lng = result.position.lng
                        // 设置维度
                        self.lat = result.position.lat
                        // 设置坐标
                        self.center = [self.lng, self.lat]
                        self.markers.push([self.lng, self.lat])
                        let address = ''
                        if (result.formattedAddress) {
                          address = result.formattedAddress
                        }
                        self.$emit('updateLocation', self.lng, self.lat, address)
                      }
                    } else {
                      // 设置经度
                      self.lng = result.position.lng
                      // 设置维度
                      self.lat = result.position.lat
                      // 设置坐标
                      self.center = [self.lng, self.lat]
                      self.markers.push([self.lng, self.lat])
                      let address = ''
                      if (result.formattedAddress) {
                        address = result.formattedAddress
                      }
                      self.$emit('updateLocation', self.lng, self.lat, address)
                    }
                    // load
                    self.loaded = true
                    // 页面渲染好后
                    self.$nextTick()
                  }
                })
              }
            }
          }
        ]
      }
    },
    created() {
      if (this.value) {
        this.searchKey = this.value
        this.address = this.value
      }
      if (this.longitude && this.latitude) {
        this.lng = this.longitude
        this.lat = this.latitude
        this.center = [this.longitude, this.latitude]
        this.markers.push([this.longitude, this.latitude])
      }
    },
    mounted() {
      if (this.isHide) {
        this.isShow = false
      }
      if (this.value) {
        this.searchKey = this.value
        this.address = this.value
      } else {
        this.searchKey = ''
        this.address = ''
      }
    },
    methods: {
      // 选择地址后自动定位到当前地址附近
      updateAddress(value, longitude, latitude) {
        this.searchKey = value
        this.address = value
        this.lng = longitude
        this.lat = latitude
        this.center = [longitude, latitude]
        this.markers = []
        this.markers.push([longitude, latitude])
      },
      initSearch() {
        const vm = this
        const map = this.amapManager.getMap()
        AMapUI.loadUI(['misc/PoiPicker'], function (PoiPicker) {
          const poiPicker = new PoiPicker({
            input: 'search',
            placeSearchOptions: {
              map: map,
              pageSize: 10
            },
            suggestContainer: 'searchTip',
            searchResultsContainer: 'searchTip'
          })
          vm.poiPicker = poiPicker
          // 监听poi选中信息
          poiPicker.on('poiPicked', function (poiResult) {
            const source = poiResult.source
            const poi = poiResult.item
            if (source !== 'search') {
              poiPicker.searchByKeyword(poi.name)
            } else {
              poiPicker.clearSearchResults()
              vm.markers = []
              const lng = poi.location.lng
              const lat = poi.location.lat
              const address = poi.name // poi.cityname + poi.adname + poi.name
              vm.center = [lng, lat]
              vm.markers.push([lng, lat])
              vm.lng = lng
              vm.lat = lat
              vm.address = address
              vm.searchKey = address
              vm.$emit('updateLocation', lng, lat, vm.searchKey)
            }
          })
        })
      },
      searchByHand() {
        if (this.searchKey !== '' && this.poiPicker) {
          this.poiPicker.searchByKeyword(this.searchKey)
        }
      },
      checksearchKey() {
        if (!this.searchKey) {
          this.errorsearchKey = '请输入详细地址'
          return false
        } else {
          this.errorsearchKey = ''
          return true
        }
      }
    }
  }
</script>
<style>
  .search-box {
    width: 100%;
  }

  .search-box input {
    width: 100%;
    height: 24px;
    line-height: 24px;
    color: #606266;
    border-radius: 4px;
  }

  .search-box input:focus {
    border-color: #409eff;
    outline: 0;
  }

  .search-box input::-webkit-input-placeholder {
    color: #c0c4cc;
  }

  .tip-box {
    width: 82%;
    max-height: 280px;
    position: absolute;
    top: 225px;
    z-index: 200;
    overflow-y: auto;
    background-color: #fff;
  }

  .amap-ui-poi-picker-sugg,
  .amap_lib_placeSearch {
    border: 1px solid #eee;
    border-radius: 4px;
  }

  .amap-box {
    height: 200px;
  }

  .mapsearchinput {
    width: 100%;
  }

  .amap-geolocation-con {
    z-index: 10 !important;
  }
</style>
