<template>
  <div>
    <van-field readonly :label="label"/>
    <van-uploader :disabled="disabled" style="padding-left: 10px" :preview-full-image="true" preview-size="1.8rem"
                  :after-read="afterRead"
                  v-model="fileList" :preview-options="previewOptions">
      <template #preview-cover="{ file }">
        <div class="preview-cover van-ellipsis"></div>
      </template>
      <van-button v-if="!disabled"
                  style="width:60px;height: 60px;margin-left: 10px;float: left;margin-top:10px;margin-bottom: 10px"
                  icon="plus"/>
    </van-uploader>
  </div>
</template>

<script>
  import {getToken} from "@/utils/auth";
  import {sysFileGetFileList} from "@/api/system/fileManage";
  import {sysFileInfo} from "../../api/detail";

  export default {
    name: 'CommonUpload',
    props: {
      value: {
        type: String,
        default: ''
      },
      label: {
        type: String,
        default: ''
      },
      disabled: {
        type: Boolean,
        default: false,
      }
    },
    data() {
      return {
        headers: {
          'X-Token': `${getToken()}`
        },
        dialogFileVisible: false,
        dialogImageUrl: '',
        fileList: [],
        previewOptions: ({
          closeable: true,
        }),
      }
    },
    mounted() {

    },
    methods: {
      setFileList(fileIds) {
        if (fileIds != null && fileIds != '') {
          sysFileGetFileList({"fileIds": fileIds}).then((response) => {
            if (response.success) {
              response.data.forEach((item, index) => {
                this.$set(this.fileList, index, {
                  id: item.id,
                  url: item.filePath,
                  fileId: item.id,
                  status: 'success'
                })
              });
              console.log(this.fileList)
            }
          })
        }
      },
      getFileIds() {
        if (this.fileList.filter(item => item.status === 'uploading').length !== 0) {
          this.$toast("图片正在上传")
          return;
        }
        let fileId = "";
        this.fileList.forEach((item) => {
          if (item.status === 'success')
            fileId = fileId + item.fileId + ","
        })
        return fileId
      },
      beforeUpload(file, fileList) {
        let testmsg = file.name.substring(file.name.lastIndexOf('.') + 1)
        let extension1 = testmsg === 'jpg'
        let extension2 = testmsg === 'png'
        let extension3 = testmsg === 'gif'
        let extension4 = testmsg === 'bmp'
        let extension5 = testmsg === 'tif'
        let bool = false
        if (extension1 || extension2 || extension3 || extension4 || extension5) {
          bool = true
        } else {
          bool = false
        }
        if (!bool) {
          this.$message.error(`请上传正确的图片格式,包含(jpg,png,gif,bmp,tif)`)
        }
        return bool
      },
      afterRead(file) {
        alert("接收到文件")
        // 此时可以自行将文件上传至服务器
        file.status = 'uploading'
        file.message = '上传中...'
        let content = file.file;
        let data = new FormData();
        alert("准备上传");
        data.append('file', content);
        sysFileInfo(data)
          .then((response) => {
            if (response.success) {
              file.status = 'success'
              file.fileId = response.data;
            } else {
              file.status = 'failed'
              file.message = '上传失败'
              this.$toast(response.message);
            }
          }).catch((err) => {
          file.status = 'failed'
          file.message = '上传失败'
          this.$toast(err + "");
        });
      },
    }
  }
</script>

<style lang="less" scoped>

  .preview-cover {
    position: absolute;
    bottom: 0;
    box-sizing: border-box;
    width: 100%;
    padding: 10px;
    color: #fff;
    font-size: 12px;
    text-align: center;
    background: rgba(0, 0, 0, 0.3);
  }
</style>
