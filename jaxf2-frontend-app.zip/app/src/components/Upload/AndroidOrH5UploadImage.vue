<template>
  <div>
    <div v-if="isAPP" style="margin-top: 5px;margin-bottom: 5px">
      <van-image
        v-for="(item,index) in localImgList"
        :key="index"
        :src="item.content"
        width="60"
        height="60"
        style="margin-right: 5px;float: left"
      />
      <div
        style="display: flex;width: 60px;height: 60px;justify-content: center;align-items: center;background-color: #f7f8fa"
        @click="offlineUpload"
      >
        <van-icon name="photograph" size="15" color="#dcdee0" />
      </div>
    </div>
    <van-uploader
      v-else
      v-model="localImgList"
      :after-read="afterRead"
      :before-read="beforeRead"
      :before-delete="beforeDelete"
      preview-size="60"
      style="padding-top: 10px;"
    />
  </div>
</template>

<script>

export default {
  name: 'AndroidOrH5UploadImage',
  props: {
    afterRead: {
      type: Function
    },
    beforeRead: {
      type: Function
    },
    beforeDelete: {
      type: Function
    },
    value: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      localImgList: [],
      isAPP: false,
      uid: this._uid
    }
  },
  watch: {
    // 监视prop的变化，并更新本地数据属性
    localImgList(newVal) {
      this.$emit('input', newVal)
    }
  },
  created() {
    console.log('this', this)
    delete window.receivePhoto
    this.isAPP = typeof window.AndroidWebView !== 'undefined'
    window.receivePhoto = this.receivePhoto
  },
  beforeDestroy() {
  },
  mounted() {
    this.localImgList = [...this.value]
  },
  methods: {
    receivePhoto() {
      const base64str = window.AndroidWebView.getBase64String()
      const content = 'data:image/png;base64,' + base64str
      const fileName = Math.floor(Math.random() * 10000000000000) + '.png'
      const file = {
        content: content,
        file: this.dataURLtoFile(content, fileName),
        status: '',
        message: '',
        fileId: null
      }
      this.localImgList.push(file)
      this.afterRead(file)
    },
    offlineUpload() {
      window.AndroidWebView.selectOrTakePhoto('item')
    },
    dataURLtoFile(dataUrl, filename) {
      const arr = dataUrl.split(',')
      const mime = arr[0].match(/:(.*?);/)[1]
      const str = atob(arr[1])
      let n = str.length
      const u8arr = new Uint8Array(n)
      while (n--) {
        u8arr[n] = str.charCodeAt(n)
      }
      return new File([u8arr], filename, { type: mime })
    }
  }
}
</script>

<style scoped>

</style>
