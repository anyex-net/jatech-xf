<template>
  <div class="app-container">
    <div class="filter-container">
      <el-form layout="inline" label-width="100px" class="mb0">
        <el-row v-show="query.query.length>0 || btns.length > 0">
          <el-col :key="pm.index" v-for="pm in query.query" :md="pm.md">
            <el-input v-if="pm.type == 'input'" v-model="pm.val" allow-clear :placeholder="pm.hint"/>
            <el-date-picker v-if="pm.type == 'daterange'" v-model="pm.val" type="daterange" range-separator="至"
                            start-placeholder="开始日期" end-placeholder="结束日期"></el-date-picker>
            <el-select v-if="pm.type == 'select'" v-model="pm.val" :placeholder="pm.hint">
              <el-option v-for="item in pm.items" :key="item.value" :label="item.label"
                         :value="item.value"></el-option>
            </el-select>
          </el-col>
          <el-col v-show="query.query.length>0" :md="4" :sm="12">
            <el-button class="filter-item" type="primary" icon="el-icon-search" @click="getList"
                       style="margin-left: 10px;">查询
            </el-button>
            <el-button v-waves class="filter-item" type="warning" icon="el-icon-refresh-left" @click="resetQuery">
              重置
            </el-button>
          </el-col>
          <el-col :key="btn.index" :md="2" v-for="btn in btns">
            <el-button v-if="hasPerm(btn.permission)" v-waves class="filter-item" type="primary" icon="el-icon-edit"
                       @click="btn.click">{{btn.name}}
            </el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="tableShadow" style="width:calc(100% - 40px);">

      <el-table :tableKey="module+name" ref="table" :data="datalist" v-loading="listLoading" :pagination="false">
        <el-table-column v-for="col in cols" :prop="col.prop" :label="col.label" :width="col.width">
          <template slot-scope="{row,$index}">
            <span
              v-show="!col.buttons">{{ (col.format) ? col.format(row, col.prop) : row[col.prop]}}</span>
            <el-button v-if="hasPerm(btn.permission)" v-for="btn in col.buttons" type="text" size="small"
                       @click="btn.click(row)">
              {{btn.name}}
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination v-show="total>0" :total="total" :page.sync="query.pageIndex" :limit.sync="query.z"
                @pagination="getList"/>
  </div>
</template>

<script>
  import {basePage} from '@/api/common/index.js'
  import Pagination from '@/components/Pagination'
  import waves from '@/directive/waves' // waves directive

  export default {
    name: 'BaseList',
    components: {Pagination},
    directives: {waves},
    data() {
      return {
        datalist: null,
        total: 0,
        listLoading: true,
      }
    },
    props: {
      listFunc: {
        type: Function,
        default: null
      },
      module: {
        required: true,
        type: String
      },
      name: {
        required: true,
        type: String
      },
      cols: {
        required: true,
        type: Array,
        default: [{prop: 'id', lable: 'id', width: '120'}]
      },
      query: {
        required: true,
        type: Object,
        default: {
          paramList: [],
          order: {field: '', dir: 'asc'},
          pageNo: 1,
          pageSize: 20,
        }
      },
      btns: {
        required: true,
        type: Array,
      }
    },
    methods: {
      resetQuery: function () {
        this.query.query.forEach((item) => {
          item.val = "";
        })
      },
      format(value, index) {
        return (value || '').split(',')[index]
      },
      getList: function () {
        this.listLoading = true;
        if (this.listFunc != null) {
        } else {
          basePage(this.module, this.name, this.query).then((response) => {
            this.datalist = response.data.records;
            this.total = parseInt(response.data.total);
            this.listLoading = false;
          }).catch((err) => {
            this.listLoading = false;
            this.$notify({title: '提示', message: err, type: 'error', duration: 2000})
          });
        }
      }
    },
    created() {
      this.getList()
    }
  }
  a
</script>

