<template>
  <diiv>
    <el-dialog title="新增/编辑" visible.sync="false" close-on-click-modal="false" destroy-on-close="true">
      <el-form ref="dialogForm" status-icon label-position="left" label-width="110px">
        <el-row :key="index" v-for="i in rowcount">
          <el-col :md="12" :sm="24" v-if="(2*i) < fields.length">
            <el-form-item :label="fields[2*i].label" :prop="fields[2*i].name" :rules="fields[2*i].rules">
              <el-input v-model="fields[2*i].val" :placeholder="fields[2*i].placeholder"/>
            </el-form-item>
          </el-col>
          <el-col :md="12" :sm="24" v-if="(2*i+1) < fields.length">
            <el-form-item :label="fields[2*i+1].label" :prop="fields[2*i+1].name" :rules="fields[2*i+1].rules">
              <el-input v-model="fields[2*i+1].val" :placeholder="fields[2*i+1].placeholder"/>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleCancel">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确认</el-button>
      </div>
    </el-dialog>
  </diiv>

</template>

<script>

  export default {
    name: 'BaseEdit',
    components: {},
    props: {
      fields: {
        required: true,
        type: Array,
        default: []
      },
    },
    data() {
      return {
        rowcount: this.fields.length / 2 + (this.fields.length % 2)
      };
    },
    created() {
      this.setDialogWidth();
    },
    methods: {
      handleSubmit() {
        alert('submit');
      },
      handleCancel() {
        alert('cancel');
      },
      setDialogWidth() {
        //设置dialog宽度，自身width值设置无效
        var val = document.body.clientWidth;
        const def = 900; // 默认宽度
        if (val < def) {
          this.dialogWidth = "100%";
        } else {
          this.dialogWidth = def + "px";
        }
      },
    },
  };
</script>
