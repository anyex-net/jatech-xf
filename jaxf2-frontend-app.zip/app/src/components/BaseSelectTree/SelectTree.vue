<template>
  <el-form-item
    :label="label"
    :prop="prop"
    :rules="rules"
  >
    <el-select
      :value="id"
      :placeholder="placeholder"
      style="width: 100%"
      ref="TreeSelect"
    >
      <el-input
        style="margin-left:6%;margin-top:10px;width: 90%;height: auto"
        placeholder="输入名称模糊搜索" v-model="filterText">
      </el-input>
      <el-option
        :value="id"
        :label="name"
        style="width: 100%;height: auto"
      >

        <el-tree style="margin-top:15px"
                 node-key="id"
                 ref="selectTree"
                 highlight-current
                 :expand-on-click-node="false"
                 :props="selectTreeProps"
                 @current-change="handleCheckChange"
                 :filter-node-method="filterNode"
                 :load="loadNode"
                 lazy
        >
           <span class="custom-tree-node" slot-scope="{ node, data }">
            <span>
              <i class="el-icon-folder" v-if="node.isLeaf != true"></i>
              <i class="el-icon-tickets" v-if="node.isLeaf === true"></i>
            </span>
            {{ node.label }}
          </span>
        </el-tree>
      </el-option>
    </el-select>
  </el-form-item>
</template>

<script>
  import {getAreaTree} from '@/api/sys/area'
  import {getUnitTree} from '@/api/sys/unit'

  export default {
    data() {
      return {
        filterText: '',
        defaultProps: {
          children: 'children',
          label: 'title'
        },
        selectTreeProps: {
          label: 'name',
          children: 'zones',
          isLeaf: 'leaf',
          treeNodeId: 'id'
        },
        TreeData: [],
        listLoading: true,
        unitCondition: {
          unitId: null,
          unitName: null,
        },
        areaCondition: {
          areaId: null,
          areaName: null,
        }
      }
    },
    created() {

    },
    watch: {
      filterText(val) {
        this.$refs.selectTree.filter(val);
      }
    },
    props: {
      id: {
        required: false,
        type: String
      },
      name: {
        required: false,
        type: String
      },
      label: {
        required: false,
        type: String
      },
      prop: {
        required: false,
        type: String
      },
      currentId: {
        required: false,
        type: String
      },
      rules: {
        required: false,
        type: Array
      },
      placeholder: {
        required: false,
        type: String
      },
      condition: {
        required: false,
        type: String
      },
    },
    methods: {
      handleCheckChange() {
        //下拉框树形选择事件
        let currSelectNode = this.$refs.selectTree.getCurrentNode();
        if (currSelectNode != null) {
          this.$emit("ok", currSelectNode.id, currSelectNode.name); //回调父组件中的函数
          this.$refs.TreeSelect.blur(); //下拉框失去焦点(隐藏下拉)
        }
      },
      filterNode(value, data) {
        if (!value) return true;
        return data.name.indexOf(value) !== -1;
      },
      loadNode(node, resolve) {
        if (this.condition === "unitId") {
          if (node.level != 0) {
            this.unitCondition.unitId = node.data.id;
          }
          getUnitTree(this.unitCondition).then((response) => {
            if (this.currentId != null) {
              let data = [];
              response.data.forEach((item) => {
                if (item.id != this.currentId)
                  data.push(item)
              });
              resolve(data);
            } else {
              resolve(response.data);
            }
            if (node.level == 0) {
              node.childNodes.forEach((item) => {
                item.expand();
              })
            }
          }).catch((err) => {
            this.$notify({title: '提示', message: err, type: 'error', duration: 2000})
          })
        } else if (this.condition === "areaId") {
          if (node.level != 0) {
            this.areaCondition.areaId = node.data.id;
          }
          getAreaTree(this.areaCondition).then((response) => {
            if (this.currentId != null) {
              let data = [];
              response.data.forEach((item) => {
                if (item.id != this.currentId)
                  data.push(item)
              });
              resolve(data);
            } else {
              resolve(response.data);
            }
            if (node.level == 0) {
              node.childNodes.forEach((item) => {
                item.expand();
              })
            }
          }).catch((err) => {
            this.$notify({title: '提示', message: err, type: 'error', duration: 2000})
          })
        }
      },
    }
  }
</script>
