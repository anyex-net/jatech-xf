import router from './router'
import store from './store'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken } from '@/utils/auth' // get token from cookie
import getPageTitle from '@/utils/get-page-title'
import { Toast } from 'vant'

NProgress.configure({ showSpinner: false }) // NProgress Configuration

const whiteList = ['/login', '/auth-redirect'] // no redirect whitelist

router.beforeEach(async(to, from, next) => {
  // start progress bar
  NProgress.start()

  // set page title
  document.title = getPageTitle(to.meta.title)
  // console.log(from)
  // alert(from.path)
  let routeArray = sessionStorage.getItem('lasterRouter')
  if (!routeArray) {
    routeArray = []
    routeArray.push(from.fullPath)
    sessionStorage.setItem('lasterRouter', JSON.stringify(routeArray))
  } else {
    routeArray = JSON.parse(routeArray)
    if (to.fullPath === routeArray[routeArray.length - 1]) {
      routeArray.splice(routeArray.length - 1, 1)
    } else {
      routeArray.push(from.fullPath)
    }
    // console.log(routeArray)
    sessionStorage.setItem('lasterRouter', JSON.stringify(routeArray))
  }
  // determine whether the user has logged in
  const hasToken = getToken()
  if (to.path.indexOf('/app/inspection/point/index') >= 0 || to.path.indexOf('/app/extinguisher/operation/index') >= 0) {
    next()
  } else {
    if (hasToken) {
      if (to.path === '/login') {
        // if is logged in, redirect to the home page
        next()
      } else {
        // determine whether the user has obtained his permission roles through getInfo
        const hasRoles = store.getters.roles && store.getters.roles.length > 0
        if (hasRoles) {
          next()
        } else {
          try {
            // get user info
            // note: roles must be a object array! such as: ['admin'] or ,['developer','editor']
            const { permissions, menus } = await store.dispatch('user/getInfo')

            // generate accessible routes map based on roles
            const accessRoutes = await store.dispatch('permission/generateRoutes', menus)

            // dynamically add accessible routes
            router.addRoutes(accessRoutes)

            // hack method to ensure that addRoutes is complete
            // set the replace: true, so the navigation will not leave a history record
            next({ ...to, replace: true })
          } catch (error) {
            // remove token and go to login page to re-login
            await store.dispatch('user/resetToken')
            Toast(error || 'Has Error')
            next(`/login?redirect=${to.path}`)
            NProgress.done()
          }
        }
      }
    } else {
      /* has no token*/

      if (whiteList.indexOf(to.path) !== -1) {
        // in the free login whitelist, go directly
        next()
      } else {
        // other pages that do not have permission to access are redirected to the login page.
        next(`/login?redirect=${to.path}`)
        NProgress.done()
      }
    }
  }
})

router.afterEach(() => {
  // finish progress bar
  NProgress.done()
})
