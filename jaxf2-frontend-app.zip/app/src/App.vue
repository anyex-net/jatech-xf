<template>
  <div id="app" class="font-PingFang" @touchstart="startMove" @touchmove="move" @touchend="endMove">
    <Loading v-show="LOADING" />
    <transition v-if="$route.meta.keepAlive" :name="transitionName">
      <keep-alive>
        <router-view ref="we" />
      </keep-alive>
    </transition>
    <transition :name="transitionName">
      <router-view ref="we" class="Router" />
    </transition>

    <navbar v-if="isUser" :user="getUser()" :is-login="isLogin()" :is-show="isShow()" />

  </div>
</template>

<script>

import store from '@/store'
import { getToken } from '@/utils/auth'
import navbar from '@/views/app/common/navbar'
import Loading from '@/views/app/common/loading'
import { mapState } from 'vuex'

export default {
  name: 'App',
  components: { navbar, Loading },
  data() {
    return {
      transitionName: '',
      startX: null,
      endX: null,
      startY: null,
      endY: null,
      startMessageX: null,
      startMessageY: null
    }
  },
  computed: {
    ...mapState(['LOADING'])
  },
  watch: {// 使用watch 监听$router的变化
    $route(to, from) {
      const application = store.getters.user.application
      // 如果to索引大于from索引,判断为前进状态,反之则为后退状态
      if (to.meta.index > -1 && application != 'wx') {
        if (to.meta.index > from.meta.index) {
          // 设置动画名称
          this.transitionName = 'slide-left'
        } else if (to.meta.index < from.meta.index) {
          this.transitionName = 'slide-right'
        } else {
          this.transitionName = ''
        }
      } else {
        this.transitionName = ''
      }
    }
  },
  created() {
    /* if (window.addEventListener) {
        window.addEventListener("pagehide", function () { // IOS
          store.commit('SET_TOKEN', null)
        })
      } else {
        window.onbeforeunload = function () { // 安卓
          store.commit('SET_TOKEN', null)
        }
      }*/
  },
  mounted() {
    localStorage.setItem('firstUrl', location.href)
  },
  methods: {
    isShow() {
      return this.$route.meta.showTab
    },
    startMove(e) {
      this.startX = e.touches[0].pageX
      this.startY = e.touches[0].pageY
    },
    move(e) {

    },
    isUser() {
      return store.getters.user !== null
    },
    isLogin() {
      return !!getToken()
    },
    getUser() {
      return store.getters.user
    },
    endMove(e) {
      if (this.startX < 40) {
        this.endX = e.changedTouches[0].pageX
        this.endY = e.changedTouches[0].pageY
        const XLength = this.endX - this.startX
        const yLength = Math.abs(this.endY - this.startY)
        if (XLength > 50 && yLength < 30) {
          try {
            if (this.$refs.we.$children[0].$refs.backRef) {
              this.$refs.we.$children[0].$refs.backRef.click()
            } else if (this.$refs.we.$refs.backRef) {
              this.$refs.we.$refs.backRef.click()
            } else if (this.$refs.we.$children[0].$children[0].$refs.backRef) {
              this.$refs.we.$children[0].$children[0].$refs.backRef.click()
            } else if (this.$refs.we.$children[0].$children[0].$children[0].$refs.backRef) {
              this.$refs.we.$children[0].$children[0].$children[0].$refs.backRef.click()
            } else if (this.$refs.we.$refs.we.$refs.backRef) {
              this.$refs.we.$refs.we.$refs.backRef.click()
            } else if (this.$refs.we.$refs.we.$children[0].$refs.backRef) {
              this.$refs.we.$refs.we.$children[0].$refs.backRef.click()
            }
          } catch (e) {
            console.log('err：', e)
          }
        }
      }
    }
  }
}
</script>

<style>
  html, body, #app {
    height: 100%;
  }

  #app {

    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
    height: 100%;
    font-family: 'pingFangSC-Regular';
    font-weight: normal;
  }

  .slide-right-enter-active,
  .slide-right-leave-active,
  .slide-left-enter-active,
  .slide-left-leave-active {
    height: 100%;
    width: 100%;
    will-change: transform;
    transition: all 500ms;
    position: absolute;
    backface-visibility: hidden;
    perspective: 1000;
  }

  .slide-right-enter, .slide-right-enter-active {
    animation: bounce-left-in 500ms;
  }

  .slide-right-leave-active {
    animation: bounce-left-out 500ms;
  }

  .slide-left-enter, .slide-left-enter-active {
    animation: bounce-right-in 500ms;
  }

  .slide-left-leave-active {
    animation: bounce-right-out 500ms;
  }

  @keyframes bounce-right-in {
    0% {
      transform: translate3d(100%, 0, 0);
    }
    100% {
      transform: translate3d(0px, 0, 0);
    }
  }

  @keyframes bounce-right-out {
    0% {
      transform: translate3d(0, 0, 0);
    }
    100% {
      transform: translate3d(-100%, 0, 0);
    }
  }

  @keyframes bounce-left-in {
    0% {
      transform: translate3d(-100%, 0, 0);
    }
    100% {
      transform: translate3d(0px, 0, 0);
    }
  }

  @keyframes bounce-left-out {
    0% {
      transform: translate3d(0, 0, 0);
    }
    100% {
      transform: translate3d(100%, 0, 0);
    }
  }
</style>
