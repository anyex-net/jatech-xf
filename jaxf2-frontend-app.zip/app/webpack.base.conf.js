module.exports = {
  entry: {
    'babel-polyfill': 'babel-polyfill',
    app: ['babel-polyfill', './src/main.js']
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        include: [resolve('src'), resolve('test'), resolve('node_modules/webpack-dev-server/client')]
      }

    ]
  }
}
